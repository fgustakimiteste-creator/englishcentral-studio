"""Preferências locais de apresentação; nunca escolhem ações pelo usuário."""
import json
from pathlib import Path
from arquivos_locais import write_json_atomic


def read_preferences(path):
    try:
        value=json.loads(Path(path).read_text(encoding='utf-8'))
        return value if isinstance(value,dict) else {}
    except (OSError,ValueError):return {}


def set_warning_preference(path,category,show_again):
    if category not in {'video','palavras','quiz','fala','curso','ia','geral'}:category='geral'
    path=Path(path);data=read_preferences(path);data[category]=bool(show_again)
    write_json_atomic(path,data)
