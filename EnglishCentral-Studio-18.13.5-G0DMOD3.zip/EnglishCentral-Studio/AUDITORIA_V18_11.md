# Auditoria da V18.11 — aplicativo para celular

Data: 6 de novembro de 2026.
Base: distribuição limpa V18.10, com o código anterior preservado em separado durante o trabalho.

## Entrega

PWA instalável e preparação de backend remoto, mantendo o modo Windows. O pacote contém fonte, testes, documentação e implantação Docker/Caddy. Não contém uma hospedagem pública já funcionando.

## Mudanças por arquivo

| Arquivo | Responsabilidade |
| --- | --- |
| `web/index.html` | Metadados de PWA, cartão de instalação, acesso persistente opcional, API relativa ao perfil, controles de teclado e sincronização de retorno |
| `web/mobile.css` | Toque, campos de 16 px, áreas seguras, telas pequenas e organização do cartão do aplicativo |
| `web/pwa.js` | Instalação, orientações Android/iPhone e atualização por escolha, sem comandos ao motor |
| `web/sw.js` | Cache restrito a arquivos públicos e fallback de navegação para tela offline |
| `web/offline.html` | Reconexão com sondagem HEAD, timeout e retorno automático |
| `web/manifest.webmanifest`, `web/icons/` | Nome, identidade, cores existentes, janela standalone e ícones locais |
| `mobile_app.py` | Recursos públicos permitidos, configuração HTTPS, validação de origem e gateway de perfis na mesma origem |
| `servidor.py` | Integração das rotas, status do aplicativo, URLs remotas, restrição do Chrome do telefone, HEAD e início remoto sem imprimir token em logs |
| `fala_sintetica.py` | Caminho eSpeak NG/eSpeak para Linux, mantendo a SAPI Windows |
| `auto_ia.py` | Configuração remota no volume persistente da pessoa; caminho Windows preservado |
| `Dockerfile`, `deploy/` | Backend com Chromium/Xvfb, voz, proxy HTTPS, volumes e configuração de domínio |
| `acesso_servidor.py` | Exibe o link privado quando solicitado no terminal do servidor |
| `empacotar.py` | Distribuição por lista de arquivos permitidos, incluindo PWA e implantação |

Os algoritmos de `auto_fluxo.py`, `ec_engine.py`, `ec_player.py`, `course_flow.py`, `progresso.py`, `exercicio.py`, `fala_automatica.py` e `fala_preferencias.py` foram mantidos da V18.10. A correção não substitui decisões do motor por respostas prontas nem fabrica conclusão de atividades.

## Continuidade

A execução permanece no processo Python. A PWA não tenta manter um Chromium dentro do telefone ou usar o service worker como executor de atividades. Eventos de fechar, ocultar e reabrir a interface não enviam início/parada automaticamente. Ao retornar do segundo plano, a interface consulta o servidor e atualiza a prévia.

O teste integrado fechou o painel e desligou a rede do contexto de navegador que representa o telefone. O motor real concluiu os vídeos locais 101 e 102 uma vez cada. As duas unidades ficaram salvas em Vídeos e continuaram pendentes em Fala. O retorno da interface recuperou o estado sem iniciar outro trabalho.

## Sessões e acesso

O acesso continua autenticado por token. Guardar o token no armazenamento persistente do aparelho exige marcar uma opção; a sessão temporária continua sendo o padrão. As chaves de armazenamento incluem o caminho do perfil remoto, evitando misturar o acesso de duas pessoas.

O gateway usa apenas a porta registrada localmente para aquela pessoa, valida o token antes de abrir processos e não aceita um destino arbitrário fornecido pelo navegador. As respostas privadas recebem `Cache-Control: no-store`. O modo remoto exige uma origem HTTPS configurada e valida Host/origem das ações.

As sessões de Google não são copiadas do telefone. A opção de conectar um Chrome pessoal permanece no modo de computador. No modo remoto, o painel explica que a sessão pertence ao servidor.

## Cache e atualização

O cache contém somente ícones, CSS, JavaScript público, manifesto e tela offline. Não guarda APIs, capturas de navegador, tokens, progresso ou respostas autenticadas. Não cria uma fila offline de comandos.

Uma versão nova do service worker aguarda o usuário escolher atualizar. A atualização da interface não manda pausar nem recomeçar o motor.

## Voz e servidor

A SAPI Windows foi preservada. Em Linux, eSpeak produz um arquivo WAV real, validado e removido após a leitura. O texto segue pelo stdin do subprocesso, sem executar shell. O caminho mantém o microfone sintético existente.

O contêiner prepara a dependência de voz, mas sua construção não pôde ser executada aqui. O teste nativo de eSpeak ficou ignorado pela ausência dessa dependência e pelo bloqueio de acesso aos pacotes Debian. A avaliação de pronúncia em Linux ainda precisa ser feita no servidor de destino; nenhuma nota é garantida.

O volume `/data` guarda as informações das pessoas. A configuração de IA remota também usa esse volume, incluindo os processos de outros perfis. Os testes verificam que configurar uma chave fictícia em uma pessoa não configura outra.

## Validação final

- Python: 400 aprovados, 1 ignorado, 0 falhas, 2 avisos de dependências.
- Interface: 76 cenários aprovados.
- Layout: 54 combinações e 9 larguras do diálogo de curso; nenhum overflow horizontal detectado.
- PWA nativa: registro, controle, cache público, offline e reconexão confirmados no Chromium.
- Dois processos reais de perfil: tokens, políticas de fala e configuração de IA isolados.
- Prévia visível: interface real e atualização do aplicativo verificadas.
- Sintaxe, arquivos do manifesto, ícones, composição de implantação, referências locais e conteúdo do ZIP conferidos.


Na finalização de uma prévia temporária com Chromium, houve um aviso de Future do Playwright: `Connection closed while reading from the driver`. Ele apareceu após o cenário concluído e o encerramento do servidor de auditoria; os testes nativos de ciclo de sessão normal passaram. O aviso não foi ocultado e não foi tratado como uma falha durante atividades. Se aparecer no uso normal, exige investigação própria.

## Pendências para produção

1. Definir um servidor e domínio HTTPS de destino.
2. Construir a imagem, iniciar o Compose e verificar a instalação física em Android/iPhone.
3. Realizar o login Google na sessão hospedada, respeitando o fluxo aceito pelo serviço.
4. Validar a voz inglesa e a avaliação de fala naquele ambiente.

Não houve contratação, publicação, cópia de credenciais ou uso da senha compartilhada anteriormente. Os testes usaram arquivos e contas fictícias locais. Consulte [GUIA_CELULAR.md](GUIA_CELULAR.md) e [TESTES.md](TESTES.md).
