import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright,expect
from conftest import chromium_launch_options

def test_openai_dialog_opens_and_submits():
    async def run():
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(**chromium_launch_options())
            try:
                page=await browser.new_page()
                errors=[]
                page.on('pageerror', lambda e:errors.append(str(e)))
                html=(Path(__file__).resolve().parents[1]/'web/index.html').read_text('utf-8')
                stub="""<script>location.hash='#token=test-token-local-1234';window.sent=false;
                window.fetch=async(url,opts)=>{if(String(url).endsWith('/ia/openai'))window.sent=true;return new Response(JSON.stringify(String(url).endsWith('/ia/openai')?{ok:true,mensagem:'Salvo'}:{aberto:false,executando:false,modo:{},auto:{}}),{status:200})};</script>"""
                await page.set_content(html.replace('<script>',stub+'<script>',1))
                await page.get_by_role('button',name='Configurações',exact=True).click()
                await page.locator('#openAIConfig').click()
                assert await page.locator('#aiDialog').is_visible()
                await page.locator('#aiKey').fill('sk-'+'x'*30)
                await page.locator('#saveAIConfig').click()
                await page.wait_for_function('window.sent===true')
                await expect(page.locator('#aiKey')).to_have_value('')
                assert not errors,errors
            finally:
                await browser.close()
    asyncio.run(run())
