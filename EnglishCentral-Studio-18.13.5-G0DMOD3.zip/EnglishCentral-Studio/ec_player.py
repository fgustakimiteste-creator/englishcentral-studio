"""Adapter DOM do player EnglishCentral: campos por letra e progresso por etapa.

Usa somente elementos apresentados na página e eventos de teclado Playwright.
Não lê modelos Angular, respostas privadas, credenciais ou APIs de progresso.
"""
from __future__ import annotations

import re
import asyncio

class ActivityChangedError(RuntimeError):
    """A tela mudou; releia sem repetir a resposta anterior."""


class PartialAnswerError(RuntimeError):
    """A página ainda não confirmou todas as letras; Enter não foi enviado."""



INSPECT_EC_JS = r'''() => {
  const clean = (value, limit=600) => String(value ?? '').replace(/\s+/g, ' ').trim().slice(0, limit);
  // O template Angular usa attr.readonly="false". Para HTML isso torna
  // e.readOnly true, mas o handler keydown do player continua aceitando letras.
  const locked = e => e.classList.contains('bg-strong') ||
    (e.hasAttribute('readonly') && e.getAttribute('readonly').toLowerCase()!=='false');
  const shown = e => {
    if (!e || !e.isConnected) return false;
    const style=getComputedStyle(e), rect=e.getBoundingClientRect();
    return style.display!=='none' && style.visibility!=='hidden' &&
      Number(style.opacity)!==0 && rect.width>0 && rect.height>0 &&
      !e.closest('[hidden],[aria-hidden="true"]');
  };
  const visible = (selector, scope=document) => [...scope.querySelectorAll(selector)].filter(shown);
  const allPlayers=[...document.querySelectorAll('ec-player-app')];
  const players=allPlayers.filter(shown);
  const player=players.length===1 ? players[0] : null;
  const activity=player?.closest('ec-activity-app') || player;
  const buttons=visible('ec-activity-list [data-testid="player-activity-button"]',activity || document);
  const button=kind => buttons.find(e=>e.classList.contains('activity-list-'+kind));
  const active=['watch','learn','speak','chat'].filter(kind=>button(kind)?.classList.contains('active'));
  let mode=active.length===1 ? active[0] : 'unknown';
  const wrap=player?.querySelector('#activity-app-container');
  if(mode==='unknown' && wrap){
    if(wrap.classList.contains('learn-mode')) mode='learn';
    else if(wrap.classList.contains('speak-mode')) mode='speak';
    else if(wrap.classList.contains('watch-mode')) mode='watch';
  }
  const videos=visible('ec-video video,video',player || document);
  const video=videos.length===1 ? videos[0] : null;
  const videoSource=video?.getAttribute('src') || video?.currentSrc || '';
  const idMatch=videoSource.match(/\/dialogs\/(\d+)\//) || (video?.id || '').match(/(?:dialog-|dialog_)(\d+)/);
  const titleNodes=visible('.dialog-title,.player-title,.activity-title,.video-title,.player-app-title', activity || document);
  const title=clean(titleNodes[0]?.innerText || document.title, 180);
  let lessonId=idMatch ? 'dialog:'+idMatch[1] : '';
  if(!lessonId && videoSource){
    try {const source=new URL(videoSource,location.href); lessonId='video:'+source.origin+source.pathname;} catch(e) {}
  }
  // O título do curso sozinho nunca distingue suas 32 aulas.
  if(!lessonId && titleNodes.length===1 && title) lessonId='title:'+title;
  const allRoots=player ? [...player.querySelectorAll('ec-player-word-input')] : [];
  const roots=allRoots.filter(shown);
  const withInputs=roots.filter(e=>visible('input.char-input',e).length);
  const focused=withInputs.filter(e=>!!e.querySelector('input.char-input.focused') || e.contains(document.activeElement));
  const editable=withInputs.filter(e=>visible('input.char-input',e).some(i=>!locked(i) && !i.disabled && !i.classList.contains('space') && !i.classList.contains('special')));
  const target=focused.length===1 ? focused[0] : editable.length===1 ? editable[0] : withInputs.length===1 ? withInputs[0] : null;
  const allInputs=target ? [...target.querySelectorAll('input.char-input')] : [];
  const letterSlots=allInputs.map((e,index)=>({index,value:clean(e.value,2),readonly:locked(e),disabled:!!e.disabled,
    shown:shown(e),space:e.classList.contains('space'),special:e.classList.contains('special')}))
    .filter(e=>e.shown && !e.space && !e.special);
  const inputRootIndex=target ? allRoots.indexOf(target) : -1;
  const row=target?.closest('.player-transcript-row') || target?.closest('.player-transcript-container') || target?.closest('ec-player-transcript');
  const render = node => {
    if(node===target) return ' ____ ';
    if(node.nodeType===Node.TEXT_NODE) return node.textContent || '';
    if(node.nodeType!==Node.ELEMENT_NODE || !shown(node)) return '';
    if(node.matches('ec-word-definition,.player-transcript-translation,.type-the-missing-word,ngb-tooltip-window')) return '';
    if(node.matches('input')) return node.value || '';
    return [...node.childNodes].map(render).join(' ');
  };
  const speechShown=e=>{
    if(!shown(e))return false;
    for(let ancestor=e;ancestor;ancestor=ancestor.parentElement){
      const style=getComputedStyle(ancestor);
      if(style.display==='none'||style.visibility==='hidden'||style.visibility==='collapse'||Number(style.opacity)===0||
         ancestor.hidden||ancestor.getAttribute('aria-hidden')==='true')return false;
    }
    return true;
  };
  const speechVisible=(selector,scope=document)=>[...scope.querySelectorAll(selector)].filter(speechShown);
  const transcriptRows=speechVisible('.player-transcript-row',activity || document);
  const activeRows=transcriptRows.filter(e=>['active','current','selected','playing'].some(token=>e.classList.contains(token)) ||
    e.getAttribute('aria-current')==='true' || e.getAttribute('aria-selected')==='true');
  const speakRow=activeRows.length===1 ? activeRows[0] : transcriptRows.length===1 ? transcriptRows[0] : null;
  const speakPromptFull=speakRow ? String(render(speakRow)).replace(/\s+/g,' ').trim() : '';
  const speakPrompt=clean(speakPromptFull,2000);
  const selectedLineBars=player ? speechVisible('.seek-bar[dialog-line-id]',player)
    .filter(e=>!!e.querySelector('.seek-bar-selected-circle')) : [];
  const speakLineId=speakRow?.getAttribute('dialog-line-id') || speakRow?.getAttribute('data-line-id') ||
    (selectedLineBars.length===1 ? selectedLineBars[0].getAttribute('dialog-line-id') : '') || '';
  const usable=e=>speechShown(e) && !e.disabled && e.getAttribute('aria-disabled')!=='true' &&
    !e.classList.contains('disabled') && !e.closest('[disabled],[aria-disabled="true"],.disabled');
  const normal=value=>clean(value,200).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
  const speakInterstitials=activity ? speechVisible('ec-speak-interstitial',activity) : [];
  const speakSelection=speakInterstitials.length===1 ? speakInterstitials[0] : null;
  const selectionText=clean(speakSelection?.innerText,1000);
  const selectedCount=selectionText.match(/(?:linhas?\s+selecionadas?|selected\s+lines?)\s*:\s*(\d+)/i);
  const speakFooters=speakSelection ? speechVisible('.footer-button,[data-testid="player-start-speaking"]',speakSelection)
    .filter(e=>usable(e)&&/^(?:falar|speak)\s+[1-9]\d{0,2}\s+(?:linhas?|lines?)$/i.test(clean(e.innerText))) : [];
  const footerCount=speakFooters[0]?.innerText.match(/\d+/);
  const speakSelectionCount=selectedCount ? Number(selectedCount[1]) : footerCount ? Number(footerCount[0]) : 0;
  const selectAllMatches=speakSelection ? speechVisible('button,[role="button"],a,div,span',speakSelection)
    .filter(e=>usable(e)&&/^(?:selecionar\s+todas(?:\s+as\s+linhas)?|todas\s+as\s+linhas|select\s+all(?:\s+lines)?)$/i.test(clean(e.innerText))) : [];
  const selectAllLeaves=selectAllMatches.filter(e=>!selectAllMatches.some(child=>child!==e&&e.contains(child)));
  const speakModes=player ? speechVisible('ec-speak-mode',player) : [];
  const speakScope=speakModes.length===1 ? speakModes[0] : player;
  const recordControls=speakScope ? speechVisible('[data-testid="player-record"],#mic-is-ready.record-control',speakScope).filter(usable) : [];
  const stopControls=speakScope ? speechVisible('[data-testid="player-stop-recording"],#mic-is-recording.record-control',speakScope).filter(usable) : [];
  const recordingMarks=speakScope ? speechVisible('[data-testid="player-recording-indicator"],.record-control.recording',speakScope) : [];
  const speakRecording=recordingMarks.length>0 || stopControls.length===1;
  const processingMarks=speakScope ? speechVisible('[data-testid="player-recording-processing"],.speech-processing',speakScope) : [];
  const speechFeedback=speakScope ? speechVisible('ec-speech-feedback,[data-testid="player-recording-result"],.speak-result',speakScope)
    .filter(e=>clean(e.innerText,600).length>0) : [];
  const feedbackLeaves=speechFeedback.filter(e=>!speechFeedback.some(child=>child!==e&&e.contains(child)));
  const speakResult=clean(feedbackLeaves.map(e=>e.innerText).join(' '),1000);
  // A nota deve vir do resultado desta linha, nunca da legenda ou do curso.
  const scoreNodes=speakScope ? speechVisible('[data-testid="player-speech-score"],.pronunciation-score,.speech-score,.overall-score',speakScope) : [];
  const scoreValues=[];
  const addScore=value=>{if(value!==null&&value!==''&&Number.isFinite(Number(value))&&Number(value)>=0&&Number(value)<=100)scoreValues.push(Number(value))};
  for(const node of [...scoreNodes,...feedbackLeaves]){
    const attr=node.getAttribute('data-score') ?? node.getAttribute('data-pronunciation-score') ?? node.getAttribute('aria-valuenow');
    if(attr!==null)addScore(attr);
  }
  const scoreText=scoreNodes.length ? scoreNodes.map(e=>e.innerText).join(' ') : speakResult;
  for(const match of scoreText.matchAll(/(?:^|[^\d.,])(\d{1,3}(?:[.,]\d+)?)\s*%/g))addScore(match[1].replace(',','.'));
  const uniqueScores=[...new Set(scoreValues)];
  const speakScore=uniqueScores.length===1 ? uniqueScores[0] : null;
  const selectedBar=selectedLineBars.length===1 ? selectedLineBars[0] : null;
  const lineStatus=selectedBar ? normal([selectedBar.getAttribute('aria-label'),selectedBar.getAttribute('title'),
    selectedBar.getAttribute('data-status')].join(' ')).replace(/[_-]/g,' ') : '';
  const lineNegative=!!selectedBar&&(selectedBar.getAttribute('data-completed')==='false'||
    /\b(?:not|nao|incomplete|pending|incorrect|failed|pendente|incorreto|incorreta)\b/.test(lineStatus)||
    speechVisible('.fa-times',selectedBar).length>0);
  const selectedBarComplete=mode==='speak'&&!!selectedBar&&!lineNegative&&speechVisible('.fa-check',selectedBar).length>0;
  const speakLineComplete=!lineNegative&&(selectedBarComplete||!!speakRow?.classList.contains('completed') || feedbackLeaves.some(e=>
    /^(?:accepted|completed?|success)$/i.test(e.getAttribute('data-status')||'') ||
    e.classList.contains('accepted') || e.classList.contains('success')) ||
    /^(?:pron[uú]ncia\s+registrada|recording\s+accepted|line\s+completed?)\b/i.test(speakResult));
  const nextControls=speakScope ? speechVisible('[data-testid="player-next-line"],[data-testid="player-skip-line"],.mic-next-line-button,.continue-button,button,[role="button"]',speakScope)
    .filter(e=>usable(e)&&(/^(?:proxima\s+(?:linha|frase)|next\s+(?:line|sentence)|continuar|continue|pular(?:\s+linha)?|skip(?:\s+line)?|avancar)$/.test(normal(e.innerText)) ||
      ['player-next-line','player-skip-line'].includes(e.getAttribute('data-testid'))||e.classList.contains('mic-next-line-button'))) : [];
  const speakPhase=speakSelection ? 'selection' : speakRecording ? 'recording' : processingMarks.length ? 'processing' :
    speakResult ? 'result' : recordControls.length===1 ? 'ready' : 'unknown';
  const phrase=row ? clean(render(row),700) : '';
  const questionIndex=target && row ? [...row.querySelectorAll('ec-player-word-input')].indexOf(target) : -1;
  const correct=visible('.correct-answer-tooltip .continue-button').length===1;
  const definitionWords=visible('ec-word-definition .word[lang="en"] > .me-1');
  const correction=definitionWords.length===1 ? clean(definitionWords[0].innerText,100) : '';
  const retryCTA=visible('ec-word-definition .cta-buttons .button').filter(e=>/^(?:tentar\s+novamente|try\s+again)$/i.test(clean(e.innerText)));
  const retryIcons=visible('.incorrect-answer-tooltip .retry-icon');
  const continueCTA=visible('ec-word-definition .cta-buttons .button').filter(e=>/^(?:continuar|continue)$/i.test(clean(e.innerText)));
  const incorrect=retryCTA.length>0 || retryIcons.length>0 || visible('.incorrect-answer-tooltip').length>0;
  const selection=visible('ec-learn-interstitial');
  const starters=selection.flatMap(e=>visible('.footer-button',e)).filter(e=>!e.disabled && e.getAttribute('aria-disabled')!=='true' &&
    /^(?:aprenda\s+\d+\s+palavras?|comece\s+a\s+aprender|learn\s+\d+\s+words?|start\s+learning)$/i.test(clean(e.innerText)));
  const selectedWords=selection.flatMap(e=>visible('.orthography-text,.word-label,.selected-word,.word .label,.word-text',e)).map(e=>clean(e.innerText,50))
    .filter(t=>/^[a-z][a-z' -]{1,49}$/i.test(t)).slice(0,80);
  const supported=!!player && (!!buttons.length || !!wrap || !!withInputs.length);
  const question=!!target && letterSlots.length>0 && (mode==='learn' || mode==='unknown') && !selection.length;
  const signature=question ? [lessonId,phrase,questionIndex,letterSlots.length].join('|') : '';
  const watch=button('watch');
  const watchMeta=watch ? [watch.className,watch.getAttribute('data-status'),watch.getAttribute('aria-label'),watch.title,watch.innerText].join(' ') : '';
  const normalizedWatchMeta=watchMeta.normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[_-]/g,' ');
  const watchPending=!!watch && (watch.getAttribute('data-completed')==='false' ||
    /\b(?:incomplete|pending|not|nao|pendente|unfinished)\b/i.test(normalizedWatchMeta));
  const watchSources=[];
  if(watch && !watchPending){
    if(['completed','complete','watched','done','finished'].some(c=>watch.classList.contains(c)))watchSources.push('controle-concluido');
    if(watch.getAttribute('data-completed')==='true')watchSources.push('data-completed');
    if(/^(?:completed?|done|watched|finished)$/i.test(watch.getAttribute('data-status')||''))watchSources.push('data-status');
    if(/\b(?:completed?|watched|finished|done)\b|conclu[ií]d[oa]|assistid[oa]/i.test([watch.getAttribute('aria-label'),watch.title].join(' ')))watchSources.push('rotulo-concluido');
    if(visible('.activity-progress-indicator .inner.completed',watch).length)watchSources.push('progresso-concluido');
    if(visible('.points-icon-wrap .fa-check',watch).length)watchSources.push('confirmacao-assistir');
  }
  const watchComplete=watchSources.length>0;
  const bar=watch?.querySelector('.activity-progress-indicator .inner,[role="progressbar"],.progress-bar');
  const barPercent=bar ? Number.parseFloat(bar.getAttribute('aria-valuenow') || bar.style.width || '') : NaN;
  const color=bar ? getComputedStyle(bar).backgroundColor.match(/[\d.]+/g)?.map(Number) : null;
  const barGreen=!!color && color[1]>color[0]*1.25 && color[1]>color[2]*.9;
  const lines=player ? visible('.seek-bar[dialog-line-id]',player) : [];
  const registered=line=>!!line.querySelector('.fa-check') || line.classList.contains('completed') || line.getAttribute('data-completed')==='true';
  const lineIds=lines.filter(line=>!registered(line)).map(line=>line.getAttribute('dialog-line-id')).filter(id=>/^\d+$/.test(id||''));
  // Leia as cores renderizadas somente na barra segmentada do vídeo.
  // Cor é evidência de contagem, nunca confirmação de conclusão da etapa.
  const tone=value=>{
    const c=String(value).match(/[\d.]+/g)?.map(Number);
    if(!c||c.length<3||(c.length>3&&c[3]<0.3))return 'unknown';
    const [r,g,b]=c;
    if(r>=130&&g>=90&&r>b*1.35&&g>b*1.2)return 'yellow';
    if(g>=60&&g>r*1.15&&g>=b*.85)return 'green';
    if(Math.min(r,g,b)>=160&&Math.max(r,g,b)-Math.min(r,g,b)<=30)return 'white';
    return 'unknown';
  };
  const visualLines=mode==='watch'?lines.map(line=>{
    const rect=line.getBoundingClientRect(),samples=Array(128).fill('unknown');
    const nodes=[line,...line.querySelectorAll('*')].filter(e=>speechShown(e)&&
      !e.closest('.seek-bar-selected-circle,.fa-check,[role="tooltip"]')&&
      !/(?:circle|handle|thumb)/i.test(String(e.className)));
    for(const node of nodes){
      const box=node.getBoundingClientRect(),style=getComputedStyle(node);
      const components=style.backgroundColor.match(/[\d.]+/g)?.map(Number);
      const gradient=style.backgroundImage!=='none';
      if(box.height<rect.height*.45||(!gradient&&(!components||(components.length>3&&components[3]<.3))))continue;
      const kind=gradient?'unknown':tone(style.backgroundColor);
      const left=Math.max(rect.left,box.left),right=Math.min(rect.right,box.right);
      // Pinte na ordem DOM: um fundo branco coberto por azul não está branco.
      for(let i=0;i<samples.length;i++){
        const x=rect.left+rect.width*(i+.5)/samples.length;
        if(x>=left&&x<right)samples[i]=kind;
      }
    }
    const green=Math.round(samples.filter(c=>c==='green').length/samples.length*100);
    const yellow=Math.round(samples.filter(c=>c==='yellow').length/samples.length*100);
    const white=samples.every(c=>c==='white');
    const active=!![...line.querySelectorAll('.seek-bar-selected-circle')].find(speechShown)||
      ['active','current','playing'].some(c=>line.classList.contains(c))||line.getAttribute('aria-current')==='true';
    return {id:line.getAttribute('dialog-line-id'),green,yellow,white,active,
      state:yellow>0?'yellow':green>0?'green':white?'white':'unknown'};
  }):[];
  const activeVisual=visualLines.filter(line=>line.active);
  const recognized=visualLines.filter(line=>line.state!=='unknown');
  const visualState=activeVisual.length===1?activeVisual[0].state:
    visualLines.some(line=>line.yellow>0)?'yellow':visualLines.some(line=>line.green>0)?'green':
    recognized.length===visualLines.length&&recognized.length>0?'white':'unknown';
  const tracking={confirmed:watchComplete,sources:watchSources,pending:watchPending,
    bar_percent:Number.isFinite(barPercent)?barPercent:null,bar_green:barGreen,
    lines_total:lines.length,lines_done:lines.filter(registered).length,pending_line_ids:lineIds,
    visual_supported:visualState!=='unknown',visual_state:visualState,
    active_line_id:activeVisual.length===1?activeVisual[0].id:null,
    visual_signature:visualLines.map(line=>[line.id,line.green,line.yellow].join(':')).join('|'),
    visual_lines:visualLines,green_lines:visualLines.filter(line=>line.green>0).length,
    yellow_lines:visualLines.filter(line=>line.yellow>0).length};
  const chatComplete=!!button('chat')?.classList.contains('completed');
  return {supported,player_index:allPlayers.indexOf(player),lesson_id:lessonId,title,mode,watch_complete:watchComplete,
    learn_complete:!!button('learn')?.classList.contains('completed'),speak_complete:!!button('speak')?.classList.contains('completed'),
    chat_complete:chatComplete,word_selection:selection.length===1,
    start_words:starters.length===1,question,phrase,question_id:signature,question_index:questionIndex,
    input_root_index:inputRootIndex,answer_length:letterSlots.length,input_count:allInputs.length,
    values:letterSlots.map(e=>e.value),letter_slots:letterSlots,correct,incorrect,correction,
    speak_prompt:speakPrompt,speak_prompt_length:speakPromptFull.length,speak_prompt_truncated:speakPromptFull.length>2000,
    speak_line_id:speakLineId,speak_phase:speakPhase,speak_recording:speakRecording,
    speak_line_complete:speakLineComplete,speak_result:speakResult,speak_score:speakScore,
    speak_result_accepted:speakLineComplete,
    speak_next_ready:(speakLineComplete||!!speakResult)&&nextControls.length===1,
    speak_selection_count:speakSelectionCount,speak_selection_ready:speakFooters.length===1&&speakSelectionCount>0,
    speak_select_all_ready:selectAllLeaves.length===1,speak_can_record:recordControls.length===1,
    speak_can_stop:stopControls.length===1,
    watch_tracking:tracking,page_visible:document.visibilityState==='visible',
    continue_ready:correct || continueCTA.length===1,retry_ready:retryCTA.length===1 || retryIcons.length===1,
    learn_finished:visible('.learn-complete-msg').length>0,definition_open:definitionWords.length>0,
    context_words:[...new Set(selectedWords)],ambiguous_inputs:!!withInputs.length && !target,
    ambiguous_videos:videos.length>1,
    video:video ? {paused:!!video.paused,ended:!!video.ended,position:video.currentTime || 0,
      duration:Number.isFinite(video.duration)?video.duration:null,ready_state:video.readyState,
      network_state:video.networkState,seeking:video.seeking,playback_rate:video.playbackRate,
      error:video.error?{code:video.error.code,message:clean(video.error.message,180)}:null} : null};
}'''


async def inspect_ec_player(page) -> dict:
    """Lê uma instância inequívoca do player em até 15 frames."""
    found=[]
    for index, frame in enumerate(page.frames[:15]):
        try:
            snapshot=await frame.evaluate(INSPECT_EC_JS)
        except Exception:
            continue
        if snapshot.get('supported'):
            snapshot['frame']=index
            found.append(snapshot)
    if len(found)==1:
        return found[0]
    return {'supported':False,'frame':0,'ambiguous_players':len(found)>1}


def _frame(page, index):
    if not isinstance(index,int) or not 0 <= index < len(page.frames):
        raise RuntimeError('O frame da atividade mudou; observe a página novamente.')
    return page.frames[index]


async def _visible_locators(locator):
    matches=[]
    for index in range(min(await locator.count(),80)):
        item=locator.nth(index)
        if await item.is_visible() and await item.is_enabled():
            # is_visible não exclui aria-hidden no ancestral.
            if await item.evaluate('(e)=>!e.closest("[hidden],[aria-hidden=\\"true\\"]") && Number(getComputedStyle(e).opacity)!==0'):
                matches.append(item)
    return matches


async def click_ec_control(page, action: str) -> dict | None:
    """Clica apenas no controle conhecido, visível e sem ambiguidade do player."""
    snapshot=await inspect_ec_player(page)
    if not snapshot.get('supported'):
        return None
    frame=_frame(page,snapshot['frame'])
    selectors={
        'watch':'ec-activity-list [data-testid="player-activity-button"].activity-list-watch',
        'learn':'ec-activity-list [data-testid="player-activity-button"].activity-list-learn',
        'speak':'ec-activity-list [data-testid="player-activity-button"].activity-list-speak',
        'chat':'ec-activity-list [data-testid="player-activity-button"].activity-list-chat',
        'start_words':'ec-learn-interstitial .footer-button',
        'continue':'.correct-answer-tooltip .continue-button',
        'retry':'ec-word-definition .cta-buttons .button',
    }
    if action not in selectors:
        raise ValueError('Controle da atividade não permitido.')
    matches=await _visible_locators(frame.locator(selectors[action]))
    if action=='start_words':
        matches=[item for item in matches if re.fullmatch(r'(?:aprenda\s+\d+\s+palavras?|comece\s+a\s+aprender|learn\s+\d+\s+words?|start\s+learning)',(await item.inner_text()).strip(),re.I)]
    if action=='retry':
        matches=[item for item in matches if re.fullmatch(r'(?:tentar\s+novamente|try\s+again)',(await item.inner_text()).strip(),re.I)]
        if not matches:
            matches=await _visible_locators(frame.locator('.incorrect-answer-tooltip .retry-icon'))
    if action=='continue' and not matches:
        matches=await _visible_locators(frame.locator('ec-word-definition .cta-buttons .button'))
        matches=[item for item in matches if re.fullmatch(r'(?:continuar|continue)',(await item.inner_text()).strip(),re.I)]
    if len(matches)!=1:
        return None
    target=matches[0]
    await target.scroll_into_view_if_needed(timeout=4000)
    box=await target.bounding_box()
    await target.click(timeout=5000)
    return {'x':round(box['x']+box['width']/2),'y':round(box['y']+box['height']/2),
            'acao':action,'texto':{'watch':'Abri Assistir ao vídeo.','learn':'Abri Aprender as palavras.',
              'speak':'Abri Fale as linhas para preparar a gravação automática.',
              'chat':'Abri Converse sobre o vídeo (MiMi).',
              'start_words':'Iniciei o exercício de palavras.','continue':'Continuei para a próxima palavra.',
              'retry':'Fechei a correção e preparei uma nova tentativa.'}[action]} if box else {'acao':action}


async def type_ec_answer(page, snapshot: dict, answer: str, *, enter: bool=True) -> dict:
    """Digita eventos reais por letra; nunca usa fill no input maxlength=1."""
    if not isinstance(answer,str) or not re.fullmatch(r"[A-Za-z]+(?:[ '\u2019-][A-Za-z]+)*",answer.strip()):
        raise ValueError('Resposta deve ser uma palavra ou expressão curta em inglês.')
    letters=re.sub(r'[^A-Za-z]','',answer).lower()
    current=await inspect_ec_player(page)
    if not current.get('supported') or not current.get('question'):
        raise ActivityChangedError('A lacuna já mudou ou não está aberta.')
    if not current.get('lesson_id') or current.get('lesson_id')!=snapshot.get('lesson_id') or current.get('question_id')!=snapshot.get('question_id'):
        raise ActivityChangedError('A aula ou a frase mudou antes da digitação.')
    if current.get('definition_open') or current.get('incorrect'):
        raise RuntimeError('Feche a correção com Tentar Novamente antes de digitar.')
    if current.get('correct'):
        return {'acao':'conferencia','texto':'A palavra já foi aceita; nenhuma digitação repetida.'}
    slots=current.get('letter_slots',[])
    if len(letters)!=len(slots):
        raise ValueError(f'A palavra tem {len(letters)} letras, mas a lacuna apresenta {len(slots)}.')
    for slot,letter in zip(slots,letters):
        if slot['readonly'] and slot['value'].casefold()!=letter:
            raise ValueError('A resposta não combina com a letra que a plataforma já mostrou.')
        if slot['disabled']:
            raise RuntimeError('O campo de letra está desabilitado.')
    frame=_frame(page,current['frame'])
    root=frame.locator('ec-player-app').nth(current['player_index']).locator('ec-player-word-input').nth(current['input_root_index'])
    fields=root.locator('input.char-input')
    first_box=None
    for slot,letter in zip(slots,letters):
        if slot['readonly']:
            continue
        # Cada press envia keydown/keyup e dá ao Angular a chance de atualizar foco.
        target=fields.nth(slot['index'])
        # Uma leitura por letra reúne visibilidade, bloqueio e posição.
        # Continua revalidando o campo antes de cada tecla, sem usar dados antigos.
        field = await target.evaluate("""e => {
            const r=e.getBoundingClientRect(),s=getComputedStyle(e);
            const attr=e.getAttribute('readonly');
            return {visible:r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden',
                readonly:attr!==null&&attr.toLowerCase()!=='false', disabled:e.disabled,
                value:e.value, box:{x:r.x,y:r.y,width:r.width,height:r.height}};
        }""", timeout=4000)
        if not field['visible']:
            raise RuntimeError('O campo de letra mudou durante a digitação.')
        if field['disabled']:
            raise RuntimeError('O campo de letra está desabilitado.')
        if field['readonly']:
            if field['value'].casefold()==letter:
                continue
            raise RuntimeError('A plataforma bloqueou uma letra durante a digitação.')
        if first_box is None:
            first_box=field['box']
        # press já foca o input. Click propagaria ao ecLaunchWordDefinition
        # ancestral e pode abrir o dicionário no meio da resposta.
        # Reescreva todo slot editável na ordem: o handler mantém currentIndex
        # próprio e precisa receber a sequência, mesmo se houver texto parcial.
        await target.press(letter,timeout=4000)
    observed=await inspect_ec_player(page)
    # Angular pode limpar os inputs enquanto prepara feedback/novo trecho.
    # Aguarde apenas observando, sem reenviar letras nem Enter.
    for _ in range(8):
        same_question = observed.get('lesson_id') == current['lesson_id'] and observed.get('question_id') == current['question_id']
        received = ''.join(str(slot.get('value', '')) for slot in observed.get('letter_slots', []))
        if not same_question or observed.get('correct') or observed.get('incorrect') or observed.get('definition_open') or received.casefold() == letters:
            break
        await asyncio.sleep(0.2)
        observed = await inspect_ec_player(page)
    same=observed.get('lesson_id')==current['lesson_id'] and observed.get('question_id')==current['question_id']
    if not same:
        raise ActivityChangedError('A frase mudou durante a digitação; nenhuma confirmação adicional foi enviada.')
    if not observed.get('correct') and not observed.get('incorrect') and not observed.get('definition_open'):
        received = ''.join(str(slot.get('value', '')) for slot in observed.get('letter_slots', []))
        if received.casefold() != letters:
            raise PartialAnswerError(f'O jogo recebeu {len(received)} de {len(letters)} letras; a resposta parcial não foi enviada.')
    # A última letra correta pode validar automaticamente. Enter nesse ponto
    # já significaria Continuar, portanto só confirma uma resposta ainda pendente.
    sent_enter=False
    if enter and not observed.get('correct') and not observed.get('incorrect') and not observed.get('definition_open'):
        target=fields.nth(next((slot['index'] for slot in reversed(slots) if not slot['readonly']),slots[-1]['index']))
        await target.press('Enter',timeout=4000)
        sent_enter=True
    pointer={'acao':'digitacao','texto':'Resposta digitada letra por letra.'+(' Enter enviado.' if sent_enter else ''),
             'enter_enviado':sent_enter}
    if first_box:
        pointer.update(x=round(first_box['x']+first_box['width']/2),y=round(first_box['y']+first_box['height']/2))
    return pointer
