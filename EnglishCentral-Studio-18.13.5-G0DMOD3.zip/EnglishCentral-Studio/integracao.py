"""Inspeção do DOM e ações explícitas de estudo, sem marcação de conclusão.

Não depende de seletores internos não documentados do EnglishCentral. Funciona em
interfaces HTML usuais e reporta quando a página não expõe elementos acessíveis.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any
from urllib.parse import urlparse


# Executado dentro de cada frame da página. Não lê senhas, tokens ou cookies.
INSPECT_JS = r"""() => {
  const clean = (v, limit=650) => String(v ?? '').replace(/\s+/g, ' ').trim().slice(0, limit);
  const displayed = e => {
    const s = getComputedStyle(e), r = e.getBoundingClientRect();
    return s.display !== 'none' && s.visibility !== 'hidden' &&
      Number(s.opacity) !== 0 && r.width > 0 && r.height > 0 &&
      !e.closest('[hidden],[aria-hidden="true"]');
  };
  const blocked = e => {
    const t = (e.getAttribute('type') || '').toLowerCase();
    const meta = [e.name, e.id, e.getAttribute('autocomplete'),e.getAttribute('aria-label'),e.placeholder].join(' ').toLowerCase();
    return ['password','email','tel','hidden','file','submit','button','checkbox','radio'].includes(t) ||
      /passw|senha|email|e-mail|login|token|otp|one.time|c[oó]digo de verifica|credit.card|cart[aã]o/.test(meta);
  };
  const fields = [];
  const targets = document.querySelectorAll('input,textarea,[contenteditable="true"]');
  for (const e of targets) {
    if (fields.length >= 32) break;
    if (blocked(e) || !displayed(e) || e.disabled || e.readOnly) continue;
    const id = String(fields.length + 1);
    e.setAttribute('data-ec-assist-id',id);
    const parent = e.closest('label,[role="group"],fieldset') || e.parentElement;
    const nearby = clean(parent?.innerText || e.parentElement?.parentElement?.innerText || '');
    const placeholder = clean(e.placeholder || '');
    const label = clean(e.getAttribute('aria-label') || e.labels?.[0]?.innerText || '');
    fields.push({id,label,placeholder,contexto:nearby, tipo:e.tagName.toLowerCase(),
      preenchido: !!(e.value || e.textContent?.trim()),
      dica: /_{2,}|\[\s*\]|\.\.\.|fill|blank|lacuna|missing|complete|complete a/i.test([nearby,label,placeholder].join(' '))});
  }
  const videos = [...document.querySelectorAll('video')].filter(displayed).slice(0,12).map((v,index) => {
    v.setAttribute('data-ec-video-id',String(index+1));
    return {id: String(index+1), reproduzindo: !v.paused && !v.ended,
    duracao: Number.isFinite(v.duration) ? v.duration : null,
    posicao: v.currentTime || 0, concluidoNoPlayer:!!v.ended,
    pronto:v.readyState,rede:v.networkState,
    origem:String(v.currentSrc||v.getAttribute('src')||'').slice(0,900),
    erro:v.error ? {code:v.error.code,message:String(v.error.message||'').slice(0,240)} : null
  };});
  const audio = [...document.querySelectorAll('audio,[aria-label*="record" i],[aria-label*="microphone" i],[aria-label*="gravar" i]')].filter(displayed).length;
  // Somente o controle de Assistir pode confirmar essa etapa. HTML de um
  // ancestral incluiria o estado de Aprender/Falar e até a palavra incomplete.
  const namedWatch = e => /^(?:assista ao v[ií]deo|assistir ao v[ií]deo|watch the video)$/i.test(clean(e.innerText,80));
  const knownWatch = [...document.querySelectorAll('ec-activity-list [data-testid="player-activity-button"].activity-list-watch')].filter(displayed);
  const labels = [...document.querySelectorAll('button,a,[role="button"],span,p,div')].filter(e=>displayed(e)&&namedWatch(e));
  const genericWatch = [...new Set(labels.map(e=>e.closest('button,a,[role="button"]')||e))]
    .filter(e=>displayed(e)&&namedWatch(e));
  const watchControls = knownWatch.length ? knownWatch : genericWatch;
  const normal = value => String(value||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
  const completeWatch = e => {
    const status=normal([e.className,e.getAttribute('aria-label'),e.getAttribute('title'),
      e.getAttribute('data-status'),e.getAttribute('data-state')].join(' '));
    if(e.getAttribute('data-completed')==='false' || /\b(?:not|nao|unfinished)\b/.test(status.replace(/[_-]/g,' ')) ||
       /(?:^|[\s:_-])(?:incomplete|pending|pendente|not[\s_-]+(?:complete[d]?|done)|nao[\s_-]+concluid[oa])(?:$|[\s:_-])/.test(status))return false;
    return e.getAttribute('data-completed')==='true' ||
      /(?:^|[\s:_-])(?:completed?|done|is-complete|concluid[oa]|success)(?:$|[\s:_-])/.test(status) ||
      [...e.querySelectorAll('.activity-progress-indicator .inner.completed,.points-icon-wrap .fa-check')].some(displayed);
  };
  const videoStepCompleted = watchControls.length===1 && completeWatch(watchControls[0]);
  const text = clean(document.body?.innerText || '', 4500);
  const login = [...document.querySelectorAll('input[type="password"]')].some(displayed);
  return {titulo:clean(document.title),texto:text,campos:fields,videos,audioDetectado:audio>0,loginDetectado:login,videoStepCompleted,
    paginaVisivel:document.visibilityState==='visible'};
}"""


async def inspect_page(page) -> dict[str, Any]:
    """Coleta indicadores DOM por frame, inclusive iframes acessíveis pelo Playwright."""
    frames_out: list[dict[str, Any]] = []
    problems: list[str] = []
    for fi, frame in enumerate(page.frames[:15]):
        try:
            info = await frame.evaluate(INSPECT_JS)
            info['frame'] = fi
            info['url'] = frame.url[:350]
            frames_out.append(info)
        except Exception as exc:
            problems.append(f'Frame {fi}: {type(exc).__name__} (indisponível)')
    fields = [{**f,'frame':fr['frame']} for fr in frames_out for f in fr['campos']]
    videos = [{**v,'frame':fr['frame']} for fr in frames_out for v in fr['videos']]
    text = '\n'.join(fr['texto'] for fr in frames_out if fr['texto'])[:6000]
    return {
        'url':page.url[:500], 'titulo':(await page.title())[:160],
        'horario': datetime.now(timezone.utc).isoformat(),
        'campos':fields,'videos':videos,
        'audioIgnorado': any(fr['audioDetectado'] for fr in frames_out),
        'videoEtapaConcluida': any(fr.get('videoStepCompleted') for fr in frames_out),
        'paginaVisivel': next((fr['paginaVisivel'] for fr in frames_out if fr['frame'] == 0), False),
        'loginDetectado':any(fr['loginDetectado'] for fr in frames_out),
        'textoVisivel':text,
        'avisos':problems,
        'interpretacao':'Observação local do DOM; não é certificado de conclusão de aula.',
    }


async def fill_selected(page, frame_number: int, field_id: str, value: str) -> None:
    """Preenche somente um campo escolhido. Nunca clica em enviar/verificar."""
    if not (0 <= frame_number < len(page.frames)):
        raise ValueError('Frame não encontrado; atualize a inspeção.')
    frame = page.frames[frame_number]
    locator = frame.locator(f'[data-ec-assist-id="{field_id}"]')
    if await locator.count() != 1 or not await locator.is_visible():
        raise ValueError('Campo mudou ou desapareceu. Analise a atividade novamente.')
    element_type = await locator.evaluate('(e) => (e.getAttribute("type") || "text").toLowerCase()')
    if element_type in {'password','email','hidden','file'}:
        raise ValueError('Campo não permitido.')
    await locator.fill(value, timeout=7000)


async def toggle_video(page, frame_number: int, video_id: str, mode: str) -> dict:
    """Usa o controle oficial no EnglishCentral; nunca altera tempo ou progresso."""
    if mode not in {'play', 'pause'}:
        raise ValueError('Ação não permitida.')
    if not (0 <= frame_number < len(page.frames)):
        raise ValueError('Frame do vídeo não encontrado.')
    frame = page.frames[frame_number]
    if not video_id.isdigit() or int(video_id) < 1:
        raise ValueError('Identificador do vídeo inválido.')
    loc = frame.locator(f'video[data-ec-video-id="{video_id}"]')
    if await loc.count() != 1 or not await loc.is_visible():
        raise ValueError('Player não acessível; use os controles na captura da página.')
    state = await loc.evaluate('v => ({paused:!!v.paused,ended:!!v.ended,reproduzindo:!v.paused&&!v.ended})')
    if (mode == 'play' and state['reproduzindo']) or (mode == 'pause' and state['paused']):
        return {'reproduzindo': state['reproduzindo'], 'controle': 'observado', 'alterado': False}
    host = (urlparse(page.url).hostname or '').lower()
    frame_host = (urlparse(frame.url).hostname or '').lower()
    englishcentral = any(value == 'englishcentral.com' or value.endswith('.englishcentral.com')
                         for value in (host, frame_host))
    scope = loc.locator('xpath=ancestor::*[self::ec-player-app or self::ec-activity-app][1]')
    wrapped = await scope.count() == 1
    controls = []
    if wrapped:
        candidates = scope.locator('[data-testid="player-play-pause"]')
        for index in range(min(await candidates.count(), 20)):
            control = candidates.nth(index)
            if (await control.is_visible() and await control.is_enabled()
                    and await control.evaluate('e=>!e.closest("[hidden],[aria-hidden=\\"true\\"],[aria-disabled=\\"true\\"]")')):
                controls.append(control)
    if len(controls) == 1:
        await controls[0].click(timeout=5000)
        current = await loc.evaluate('v=>({reproduzindo:!v.paused&&!v.ended})')
        return {**current, 'controle': 'site', 'alterado': True}
    if englishcentral or wrapped:
        raise RuntimeError('Não encontrei um controle Reproduzir/Pausar único do EnglishCentral. '
                           'Use o botão oficial na janela do curso e confira o registro de Assistir.')
    if mode == 'pause':
        current = await loc.evaluate('v => {v.pause();return {reproduzindo: !v.paused&&!v.ended}}')
    else:
        current = await loc.evaluate('async v => {await v.play();return {reproduzindo: !v.paused&&!v.ended}}')
    return {**current, 'controle': 'nativo', 'alterado': True}
