"""Testes locais com uma página HTML de aula SIMULADA; não testam EnglishCentral real."""
import asyncio
import os
from playwright.async_api import async_playwright
from conftest import chromium_launch_options
from integracao import inspect_page, fill_selected, toggle_video

MOCK = '''<!doctype html><html><head><title>Exercício simulado</title></head><body>
<h1>Complete the sentence</h1>
<label>I ____ to school every day. <input id="blank" placeholder="Missing word" /></label>
<input type="password" id="pwd" value="nao-coletar" />
<input type="email" id="email" />
<video id="lesson" width="320" height="180" controls></video>
<audio controls></audio>
</body></html>'''


def test_detecta_campos_e_video_sem_senhas():
    async def main():
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(**chromium_launch_options())
            page = await browser.new_page(viewport={'width':430,'height':800})
            await page.set_content(MOCK)
            data = await inspect_page(page)
            assert len(data['campos']) == 1
            assert data['campos'][0]['dica'] is True
            assert data['loginDetectado'] is True
            assert len(data['videos']) == 1
            assert data['audioIgnorado'] is True
            assert 'nao-coletar' not in str(data)
            await fill_selected(page, 0, '1', 'go')
            assert await page.locator('#blank').input_value() == 'go'
            assert await page.locator('#pwd').input_value() == 'nao-coletar'
            state = await toggle_video(page, 0, '1', 'pause')
            assert state['reproduzindo'] is False
            await browser.close()
    asyncio.run(main())


def test_nao_permite_campo_inexistente():
    async def main():
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(**chromium_launch_options())
            page = await browser.new_page()
            await page.set_content(MOCK)
            await inspect_page(page)
            try:
                await fill_selected(page,0,'18','go')
            except ValueError:
                pass
            else:
                raise AssertionError('O campo inexistente deveria ser rejeitado')
            await browser.close()
    asyncio.run(main())
