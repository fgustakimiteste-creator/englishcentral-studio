import asyncio,json
from types import SimpleNamespace
from unittest.mock import AsyncMock
import servidor

def test_year_stage_mapping_is_saved_and_reused(tmp_path,monkeypatch):
    page=SimpleNamespace(is_closed=lambda:False,goto=AsyncMock(),bring_to_front=AsyncMock(),url='https://pt.englishcentral.com/course/8598')
    page.context=SimpleNamespace(pages=[page])
    monkeypatch.setattr(servidor,'page',page)
    monkeypatch.setattr(servidor,'current_page',lambda:page)
    monkeypatch.setattr(servidor,'DATA',tmp_path)
    monkeypatch.setattr(servidor,'course_url',lambda url:url)
    monkeypatch.setattr(servidor,'pause_for_manual_action',AsyncMock())
    async def run():
        result=await servidor.select_course(servidor.CourseSelection(ano=3,etapa=4,url='https://pt.englishcentral.com/course/8598'))
        assert result['ok']
        await servidor.select_course(servidor.CourseSelection(ano=3,etapa=4))
    asyncio.run(run())
    assert page.goto.await_count==2
    assert json.loads((tmp_path/'cursos_selecionados.json').read_text())['3:4'].endswith('/8598')
