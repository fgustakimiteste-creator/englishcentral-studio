## Atualização V18.13.5 — correções AutoTune/ULTRAPLINIAN G0DM0D3

- Mantidos todos os módulos, telas, rotas, recursos e dados locais da V18.13.0; esta revisão é aditiva.
- A fila do SEDUCTEC executa primeiro os materiais/PDFs da seção e só depois inicia quizzes, fóruns e tarefas, entregando o texto extraído à fase seguinte apenas em memória.
- O material é passado ao modelo por seleção de trechos relevantes; o AutoTune ajusta a temperatura conforme o tipo predominante de questão.
- Um avaliador heurístico inspirado no ULTRAPLINIAN compara correspondência de IDs, índices, completude, relação textual e confiança entre tentativas. A pontuação nunca é tratada como gabarito nem prova de correção.
- Estados desconhecidos deixam de ser contabilizados como sucesso; somente leitura confirmada de PDF/material conta como sucesso da fila. Quiz preenchido, rascunho de fórum, tarefa manual, pulado e não confirmado ficam em revisão.
- Ordenação dos materiais pelo índice original; conteúdo temporário eliminado ao final da seção/execução e nunca persistido no histórico.
- Contagem de páginas do PDF agora reflete as páginas realmente examinadas antes do limite de caracteres. Persistência do destino também respeita diretórios isolados de perfis.
- Validação focada: 109 testes de SEDUCTEC/IA/perfis/navegação/regressões passaram; adicionalmente, teste de seleção de curso e cinco testes do motor EnglishCentral passaram. Compilação Python, sintaxe do inicializador Termux e sintaxe JavaScript passaram.

**Limites que continuam explícitos:** não há envio automático/finalização de quiz, publicação automática de fórum ou submissão de tarefa; documentos digitalizados sem texto selecionável não são lidos por OCR; a MiMi do Studio é alternativa e não a MiMi oficial. A suíte completa não terminou neste ambiente devido a navegação real bloqueada (`ERR_BLOCKED_BY_ADMINISTRATOR`) e timeouts em testes externos/legados. O portal real autenticado não foi validado nesta sessão.

---

## Histórico V18.13.0

## Atualização V18.13.0 — automação de curso e prévias paralelas

- Fila SEDUCTEC de curso inteiro com expansão de seções, ordenação por seção/atividade e retomada baseada em metadados de progresso.
- Até quatro agentes por perfil, cada um em uma aba de navegador própria, com captura de prévia e progresso por etapa.
- Grade interativa de sessões independentes por pessoa/conta.
- Navegação de retorno compacta e controle vertical de rolagem da prévia.
- Preferências da MiMi persistidas no servidor por perfil.
- Ação final de enviar/publicar/finalizar continua manual; quizzes e fóruns ficam como rascunho para revisão.

# EnglishCentral Studio V18.13.0 — Automação sequencial, multiagente e sessões paralelas


## Correções desta revisão V18.13.0

A execução completa do SEDUCTEC agora expande controles de seção recolhida e percorre a página por rolagem para disparar carregamento tardio antes de montar a fila. As atividades ficam agrupadas por seção: até quatro agentes trabalham em paralelo em abas separadas dentro da aula atual, e existe uma barreira para não iniciar a próxima aula antes de terminar a seção atual. Cartões sem link ou com origem inválida são ignorados sem interromper a fila.

Cada agente tem uma página/DOM próprio e uma prévia atualizada; ao ler um PDF, abre uma aba temporária autenticada que aparece na prévia daquele agente, extrai até 50 páginas/20 MB com texto selecionável e fecha apenas a aba temporária. O botão compacto Voltar fecha o PDF temporário aberto manualmente e restaura a página do curso; a barra vertical controla a rolagem da prévia principal. A grade de Pessoas abre painéis de perfis separados, para acompanhar e iniciar execuções em contas diferentes.

As preferências da MiMi alternativa do Studio (nível, estilo e idioma de apoio) ficam nas Configurações e são salvas no servidor do perfil, sendo usadas na conversa com vídeo. Isso não altera a MiMi oficial do EnglishCentral.

**Limites que permanecem explícitos:** nenhuma tentativa de quiz é enviada/finalizada nem postagem de fórum é publicada automaticamente. A automação pode abrir, ler, gerar, preencher e reler rascunhos; a ação final continua com a pessoa usuária. PDFs digitalizados sem texto selecionável não são interpretados por OCR neste fluxo. Consulte `AUDITORIA_EnglishCentral_Studio_V18.13.0.md` e `TESTES_EnglishCentral_Studio_V18.13.0.md` para os resultados e limites de verificação.


Painel de estudos para computador e celular. Preserva o motor existente do EnglishCentral e mantém um ambiente separado para SEDUCTEC/Moodle, com automação dos controles visíveis, IA por API ou modelo local e perfis independentes.

## Atualização V18.12.4 — segurança do fluxo e inicialização Android

Esta versão restringe a leitura de PDFs aos recursos efetivamente listados na página atual do curso, restaura a página do curso após redirecionamentos externos em atividades e tentativas de quiz, rejeita origens desconhecidas em vez de classificá-las como EnglishCentral e alinha o uso de Chromium entre o servidor e o inicializador Termux. A variável `EC_BROWSER_EXECUTABLE` tem prioridade e `EC_CHROMIUM_PATH` continua aceita como compatibilidade. Consulte `AUDITORIA_V18_12_4.md` para as evidências e limitações.

## Histórico da V18.12.3 — fila do navegador e automação sequencial

Esta rodada reduz o aviso de navegador ocupado, adiciona controles de voltar/rolagem à prévia, retoma a sequência após leitura de PDF e adiciona preferências da MiMi às configurações EnglishCentral. Consulte `AUDITORIA_V18_12_3.md` para testes e limites.

## Histórico da automação Moodle introduzida na V18.12.3

A atualização anterior corrigiu o fluxo do botão **Executar** no SEDUCTEC: procura a próxima atividade visível pendente no curso, navega para ela e despacha quiz, fórum ou PDF. O início da primeira tentativa é separado de “Tentar novamente”; links de ação mantêm `sesskey` apenas durante a navegação e não o persistem. Recursos PDF intermediários são resolvidos para o arquivo `pluginfile.php` real. Configurações antigas que mantinham fórum desativado por padrão são migradas uma vez; depois, preferências salvas pelo usuário são preservadas. Consulte `AUDITORIA_MINUCIOSA_V18_12_2.md`, `CHANGELOG.md` e `TESTES.md` para o histórico das correções, evidências e limitações de teste real.

## Dois ambientes separados

- **EnglishCentral (principal):** `https://pt.englishcentral.com/myclass/232103/0/courses`. Mantém vídeos, vocabulário, fala sintética, quizzes, atividades de áudio, histórico e as preferências anteriores. A área de conversação oferece tanto acesso ao controle oficial de MiMi quando ele aparece na página quanto uma companheira alternativa do Studio com contexto do vídeo.
- **SEDUCTEC/Moodle:** `https://seductec.seduc.pi.gov.br/`. Tem configuração própria: Tudo, somente PDF, somente Fórum ou somente Quiz. Pode ler/abrir/fechar PDFs, identificar conclusão, gerar e preencher rascunhos de fórum, analisar questionários e preencher campos pendentes, além de abrir uma tentativa nova quando o Moodle exibir o botão correspondente.

O seletor no topo mantém uma aba própria para cada plataforma na mesma sessão do navegador: ao alternar, a outra aba permanece aberta e é reutilizada na próxima seleção. As opções de SEDUCTEC não alteram o motor ou as preferências do EnglishCentral.

## Automação do Moodle

As ações são executadas na sessão autenticada do navegador, por meio de elementos visíveis e formulários da página. Não copiamos cookies nem chamamos endpoints privados do Moodle. O Studio verifica novamente os campos depois de preenchê-los.

- **PDF:** identifica recursos no curso atual; abre uma aba temporária; lê texto selecionável (limite de 20 MB e 50 páginas); fecha a aba temporária e retorna ao curso. PDF digitalizado sem texto selecionável é identificado como não extraível neste fluxo.
- **Fórum:** lê a discussão aberta, gera rascunho e pode preencher o editor visível. A publicação final permanece na interface oficial para revisão e ação da pessoa usuária.
- **Quiz:** identifica cada pergunta, estado, alternativas/campos e respostas pendentes; valida IDs/índices do modelo; preenche e relê os campos. Distingue pendente, parcial, preenchido sem envio, concluído e não confirmado. Uma nova tentativa só é aberta quando há um botão visível disponível.

“Preenchido” não significa “enviado” ou “correto”. A IA não clica automaticamente em finalizar/publicar. A pontuação de qualidade é heurística, não validação factual.

## IA: API ou local

O assistente aceita:

- **API OpenAI:** configure pelo botão **Configurar API OpenAI**. A API recebe o enunciado, trechos do material e mensagens que você enviar. Não envie dados pessoais ou informações de acesso.
- **Ollama:** modelo instalado no host que executa o servidor, em `http://127.0.0.1:11434`.
- **LM Studio ou llama.cpp:** servidor OpenAI-compatível local em `localhost`/`127.0.0.1`/`::1`.

Exemplo LM Studio/llama.cpp em `config_ia.local.txt` do perfil:

```ini
EC_IA_PROVEDOR=local_openai
EC_IA_MODELO=nome-do-modelo-carregado
EC_IA_URL=http://127.0.0.1:1234/v1
```

A estratégia AutoTune classifica definição, comparação, explicação, interpretação, resumo, opinião, causas/consequências e cálculo; seleciona partes relevantes do material; revisa quando encontra sinais de qualidade baixa; e usa feedback agregado por categoria. O feedback não armazena perguntas nem respostas. APIs de nuvem exigem conexão e cobrança/cota ativa na conta do provedor.

## MiMi e conversa sobre vídeo

Na aba EnglishCentral, abra um vídeo e use **Conversar com a MiMi**. A companheira do Studio considera título, legendas e texto visível e pode corrigir inglês, explicar vocabulário e manter o diálogo. Ela não é a MiMi oficial e não gera XP/registro no EnglishCentral. **Abrir MiMi oficial** tenta acionar o botão existente no próprio site; quando o botão não está disponível, informa isso sem simular acesso.

## Múltiplas contas

Cada perfil mantém navegador, porta, token, pasta de dados, sessão, configurações e histórico próprios. Clique em **Adicionar pessoa** e depois **Abrir painel** para uma nova aba com outro login. O perfil principal preserva a configuração de IA legada; cada perfil adicional tem seu próprio `config_ia.local.txt` e não herda a chave de outra pessoa. Em navegadores móveis que bloqueiam novas abas, use Chrome/Firefox normal e permita pop-ups; o painel não substitui a conta que já está aberta.

## Instalação e atualização

1. Faça backup da instalação atual.
2. Extraia o ZIP novo em uma pasta separada.
3. Mantenha a pasta `.dados_locais` e arquivos de configuração antigos; não apague o diretório de perfis.
4. No Windows, execute `INICIAR.bat`. No Termux, siga `GUIA_CELULAR.md` e use `bash TERMUX_INICIAR.sh`.
5. Após iniciar, escolha um dos dois ambientes no seletor do topo e faça login diretamente no portal.

O servidor precisa permanecer ligado. O PWA é a interface; Python e Chromium executam no computador/servidor. Para segunda conta em celular, o navegador normal pode ser necessário se o modo PWA não permitir pop-ups.

## Validação desta versão

Consulte `AUDITORIA_V18_12_4.md`, `AUDITORIA_MINUCIOSA_V18_12_2.md`, `TESTES.md`, `GUIA.md`, `GUIA_CELULAR.md` e `SKILL.md`. A integração foi validada com testes Python e um Chromium local usando páginas Moodle de fixture. Não foram fornecidos login do SEDUCTEC, credenciais EnglishCentral, chave de API nem acesso a um curso real autenticado; portanto login/entitlements/seletores particulares da conta real ainda precisam ser confirmados no aparelho do usuário.

**Estado real da IA:** o painel consulta o endpoint do modelo OpenAI ou a lista de modelos do Ollama/servidor local. “Conectada” significa que o modelo foi localizado; isso não garante crédito/cota para uma geração.
