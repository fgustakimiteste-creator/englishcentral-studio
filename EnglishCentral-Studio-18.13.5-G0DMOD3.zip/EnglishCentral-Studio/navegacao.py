"""Observação de UI e navegação cautelosa entre lições EnglishCentral.

Funciona com elementos semânticos visíveis. Não contorna CAPTCHA, login,
verificações, áudio, pagamento ou confirmações de conta.
"""
from __future__ import annotations

import re
from urllib.parse import urlparse

BLOCK = re.compile(r'login|log in|entrar|sign in|cadastro|sign up|criar conta|senha|password|'
                   r'google|facebook|perfil|profile|configura|setting|ajuda|help|sair|logout|'
                   r'excluir|delete|pagamento|payment|upgrade|premium|comprar|buy|subscription|'
                   r'gravar|record|microfone|microphone|falar|speak|convers[aã]|go live|'
                   r'voz|voice|áudio|audio|quiz|teste|prova|exam|avalia|assessment|'
                   r'voltar|back|cancelar|cancel|pular|skip', re.I)
START = re.compile(r'^(come[çc]ar|iniciar|iniciar aula|come[çc]ar aula|start|start lesson|watch|assistir|play|ver aula)$', re.I)
NEXT = re.compile(r'^(continuar|pr[oó]ximo|pr[oó]xima|pr[oó]xima aula|next|next video|next lesson|continue)$', re.I)

SCAN_JS = r"""() => {
const visible = el => { const s=getComputedStyle(el), r=el.getBoundingClientRect();
  return s.display!=='none' && s.visibility!=='hidden' && r.width>0 && r.height>0 && !el.disabled;
};
let items = [...document.querySelectorAll('a[href],button,[role="button"]')].filter(visible).slice(0,160);
return items.map((e,i) => ({i, label:(e.innerText || e.getAttribute('aria-label') || e.getAttribute('title') || '').replace(/\s+/g,' ').trim().slice(0,80),
  href:e.tagName.toLowerCase()==='a'?e.href:null, tag:e.tagName.toLowerCase() }));
}"""


def safe_target(item: dict) -> bool:
    label = str(item.get('label') or '').strip()
    if not label or BLOCK.search(label) or len(label) > 80:
        return False
    href = item.get('href')
    if href:
        parsed = urlparse(href)
        if parsed.scheme not in ('http', 'https'):
            return False
        host = (parsed.hostname or '').lower()
        if host != 'englishcentral.com' and not host.endswith('.englishcentral.com'):
            return False
        if BLOCK.search(parsed.path):
            return False
    return True


async def choose_navigation(page, *, next_only=False) -> dict:
    """Nunca clica em opções ambíguas. Limita-se a ações simples de aula."""
    try:
        frame = page.main_frame
        items = await frame.evaluate(SCAN_JS)
    except Exception:
        return {'tipo': 'indefinido', 'mensagem': 'Interface não acessível. Use a janela do navegador.'}
    choices = [item for item in items if safe_target(item)]
    rule = NEXT if next_only else START
    hits = [x for x in choices if rule.fullmatch(x['label'].strip())]
    if len(hits) == 1:
        hit = hits[0]
        # Recupera elemento pelo mesmo índice (lista original); revalida semântica ao clicar.
        try:
            # A seleção pelo índice do scan é resolvida pelo JS somente se label/url não mudarem.
            await frame.evaluate(r"""({i, label, href}) => {
              const visible = el => {const s=getComputedStyle(el),r=el.getBoundingClientRect();return s.display!=='none' && s.visibility!=='hidden' && r.width>0 && r.height>0 && !el.disabled};
              const el = [...document.querySelectorAll('a[href],button,[role="button"]')].filter(visible).slice(0,160)[i];
              const t=(el?.innerText || el?.getAttribute('aria-label') || el?.getAttribute('title') || '').replace(/\s+/g,' ').trim().slice(0,80);
              if(!el || t!==label || (href && el.href !== href)) throw Error('A interface mudou');
              el.click();
            }""", hit)
            return {'tipo': 'navegacao', 'mensagem': f'Ação de navegação realizada: {hit["label"]}.'}
        except Exception:
            return {'tipo': 'indefinido', 'mensagem': 'A página mudou antes de iniciar a aula.'}
    if len(hits) > 1:
        return {'tipo': 'indefinido', 'mensagem': 'Há várias opções possíveis. Abra a aula desejada no Chrome.'}
    return {'tipo': 'indefinido', 'mensagem': 'Não identifiquei uma ação segura de navegação nesta página. Abra uma aula no Chrome.'}
