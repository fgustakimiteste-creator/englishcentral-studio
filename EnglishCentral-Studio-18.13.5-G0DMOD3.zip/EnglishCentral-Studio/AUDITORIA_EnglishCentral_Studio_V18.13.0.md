# Auditoria técnica — EnglishCentral Studio V18.13.0

## Objetivo da revisão

Corrigir o fluxo completo do SEDUCTEC/Moodle mostrado na captura do curso (Leitura Aula 02 em PDF, Fórum Aula 02 e Quiz Aula 02), melhorar a navegação por seções, permitir agentes concorrentes, oferecer prévias simultâneas e integrar as preferências da MiMi às configurações do perfil sem alterar o motor principal do EnglishCentral.

## Alterações implementadas

### 1. Varredura e sequência do curso

- A automação verifica controles de expansão por aria-state, classe `collapsed`, controles Moodle específicos e botões de expansão global.
- Os controles são marcados após o primeiro clique para que um botão sem `aria-expanded` não seja clicado novamente e recolha as seções.
- A página é percorrida em etapas para permitir carregamento tardio; o DOM é verificado novamente depois da rolagem.
- Cartões sem URL ou com origem fora do host oficial são descartados sem interromper a preparação da fila.
- As atividades são agrupadas pela seção/ordem. Até quatro agentes trabalham em paralelo dentro da seção atual. A próxima seção só começa depois que todos os workers terminam a seção anterior.
- O estado local registra apenas metadados mínimos de atividade (URL normalizada, nome, tipo, estado e data); não armazena enunciados, respostas, cookies ou conteúdo dos PDFs.

### 2. PDF e prévia

- Cada agente trabalha em uma `Page` separada. Para PDF reconhecido no curso/atividade atual, abre uma aba temporária autenticada e a associa à prévia daquele agente.
- A leitura usa a requisição autenticada do navegador e valida origem, status, assinatura/tipo e tamanho máximo de 20 MB.
- `pypdf` extrai no máximo 50 páginas e 24.000 caracteres. PDF sem texto selecionável é marcado como não extraível; OCR não é simulado.
- A prévia captura o PDF antes de fechar a aba e mantém a captura até o agente iniciar a próxima atividade.
- A seta Voltar da prévia principal fecha somente a aba temporária criada pelo Studio e restaura o curso original. A barra vertical controla a rolagem da página/visualizador principal.

### 3. Multiagente e contas paralelas

- Cada agente tem uma aba própria no contexto autenticado do perfil e uma captura própria, com estado, etapa, tarefa, progresso e erro.
- O limite é de quatro agentes por perfil. Em uma conta, a fila distribui as atividades da seção atual entre agentes; não compartilha DOM.
- Perfis diferentes mantêm processos, portas, tokens, diretórios, preferências e contextos separados.
- A grade de Pessoas abre painéis independentes em quadros separados; a pessoa pode iniciar a automação em cada perfil sem substituir a sessão que já está aberta.
- Ao terminar a fila, o painel envia uma notificação e mostra itens concluídos, itens para revisão e falhas.

### 4. MiMi

- Nível, estilo e idioma de apoio estão nas Configurações.
- Preferências são salvas no servidor de cada perfil e aplicadas à chamada da conversa alternativa contextualizada pelo vídeo.
- A MiMi do Studio continua identificada como recurso alternativo; não se apresenta como a MiMi oficial e não gera XP oficial.

### 5. Correções de regressão encontradas durante a revisão

- Importações ausentes (`page_kind` e `is_direct_moodle_pdf`) no controlador da automação.
- Atividades sem URL/URL externa causavam erro durante a busca de progresso salvo; agora são filtradas antes da normalização.
- A fila anterior não tinha barreira entre seções; agora respeita a ordem das aulas.
- O snapshot do orquestrador não deve expor objetos Playwright; páginas e bytes de prévia são removidos do JSON de status.
- A expansão global sem aria-state podia ser clicada mais de uma vez e recolher seções; agora há marca de idempotência.
- A prévia do PDF podia desaparecer antes do próximo polling; a captura é mantida até a atividade seguinte.

## Integridade e segurança

- O adaptador SEDUCTEC só opera em `https://seductec.seduc.pi.gov.br`.
- EnglishCentral e SEDUCTEC continuam com adaptadores e estados separados.
- Perfis não compartilham tokens ou cookies.
- A distribuição exclui diretórios de dados locais, sessões, `.env`, cookies, bancos de estado, logs, dependências instaladas e caches.

## Limites que continuam explícitos

- O sistema não clica automaticamente em **Enviar/Finalizar** questionários, **Publicar** fóruns nem submete tarefas. Ele pode ler, gerar rascunhos, preencher campos pendentes e reler para verificar; a ação final exige revisão/ação da pessoa usuária.
- PDFs digitalizados sem camada de texto não são lidos por OCR neste fluxo.
- A automação depende de sessão SEDUCTEC autenticada e controles/atividades disponíveis para a conta. Não foi fornecido login SEDUCTEC nem acesso autenticado ao curso real nesta revisão.
- O ambiente de teste bloqueia navegação do Chromium para alguns domínios externos e mesmo para URLs locais de servidores de fixture (`ERR_BLOCKED_BY_ADMINISTRATOR`). Portanto, os testes locais não provam login, permissão, seletor específico ou conclusão oficial no portal real.

## Referências de versão

- Código: V18.13.0.
- Skill: `SKILL.md` — ciclo Analyze → Plan → Execute → Test → Fix → Optimize, com regra adicional de barreira por seção e páginas isoladas por agente.
- Resultados de teste: `TESTES_EnglishCentral_Studio_V18.13.0.md`.
