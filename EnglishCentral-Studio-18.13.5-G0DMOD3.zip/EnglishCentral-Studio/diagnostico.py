"""Diagnóstico local sem cookies, senhas, token ou conteúdo do curso."""
from __future__ import annotations

import importlib.metadata
import os
import platform
import socket
from datetime import datetime
from pathlib import Path

ROOT=Path(__file__).resolve().parent
DATA=Path(os.getenv('EC_DATA_DIR', str(ROOT/'.dados_locais')))
PORT=int(os.getenv('EC_PORT', '8765'))


def check_port() -> str:
    with socket.socket() as connection:
        connection.settimeout(0.25)
        try:
            connection.connect(('127.0.0.1',PORT))
            return 'ocupada (há um serviço local nessa porta)'
        except OSError:
            return 'disponível'


def report() -> str:
    lines=[
        'DIAGNÓSTICO ENGLISHCENTRAL STUDIO V18.13.1',
        f'Data local: {datetime.now().strftime("%Y-%m-%d %H:%M")}',
        f'Sistema: {platform.system()} {platform.release()}',
        f'Python: {platform.python_version()}',
        f'Porta {PORT}: {check_port()}',
    ]
    for name in ('fastapi','uvicorn','playwright'):
        try:
            value=importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            value='não instalado'
        lines.append(f'{name}: {value}')
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as pw:
            exe=Path(pw.chromium.executable_path)
        lines.append('Chromium Playwright: '+('disponível' if exe.exists() else 'não instalado'))
    except Exception as exc:
        lines.append('Chromium Playwright: indisponível ('+type(exc).__name__+')')
    lines += [
        'Perfil do navegador: '+('criado' if (DATA/'perfil_chromium').exists() else 'ainda não criado'),
        '',
        'Nenhum cookie, senha, token, URL de sessão ou resposta foi incluído neste arquivo.',
    ]
    return '\n'.join(lines)+'\n'


if __name__=='__main__':
    output=ROOT/'diagnostico_local.txt'
    output.write_text(report(),encoding='utf-8')
    print(report())
    print('Diagnóstico salvo em diagnostico_local.txt (sem credenciais).')
