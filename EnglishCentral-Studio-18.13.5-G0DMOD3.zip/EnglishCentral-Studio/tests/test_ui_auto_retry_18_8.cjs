const fs=require('node:fs'),assert=require('node:assert/strict');
const {JSDOM,VirtualConsole}=require(process.env.EC_JSDOM||'jsdom');
const html=fs.readFileSync(require('node:path').join(__dirname,'../web/index.html'),'utf8');
const wait=()=>new Promise(r=>setTimeout(r,40));let passed=0;
const plan=(changes={})=>({ativa:true,cancelada:false,esgotada:false,duracao_ms:10000,restante_ms:10000,tentativa:1,limite:3,...changes});
const question=(changes={})=>({id:'issue-1',motivo:'Teste local: erro transitório no quiz.',categoria:'quiz',pode_pular:true,mostrar_novamente:true,auto_retry:plan(),...changes});
async function boot({request=question(),race=false}={}){
 let clock=0,nextId=1;const timers=new Map(),calls=[],errors=[];
 const state={aberto:false,executando:true,eventos:[],modo:{assistir:false,aprender:false,falar:false,quiz:true,activities:false},auto:{tipo:'aguardando_confirmacao'},confirmacao_parada:request};
 const vc=new VirtualConsole();vc.on('jsdomError',e=>errors.push(e.message));
 const dom=new JSDOM(html,{url:'http://localhost:8765/#token=fixture-only',runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:vc,beforeParse(w){
  w.scrollTo=()=>{};w.HTMLElement.prototype.scrollIntoView=()=>{};
  w.HTMLDialogElement.prototype.showModal=function(){this.open=true};w.HTMLDialogElement.prototype.close=function(){this.open=false};
  Object.defineProperty(w.performance,'now',{value:()=>clock});
  w.setInterval=(fn,delay)=>{const id=nextId++;timers.set(id,{fn,delay});return id};w.clearInterval=id=>timers.delete(id);
  w.fetch=async(url,opts={})=>{
   const data=opts.body?JSON.parse(opts.body):null,method=opts.method||'GET';calls.push({url,method,data});let result={};
   if(url==='/api/status')result=structuredClone(state);
   if(url==='/api/auto/decision/options'){
    if(data.tentativa_automatica===false)Object.assign(state.confirmacao_parada.auto_retry,{ativa:false,cancelada:true,restante_ms:0});
    if(typeof data.mostrar_novamente==='boolean')state.confirmacao_parada.mostrar_novamente=data.mostrar_novamente;
    result={ok:true,confirmacao_parada:structuredClone(state.confirmacao_parada)};
   }
   if(url==='/api/auto/decision'){
    state.confirmacao_parada=null;state.auto={tipo:'navegacao',mensagem:'Relendo a atividade.'};result={executando:true};
    if(race)return{ok:false,status:409,json:async()=>({detail:'Essa solicitação já foi resolvida. Atualize o painel.'})};
   }
   return{ok:true,json:async()=>result};
  };
 }});await wait();assert.deepEqual(errors,[]);
 const tick=ms=>{clock+=ms;for(const timer of [...timers.values()])if(timer.delay===100)timer.fn()};
 const refresh=async()=>{for(const timer of [...timers.values()])if(timer.delay===1500)timer.fn();await wait()};
 return{dom,w:dom.window,d:dom.window.document,state,timers,calls,tick,refresh};
}
async function test(name,fn){await fn();passed++;console.log('PASS',name)}
(async()=>{
 await test('Aviso exibe dez segundos, barra e limite de tentativas',async()=>{const t=await boot();assert(!t.d.getElementById('retryCountdown').classList.contains('hide'));assert.equal(t.d.getElementById('retrySeconds').textContent,'10 s');assert.equal(t.d.getElementById('retryFill').style.width,'100%');assert.match(t.d.getElementById('retryAttemptLabel').textContent,/1 de 3/);t.dom.window.close()});
 await test('Barra diminui com o tempo e informa o restante acessível',async()=>{const t=await boot();t.tick(3500);assert.equal(t.d.getElementById('retrySeconds').textContent,'7 s');assert.equal(t.d.getElementById('retryFill').style.width,'65%');assert.equal(t.d.getElementById('retryProgress').getAttribute('aria-valuenow'),'35');assert.match(t.d.getElementById('retryProgress').getAttribute('aria-valuetext'),/7 segundos/);t.dom.window.close()});
 await test('Ao zerar, interface aguarda o servidor sem duplicar o clique',async()=>{const t=await boot();t.tick(10000);assert.equal(t.d.getElementById('retryFill').style.width,'0%');assert.match(t.d.getElementById('retryCountdownTitle').textContent,/Preparando nova tentativa/);assert(!t.calls.some(c=>c.url==='/api/auto/decision'));t.dom.window.close()});
 await test('Aguardar minha escolha cancela só a tentativa automática',async()=>{const t=await boot();t.d.getElementById('cancelAutoRetry').click();await wait();assert.deepEqual(t.calls.find(c=>c.url==='/api/auto/decision/options').data,{solicitacao:'issue-1',tentativa_automatica:false,mostrar_novamente:true});assert.match(t.d.getElementById('retryCountdownTitle').textContent,/cancelada/);assert(!t.d.getElementById('keepWorking').disabled);assert(!t.calls.some(c=>c.url==='/api/auto/stop'));t.dom.window.close()});
 await test('Tentar novamente manual mantém contrato e encerra a barra',async()=>{const t=await boot();t.d.getElementById('keepWorking').click();await wait();assert.deepEqual(t.calls.find(c=>c.url==='/api/auto/decision').data,{solicitacao:'issue-1',acao:'retry',mostrar_novamente:true});assert(t.d.getElementById('retryCountdown').classList.contains('hide'));assert(![...t.timers.values()].some(timer=>timer.delay===100));t.dom.window.close()});
 await test('Nova solicitação ganha seu próprio relógio',async()=>{const t=await boot();t.tick(9000);t.state.confirmacao_parada=question({id:'issue-2'});await t.refresh();assert.equal(t.d.getElementById('retrySeconds').textContent,'10 s');t.tick(2000);assert.equal(t.d.getElementById('retrySeconds').textContent,'8 s');t.dom.window.close()});
 await test('Aviso recolhido preserva contagem e cancelamento visíveis',async()=>{const t=await boot({request:question({mostrar_novamente:false})});assert(t.d.getElementById('stopQuestion').classList.contains('hide'));assert(!t.d.getElementById('compactWarning').classList.contains('hide'));assert(!t.d.getElementById('retryCountdown').classList.contains('hide'));assert(!t.d.getElementById('cancelAutoRetry').disabled);t.dom.window.close()});
 await test('Sem tentativa automática, decisões continuam manuais',async()=>{const t=await boot({request:question({auto_retry:plan({ativa:false,restante_ms:0})})});assert(t.d.getElementById('retryCountdown').classList.contains('hide'));assert(![...t.timers.values()].some(timer=>timer.delay===100));t.dom.window.close()});
 await test('Limite esgotado explica que aguarda escolha',async()=>{const t=await boot({request:question({auto_retry:plan({ativa:false,esgotada:true,restante_ms:0,tentativa:3})})});assert.match(t.d.getElementById('retryCountdownTitle').textContent,/3 tentativas automáticas/);assert(t.d.getElementById('retryCountdown').classList.contains('isWaiting'));t.dom.window.close()});
 await test('Preferência de aviso chega ao servidor durante a contagem',async()=>{const t=await boot();const checkbox=t.d.getElementById('showWarningAgain');checkbox.checked=false;checkbox.dispatchEvent(new t.w.Event('change'));await wait();assert.deepEqual(t.calls.find(c=>c.url==='/api/auto/decision/options').data,{solicitacao:'issue-1',mostrar_novamente:false});assert(!t.d.getElementById('retryCountdown').classList.contains('hide'));t.dom.window.close()});
 await test('Resposta manual junto do prazo não mostra falso erro',async()=>{const t=await boot({race:true});t.d.getElementById('keepWorking').click();await wait();assert(!t.d.getElementById('activityMsg').classList.contains('error'));assert(t.d.getElementById('retryCountdown').classList.contains('hide'));t.dom.window.close()});
 await test('Sair do painel limpa só a animação e não manda parar',async()=>{const t=await boot();t.w.dispatchEvent(new t.w.Event('pagehide'));assert(![...t.timers.values()].some(timer=>timer.delay===100));assert(!t.calls.some(c=>c.url==='/api/auto/stop'));t.dom.window.close()});
 console.log(`${passed} cenários de contagem aprovados (DOM/API simulados).`);
})().catch(error=>{console.error(error);process.exitCode=1});
