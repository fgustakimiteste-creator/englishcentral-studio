import asyncio
from unittest.mock import AsyncMock, patch
from auto_fluxo import EngineState, _finish_quiz

def test_failed_attempt_retries_without_recording_completion():
    state=EngineState(quiz_failed=True, last_answer='wrong')
    with patch('auto_fluxo._click_unique', AsyncMock(return_value=True)):
        result=asyncio.run(_finish_quiz(None,'1:q4',state,{},submit=True))
    assert result['tipo']=='navegacao'
    assert 'quiz_concluido' not in result
    assert not state.quiz_failed and not state.last_answer

def test_missing_retry_button_keeps_failed_quiz_pending():
    state=EngineState(quiz_failed=True)
    with patch('auto_fluxo._click_unique', AsyncMock(return_value=False)):
        result=asyncio.run(_finish_quiz(None,'1:q4',state,{},submit=True))
    assert result['tipo']=='conferencia'
    assert 'quiz_concluido' not in result and state.quiz_failed

def test_actual_failed_result_reopens_review():
    from test_ec_player import run_with_page
    from auto_fluxo import process_page
    async def scenario(page):
        await page.set_content('<h2>Prática completa</h2><p>Você acertou 0 de 3 palavras</p><button onclick="window.review=true">Revise suas palavras perdidas</button>')
        with patch('auto_fluxo.is_englishcentral',return_value=True):
            result=await process_page(page,engine=EngineState(),submit=True)
        assert result['tipo']=='navegacao'
        assert await page.evaluate('window.review') is True
        assert 'quiz_concluido' not in result
    run_with_page(scenario)

def test_review_word_list_starts_remaining_word_quiz():
    from test_ec_player import run_with_page
    from auto_fluxo import process_page
    async def scenario(page):
        await page.set_content('<button onclick="window.started=(window.started||0)+1">Comece o Quiz</button><p>1 palavra disponível para o Quiz</p><p>Figure Out Verb: descobrir; entender Aulas perdidas</p>')
        with patch('auto_fluxo.is_englishcentral',return_value=True):
            state=EngineState()
            result=await process_page(page,engine=state,submit=True)
            assert result['tipo']=='navegacao'
            await process_page(page,engine=state,submit=True)
        assert await page.evaluate('window.started')==1
        assert 'quiz_concluido' not in result
    run_with_page(scenario)

def test_all_words_correct_returns_to_course_instead_of_review():
    from types import SimpleNamespace
    from auto_fluxo import process_page
    page=SimpleNamespace(url='https://pt.englishcentral.com/course/8597',goto=AsyncMock())
    state=EngineState(quiz_failed=True)
    state.real.cursor.pending='quiz:59286:q4'
    quiz={'quiz_concluido':True,'texto':'Prática completa Você acertou 2 de 2 palavras Revise suas palavras perdidas'}
    with patch('auto_fluxo._page_gate',AsyncMock(return_value={})),patch('auto_fluxo.inspect_ec_player',AsyncMock(return_value={})),patch('auto_fluxo.inspect_quiz',AsyncMock(return_value=quiz)),patch('auto_fluxo._click_unique',AsyncMock()) as click:
        result=asyncio.run(process_page(page,engine=state,submit=True))
    assert result['quiz_concluido']=='59286:q4'
    page.goto.assert_awaited_once()
    click.assert_not_awaited()
