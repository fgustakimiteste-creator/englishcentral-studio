import asyncio
import io
import json
from types import SimpleNamespace
from unittest.mock import AsyncMock

import httpx
import pytest
from fastapi import HTTPException
import perfis
import servidor
from perfis import ProfileManager
from progresso import ProgressoVerificado
from arquivos_locais import local_token, write_text_atomic
from concurrent.futures import ThreadPoolExecutor
from unittest.mock import MagicMock, patch
import auto_ia
import memoria
import network_probe
from modos import ModoEstudo


@pytest.mark.parametrize('value',[True,float('nan')])
def test_dado_invalido_nao_confirma_unidade(tmp_path,value):
    path=tmp_path/'progress.json'
    path.write_text(json.dumps({'cursos':{},'unidades_verificadas':{'8597':{'assistir':{'u1':value}}}}))
    assert not ProgressoVerificado(path).unidades('8597',('assistir',))


@pytest.mark.parametrize('bad', [{'quizzes_verificados':[]}, {'historico':[None,{'curso':'8597','acao':'valid'}]},
                                {'linhas_fala':[]}, {'unidades_verificadas':[]}, {'cursos':{'8597':[]}}])
def test_leitura_de_historico_tolera_grupos_invalidos(tmp_path,bad):
    path=tmp_path/'progress.json';path.write_text(json.dumps({'cursos':{},**bad}))
    progress=ProgressoVerificado(path)
    progress.quizzes('8597');progress.historico('8597');progress.historico_fala('8597')
    progress.unidades('8597',('assistir',));progress.concluidas('8597',('assistir',))
    progress.confirmar('8597','123',{'assistir':True})
    progress.confirmar_unidades('8597',('assistir',),{'u1'})


@pytest.mark.parametrize('people',[[None],[{'id':'pessoa2'}],[{'id':'../escape','nome':'Nome','porta':8765}]])
def test_cadastro_invalido_e_recusado_sem_sobrescrever(tmp_path,people):
    path=tmp_path/'perfis.json';body=json.dumps({'pessoas':people,'proximo':3});path.write_text(body)
    with pytest.raises(RuntimeError):ProfileManager(tmp_path,tmp_path).list()
    assert path.read_text()==body


def test_sonda_de_perfil_usa_rota_independente_do_navegador(monkeypatch):
    seen=[]
    def response(request,timeout):
        seen.append(request.full_url)
        return io.BytesIO(json.dumps({'ok':True,'perfil':{'id':'pessoa2'}}).encode())
    monkeypatch.setattr(perfis,'urlopen',response)
    assert ProfileManager._ready(8766,'token-de-teste','pessoa2')
    assert seen==['http://127.0.0.1:8766/api/health']


def test_health_responde_sem_esperar_titulo_da_aula(monkeypatch,tmp_path):
    async def run():
        title=AsyncMock(side_effect=AssertionError('Health não deve consultar o navegador'))
        monkeypatch.setattr(servidor,'page',SimpleNamespace(is_closed=lambda:False,url='https://pt.englishcentral.com/course/8597',title=title))
        monkeypatch.setattr(servidor,'get_token',lambda:'teste-health-token')
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=servidor.app),base_url='http://local') as client:
            denied=await client.get('/api/health');assert denied.status_code==401
            result=await asyncio.wait_for(client.get('/api/health',headers={'X-EC-Token':'teste-health-token'}),timeout=.1)
            assert result.status_code==200 and result.json()['ok'] is True
            title.assert_not_awaited()
    asyncio.run(run())


def test_recuperacao_preserva_dados_validos_e_original(tmp_path):
    path=tmp_path/'progress.json'
    original=json.dumps({'cursos':{'8597':{'123':{'assistir':True}}},'historico':[None],
                         'unidades_verificadas':{'8597':{'assistir':{'u1':True}}}})
    path.write_text(original)
    progress=ProgressoVerificado(path)
    assert progress.avisos and progress.concluidas('8597',('assistir',))=={'123'}
    assert not list(tmp_path.glob('*.bak'))
    progress.confirmar('8597','124',{'assistir':True})
    assert next(tmp_path.glob('*.bak')).read_text()==original
    assert ProgressoVerificado(path).concluidas('8597',('assistir',))=={'123','124'}


def test_foco_combinado_antigo_preserva_etapas_que_nao_foram_invalidada(tmp_path):
    import time
    path=tmp_path/'progress.json'
    path.write_text(json.dumps({'cursos':{},'unidades_verificadas':{'8597':{'assistir|aprender|quizzes':{'u1':time.time()}}}}))
    progress=ProgressoVerificado(path)
    progress.invalidar_unidade('8597','u1',('quizzes',))
    assert progress.unidades('8597',('assistir','aprender'))=={'u1'}
    assert not progress.unidades('8597',('quizzes',))


def test_arquivo_original_permanece_se_gravacao_falhar(tmp_path,monkeypatch):
    path=tmp_path/'data.json';path.write_text('original')
    def fail(*_):raise OSError('Falha de disco simulada')
    monkeypatch.setattr(type(path),'replace',fail)
    with pytest.raises(OSError):write_text_atomic(path,'novo')
    assert path.read_text()=='original' and not list(tmp_path.glob('*.tmp'))


def test_token_vazio_e_recuperado_e_criacao_concorrente_e_estavel(tmp_path):
    path=tmp_path/'token_painel.txt';path.write_text('')
    with ThreadPoolExecutor(max_workers=6) as pool:
        values=list(pool.map(lambda _:local_token(path),range(12)))
    assert len(set(values))==1 and len(values[0])>=32
    assert len(list(tmp_path.glob('*.bak')))==1


def test_memoria_malformada_preserva_correcoes_validas(tmp_path,monkeypatch):
    path=tmp_path/'memoria.json';original=json.dumps({'frases':{'she rides':'ride','bad':None},'palavras':None})
    path.write_text(original);monkeypatch.setattr(memoria,'MEMORY_PATH',path)
    assert memoria.known_answer('she rides')=='ride' and memoria.read_memory()['palavras']==[]
    memoria.store_words(['hello'])
    assert next(tmp_path.glob('*.bak')).read_text()==original
    assert memoria.known_answer('she rides')=='ride'


def test_captura_aguarda_na_fila_quando_navegador_esta_ocupado(monkeypatch):
    async def run():
        capture=AsyncMock(return_value=b'image-test')
        browser_lock=asyncio.Lock()
        monkeypatch.setattr(servidor,'lock',browser_lock)
        monkeypatch.setattr(servidor,'current_page',lambda:SimpleNamespace(screenshot=capture))
        await browser_lock.acquire()
        queued = asyncio.create_task(servidor.screenshot())
        try:
            await asyncio.sleep(.06)
            assert not queued.done(), 'A prévia deve esperar a operação atual liberar o navegador.'
        finally:
            browser_lock.release()
        response = await asyncio.wait_for(queued, timeout=1)
        assert response.body == b'image-test'
        assert response.media_type == 'image/jpeg'
        capture.assert_awaited_once()
    asyncio.run(run())


@pytest.mark.parametrize('error',[RuntimeError('Rede caiu'),servidor.BrowserTimeoutError('Leitura falhou')])
def test_queda_durante_tratamento_de_erro_preserva_motor(monkeypatch,tmp_path,error):
    async def run():
        engines=[]
        async def process(*_,engine,**__):
            engines.append(engine)
            if len(engines)==1:
                engine.real.video_replays=1
                raise error
            assert engine.real.video_replays==1
            return {'tipo':'escopo_concluido','mensagem':'Teste finalizado'}
        async def decide(result,*_):
            assert result['tipo']=='escopo_concluido'
            return False
        for key,value in {'DATA':tmp_path,'COURSE_FILE':tmp_path/'course.txt','PROGRESS_FILE':tmp_path/'progress.json',
            'page':SimpleNamespace(url='https://pt.englishcentral.com/course/8597',is_closed=lambda:False,frames=[]),
            'auto_running':True,'auto_mode':ModoEstudo(True,False,False,False),'lock':asyncio.Lock(),
            'network_available':AsyncMock(side_effect=[True,False,True]),'restore_network_page':AsyncMock(),
            'process_page':process,'request_stop_confirmation':decide}.items():monkeypatch.setattr(servidor,key,value)
        await asyncio.wait_for(servidor.auto_worker(),timeout=.5)
        assert len(engines)==2 and engines[0] is engines[1]
        servidor.restore_network_page.assert_awaited_once()
    asyncio.run(run())


def test_sonda_de_rede_tem_limite_total(monkeypatch):
    async def run():
        async def blocked(*_):await asyncio.Event().wait()
        monkeypatch.setattr(network_probe.asyncio,'to_thread',blocked)
        monkeypatch.setattr(network_probe,'NETWORK_CHECK_TIMEOUT_SECONDS',.015)
        assert await asyncio.wait_for(network_probe.network_available(),timeout=.1) is False
    asyncio.run(run())


def test_atualizar_chave_preserva_modelo_e_configuracao_visual(tmp_path,monkeypatch):
    path=tmp_path/'config.txt'
    path.write_text('EC_IA_PROVEDOR=openai\nEC_IA_MODELO=modelo-personalizado\nEC_IA_VISAO_MODELO=visao-local\nEC_IA_CHAVE=antiga\n')
    monkeypatch.setattr(auto_ia,'CONFIG',path);monkeypatch.setenv('EC_IA_CHAVE','nao-deve-ser-copiada-do-ambiente')
    auto_ia.save_openai_key('nova-chave-local')
    saved=path.read_text()
    assert 'EC_IA_MODELO=modelo-personalizado' in saved and 'EC_IA_VISAO_MODELO=visao-local' in saved
    assert 'EC_IA_CHAVE=nova-chave-local' in saved and 'nao-deve-ser-copiada-do-ambiente' not in saved


@pytest.mark.parametrize('model', ['gpt-4o-mini','o3-mini','modelo-personalizado',None])
def test_payload_openai_nao_impoe_parametro_incompativel(model):
    cfg={'EC_IA_PROVEDOR':'openai','EC_IA_CHAVE':'fixture-only'}
    if model:cfg['EC_IA_MODELO']=model
    response={'status':'completed','output':[{'type':'message','content':[{'type':'output_text','text':'{"ok":true}'}]}]}
    with patch('auto_ia._post_json',return_value=response) as post:
        assert auto_ia._request_text('Return JSON',cfg)=='{"ok":true}'
    payload=post.call_args.args[1]
    assert ('reasoning' in payload)==(model is None)
    assert payload['model']==(model or auto_ia.DEFAULT_OPENAI_MODEL)


def test_quiz_pendente_nao_apaga_unidade_de_videos_e_palavras(monkeypatch,tmp_path):
    from course_flow import _advance_course, course_progress
    async def run():
        progress_path=tmp_path/'progress.json'
        saved=ProgressoVerificado(progress_path)
        saved.confirmar('8597','123',{'assistir':True,'aprender':True})
        saved.confirmar_unidades('8597',('assistir','aprender','quizzes'),{'u1'})
        saved.confirmar_quiz('8597','u1:q1')
        snapshot={'supported':True,'course_id':'8597','units':[{
            'id':'u1','index':0,'active':True,'visible':True,'ready':True,'cards':[
                {'index':0,'video':True,'lesson_id':'123','title':'Aula','visible':True,'pending':True},
                {'index':1,'quiz':True,'quiz_key':'u1:q1','title':'Quiz','visible':True,'pending':True}]}]}
        p=MagicMock();p.url='https://pt.englishcentral.com/course/8597';p.is_closed.return_value=False;p.frames=[]
        calls=[]
        async def process(page,*,engine,**_):
            cursor=engine.real.cursor;calls.append(cursor)
            if len(calls)==1:
                result=await _advance_course(page,cursor,include_quizzes=True,snapshot=snapshot)
                assert result['quiz_id']=='u1:q1'
                result['progresso_curso']=course_progress(snapshot,cursor,include_quizzes=True)
                return result
            disk=ProgressoVerificado(progress_path)
            assert disk.unidades('8597',('assistir','aprender'))=={'u1'}
            assert disk.unidades('8597',('quizzes',))==set()
            return {'tipo':'escopo_concluido','mensagem':'Fim do teste'}
        for key,value in {'DATA':tmp_path,'COURSE_FILE':tmp_path/'course.txt','PROGRESS_FILE':progress_path,
            'page':p,'auto_running':True,'auto_mode':ModoEstudo(True,True,False,True),
            'lock':asyncio.Lock(),'warm_local_model':lambda:None,'network_available':AsyncMock(return_value=True),
            'process_page':process,'request_stop_confirmation':AsyncMock(return_value=False)}.items():
            monkeypatch.setattr(servidor,key,value)
        with patch('course_flow._click',AsyncMock(return_value={'tipo':'navegacao'})):
            await asyncio.wait_for(servidor.auto_worker(),timeout=1.5)
        assert len(calls)==2 and calls[0] is calls[1]
    asyncio.run(run())
