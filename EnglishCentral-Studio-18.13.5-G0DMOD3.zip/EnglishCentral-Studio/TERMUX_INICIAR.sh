#!/data/data/com.termux/files/usr/bin/bash
# Inicializador Android/Termux. Não usa `playwright install chromium`: o navegador
# deve ser o Chromium do Termux ou o Chrome do telefone via depuração autorizada.
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

fail() { printf '\nERRO: %s\n' "$*" >&2; exit 1; }

command -v python >/dev/null 2>&1 || fail 'Python não encontrado. Instale com: pkg install python'
command -v node >/dev/null 2>&1 || fail 'Node.js não encontrado. Instale com: pkg install nodejs-lts'

CHROMIUM="${EC_BROWSER_EXECUTABLE:-${EC_CHROMIUM_PATH:-}}"
if [[ -z "$CHROMIUM" ]]; then
  CHROMIUM="$(command -v chromium-browser || command -v chromium || true)"
fi
if [[ -z "$CHROMIUM" ]]; then
  printf '%s\n' 'Aviso: Chromium do Termux não encontrado.' \
    'Para usar uma sessão própria: pkg install x11-repo && pkg install chromium' \
    'Alternativamente, conecte o Chrome do telefone por depuração autorizada.'
else
  [[ -f "$CHROMIUM" && -x "$CHROMIUM" ]] || fail "O Chromium configurado não existe ou não é executável: $CHROMIUM"
  export EC_BROWSER_EXECUTABLE="$CHROMIUM"
  export EC_CHROMIUM_PATH="$CHROMIUM"
fi

PYTHON_BIN="$(command -v python)"
if ! "$PYTHON_BIN" -c 'import fastapi,pydantic,uvicorn,playwright,pypdf' >/dev/null 2>&1; then
  printf '%s\n' '[1/2] Instalando dependências Python do projeto…'
  "$PYTHON_BIN" -m pip install --upgrade pip
  "$PYTHON_BIN" -m pip install -r "$ROOT/requirements.txt" || fail 'Não foi possível instalar requirements.txt. Confira a internet e a versão do Python do Termux.'
fi

"$PYTHON_BIN" - <<'PY' || fail 'As dependências instaladas não passaram na verificação.'
import fastapi, pydantic, uvicorn, playwright, pypdf
print('[1/2] Dependências verificadas.')
PY

export EC_TERMUX=1
export EC_FORCE_DESKTOP=0
export EC_HEADLESS="${EC_HEADLESS:-1}"
export EC_PORT="${EC_PORT:-8765}"
mkdir -p "$ROOT/.dados_locais"
printf '[2/2] Iniciando EnglishCentral Studio na porta %s…\n' "$EC_PORT"
printf 'Mantenha o Termux aberto. Para encerrar, pressione Ctrl+C.\n'
exec "$PYTHON_BIN" -u "$ROOT/servidor.py" --port "$EC_PORT"
