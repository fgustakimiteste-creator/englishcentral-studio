# Auditoria minuciosa — EnglishCentral Studio V18.12.2

## Resumo executivo

A V18.12.1 não estava pronta para ser chamada de integralmente funcional. A revisão de código confirmou defeitos de isolamento entre perfis, mapeamento de alternativas Moodle, estado de conclusão, aplicações em páginas alteradas e fluxos de fórum/PDF. Esses defeitos foram corrigidos nesta cópia e receberam testes de regressão.

**Resultado da auditoria:** 337 testes passaram em baterias independentes e selecionadas. A suíte total não foi aprovada: 462 testes foram coletados, mas a execução integral excedeu o limite do ambiente. Três testes de navegação do navegador tiveram falha de ambiente (`ERR_BLOCKED_BY_ADMINISTRATOR`) e outros testes de áudio/vídeo não terminaram. Portanto, esta auditoria não afirma “zero bugs” nem valida uma conta real autenticada.

## Bugs confirmados e correções

### Alta prioridade — isolamento de credenciais

- **Arquivo:** `perfis.py`.
- **Defeito:** subprocessos de perfis adicionais herdavam variáveis de ambiente `EC_IA_*` do perfil principal. Como `auto_ia.settings()` prioriza variáveis de ambiente sobre o arquivo do perfil, uma conta secundária poderia usar a chave/provedor/modelo da conta principal.
- **Correção:** remover `EC_IA_*` do ambiente herdado ao iniciar perfil secundário. Cada pessoa lê sua própria configuração privada. O perfil principal mantém o comportamento/arquivo legado.
- **Teste:** regressão que configura chave/provedor no ambiente pai e confirma que não são encaminhados ao processo secundário.

### Alta prioridade — alternativas e índices do Moodle

- **Arquivos:** `moodle_adapter.py`, `auto_ia.py`.
- **Defeito:** após filtrar controles ocultos, os índices enviados à IA podiam diferir da ordem de controles usada na aplicação. Além disso, o prompt orientava renumerar alternativas a partir de zero.
- **Correção:** manter índices DOM originais, validar índices permitidos e instruir a IA a não renumerá-los.
- **Teste:** fixture Chromium com uma alternativa oculta antes da alternativa visível; teste da IA com índice não contíguo.

### Alta prioridade — conclusão falsa do curso

- **Arquivo:** `moodle_adapter.py`.
- **Defeito:** um badge “concluído” de uma atividade podia fazer a página inteira da disciplina parecer concluída mesmo havendo outras atividades pendentes.
- **Correção:** a página geral do curso não infere conclusão global a partir de textos/badges de atividades; os estados de cada atividade continuam separados.
- **Teste:** curso de fixture com quiz concluído, fórum pendente e aviso global de nota; curso permanece `nao_confirmado` e cada atividade conserva seu estado.

### Alta prioridade — aplicar resposta a uma página que mudou

- **Arquivo:** `servidor.py`.
- **Defeito:** o servidor verificava URL e IDs de perguntas antes de aplicar respostas geradas. Enunciado, alternativas ou estado podiam mudar enquanto a IA processava.
- **Correção:** fingerprint SHA-256 de pergunta, tipo, estado, opções, seleção, campos e valores; se a leitura nova diferir, o servidor aborta e não preenche.
- **Teste:** mudanças de enunciado, alternativas e estado produzem fingerprints diferentes.

### Média prioridade — vários campos e editor iframe

- **Arquivo:** `moodle_adapter.py`.
- **Defeito:** uma resposta única podia preencher apenas o primeiro campo de uma questão com várias lacunas; a contagem não considerava um editor TinyMCE/Atto em iframe junto a um campo comum.
- **Correção:** contar também editores iframe editáveis; quando houver mais de um campo, não preencher parcialmente. O status informa que as respostas devem ser fornecidas por campo. Questões numéricas aceitam vírgula decimal e o valor é relido.
- **Teste:** dois campos de texto, campo comum + iframe e campo numérico.

### Média prioridade — fórum e destino do rascunho

- **Arquivos:** `moodle_adapter.py`, `servidor.py`, `web/index.html`.
- **Defeito:** clicar em Executar sobre uma listagem de fórum podia tentar gerar um rascunho antes de abrir uma discussão. Também havia risco de gerar texto para o último post e abrir resposta em um post anterior.
- **Correção:** abrir primeiro uma discussão visível da listagem, identificar o post que tem ação “Responder”, usar esse post para o rascunho e abrir o editor depois. O botão manual de abrir resposta gera primeiro o rascunho quando necessário, preservando o contexto.
- **Teste:** fixture de listagem → discussão → post com ação de resposta; teste para post anterior quando o mais recente não permite resposta.

### Média prioridade — fechamento de PDF e responsividade

- **Arquivos:** `servidor.py`, `moodle_adapter.py`.
- **Defeitos:** o painel podia declarar PDF fechado sem confirmar o encerramento ou a restauração da aba original; extração de PDF podia bloquear o event loop e manter lock do navegador.
- **Correção:** validar `is_closed()`, reportar `fechado` e `restaurado` separadamente e executar extração `pypdf` em `asyncio.to_thread`, fora do lock do navegador. O limite continua explícito: 20 MB, até 50 páginas e 24 mil caracteres.
- **Teste:** fechamento/retorno com páginas de teste, tratamento de erro e PDF de texto selecionável / PDF sem texto.

### Média prioridade — questionários longos

- **Arquivos:** `servidor.py`, `auto_ia.py`.
- **Defeito:** `suggest_moodle_quiz` limitava cada geração a 25 perguntas; questionários com 26–40 perguntas visíveis falhavam como um todo.
- **Correção:** gerar lotes de até 25, validar todos antes de preencher qualquer campo e abortar a rodada completa se um lote falhar.
- **Teste:** quiz de 28 perguntas é dividido em lotes 25 + 3, mantendo IDs e ordem.

### Média prioridade — configurações e tipo de resposta

- **Arquivo:** `servidor.py`.
- **Defeito:** PUT parcial de preferências Moodle podia redefinir opções que não vinham no corpo da requisição.
- **Correção:** campos omitidos preservam o valor salvo no perfil.
- **Teste:** atualização apenas do modo mantém as demais opções.

### Compatibilidade Android/Termux

- **Defeito de distribuição:** o guia citava `TERMUX_INICIAR.sh`, mas o pacote não incluía esse inicializador.
- **Correção:** incluído `TERMUX_INICIAR.sh`, que verifica dependências, usa Chromium do Termux quando instalado e não tenta instalar o Chromium Linux por `playwright install chromium`.
- **Validação:** `bash -n` passou. Não foi executado dentro de um aparelho Android/Termux nesta sessão.

## Verificações estáticas e funcionais executadas

- `python -m compileall -q .`: aprovado.
- `node --check`: dois scripts inline da interface e todos os arquivos `.js`/`.cjs` examinados: aprovados.
- HTML: 274 IDs, nenhum duplicado; 162 referências literais `$('id')`, nenhuma sem elemento correspondente.
- PDF: extração local de texto selecionável testada; PDF em branco reporta ausência de texto e deixa claro que OCR não está habilitado.
- ZIP de origem: `unzip -t` aprovado; dados locais e chave privada excluídos da distribuição.
- Testes de perfis, API, SEDUCTEC, adaptação Moodle e correções: 88 aprovados.
- Motor EnglishCentral (engine/player/curso/auto): 46 aprovados.
- Quizzes/seleção/revisão EnglishCentral: 31 aprovados.
- Integração/navegação/modos: 18 aprovados.
- Testes de painel/mobile/PC: 89 aprovados; 2 testes de navegação não iniciaram por bloqueio do Chromium do ambiente.
- Testes complementares de auditoria, conexão, etapas, histórico, restrições de quiz, lacunas, correção de frase e preferências: 65 aprovados.

**Total nas baterias independentes listadas: 337 testes aprovados.** O número não representa aprovação da suíte inteira, pois módulos de voz/vídeo e testes de navegador restantes não terminaram.

## Falhas e limitações de validação do ambiente

1. A suíte total coletou 462 testes, mas ultrapassou o limite de execução e não chegou ao fim.
2. Dois testes de interface falharam antes de chegar ao código do Studio: Chromium devolveu `net::ERR_BLOCKED_BY_ADMINISTRATOR` ao navegar para `127.0.0.1` e para um domínio de fixture interceptado. Um teste do motor de vídeo também foi bloqueado ao navegar para `pt.englishcentral.com`.
3. Testes de áudio/vídeo adicionais ficaram sem conclusão dentro do tempo disponível.
4. `npm run test:ui` não pôde ser executado: `jsdom` não está instalado e o ambiente tem Node 22.16.0, enquanto `package.json` declara Node >=24.15. A sintaxe CJS foi verificada; os testes CJS não foram executados.
5. `pip check` reporta conflito do ambiente base entre `moviepy 2.2.1` e `pillow 12.3.0`; `moviepy` não está nas dependências runtime do projeto. Isso parece ser conflito do ambiente de teste, não da lista `requirements.txt` do Studio.

## Limitações funcionais conhecidas (não mascaradas como sucesso)

- Não foi fornecida sessão autenticada do SEDUCTEC ou EnglishCentral. Permissões, seletores do tema/curso e variações de conta ainda exigem teste no aparelho do usuário.
- Não foi fornecida chave real OpenAI nem servidor Ollama/LM Studio; o caminho de configuração e validações de provedor foram testados, mas não houve geração real nesta auditoria.
- PDF digitalizado/imagem sem camada de texto não é OCR; é informado como não legível nesse fluxo.
- Questionário com várias lacunas, controles mistos, matching/arrastar-e-soltar, upload ou controles não suportados é ignorado ou marcado para revisão; não se afirma preenchimento completo.
- Até 40 perguntas são inspecionadas por leitura e processadas em lotes de até 25. Questionários maiores precisam ser divididos/rolados no Moodle.
- “Tudo” habilita tipos de atividade; cada clique em Executar processa a próxima atividade visível, não percorre todo o curso numa execução contínua.
- O Studio prepara rascunhos e preenche campos visíveis. Publicar fórum e enviar/finalizar quiz continuam ações explícitas da pessoa usuária.
- O teste de compatibilidade Termux foi estático (script/sintaxe); ainda precisa de execução em Android com versões reais de Python, Node, Playwright e Chromium.

## Parecer

A V18.12.2 corrige defeitos reproduzíveis e amplia os testes do fluxo Moodle/IA. Não há base para prometer “sem bugs” ou “tudo validado em produção”. A próxima etapa indispensável é uma execução assistida, primeiro com uma disciplina/atividade de teste e uma API/modelo real, confirmando DOM e permissões reais antes de confiar em lotes maiores.
