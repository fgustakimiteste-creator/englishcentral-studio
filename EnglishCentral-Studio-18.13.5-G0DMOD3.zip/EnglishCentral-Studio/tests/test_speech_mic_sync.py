"""Gravação nativa sincronizada e áudio real da entrada sintética local."""
import asyncio
import base64
import io
import wave

from playwright.async_api import async_playwright

from conftest import chromium_launch_options
from fala_sintetica import SYNTHETIC_MIC_INIT
from test_synthetic_audio import _tone_wav


def _run(scenario, prelude=''):
    async def run():
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(**chromium_launch_options())
            try:
                context=await browser.new_context()
                await context.add_init_script(script=prelude+'\n'+SYNTHETIC_MIC_INIT)
                page=await context.new_page()
                await page.route('https://ec-mic-sync.test/**',lambda route:route.fulfill(
                    body='<button id="activate" onclick="window.__ecStudioSyntheticMic.setEnabled(true)">Ativar</button>'))
                await page.goto('https://ec-mic-sync.test/')
                await page.locator('#activate').click()
                await scenario(page,base64.b64encode(_tone_wav()).decode('ascii'))
            finally:
                await browser.close()
    asyncio.run(run())


_RECORD_AND_MEASURE = '''async function recordAndMeasure(mic, stream, payload){
  const generation=mic.status().recordingGeneration;
  const recorder=new MediaRecorder(stream),chunks=[];
  recorder.ondataavailable=event=>{if(event.data.size)chunks.push(event.data)};
  const stopped=new Promise(resolve=>recorder.onstop=resolve);
  recorder.start();
  if(!await mic.waitForRecording(1000,generation))throw Error('O gravador não iniciou');
  await mic.feed(payload);
  recorder.stop();await stopped;
  const context=new AudioContext();
  const buffer=await context.decodeAudioData(await new Blob(chunks,{type:recorder.mimeType}).arrayBuffer());
  const samples=buffer.getChannelData(0);
  const rms=Math.sqrt(samples.reduce((sum,value)=>sum+value*value,0)/samples.length);
  await context.close();
  return {rms,duration:buffer.duration,generation:mic.status().recordingGeneration};
}'''


def test_stream_antigo_nao_confirma_gravacao_e_inicio_atrasado_preserva_audio():
    async def scenario(page,payload):
        result=await page.evaluate('''async payload=>{
          const mic=window.__ecStudioSyntheticMic;
          const stream=await navigator.mediaDevices.getUserMedia({audio:true});
          const streamReady=await mic.waitForStream(10);
          const before=mic.status();
          const premature=await mic.waitForRecording(25);
          const recorder=new MediaRecorder(stream),chunks=[];
          const compatible=recorder instanceof MediaRecorder &&
            Object.getPrototypeOf(recorder)===MediaRecorder.prototype &&
            MediaRecorder.isTypeSupported('audio/webm');
          recorder.ondataavailable=e=>{if(e.data.size)chunks.push(e.data)};
          const stopped=new Promise(resolve=>recorder.onstop=resolve);
          const startedAt=performance.now();setTimeout(()=>recorder.start(),300);
          const ready=await mic.waitForRecording(1000,before.recordingGeneration);
          const elapsed=performance.now()-startedAt;
          const during=mic.status();
          await mic.feed(payload);recorder.stop();await stopped;
          const context=new AudioContext();
          const buffer=await context.decodeAudioData(await new Blob(chunks,{type:recorder.mimeType}).arrayBuffer());
          const samples=buffer.getChannelData(0);
          const rms=Math.sqrt(samples.reduce((sum,x)=>sum+x*x,0)/samples.length);
          await context.close();
          const after=mic.status();await mic.release();
          return {streamReady,premature,compatible,before,during,after,ready,elapsed,rms,duration:buffer.duration};
        }''',payload)
        assert result['streamReady'] and not result['premature']
        assert result['compatible'] and not result['before']['recording']
        assert result['ready'] and result['elapsed']>=250, result
        assert result['during']['recording'] and result['during']['recordingGeneration']==1
        assert not result['after']['recording']
        assert result['rms']>0.02, result
        assert result['duration']>=0.65, result
    _run(scenario)


def test_duas_capturas_tem_geracoes_distintas_e_audio_nao_silencioso():
    async def scenario(page,payload):
        result=await page.evaluate('''async payload=>{
          '''+_RECORD_AND_MEASURE+'''
          const mic=window.__ecStudioSyntheticMic,measurements=[];
          for(let i=0;i<2;i++){
            const stream=await navigator.mediaDevices.getUserMedia({audio:true});
            measurements.push(await recordAndMeasure(mic,stream,payload));
            stream.getTracks().forEach(track=>track.stop());
          }
          const status=mic.status();await mic.release();return {measurements,status};
        }''',payload)
        assert [row['generation'] for row in result['measurements']]==[1,2]
        assert all(row['rms']>0.02 and row['duration']>=0.65 for row in result['measurements'])
        assert not result['status']['recording'] and result['status']['liveTracks']==0
    _run(scenario)


def test_release_cancela_audio_e_espera_sem_deixar_pistas_ativas():
    async def scenario(page,payload):
        result=await page.evaluate('''async payload=>{
          const mic=window.__ecStudioSyntheticMic;
          const stream=await navigator.mediaDevices.getUserMedia({audio:true});
          const recorder=new MediaRecorder(stream);recorder.start();
          if(!await mic.waitForRecording(1000))throw Error('O gravador não iniciou');
          const waiting=mic.waitForRecording(5000,mic.status().recordingGeneration);
          const feeding=mic.feed(payload).then(()=>false,()=>true);
          await new Promise(resolve=>setTimeout(resolve,80));
          const stoppedAt=performance.now();await mic.release();
          const cancelled=await feeding,waitResult=await waiting;
          const elapsed=performance.now()-stoppedAt,status=mic.status();
          mic.setEnabled(true);
          const next=await navigator.mediaDevices.getUserMedia({audio:true});
          const reusable=next.getAudioTracks()[0].readyState==='live';
          await mic.release();return {cancelled,waitResult,elapsed,status,reusable};
        }''',payload)
        assert result['cancelled'] and not result['waitResult']
        assert result['elapsed']<1000, result
        assert result['status']['liveTracks']==0 and not result['status']['recording']
        assert result['status']['recorderCount']==0 and result['reusable']
    _run(scenario)


def test_dispositivo_sintetico_resiste_falha_de_enumeracao_sem_vazar_captura_de_camera():
    prelude='''(() => {
      navigator.mediaDevices.enumerateDevices=async()=>{throw new DOMException('Local test','NotAllowedError')};
      navigator.mediaDevices.getUserMedia=async()=>{throw new DOMException('Local camera test','NotAllowedError')};
    })();'''
    async def scenario(page,_payload):
        result=await page.evaluate('''async()=>{
          const mic=window.__ecStudioSyntheticMic;
          const devices=await navigator.mediaDevices.enumerateDevices();
          let cameraRejected=false;
          try{await navigator.mediaDevices.getUserMedia({audio:true,video:true})}catch{cameraRejected=true}
          const status=mic.status();mic.setEnabled(false);
          let nativeRejected=false;
          try{await navigator.mediaDevices.enumerateDevices()}catch{nativeRejected=true}
          await mic.release();return {devices:devices.map(d=>d.deviceId),cameraRejected,nativeRejected,status};
        }''')
        assert result['devices']==['ec-studio-synthetic']
        assert result['cameraRejected'] and result['nativeRejected']
        assert result['status']['liveTracks']==0 and result['status']['requestCount']==0
    _run(scenario,prelude)


def test_identidade_e_observacao_sao_preservadas_quando_o_site_clona_a_pista():
    async def scenario(page,_payload):
        result=await page.evaluate('''async()=>{
          const mic=window.__ecStudioSyntheticMic;
          const stream=await navigator.mediaDevices.getUserMedia({audio:{deviceId:{exact:'ec-studio-synthetic'}}});
          const original=stream.getAudioTracks()[0],clone=original.clone();
          original.stop();
          const recorder=new MediaRecorder(new MediaStream([clone]));recorder.start();
          const ready=await mic.waitForRecording(1000),settings=clone.getSettings();
          const status=mic.status();recorder.stop();await mic.release();
          return {ready,settings,status,ended:clone.readyState==='ended'};
        }''')
        assert result['ready'] and result['status']['recording']
        assert result['status']['liveTracks']==1
        assert result['settings']['deviceId']=='ec-studio-synthetic'
        assert result['settings']['groupId']=='ec-studio'
        assert result['ended']
    _run(scenario)


def test_gravador_de_stream_nativo_nao_e_confundido_com_o_sintetico():
    async def scenario(page,_payload):
        result=await page.evaluate('''async()=>{
          const mic=window.__ecStudioSyntheticMic,context=new AudioContext();
          const destination=context.createMediaStreamDestination();
          const silence=context.createConstantSource();silence.offset.value=0;
          silence.connect(destination);silence.start();
          const recorder=new MediaRecorder(destination.stream);
          const started=new Promise(resolve=>recorder.onstart=resolve);
          recorder.start();await started;
          const status=mic.status(),ready=await mic.waitForRecording(25);
          recorder.stop();silence.stop();silence.disconnect();destination.stream.getTracks().forEach(t=>t.stop());await context.close();
          await mic.release();return {status,ready};
        }''')
        assert not result['ready'] and not result['status']['recording']
        assert result['status']['recorderCount']==0
    _run(scenario)


def test_feed_vinculado_a_gravacao_para_quando_o_gravador_encerra_e_libera_nova_frase():
    async def scenario(page,payload):
        with wave.open(io.BytesIO(_tone_wav()),'rb') as tone:
            parameters=tone.getparams()
            frames=tone.readframes(tone.getnframes())*2
        long_tone=io.BytesIO()
        with wave.open(long_tone,'wb') as tone:
            tone.setparams(parameters)
            tone.writeframes(frames)
        long_payload=base64.b64encode(long_tone.getvalue()).decode('ascii')
        result=await page.evaluate('''async ({payload,longPayload})=>{
          const mic=window.__ecStudioSyntheticMic;
          const stream=await navigator.mediaDevices.getUserMedia({audio:true});
          const recorder=new MediaRecorder(stream);recorder.start();
          if(!await mic.waitForRecording(1000))throw Error('O gravador não iniciou');
          const generation=mic.status().recordingGeneration;
          const startedAt=performance.now();
          const feeding=mic.feed(longPayload,{requireRecordingGeneration:generation})
            .then(()=>({rejected:false}),error=>({rejected:true,message:error.message}));
          setTimeout(()=>recorder.stop(),150);
          const first=await feeding,elapsed=performance.now()-startedAt,after=mic.status();
          let staleRejected=false;
          try{await mic.feed(payload,{requireRecordingGeneration:generation})}catch{staleRejected=true}
          const next=new MediaRecorder(stream);next.start();
          if(!await mic.waitForRecording(1000,generation))throw Error('A nova captura não iniciou');
          const newGeneration=mic.status().recordingGeneration;
          const seconds=await mic.feed(payload,{requireRecordingGeneration:newGeneration});
          next.stop();await mic.release();
          return {first,elapsed,after,staleRejected,newGeneration,seconds};
        }''',{'payload':payload,'longPayload':long_payload})
        assert result['first']['rejected'],result
        assert result['elapsed']<1000,result
        assert not result['after']['feeding'] and result['after']['activeSources']==0
        assert result['staleRejected'] and result['newGeneration']==2
        assert result['seconds']==0.75
    _run(scenario)
