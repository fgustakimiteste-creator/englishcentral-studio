"""Exercício SIMULADO. Não prova compatibilidade com EnglishCentral autenticado."""
import asyncio
import pytest
from unittest.mock import patch
from playwright.async_api import async_playwright
from conftest import chromium_launch_options
from auto_ia import _parse_answers, ia_status
from auto_fluxo import process_page, is_englishcentral


def test_respostas_e_bloqueio_de_sites():
    assert _parse_answers('{"respostas":["go","went"]}', 2) == ['go', 'went']
    with pytest.raises(RuntimeError):
        _parse_answers('{"respostas":["go"]}', 2)
    assert is_englishcentral('https://pt.englishcentral.com/course/8597')
    assert not is_englishcentral('https://englishcentral.com.evil.example/course')
    assert not is_englishcentral('https://example.com/')


def test_auto_preenche_sem_enviar_e_sem_ler_senha():
    async def run():
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(**chromium_launch_options())
            p = await browser.new_page(viewport={'width':430,'height':800})
            html = '''<!doctype html><title>English lesson</title><h1>Complete the sentence</h1>
<label>I ____ to school every day. <input id="blank" placeholder="Missing word"></label>
<button id="check" onclick="window.sent=true">Check</button>'''
            await p.set_content(html)
            with patch('auto_fluxo.is_englishcentral', return_value=True), patch('auto_fluxo.suggest', return_value=['go']), patch('auto_fluxo.ia_status', return_value={'configurada': True}):
                result = await process_page(p,submit=False)
            assert result['tipo'] == 'lacunas'
            assert result['preenchidas'] == 1
            assert result['enviadas'] is False
            assert await p.locator('#blank').input_value() == 'go'
            assert await p.evaluate('!!window.sent') is False
            await browser.close()
    asyncio.run(run())


def test_auto_nao_preenche_login():
    async def run():
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(**chromium_launch_options())
            p = await browser.new_page(viewport={'width':430,'height':800})
            html = '''<!doctype html><label>Login <input type="password" id="secret"></label>
<label>I ____ to school <input placeholder="Missing word"></label>'''
            await p.set_content(html)
            with patch('auto_fluxo.is_englishcentral', return_value=True), patch('auto_fluxo.suggest', side_effect=AssertionError('Não pode chamar IA na página de login')):
                result = await process_page(p)
            assert result['tipo'] == 'login'
            await browser.close()
    asyncio.run(run())


def test_auto_pode_confirmar_quando_unico_botao():
    async def run():
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(**chromium_launch_options())
            p = await browser.new_page(viewport={'width':430,'height':800})
            html = '''<!doctype html><label>I ____ to school. <input placeholder="Missing word"></label>
<button onclick="window.sent=true">Check</button>'''
            await p.set_content(html)
            with patch('auto_fluxo.is_englishcentral', return_value=True), patch('auto_fluxo.suggest', return_value=['go']), patch('auto_fluxo.ia_status', return_value={'configurada': True}):
                result = await process_page(p,submit=True)
            assert result['enviadas'] is True
            assert await p.evaluate('window.sent') is True
            await browser.close()
    asyncio.run(run())
