# Auditoria incremental — EnglishCentral Studio V18.12.3

## Correções aplicadas nesta rodada

1. **Fila do navegador:** endpoints de leitura que encontram o navegador ocupado deixam de retornar imediatamente `409`. Eles aguardam a liberação do lock, com timeout ampliado para leituras, reduzindo o alerta repetido durante automação.
2. **Prévia ao vivo:** captura de tela entra na mesma fila de operações e aguarda até 40 segundos, em vez de responder com o aviso transitório “navegador ocupado”. A imagem permanece uma captura real do navegador, não uma prévia simulada.
3. **Controles móveis da prévia:** adicionados botões Voltar, rolar para cima e rolar para baixo, acionando navegação/scroll reais do Playwright.
4. **PDF sequencial:** o executor marca recursos visitados, lê PDFs detectados, fecha apenas a aba temporária criada pelo Studio e retorna para a lista do curso para continuar a busca. Recursos que não expõem PDF também retornam à lista quando o histórico permite.
5. **MiMi nas configurações EnglishCentral:** preferências de nível, estilo de resposta e idioma de apoio ficam nas configurações e são persistidas por caminho de perfil no navegador. O backend recebe essas opções e ajusta a instrução da geração.

## Testes executados nesta rodada

- `python -m py_compile *.py`: aprovado.
- `node --check` sobre os scripts inline de `web/index.html`: aprovado.
- `pytest tests/test_runtime_queue_18_12_3.py tests/test_moodle_execute_18_13.py tests/test_profiles_18_7.py tests/test_profiles_native_18_7.py tests/test_api.py`: 38 aprovados.
- O teste completo da suíte anterior `tests/test_audit_fixes_18_12_2.py` tem falha preexistente de fixture: `reportlab.pdfgen.canvas` não foi importado pelo teste; isso não é uma falha do extrator do Studio.

## Limites explícitos

- Não foi possível autenticar no SEDUCTEC/EnglishCentral real nem testar uma chave de API real neste ambiente.
- A navegação e o DOM do Moodle variam por atividade, tema, permissões e versão. A confirmação em conta real continua necessária.
- Perfis independentes já iniciam processos/portas e painéis separados. **Não foi implementada execução concorrente de vários agentes clicando na mesma página Moodle**: múltiplos agentes sobre o mesmo DOM/sessão podem disputar foco, navegação e respostas. Nesta versão, as ações de navegador são serializadas para evitar corrupção da sessão. Tarefas de análise podem ser paralelizadas futuramente em páginas isoladas.
- O executor não envia/publica respostas de quiz ou fórum automaticamente; o envio final continua na plataforma, sob confirmação da pessoa usuária.
- A MiMi do Studio é prática complementar; não é a MiMi oficial e não grava XP.

- Tentativas de ampliar a suíte: `tests/test_course_selection.py` tem falha na fixture por não criar o diretório de dados após substituir `DATA`; `tests/test_integracao.py` não conseguiu iniciar Chromium por falta do executável Playwright padrão. Essas falhas não foram contadas como aprovadas.
