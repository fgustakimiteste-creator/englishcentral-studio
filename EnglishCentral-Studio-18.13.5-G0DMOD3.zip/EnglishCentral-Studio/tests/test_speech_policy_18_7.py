import asyncio
from dataclasses import asdict
from unittest.mock import AsyncMock

import pytest
from auto_fluxo import EngineState
from fala_automatica import handle_speech, signature
from fala_preferencias import SpeechPolicy, load_speech_policy, save_speech_policy
from progresso import ProgressoVerificado
import fala_automatica
import session_actions


def snapshot(score=70, **changes):
    return {'supported': True, 'frame': 0, 'lesson_id': 'dialog:123', 'mode': 'speak',
            'speak_line_id': '101', 'speak_prompt': 'A sample line.', 'speak_phase': 'result',
            'speak_result': f'{score}%', 'speak_score': score, 'speak_line_complete': False,
            'speak_result_accepted': False, 'speak_next_ready': True, **changes}


@pytest.fixture
def speech(monkeypatch):
    monkeypatch.setattr(fala_automatica, 'prepare_synthetic_mic', AsyncMock(return_value=True))
    monkeypatch.setattr(fala_automatica, 'controls', AsyncMock(return_value=[]))
    click = AsyncMock(return_value={'acao': 'fala_next'})
    monkeypatch.setattr(fala_automatica, 'click_control', click)
    return click


def cycle(data, state=None, fresh=None):
    state = state or EngineState()
    return asyncio.run(handle_speech(object(), data, state, submit=True,
                       synthesizer=lambda _: (_ for _ in ()).throw(AssertionError('Não sintetizar no resultado')),
                       inspect=AsyncMock(return_value=fresh or data)))


@pytest.mark.parametrize('score,goal,expected', [(70, 80, 'abaixo_meta'), (85, 80, 'meta_atingida'),
                                               (70, 60, 'meta_atingida'), (70, 100, 'abaixo_meta'), (0, 80, 'abaixo_meta')])
def test_nota_numerica_avanca_sem_exigir_cem(speech, score, goal, expected):
    data = snapshot(score)
    state = EngineState(speech_policy=SpeechPolicy(goal))
    state.speech_flow.sent = signature(data)
    out = cycle(data, state)
    assert out['tipo'] == 'navegacao' and out['fala_evento']['estado'] == expected
    assert out['fala_evento']['precisao'] == score
    assert out.get('progresso_etapas', {}).get('falar') is not True
    assert speech.await_args.args[1] == 'next'


def test_avanco_nao_repete_clique_no_mesmo_resultado(speech):
    data = snapshot(); state = EngineState()
    cycle(data, state)
    assert cycle(data, state)['tipo'] == 'aguardando'
    assert speech.await_count == 1


def test_repeticao_e_limitada_e_nao_clica_duas_vezes(speech):
    data = snapshot(); state = EngineState(speech_policy=SpeechPolicy(80, 2, 'retry'))
    state.speech_flow.attempts[signature(data)] = 1
    assert cycle(data, state)['tipo'] == 'navegacao'
    assert speech.await_args.args[1] == 'retry'
    assert cycle(data, state)['tipo'] == 'aguardando' and speech.await_count == 1
    state.speech_flow.retried = ''
    state.speech_flow.attempts[signature(data)] = 2
    out = cycle(data, state)
    assert out['fala_evento']['pulado'] and speech.await_args.args[1] == 'next'


@pytest.mark.parametrize('score', [70, None])
def test_perguntar_respeita_escolha_e_tentar_novamente_explicito(speech, score):
    data = snapshot(score); state = EngineState(speech_policy=SpeechPolicy(80, 2, 'ask'))
    assert cycle(data, state)['tipo'] == 'ajuda'
    speech.assert_not_awaited()
    state.speech_flow.force_retry = signature(data)
    assert cycle(data, state)['tipo'] == 'navegacao'
    assert speech.await_args.args[1] == 'retry'


@pytest.mark.parametrize('change', [{'speak_line_id': '102'}, {'lesson_id': 'dialog:124'}, {'speak_score': 90}])
def test_mudanca_da_linha_ou_resultado_cancela_clique(speech, change):
    assert cycle(snapshot(), fresh=snapshot(**change))['tipo'] == 'aguardando'
    speech.assert_not_awaited()


def test_resultado_sem_nota_ou_aceite_pede_decisao(speech):
    out = cycle(snapshot(None, speak_result='Tente novamente'))
    assert out['tipo'] == 'ajuda'
    speech.assert_not_awaited()


def test_aceite_sem_numero_nao_inventa_nota(speech):
    out = cycle(snapshot(None, speak_line_complete=True))
    assert out['tipo'] == 'navegacao' and out['fala_evento']['precisao'] is None
    assert out['fala_evento']['estado'] == 'registrada_sem_nota'


def test_botao_indisponivel_nao_forca_avanco(speech):
    assert cycle(snapshot(speak_next_ready=False))['tipo'] == 'aguardando'
    speech.assert_not_awaited()


def test_preferencias_isoladas_e_persistentes(tmp_path):
    one, two = tmp_path / 'p1' / 'fala.json', tmp_path / 'p2' / 'fala.json'
    save_speech_policy(one, SpeechPolicy(65, 3, 'retry'))
    save_speech_policy(two, SpeechPolicy(90, 1, 'ask'))
    assert asdict(load_speech_policy(one)) == {'precisao_minima': 65, 'max_tentativas': 3, 'abaixo_meta': 'retry'}
    assert load_speech_policy(two).precisao_minima == 90


@pytest.mark.parametrize('config', [{'precisao_minima': 101}, {'precisao_minima': True}, {'max_tentativas': 0}, {'abaixo_meta': 'whatever'}])
def test_configuracao_invalida_rejeitada(config):
    with pytest.raises(ValueError): SpeechPolicy(**config)


def test_historico_de_nota_baixa_nao_confirma_aula(tmp_path):
    path = tmp_path / 'progress.json'; p = ProgressoVerificado(path)
    p.registrar_fala('8597', 'dialog:123', {'linha': '101', 'precisao': 70, 'meta': 80,
                                         'tentativas': 1, 'estado': 'abaixo_meta', 'pulado': True})
    reloaded = ProgressoVerificado(path)
    assert reloaded.historico_fala('8597')[0]['precisao'] == 70
    assert not reloaded.concluidas('8597', ('falar',)) and not reloaded.unidades('8597', ('falar',))


def test_pular_no_aviso_de_fala_avanca_so_a_linha(monkeypatch):
    data = snapshot(); state = EngineState()
    monkeypatch.setattr(session_actions, 'inspect_quiz', AsyncMock(return_value={'ativa': False}))
    monkeypatch.setattr(session_actions, 'inspect_ec_player', AsyncMock(return_value=data))
    monkeypatch.setattr(session_actions, 'inspect_course', AsyncMock(return_value={'supported': True, 'course_id': '8597'}))
    click = AsyncMock(return_value={'acao': 'fala_next'})
    monkeypatch.setattr(fala_automatica, 'click_control', click)
    async def run():
        context = await session_actions.issue_context(object(), state, '8597', {'tipo': 'ajuda'})
        assert context['tipo'] == 'linha_fala' and context['pode_pular']
        assert await session_actions.skip_issue(object(), state, context)
        assert not state.real.cursor.skipped_lessons and not state.skip_return_url
    asyncio.run(run())
