"""Pendência atual prevalece sobre cache, sem repetir escopos já conferidos."""
import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

from course_flow import CourseCursor, _advance_course, course_progress
from progresso import ProgressoVerificado


def _course(**card_status):
    card = {'video':True,'lesson_id':'101','index':0,'visible':True,'title':'Aula', **card_status}
    return {'supported':True,'course_id':'8597','units':[
        {'id':'unit-1','index':0,'active':True,'visible':True,'ready':True,'cards':[card]},
    ]}


def test_cartao_pendente_reabre_aula_salva_em_cache_antigo():
    cursor = CourseCursor(seen={'101'}, verified_units={'unit-1'}, visited_units={'unit-1'})
    with patch('course_flow._click', AsyncMock(return_value={'tipo':'navegacao'})) as click:
        result = asyncio.run(_advance_course(MagicMock(), cursor, snapshot=_course(pending=True)))
    assert result['tipo'] == 'navegacao'
    assert cursor.pending == 'lesson:101'
    assert '101' not in cursor.seen
    assert 'unit-1' not in cursor.verified_units and 'unit-1' not in cursor.visited_units
    click.assert_awaited_once()


def test_cartao_concluido_agregado_ainda_exige_inspecao_do_player():
    cursor = CourseCursor()
    with patch('course_flow._click', AsyncMock(return_value={'tipo':'navegacao'})) as click:
        asyncio.run(_advance_course(MagicMock(), cursor, snapshot=_course(completed=True)))
    assert cursor.pending == 'lesson:101'
    assert not cursor.seen and not cursor.session_verified_lessons
    click.assert_awaited_once()


def test_escopo_conferido_na_sessao_nao_repete_por_outras_etapas_pendentes():
    cursor = CourseCursor()
    cursor.mark_done('dialog:101')
    info = _course(pending=True)
    with patch('course_flow._click', AsyncMock()) as click:
        result = asyncio.run(_advance_course(None, cursor, snapshot=info))
        repeated = asyncio.run(_advance_course(None, cursor, snapshot=info))
    assert result['tipo'] == repeated['tipo'] == 'escopo_concluido'
    assert cursor.seen == cursor.session_verified_lessons == {'101'}
    click.assert_not_awaited()
    report = course_progress(info, cursor)['unidades'][0]
    assert report['confirmadas'] == 1 and report['estado'] == 'concluida'
    cursor.reset()
    assert not cursor.session_verified_lessons


def test_resumo_nao_confirma_video_pendente_apenas_pelo_cache():
    cursor = CourseCursor(seen={'101'}, verified_units={'unit-1'})
    report = course_progress(_course(pending=True), cursor)['unidades'][0]
    assert report['confirmadas'] == 0 and report['estado'] == 'pendente'


def test_pendencia_fora_do_modo_nao_apaga_confirmacao_de_video():
    cursor = CourseCursor(seen={'101'})
    result = asyncio.run(_advance_course(None, cursor, snapshot=_course(pending=True, activity=True),
                                        include_activities=False))
    assert result['tipo'] == 'escopo_concluido' and cursor.seen == {'101'}


def test_invalidar_remove_so_etapa_contradita_e_seus_escopos_de_unidades(tmp_path):
    path = tmp_path / 'progress.json'
    progress = ProgressoVerificado(path)
    progress.confirmar('8597', 'dialog:101', {'assistir':True,'aprender':True})
    progress.confirmar('8597', 'dialog:202', {'assistir':True})
    progress.confirmar_quiz('8597', 'unit-1:q1')
    progress.confirmar_unidades('8597', ('assistir',), {'unit-1'})
    progress.confirmar_unidades('8597', ('assistir','aprender'), {'unit-1'})
    progress.confirmar_unidades('8597', ('aprender',), {'unit-1'})
    untouched_units = progress.data['unidades_verificadas']['8597']['aprender'].copy()
    assert progress.invalidar('8597', 'dialog:101', ('assistir',))
    reread = ProgressoVerificado(path)
    assert reread.concluidas('8597', ('assistir',)) == {'202'}
    assert reread.concluidas('8597', ('aprender',)) == {'101'}
    assert reread.quizzes('8597') == {'unit-1:q1'}
    assert not reread.unidades('8597', ('assistir',))
    assert not reread.unidades('8597', ('assistir','aprender'))
    assert reread.data['unidades_verificadas']['8597']['aprender'] == untouched_units
    assert not reread.invalidar('8597', 'dialog:101', ('assistir',))


def test_invalidar_rejeita_identidade_invalida_e_nao_cria_arquivo(tmp_path):
    path = tmp_path / 'progress.json'
    progress = ProgressoVerificado(path)
    assert not progress.invalidar('invalid', '101', ('assistir',))
    assert not progress.invalidar('8597', '/course/8597', ('assistir',))
    assert not progress.invalidar('8597', '101', ('desconhecida',))
    assert not path.exists()
