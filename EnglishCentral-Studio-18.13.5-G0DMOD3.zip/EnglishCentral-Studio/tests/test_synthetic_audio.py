"""Verifica o microfone virtual local sem tocar o áudio nos alto-falantes."""
import asyncio
import base64
import io
import math
import struct
import wave
from unittest.mock import patch

from playwright.async_api import async_playwright
from conftest import chromium_launch_options
from fala_sintetica import SYNTHETIC_MIC_INIT
from auto_fluxo import EngineState, _handle_synthetic_speech


def _tone_wav() -> bytes:
    rate, count = 16000, 12000
    stream = io.BytesIO()
    with wave.open(stream, 'wb') as out:
        out.setnchannels(1)
        out.setsampwidth(2)
        out.setframerate(rate)
        out.writeframes(b''.join(struct.pack('<h', int(5000 * math.sin(2 * math.pi * 440 * i / rate)))
                                 for i in range(count)))
    return stream.getvalue()


def test_microfone_virtual_entrega_audio_ao_gravador_sem_saida_de_som():
    async def run():
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(**chromium_launch_options())
            context = await browser.new_context(ignore_https_errors=True)
            page = await context.new_page()
            await page.add_init_script(script=SYNTHETIC_MIC_INIT)
            await page.route('https://ec-synthetic.test/**', lambda route: route.fulfill(body='''<!doctype html>
              <button id="record">Record</button><script>
                window.__ecStudioSyntheticMic.setEnabled(true);
                window.__ecStudioTestFeed = async base64 => {
                  const stream=await navigator.mediaDevices.getUserMedia({audio:true});
                  const recorder=new MediaRecorder(stream), parts=[];
                  recorder.ondataavailable=e=>parts.push(e.data);
                  recorder.start();
                  const seconds=await window.__ecStudioSyntheticMic.feed(base64);
                  await new Promise(resolve=>{recorder.onstop=resolve;recorder.stop()});
                  window.__recorded={seconds,bytes:(await new Blob(parts).arrayBuffer()).byteLength,
                    track:stream.getAudioTracks()[0].readyState};
                };
              </script>'''))
            try:
                await page.goto('https://ec-synthetic.test/')
                payload = base64.b64encode(_tone_wav()).decode('ascii')
                await page.evaluate('base64=>window.__ecStudioTestPayload=base64', payload)
                await page.locator('#record').click()
                await page.evaluate('base64=>window.__ecStudioTestFeed(base64)', payload)
                await page.wait_for_function('window.__recorded !== undefined')
                captured = await page.evaluate('window.__recorded')
                assert captured['seconds'] == 0.75
                assert captured['bytes'] > 100
                assert captured['track'] == 'live'
                # O módulo conecta a origem somente à saída MediaStream, nunca ao alto-falante.
                assert 'source.connect(state.destination)' in SYNTHETIC_MIC_INIT
                assert 'source.connect(context.destination)' not in SYNTHETIC_MIC_INIT
            finally:
                await browser.close()
    asyncio.run(run())


def test_fluxo_sintetico_inicia_grava_alimenta_e_para():
    async def run():
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(**chromium_launch_options())
            context = await browser.new_context(ignore_https_errors=True)
            page = await context.new_page()
            await page.add_init_script(script=SYNTHETIC_MIC_INIT)
            await page.route('https://ec-synthetic.test/**', lambda route: route.fulfill(body='''<!doctype html>
              <button id="record">Record</button><button id="stop">Stop recording</button>
              <script>
                window.__ecStudioSyntheticMic.setEnabled(true);
                document.querySelector('#record').onclick=async()=>{
                  const stream=await navigator.mediaDevices.getUserMedia({audio:true});
                  const recorder=new MediaRecorder(stream),parts=[];
                  recorder.ondataavailable=e=>parts.push(e.data);
                  recorder.onstop=async()=>window.__recorded={bytes:(await new Blob(parts).arrayBuffer()).byteLength};
                  recorder.start();window.__recorder=recorder;
                };
                document.querySelector('#stop').onclick=()=>window.__recorder?.stop();
              </script>'''))
            try:
                await page.goto('https://ec-synthetic.test/')
                state = EngineState()
                snapshot = {'supported':True,'mode':'speak','frame':0,
                            'lesson_id':'dialog:1','speak_prompt':'This is a test sentence.'}
                with patch('auto_fluxo.synthesize_wav', return_value=(_tone_wav(), 0.75)), \
                     patch('auto_fluxo.inspect_ec_player', return_value=snapshot):
                    # O motor do player devolve aula_id; a releitura usa lesson_id.
                    engine_result = {**snapshot, 'aula_id':snapshot['lesson_id']}
                    del engine_result['lesson_id']
                    result = await _handle_synthetic_speech(page, engine_result, state, submit=True)
                assert result['tipo'] == 'fala_sintetica'
                assert result['duracao'] == 0.75
                await page.wait_for_function('window.__recorded !== undefined')
                assert await page.evaluate('window.__recorded.bytes') > 100
            finally:
                await browser.close()
    asyncio.run(run())

def test_selecao_de_linhas_inicia_antes_de_sintetizar():
    async def run():
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(**chromium_launch_options())
            try:
                page = await browser.new_page()
                await page.set_content('''<ec-player-app><button class="footer-button"
                  onclick="window.started=true">Falar 7 linhas</button></ec-player-app>''')
                state=EngineState()
                with patch('auto_fluxo.synthesize_wav') as synth:
                    result=await _handle_synthetic_speech(page, {'speak_prompt':''},state,submit=True)
                    assert result['tipo']=='navegacao'
                    assert await page.evaluate('window.started')
                    assert (await _handle_synthetic_speech(page, {'speak_prompt':''},state,submit=True))['tipo']=='aguardando'
                    synth.assert_not_called()
            finally:
                await browser.close()
    asyncio.run(run())
