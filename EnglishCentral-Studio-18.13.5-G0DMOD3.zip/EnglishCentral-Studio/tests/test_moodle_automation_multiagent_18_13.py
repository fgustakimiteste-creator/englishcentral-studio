"""Testes reais do orquestrador paralelo e varredura de seções Moodle."""
import asyncio
import os
from pathlib import Path

import pytest

from moodle_automation import MoodleAutomation
from moodle_adapter import expand_moodle_course_sections

SED = 'https://seductec.seduc.pi.gov.br'


class FakePage:
    def __init__(self, number):
        self.number = number
        self.closed = False
        self.url = f'{SED}/course/view.php?id=99'

    def is_closed(self):
        return self.closed

    async def screenshot(self, **kwargs):
        return f'preview-{self.number}'.encode()

    async def close(self):
        self.closed = True


class FakeContext:
    def __init__(self):
        self.pages = []

    async def new_page(self):
        page = FakePage(len(self.pages) + 1)
        self.pages.append(page)
        return page


@pytest.mark.asyncio
async def test_orquestrador_distribui_fila_em_abas_paralelas_sem_compartilhar_dom():
    context = FakeContext()
    manager = MoodleAutomation()
    active = 0
    max_active = 0
    visited = []
    guard = asyncio.Lock()

    async def processor(page, item, lane):
        nonlocal active, max_active
        async with guard:
            active += 1
            max_active = max(max_active, active)
            visited.append((page.number, item['url']))
        lane['fase'] = 'Executando fixture'
        lane['progresso'] = 50
        await asyncio.sleep(.025)
        async with guard:
            active -= 1
        return {'estado': 'material_lido', 'mensagem': 'Texto fixture lido.'}

    activities = [
        {'nome': f'Leitura Aula {i}', 'tipo': 'resource', 'url': f'{SED}/mod/resource/view.php?id={i}'}
        for i in range(1, 7)
    ]
    await manager.start(context, f'{SED}/course/view.php?id=99', activities, processor, workers=3)
    await asyncio.wait_for(manager._task, timeout=3)
    status = manager.snapshot()

    assert len(context.pages) == 3
    assert len({id(page) for page in context.pages}) == 3
    assert len(visited) == 6
    assert max_active >= 2, 'Os agentes devem processar mais de uma atividade simultaneamente.'
    assert status['processadas'] == 6
    assert status['sucesso'] == 6
    assert status['estado'] == 'processada'
    assert len(status['agentes']) == 3
    assert (await manager.screenshot('agente-1')) == b'preview-1'
    await manager.close_pages()
    assert all(page.closed for page in context.pages)


@pytest.mark.asyncio
async def test_orquestrador_marca_erro_se_todas_as_abas_falharem():
    class BrokenContext:
        async def new_page(self):
            raise RuntimeError('chromium indisponível')

    manager = MoodleAutomation()
    await manager.start(BrokenContext(), f'{SED}/course/view.php?id=99', [
        {'nome': 'Quiz', 'tipo': 'quiz', 'url': f'{SED}/mod/quiz/view.php?id=8'}
    ], lambda *_: asyncio.sleep(0, result={'estado': 'ok'}), workers=2)
    await asyncio.wait_for(manager._task, timeout=2)
    status = manager.snapshot()
    assert status['estado'] == 'falhou'
    assert status['processadas'] == 0
    assert status['falhas'] == 2


@pytest.mark.skipif(not Path('/usr/bin/chromium').exists(), reason='Chromium do sistema não instalado')
@pytest.mark.asyncio
async def test_expansao_clica_controles_colapsados_e_revela_atividades_escondidas():
    from playwright.async_api import async_playwright

    async with async_playwright() as pw:
        browser = await pw.chromium.launch(executable_path='/usr/bin/chromium', headless=True,
                                           args=['--no-sandbox'])
        page = await browser.new_page(viewport={'width': 1024, 'height': 720})
        await page.set_content('''<!doctype html><html><body>
          <ul><li class="section" id="section-2">
            <h3 class="sectionname">Aula 02</h3>
            <button id="expand" aria-expanded="false" type="button">Mostrar atividades</button>
            <div id="activities" hidden>
              <ul><li class="activity modtype_resource"><div class="activityname"><a href="/mod/resource/view.php?id=21">Leitura Aula 02</a></div></li></ul>
              <ul><li class="activity modtype_quiz"><div class="activityname"><a href="/mod/quiz/view.php?id=22">Quiz Aula 02</a></div></li></ul>
            </div>
          </li></ul>
          <script>document.getElementById('expand').addEventListener('click',()=>{
            document.getElementById('activities').hidden=false;
            document.getElementById('expand').setAttribute('aria-expanded','true');
          });</script>
        </body></html>''')

        class PageProxy:
            url = f'{SED}/course/view.php?id=99'
            def __init__(self, inner): self.inner = inner
            async def evaluate(self, *args): return await self.inner.evaluate(*args)
            async def wait_for_timeout(self, ms): return await self.inner.wait_for_timeout(ms)

        proxy = PageProxy(page)
        result = await expand_moodle_course_sections(proxy)
        assert result['controles_acionados'] == 1
        assert await page.locator('#activities').is_visible()
        assert await page.locator('li.activity').count() == 2
        assert await page.locator('#expand').get_attribute('aria-expanded') == 'true'
        await browser.close()

@pytest.mark.asyncio
async def test_seta_voltar_fecha_pdf_e_restaurar_curso(monkeypatch):
    import servidor

    class Page:
        def __init__(self, url):
            self.url = url
            self.context = object()
            self.closed = False
            self.brought_front = False
        def is_closed(self): return self.closed
        async def close(self): self.closed = True
        async def bring_to_front(self): self.brought_front = True

    pdf = Page(f'{SED}/pluginfile.php/22/mod_resource/content/1/aula.pdf')
    course = Page(f'{SED}/course/view.php?id=99')
    previous = (servidor.page, servidor.context, servidor.moodle_pdf_page, servidor.moodle_pdf_return_page)
    try:
        servidor.page = pdf
        servidor.context = pdf.context
        servidor.moodle_pdf_page = pdf
        servidor.moodle_pdf_return_page = course
        monkeypatch.setattr(servidor, 'current_page', lambda: pdf)
        monkeypatch.setattr(servidor, 'pause_for_manual_action', lambda: asyncio.sleep(0))
        monkeypatch.setattr(servidor, 'lock', asyncio.Lock())
        monkeypatch.setattr(servidor, 'record', lambda *_: None)

        result = await servidor.navigation('back')

        assert result == {'ok': True, 'pdf_fechado': True, 'restaurado': True}
        assert pdf.closed is True
        assert course.brought_front is True
        assert servidor.page is course
        assert servidor.context is course.context
        assert servidor.moodle_pdf_page is None
        assert servidor.moodle_pdf_return_page is None
    finally:
        servidor.page, servidor.context, servidor.moodle_pdf_page, servidor.moodle_pdf_return_page = previous


@pytest.mark.asyncio
async def test_preferencias_mimi_sao_salvas_por_perfil_no_servidor(monkeypatch, tmp_path):
    import servidor
    target = tmp_path / 'pessoa' / 'preferencias_mimi.json'
    target.parent.mkdir()
    monkeypatch.setattr(servidor, 'MIMI_SETTINGS_FILE', target)
    saved = await servidor.put_mimi_settings(servidor.MimiSettingsRequest(
        nivel='B1', estilo='detalhada', idioma_apoio='bilíngue'))
    assert saved['ok'] is True
    loaded = await servidor.get_mimi_settings()
    assert loaded['salva'] is True
    assert loaded['configuracao'] == {'nivel': 'B1', 'estilo': 'detalhada', 'idioma_apoio': 'bilíngue'}
    assert target.exists()


def test_interface_expoe_scroll_vertical_grade_de_sessoes_e_previa_por_agente():
    html = Path(__file__).resolve().parents[1] / 'web' / 'index.html'
    source = html.read_text('utf-8')
    assert 'class="previewSideScroll"' in source
    assert 'id="previewScrollBar"' in source
    assert "api('scroll/to','POST'" in source
    assert 'id="openMultiWorkspace"' in source
    assert 'id="multiWorkspaceGrid"' in source
    assert 'profiles/'+"'" in source or "profiles/'+encodeURIComponent(person.id)+'/open'" in source
    assert 'id="mimiSettingsStatus"' in source
    assert 'id="moodleAgentGrid"' in source

@pytest.mark.asyncio
async def test_proxima_secao_so_inicia_depois_da_leitura_e_acao_da_secao_anterior():
    context = FakeContext()
    manager = MoodleAutomation()
    started = []
    finished = []
    material_text = 'Material pedagógico da Aula 01.'

    async def processor(page, item, lane):
        started.append(item['nome'])
        if item['nome'] == 'Leitura Aula 01':
            await asyncio.sleep(.02)
            finished.append(item['nome'])
            return {'estado': 'material_lido', '_contexto_material': material_text}
        if item['nome'] == 'Quiz Aula 01':
            assert material_text in lane.get('_material_context', '')
            finished.append(item['nome'])
            return {'estado': 'preenchido_nao_enviado'}
        finished.append(item['nome'])
        return {'estado': 'material_lido'}

    activities = [
        {'nome': 'Leitura Aula 01', 'url': f'{SED}/mod/resource/view.php?id=1', 'tipo': 'resource', 'secao_indice': 0, 'secao': 'Aula 01'},
        {'nome': 'Quiz Aula 01', 'url': f'{SED}/mod/quiz/view.php?id=2', 'tipo': 'quiz', 'secao_indice': 0, 'secao': 'Aula 01'},
        {'nome': 'Leitura Aula 02', 'url': f'{SED}/mod/resource/view.php?id=3', 'tipo': 'resource', 'secao_indice': 1, 'secao': 'Aula 02'},
    ]
    await manager.start(context, f'{SED}/course/view.php?id=99', activities, processor, workers=2)
    await asyncio.wait_for(manager._task, timeout=3)
    assert started.index('Quiz Aula 01') > started.index('Leitura Aula 01')
    assert started.index('Leitura Aula 02') > started.index('Quiz Aula 01')
    assert finished[-1] == 'Leitura Aula 02'
    assert manager.snapshot()['estado'] == 'aguardando_revisao'


@pytest.mark.skipif(not Path('/usr/bin/chromium').exists(), reason='Chromium do sistema não instalado')
@pytest.mark.asyncio
async def test_expansao_moodle_detecta_classe_collapsed_e_secoes_carregadas_ao_rolar():
    from playwright.async_api import async_playwright

    async with async_playwright() as pw:
        browser = await pw.chromium.launch(executable_path='/usr/bin/chromium', headless=True,
                                           args=['--no-sandbox'])
        page = await browser.new_page(viewport={'width': 1000, 'height': 500})
        await page.set_content('''<!doctype html><html><body style="min-height:2600px">
          <ul id="course"><li class="section" id="section-1">
            <a class="sectionname collapsed" href="#content-1">Aula 01</a>
            <div class="content" id="content-1" style="display:none"><div class="activity"><a href="/mod/resource/view.php?id=1">Leitura</a></div></div>
          </li></ul>
          <script>
          document.querySelector('.sectionname').addEventListener('click',e=>{
            e.preventDefault();e.currentTarget.classList.remove('collapsed');document.querySelector('#content-1').style.display='block';
          });
          window.addEventListener('scroll',()=>{
            if(scrollY>450&&!document.querySelector('#section-2')){
              const li=document.createElement('li');li.id='section-2';li.className='section';
              li.innerHTML='<a class="sectionname collapsed" href="#content-2">Aula 02</a><div class="content" id="content-2" style="display:none"><a href="/mod/quiz/view.php?id=2">Quiz</a></div>';
              li.querySelector('a.sectionname').addEventListener('click',e=>{e.preventDefault();e.currentTarget.classList.remove('collapsed');li.querySelector('.content').style.display='block'});
              document.querySelector('#course').append(li);
            }
          });
          </script></body></html>''')

        class PageProxy:
            url = f'{SED}/course/view.php?id=99'
            def __init__(self, inner): self.inner = inner
            async def evaluate(self, *args): return await self.inner.evaluate(*args)
            async def wait_for_timeout(self, ms): return await self.inner.wait_for_timeout(ms)

        result = await expand_moodle_course_sections(PageProxy(page))
        assert result['secoes_detectadas_depois'] == 2
        assert result['controles_acionados'] == 2
        assert await page.locator('#content-1').is_visible()
        assert await page.locator('#content-2').is_visible()
        await browser.close()


@pytest.mark.skipif(not Path('/usr/bin/chromium').exists(), reason='Chromium do sistema não instalado')
@pytest.mark.asyncio
async def test_expand_all_sem_aria_nao_e_clicado_de_novo_e_recolher_secoes():
    from playwright.async_api import async_playwright

    async with async_playwright() as pw:
        browser = await pw.chromium.launch(executable_path='/usr/bin/chromium', headless=True,
                                           args=['--no-sandbox'])
        page = await browser.new_page(viewport={'width': 900, 'height': 600})
        await page.set_content('''<!doctype html><html><body>
          <button id="expand-all">Mostrar tudo</button>
          <ul><li class="section"><div class="content" hidden>Atividade</div></li></ul>
          <script>
            let expanded=false;
            document.querySelector('#expand-all').addEventListener('click',()=>{
              expanded=!expanded;document.querySelector('.content').hidden=!expanded;
            });
          </script></body></html>''')

        class PageProxy:
            url = f'{SED}/course/view.php?id=99'
            def __init__(self, inner): self.inner = inner
            async def evaluate(self, *args): return await self.inner.evaluate(*args)
            async def wait_for_timeout(self, ms): return await self.inner.wait_for_timeout(ms)

        result = await expand_moodle_course_sections(PageProxy(page))
        assert result['controles_acionados'] == 1
        assert await page.locator('.content').is_visible()
        assert await page.locator('#expand-all').get_attribute('data-ec-studio-expanded') == 'true'
        await browser.close()


@pytest.mark.asyncio
async def test_estado_desconhecido_nao_e_contabilizado_como_sucesso():
    manager = MoodleAutomation()
    context = FakeContext()

    async def processor(_page, _item, _lane):
        return {'estado': 'ok', 'mensagem': 'Estado genérico não confirmado.'}

    await manager.start(context, f'{SED}/course/view.php?id=99', [{
        'nome': 'Leitura com retorno inesperado', 'tipo': 'resource',
        'url': f'{SED}/mod/resource/view.php?id=901',
    }], processor, workers=1)
    await asyncio.wait_for(manager._task, timeout=3)
    status = manager.snapshot()
    assert status['sucesso'] == 0
    assert status['falhas'] == 1
    assert status['estado'] == 'concluida_com_erros'
    assert 'não reconhecido' in status['agentes'][0]['erro']


@pytest.mark.asyncio
async def test_material_da_secao_e_entregue_ao_quiz_em_fase_separada_sem_vazar_no_status():
    manager = MoodleAutomation()
    context = FakeContext()
    execution_order = []
    material_text = 'A fotossíntese utiliza luz, água e gás carbônico para produzir glicose.'

    async def processor(_page, item, lane):
        if item['tipo'] == 'resource':
            execution_order.append('leitura_iniciada')
            await asyncio.sleep(0.01)
            execution_order.append('leitura_concluida')
            return {'estado': 'pdf_lido', 'paginas_lidas': 2,
                    '_contexto_material': material_text}
        assert execution_order[-1] == 'leitura_concluida'
        assert material_text in lane.get('_material_context', '')
        execution_order.append('quiz_com_contexto')
        return {'estado': 'preenchido_nao_enviado', 'confirmadas': 1,
                'mensagem': 'Campo preenchido e relido; envio manual.'}

    activities = [
        {'nome': 'Material Aula 01', 'tipo': 'resource', 'pdf': True,
         'url': f'{SED}/mod/resource/view.php?id=910', 'secao_indice': 0, 'secao': 'Aula 01'},
        {'nome': 'Quiz Aula 01', 'tipo': 'quiz',
         'url': f'{SED}/mod/quiz/view.php?id=911', 'secao_indice': 0, 'secao': 'Aula 01'},
    ]
    await manager.start(context, f'{SED}/course/view.php?id=99', activities, processor, workers=2)
    await asyncio.wait_for(manager._task, timeout=3)
    status = manager.snapshot()
    assert execution_order == ['leitura_iniciada', 'leitura_concluida', 'quiz_com_contexto']
    assert status['sucesso'] == 1
    assert status['revisao'] == 1
    assert status['estado'] == 'aguardando_revisao'
    assert material_text not in str(status)
    assert all('_material_context' not in lane for lane in status['agentes'])
