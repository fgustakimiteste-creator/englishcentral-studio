import asyncio
from types import SimpleNamespace
from unittest.mock import AsyncMock
from urllib.error import HTTPError
import pytest
from fastapi import HTTPException
import servidor
import network_probe
from modos import ModoEstudo

SLEEP=asyncio.sleep

@pytest.fixture
def env(monkeypatch,tmp_path):
    page=SimpleNamespace(url='https://pt.englishcentral.com/course/8597',is_closed=lambda:False,frames=[])
    for key,value in {'page':page,'auto_running':False,'auto_task':None,'auto_control_lock':asyncio.Lock(),
        'lock':asyncio.Lock(),'auto_mode':ModoEstudo(True,False,False,False),'auto_latest':{},
        'stop_confirmation':None,'stop_confirmation_event':None,'DATA':tmp_path,
        'PROGRESS_FILE':tmp_path/'progress.json','COURSE_FILE':tmp_path/'course.txt',
        'network_available':AsyncMock(return_value=True),'restore_network_page':AsyncMock()}.items():
        monkeypatch.setattr(servidor,key,value)

async def question(previous=None):
    for _ in range(1000):
        q=servidor.stop_confirmation
        if q and q['id']!=previous:return q.copy()
        await SLEEP(.001)
    raise AssertionError('Pergunta não apareceu')

async def launch():
    servidor.auto_running=True
    servidor.auto_task=asyncio.create_task(servidor.auto_worker())

def test_pergunta_sem_parar_nem_repetir_e_respeita_parar(env,monkeypatch):
    async def run():
        process=AsyncMock(return_value={'tipo':'ajuda','mensagem':'Confira a atividade'})
        monkeypatch.setattr(servidor,'process_page',process);await launch()
        try:
            q=await question();await SLEEP(.02)
            assert servidor.auto_running and process.await_count==1
            assert servidor.auto_latest['tipo']=='aguardando_confirmacao'
            await servidor.auto_decision(servidor.StopDecision(solicitacao=q['id'],continuar=False))
            assert not servidor.auto_running and servidor.stop_confirmation is None
        finally:await servidor.auto_stop()
    asyncio.run(run())

@pytest.mark.parametrize('kind',['erro_ia','incerto','campo','lacuna_sem_texto','lacuna_sem_campo'])
def test_erros_de_resposta_perguntam_em_vez_de_repetir(env,monkeypatch,kind):
    async def run():
        process=AsyncMock(return_value={'tipo':kind,'mensagem':'Não consegui responder esta atividade.'})
        monkeypatch.setattr(servidor,'process_page',process)
        async def fast_sleep(_):await SLEEP(0)
        monkeypatch.setattr(servidor.asyncio,'sleep',fast_sleep)
        await launch()
        try:
            q=await question()
            await SLEEP(.02)
            assert q['tipo']==kind and servidor.auto_running
            assert process.await_count==(3 if kind.startswith('lacuna_') else 1)
        finally:await servidor.auto_stop()
    asyncio.run(run())

def test_continuar_rele_e_conclusao_tambem_pergunta(env,monkeypatch):
    async def run():
        process=AsyncMock(side_effect=[{'tipo':'ajuda','mensagem':'Confira'}, {'tipo':'escopo_concluido','mensagem':'Concluído'}])
        monkeypatch.setattr(servidor,'process_page',process);await launch()
        try:
            first=await question()
            await servidor.auto_decision(servidor.StopDecision(solicitacao=first['id'],continuar=True))
            second=await question(first['id'])
            assert second['tipo']=='escopo_concluido' and process.await_count==2 and servidor.auto_running
        finally:await servidor.auto_stop()
    asyncio.run(run())

def test_decisao_antiga_nao_para_nova_execucao(env,monkeypatch):
    async def run():
        monkeypatch.setattr(servidor,'process_page',AsyncMock(return_value={'tipo':'login','mensagem':'Faça login'}));await launch()
        try:
            await question()
            with pytest.raises(HTTPException) as error:
                await servidor.auto_decision(servidor.StopDecision(solicitacao='antiga',continuar=False))
            assert error.value.status_code==409 and servidor.auto_running
        finally:await servidor.auto_stop()
    asyncio.run(run())

def test_pausa_manual_cancela_pergunta(env,monkeypatch):
    async def run():
        monkeypatch.setattr(servidor,'process_page',AsyncMock(return_value={'tipo':'verificacao','mensagem':'Verificação necessária'}));await launch()
        await question();await servidor.auto_stop()
        assert not servidor.auto_running and servidor.stop_confirmation is None
    asyncio.run(run())

@pytest.mark.parametrize('fail_during_action',[False,True])
def test_reconexao_preserva_motor_e_retoma_sozinha(env,monkeypatch,fail_during_action):
    async def run():
        clock=[0];seen=[];phases=[]
        monkeypatch.setattr(servidor,'time',SimpleNamespace(monotonic=lambda:clock[0],time=lambda:1000+clock[0]))
        monkeypatch.setattr(servidor,'network_available',AsyncMock(side_effect=[True,False,False,True]))
        async def sleep(_):clock[0]+=11;phases.append(servidor.auto_latest.get('tipo'));await SLEEP(0)
        async def process(*args,engine,**kwargs):
            seen.append(engine)
            if len(seen)==1:
                engine.real.video_tracking_replays=1
                if fail_during_action:raise RuntimeError('Rede caiu durante leitura')
                return {'tipo':'video','mensagem':'Assistindo'}
            assert engine.real.video_tracking_replays==1
            return {'tipo':'escopo_concluido','mensagem':'Concluído'}
        monkeypatch.setattr(servidor,'process_page',process);monkeypatch.setattr(servidor.asyncio,'sleep',sleep)
        await launch()
        try:
            q=await question()
            assert q['tipo']=='escopo_concluido' and len(seen)==2 and seen[0] is seen[1]
            assert 'reconectando' in phases and servidor.auto_running
            servidor.restore_network_page.assert_awaited_once()
        finally:await servidor.auto_stop()
    asyncio.run(run())

@pytest.mark.parametrize('exception',[TimeoutError('ação incerta'),RuntimeError('falha inesperada')])
def test_erro_com_rede_online_pergunta(env,monkeypatch,exception):
    async def run():
        monkeypatch.setattr(servidor,'process_page',AsyncMock(side_effect=exception));await launch()
        try:await question();assert servidor.auto_running
        finally:await servidor.auto_stop()
    asyncio.run(run())

def test_falha_preparacao_pergunta(env,monkeypatch):
    async def run():
        monkeypatch.setattr(servidor,'_auto_worker_run',AsyncMock(side_effect=RuntimeError('preparação')));await launch()
        try:await question();assert servidor.auto_running
        finally:await servidor.auto_stop()
    asyncio.run(run())

@pytest.mark.parametrize('code,expected',[(403,True),(429,True),(503,False)])
def test_resposta_http_distingue_rede_e_acesso(monkeypatch,code,expected):
    def fail(*a,**kw):raise HTTPError('https://pt.englishcentral.com/',code,'teste',{},None)
    monkeypatch.setattr(network_probe,'urlopen',fail)
    assert network_probe._public_site_available() is expected

@pytest.mark.parametrize('broken',[True,False])
def test_reabre_apenas_pagina_de_erro(broken):
    async def run():
        page=SimpleNamespace(evaluate=AsyncMock(return_value=broken),goto=AsyncMock())
        await network_probe.restore_network_page(page,'https://pt.englishcentral.com/course/1')
        assert page.goto.await_count==int(broken)
    asyncio.run(run())


def test_preferencia_e_pulo_explicito_persistem_sem_conclusao(env,monkeypatch):
    from progresso import ProgressoVerificado
    from assistant_preferences import read_preferences
    async def run():
        monkeypatch.setattr(servidor,'issue_context',AsyncMock(return_value={'tipo':'quiz','curso':'8597','id':'u1:q1','rotulo':'Quiz 1','categoria':'quiz','pode_pular':True}))
        monkeypatch.setattr(servidor,'skip_issue',AsyncMock(return_value=True))
        monkeypatch.setattr(servidor,'process_page',AsyncMock(return_value={'tipo':'ajuda','mensagem':'Erro no quiz'}))
        await launch()
        try:
            first=await question()
            await servidor.auto_decision(servidor.StopDecision(solicitacao=first['id'],acao='skip',mostrar_novamente=False))
            second=await question(first['id'])
            assert second['mostrar_novamente'] is False and servidor.auto_running
            assert read_preferences(servidor.DATA/'preferencias_assistente.json')['quiz'] is False
            p=ProgressoVerificado(servidor.PROGRESS_FILE)
            assert p.historico('8597')[0]['acao']=='pular' and not p.unidades('8597',('quizzes',))
            servidor.skip_issue.assert_awaited_once()
        finally:await servidor.auto_stop()
    asyncio.run(run())


def test_sem_alvo_nao_aceita_pular(env,monkeypatch):
    async def run():
        monkeypatch.setattr(servidor,'process_page',AsyncMock(return_value={'tipo':'login','mensagem':'Faça login'}));await launch()
        try:
            q=await question()
            with pytest.raises(HTTPException) as error:await servidor.auto_decision(servidor.StopDecision(solicitacao=q['id'],acao='skip'))
            assert error.value.status_code==409 and servidor.auto_running
        finally:await servidor.auto_stop()
    asyncio.run(run())
