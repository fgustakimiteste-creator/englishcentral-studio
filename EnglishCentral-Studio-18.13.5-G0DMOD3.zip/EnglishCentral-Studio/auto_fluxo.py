"""Assistente de estudo: reconhece a etapa da página antes de tocar no player.

A conclusão depende do site; a fala usa a entrada sintética configurada.
"""
from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from urllib.parse import urlparse

from integracao import inspect_page, fill_selected, toggle_video
from auto_ia import suggest, suggest_quiz_choice, ia_status, visual_status, suggest_visual, run_inference, mimi_video_chat
from etapas import classify_stage
from navegacao import choose_navigation
from exercicio import inspect_quiz, inspect_words, read_correction, type_quiz_answer, select_quiz_choice
from memoria import read_memory, store_words, store_correction, known_answer, clean
from ec_engine import ECState, process_ec_page
from ec_player import inspect_ec_player
from modos import ModoEstudo
from revisao_quiz import learn_review, review_answer
from quiz_constraints import fits_quiz
from fala_sintetica import synthesize_wav
from fala_automatica import SpeechState, handle_speech
from fala_preferencias import SpeechPolicy
from browser_session import dismiss_course_tour, google_login_url

@dataclass
class EngineState:
    speech_policy: SpeechPolicy = field(default_factory=SpeechPolicy)
    speech_flow: SpeechState = field(default_factory=SpeechState)
    mimi_history: list = field(default_factory=list)
    quiz_word_list_attempt: str = ''
    quiz_start_signature: str = ''
    review_started_at: float = 0.0
    rejected_answers: list[str] = field(default_factory=list)
    quiz_failed: bool = False
    real: ECState = field(default_factory=ECState)
    last_question: str = ''
    last_answer: str = ''
    attempt_time: float = 0.0
    corrected: bool = False
    skip_return_url: str = ''
    last_video_key: str = ''
    last_video_time: float = 0.0
    last_video_position: float = -1.0
    last_video_progress_at: float = 0.0
    last_video_ended_at: float = 0.0
    generic_video_replays: int = 0
    generic_video_resumes: int = 0
    words_opened_key: str = ''
    visual_try_time: float = 0.0
    choice_question: str = ''
    choice_answer: str = ''
    choice_time: float = 0.0
    choice_attempts: int = 0
    quiz_intro_key: str = ''
    quiz_intro_time: float = 0
    quiz_intro_attempts: int = 0
    speak_signature: str = ''
    speak_started: float = 0.0
    speak_selection_started: float = 0.0
    inference: object | None = None
    course_tour_attempts: int = 0


SAFE_CONFIRM = {'check', 'check answer', 'check answers', 'verificar', 'verificar resposta',
                'verificar respostas', 'conferir', 'conferir resposta', 'submit answer',
                'submit answers', 'enviar resposta', 'enviar respostas', 'confirmar resposta',
                'check my answer'}
SAFE_QUIZ_CONFIRM = {'check', 'check answer', 'submit', 'submit answer', 'confirm',
                     'verificar', 'verificar resposta', 'enviar', 'enviar resposta', 'confirmar'}
SAFE_QUIZ_NEXT = {'continue', 'next', 'done', 'finish', 'continuar', 'próximo', 'proxima',
                  'próxima', 'concluir', 'finalizar'}

async def _quiz_start_buttons(page, *, word_list=False):
    """Encontra a ação pelo texto normalizado, incluindo botões feitos de div/span."""
    targets=[]
    for frame in page.frames[:15]:
        try:
            buttons=await frame.evaluate(r'''wordList => {
          const label=e=>(e.innerText||e.value||'').replace(/\s+/g,' ').trim();
          const rx=wordList?/^(?:ver palavras|view words|lista de palavras|word list)$/i:/^(?:comece\s+(?:o\s+)?quiz|come[çc]ar\s+(?:o\s+)?quiz|iniciar\s+o\s+teste|start\s+(?:the\s+)?(?:test|quiz))$/i;
          const attr=wordList?'data-ec-quiz-word-list':'data-ec-quiz-start';
          document.querySelectorAll('['+attr+']').forEach(e=>e.removeAttribute(attr));
          const matches=[...document.querySelectorAll('button,a,[role="button"],div,span')].filter(e=>{
            const r=e.getBoundingClientRect(),s=getComputedStyle(e);
            return rx.test(label(e))&&r.width>0&&r.height>0&&s.visibility!=='hidden'&&s.display!=='none'
                &&!e.closest('[disabled],[aria-disabled="true"]');
          });
          return matches.filter(e=>!matches.some(child=>child!==e&&e.contains(child))).map((e,i)=>{
            e.setAttribute(attr,String(i));return {id:String(i),label:label(e)};
          });
        }''', word_list)
        except Exception:
            continue
        attr='data-ec-quiz-word-list' if word_list else 'data-ec-quiz-start'
        targets.extend((frame.locator('['+attr+'="'+b['id']+'"]'),b['label']) for b in buttons)
    return targets

async def _recover_quiz_cursor(page, state):
    cursor=state.real.cursor
    if cursor.pending.startswith('quiz:'):
        return
    from course_flow import inspect_course
    course=await inspect_course(page)
    cards=[(u,c) for u in course.get('units',[]) if u.get('active') and not u.get('locked')
           for c in u.get('cards',[]) if c.get('quiz') and not c.get('locked')]
    if len(cards)==1 and cards[0][1].get('quiz_key'):
        unit,card=cards[0]
        cursor.course_id=course.get('course_id','')
        cursor.current_unit=unit['id']
        cursor.pending='quiz:'+card['quiz_key']
        cursor.pending_since=time.monotonic()
        cursor.seen_quizzes.discard(card['quiz_key'])
PAGE_GATE_JS = r'''() => {
  const text=(document.body?.innerText||'').slice(0,1500).toLowerCase();
  return {login:[...document.querySelectorAll('input[type="password"]')].some(e=>{
    const s=getComputedStyle(e),r=e.getBoundingClientRect();
    return s.display!=='none'&&s.visibility!=='hidden'&&r.width>0&&r.height>0;
  }),captcha:/captcha|verify you are human|não sou um robô/.test(text)};
}'''


async def _page_gate(page) -> dict:
    for frame in page.frames[:15]:
        try:
            result = await frame.evaluate(PAGE_GATE_JS)
            if result.get('login') or result.get('captcha'):
                return result
        except Exception:
            continue
    return {'login': False, 'captcha': False}


def is_englishcentral(url: str) -> bool:
    host = (urlparse(url).hostname or '').lower()
    return host == 'englishcentral.com' or host.endswith('.englishcentral.com')


async def _click_unique(page, options: set[str]) -> bool:
    for frame in page.frames[:15]:
        try:
            loc = frame.locator('button, input[type="submit"], [role="button"], .button, .continue-button')
            candidates = await loc.evaluate_all('''(els, options) => els.map((e,i) => {
                const st = getComputedStyle(e), r = e.getBoundingClientRect();
                return {index:i, text:(e.innerText || e.value || e.getAttribute('aria-label') || '').trim().toLocaleLowerCase(),
                   valid: st.display !== 'none' && st.visibility !== 'hidden' && r.width > 0 && r.height > 0 &&
                   !e.disabled && e.getAttribute('aria-disabled') !== 'true'};
              }).filter(e => e.valid && options.includes(e.text)).map(e=>e.index)''', list(options))
            if len(candidates) == 1:
                await loc.nth(candidates[0]).click(timeout=5000)
                return True
        except Exception:
            continue
    return False



async def _handle_mimi_conversation(page, snapshot: dict, state: EngineState, *, submit: bool) -> dict:
    """Responde na atividade Converse sobre o vídeo usando a MiMi de prática do Studio.

    Abre/interage com o chat oficial do EnglishCentral quando o modo conversar
    está ativo. Envia linhas de resposta geradas pela IA configurada (local/API).
    Não inventa conclusão: depende do indicador chat_complete do player.
    """
    if snapshot.get('chat_complete'):
        return outcome('conversa', 'A conversa sobre o vídeo já está concluída no EnglishCentral.', {
            'codigo': 'conversa', 'nome': 'Converse sobre o vídeo'
        })
    if not ia_status().get('configurada'):
        return outcome('configuracao', 'Conversa sobre o vídeo selecionada; configure a IA (Ollama/local/OpenAI) para responder.', {
            'codigo': 'conversa', 'nome': 'Converse sobre o vídeo'
        })
    title = str(snapshot.get('title') or '')
    prompt = str(snapshot.get('speak_prompt') or snapshot.get('question') or '')
    video_context = f"Video title: {title}\nVisible prompt: {prompt}".strip()
    # Tenta localizar um campo de mensagem do chat oficial na página.
    input_candidates = page.locator(
        'textarea[placeholder*="mensagem" i], textarea[placeholder*="message" i], '
        'input[placeholder*="mensagem" i], input[placeholder*="message" i], '
        'textarea[aria-label*="message" i], [contenteditable="true"][data-placeholder*="message" i], '
        '.chat-input textarea, .message-input textarea, [data-testid*="chat"] textarea'
    )
    count = await input_candidates.count()
    visible_inputs = []
    for i in range(min(count, 8)):
        el = input_candidates.nth(i)
        try:
            if await el.is_visible() and not await el.is_disabled():
                visible_inputs.append(el)
        except Exception:
            continue
    if not visible_inputs:
        # Tenta clicar em "Começar" de um tópico de conversa se existir.
        starters = page.locator('button:has-text("Começar"), a:has-text("Começar"), button:has-text("Start")')
        for i in range(min(await starters.count(), 6)):
            btn = starters.nth(i)
            try:
                if await btn.is_visible() and not await btn.is_disabled():
                    await btn.click(timeout=4000)
                    await page.wait_for_timeout(700)
                    break
            except Exception:
                continue
        return outcome('conversa', 'Conversa sobre o vídeo aberta. Aguardando o campo de mensagem ou o próximo prompt da MiMi.', {
            'codigo': 'conversa', 'nome': 'Converse sobre o vídeo'
        })
    # Gera uma resposta curta contextualizada.
    history = getattr(state, 'mimi_history', None) or []
    try:
        result = await run_inference(
            mimi_video_chat, 'Please answer the conversation prompt about this video in clear English.',
            video_context, history, 'B1', 'natural', 'pt',
            runner=state.inference,
        )
    except Exception as exc:
        return outcome('ajuda', f'A MiMi de prática não conseguiu gerar resposta: {type(exc).__name__}.', {
            'codigo': 'conversa', 'nome': 'Converse sobre o vídeo'
        })
    reply = str((result or {}).get('resposta') or (result or {}).get('mensagem') or '').strip()
    if not reply:
        return outcome('ajuda', 'A MiMi não retornou texto utilizável para a conversa.', {
            'codigo': 'conversa', 'nome': 'Converse sobre o vídeo'
        })
    # Limita tamanho razoável para chat.
    reply = reply[:500]
    field = visible_inputs[0]
    try:
        await field.click(timeout=3000)
        await field.fill(reply)
        await page.wait_for_timeout(200)
        # Tenta enviar com Enter ou botão de envio.
        sent = False
        try:
            await field.press('Enter')
            sent = True
        except Exception:
            pass
        if not sent:
            send_btn = page.locator(
                'button:has-text("Enviar"), button:has-text("Send"), '
                '[data-testid*="send"], button[aria-label*="send" i], button[type="submit"]'
            )
            for i in range(min(await send_btn.count(), 6)):
                btn = send_btn.nth(i)
                try:
                    if await btn.is_visible() and not await btn.is_disabled():
                        await btn.click(timeout=3000)
                        sent = True
                        break
                except Exception:
                    continue
        # Guarda histórico curto no estado da sessão.
        history = list(history)[-6:] + [
            {'role': 'user', 'content': prompt or 'conversation prompt'},
            {'role': 'assistant', 'content': reply},
        ]
        state.mimi_history = history
        return outcome('conversa',
                       f'Resposta enviada na conversa sobre o vídeo ({len(reply)} caracteres). Aguardando a próxima linha ou a conclusão.',
                       {'codigo': 'conversa', 'nome': 'Converse sobre o vídeo'},
                       enviadas=sent)
    except Exception as exc:
        return outcome('ajuda', f'Não foi possível digitar no chat: {type(exc).__name__}.', {
            'codigo': 'conversa', 'nome': 'Converse sobre o vídeo'
        })


async def _handle_synthetic_speech(page, snapshot: dict, state: EngineState, *, submit: bool) -> dict:
    response = await handle_speech(page, snapshot, state, submit=submit,
                                   synthesizer=synthesize_wav, inspect=inspect_ec_player)
    response.update(aula_id=snapshot.get('lesson_id', ''), aula=snapshot.get('title', ''),
                    progresso_etapas={'assistir': snapshot.get('watch_complete') is True,
                                      'aprender': snapshot.get('learn_complete') is True,
                                      'falar': snapshot.get('speak_complete') is True,
                                      'conversar': snapshot.get('chat_complete') is True})
    return response


async def _start_words(page) -> dict | None:
    """Só toca no botão inequívoco 'Aprenda N palavras', sem chutar outras áreas da UI."""
    matching = []
    for frame in page.frames[:15]:
        try:
            loc = frame.locator('button, input[type="submit"], [role="button"], .button, .continue-button')
            candidates = await loc.evaluate_all(r'''els => els.map((e,i) => {
                const t=(e.innerText || e.value || e.getAttribute('aria-label') || '').replace(/\s+/g,' ').trim();
                const st=getComputedStyle(e),r=e.getBoundingClientRect();
                return {i,t,valid:st.display!=='none' && st.visibility!=='hidden' && r.width>0 && r.height>0 && !e.disabled};
            }).filter(e=>e.valid && /^aprenda\s+\d{1,3}\s+palavras?$/i.test(e.t)).map(e=>e.i)''')
            matching.extend((frame, loc, index) for index in candidates)
        except Exception:
            continue
    if len(matching) != 1:
        return None
    frame, loc, i = matching[0]
    target = loc.nth(i)
    box = await target.bounding_box()
    await target.click(timeout=6000)
    return {'x':round(box['x']+box['width']/2),'y':round(box['y']+box['height']/2), 'texto':'Cliquei em Aprenda N palavras.'} if box else None




async def _open_words_step(page) -> dict | None:
    """Abre cartão da próxima etapa somente quando o vídeo marcou conclusão."""
    found=[]
    for frame in page.frames[:15]:
        try:
            loc=frame.get_by_text(re.compile(r'^\s*Aprenda as palavras\s*$', re.I),exact=True)
            n=await loc.count()
            for i in range(min(n,5)):
                candidate=loc.nth(i)
                if await candidate.is_visible():
                    found.append(candidate)
        except Exception:
            pass
    if len(found)!=1:
        return None
    box = await found[0].bounding_box()
    await found[0].click(timeout=4000)
    return {'x':round(box['x']+box['width']/2),'y':round(box['y']+box['height']/2), 'texto':'Cliquei em Aprenda as palavras.'} if box else None

def outcome(tipo: str, mensagem: str, etapa: dict, **more) -> dict:
    return {'tipo': tipo, 'mensagem': mensagem, 'etapa': etapa, **more}


async def _handle_video_quiz(page, quiz: dict, etapa: dict, state: EngineState, *, submit: bool) -> dict:
    # Só corrige/executa se frase e campo real puderem ser detectados.
    phrase = clean(quiz.get('frase', ''), 280)
    snippets = [clean(x, 260) for x in quiz.get('trechos', []) if x]
    visually_suggested = None
    if not phrase and visual_status() and time.monotonic()-state.visual_try_time > 30:
        state.visual_try_time = time.monotonic()
        try:
            jpeg = await page.screenshot(type='jpeg', quality=66, timeout=10000)
            visual = await run_inference(suggest_visual, jpeg, read_memory().get('palavras', []), runner=state.inference)
            if visual.get('frase') and visual.get('resposta'):
                phrase, visually_suggested = clean(visual['frase'], 280), visual['resposta']
        except Exception:
            pass
    if not phrase:
        return outcome('lacuna_sem_texto',
                       'Reconheci “Digite a palavra que falta”, mas não consegui ler a frase. '
                       'Se ela estiver gravada nos pixels do vídeo, instale o modelo de visão local opcional.', etapa)
    if not quiz.get('campos'):
        return outcome('lacuna_sem_campo',
                       'Encontrei o enunciado, mas o jogo não expõe um campo digitável identificável. '
                       'Não vou reiniciar o vídeo nem clicar às cegas.', etapa)

    signature = phrase.casefold()
    if signature != state.last_question:
        state.rejected_answers.clear()
        state.last_question, state.last_answer, state.attempt_time, state.corrected = signature, '', 0.0, False
    feedback = quiz.get('feedback', '')
    corrected = read_correction(feedback)
    if corrected and state.last_answer and corrected.casefold() != state.last_answer.casefold() and not state.corrected:
        try:
            pointer = await type_quiz_answer(page, quiz, corrected, enter=submit)
            store_correction(phrase, corrected)
            state.last_answer, state.corrected, state.attempt_time = corrected, True, time.monotonic()
            return outcome('correcao', 'A plataforma indicou uma correção. Registrei a palavra e '
                           + ('confirmei com Enter.' if submit else 'preenchi sem enviar.'), etapa,
                           ponteiro=pointer, resposta=corrected)
        except RuntimeError as exc:
            return outcome('ajuda', 'Correção visível, mas não consegui preencher com segurança: '+str(exc), etapa)
    if corrected and state.last_answer and corrected.casefold() == state.last_answer.casefold():
        store_correction(phrase, corrected)
        return outcome('conferencia', 'A palavra da correção coincide com a resposta. Aguardando próxima frase.', etapa)
    if state.last_answer:
        elapsed = int(time.monotonic() - state.attempt_time)
        return outcome('aguardando', 'Resposta já '+('enviada' if submit else 'preenchida')+
                       f'. Aguardando mudança da frase ou retorno da plataforma ({elapsed}s). '
                       'Não vou enviar a mesma palavra repetidamente.', etapa)
    learned = read_memory()
    words = learned.get('palavras', [])[-80:]
    remembered = known_answer(phrase)
    best_field=max(quiz['campos'],key=lambda f:f.get('score',0))
    remembered = review_answer(phrase,best_field) or remembered
    if remembered and best_field.get('group'):
        letters=re.sub(r'[^A-Za-z]','',remembered).casefold()
        pattern=best_field.get('pattern','').casefold()
        if (best_field.get('limit') and len(letters)!=best_field['limit']) or (pattern and (
            len(pattern)!=len(letters) or any(p!='_' and p!=a for p,a in zip(pattern,letters))
        )):
            remembered=None
    answer = remembered or visually_suggested
    if answer and answer.casefold() in state.rejected_answers:
        answer = None
    origin = 'memória de correções' if remembered else 'modelo visual local'
    if not answer and not ia_status()['configurada']:
        # Só sugere uma palavra sem IA se houver exatamente um candidato com o tamanho exigido.
        lengths = [f['limit'] for f in quiz['campos'] if f.get('limit')]
        size = lengths[0] if lengths else 0
        matches = [w for w in words if len(w)==size and w.isalpha()] if size else []
        if len(matches)==1:
            answer = matches[0]
            origin = 'lista de palavras'
        else:
            return outcome('sem_ia', 'Lacuna identificada, mas não há IA configurada. '
                           'Execute CONFIGURAR_IA_LOCAL.bat para analisar frases e vocabulário.', etapa)
    if not answer:
        selected=max(quiz['campos'],key=lambda f:f.get('score',0))
        hint=f"{selected.get('limit') or '?'} letras; padrão: {selected.get('pattern','')}"
        field = {'contexto': phrase, 'label': 'Palavra que falta', 'placeholder': hint}
        # A memória global contém palavras de outras aulas; não é uma lista de opções.
        prompt_text = phrase + '\nDicas obrigatórias: ' + hint
        field['rejeitadas']=state.rejected_answers[-4:]
        field['letras_disponiveis']=''.join(selected.get('letter_bank') or quiz.get('banco_letras') or [])
        field['tamanhos_palavras']=selected.get('word_lengths') or []
        try:
            answers = await run_inference(suggest, [field], prompt_text, runner=state.inference,
                                         validator=lambda values: isinstance(values,list) and len(values)==1
                                         and fits_quiz(values[0],selected)
                                         and values[0].casefold() not in state.rejected_answers)
            answer = answers[0].strip() if answers else ''
            origin = 'IA local'
        except Exception as exc:
            return outcome('erro_ia', 'IA indisponível: '+str(exc)[:160], etapa)
    if not answer or answer in ('?', 'não sei', 'unknown'):
        return outcome('incerto', 'Não consegui determinar uma palavra com segurança. Mantendo a lacuna aberta.', etapa)
    answer = clean(answer, 90)
    if len(answer.split()) > 3:
        return outcome('incerto', 'A resposta sugerida não parece ser uma única palavra. Não digitei.', etapa)
    # A IA pode terminar depois do cronômetro; nunca digite numa questão encerrada.
    fresh = await inspect_quiz(page)
    if fresh.get('expirou') or fresh.get('quiz_concluido') or fresh.get('correta'):
        return outcome('aguardando', 'A questão já foi encerrada. Conferindo o próximo passo.', etapa)
    if clean(fresh.get('frase',''),280) != phrase:
        return outcome('aguardando', 'A pergunta mudou durante a análise. Relendo a atividade atual.', etapa)
    quiz = fresh
    selected = max(quiz['campos'], key=lambda f: f.get('score', 0)) if quiz.get('campos') else {}
    if selected.get('group'):
        letters = re.sub(r'[^A-Za-z]', '', answer).casefold()
        pattern = selected.get('pattern', '').casefold()
        if (selected.get('limit') and len(letters) != selected['limit']) or (pattern and (
            len(pattern) != len(letters) or any(p != '_' and p != a for p, a in zip(pattern, letters))
        )):
            if answer.casefold() not in state.rejected_answers:
                state.rejected_answers.append(answer.casefold())
            return outcome('incerto', 'A sugestão não respeita as dicas. Vou pedir outra resposta.', etapa)
    try:
        pointer = await type_quiz_answer(page, quiz, answer, enter=submit)
    except (RuntimeError, ValueError) as exc:
        return outcome('campo', 'Reconheci a lacuna, mas não consegui digitar: '+str(exc), etapa)
    state.last_answer, state.attempt_time = answer, time.monotonic()
    return outcome('lacuna_video', f'Preenchi uma resposta da {origin}.'+
                   (' Pressionei Enter e estou conferindo.' if submit else ' Aguardando confirmação.'), etapa,
                   preenchidas=1, ponteiro=pointer, resposta=answer, enviadas=submit)


async def _handle_multiple_choice(page, quiz: dict, etapa: dict, state: EngineState, *, submit: bool) -> dict:
    question = clean(quiz.get('pergunta', ''), 500)
    options = quiz.get('opcoes') or []
    labels = [clean(option.get('text', ''), 180) for option in options]
    signature = (question.casefold() + '|' + '|'.join(label.casefold() for label in labels))
    quiz_id = state.real.cursor.pending.partition(':')[2] if state.real.cursor.pending.startswith('quiz:') else ''

    if quiz.get('quiz_concluido'):
        if quiz_id:
            return outcome('quiz_concluido', 'A plataforma mostrou o resultado final do quiz.', etapa,
                           quiz_concluido=quiz_id)
        return outcome('conferencia', 'A plataforma mostrou o resultado final do quiz.', etapa)
    if quiz.get('correta'):
        if submit and await _click_unique(page, SAFE_QUIZ_NEXT):
            return outcome('quiz_resposta', 'Resposta aceita pela plataforma. Avançando para a próxima questão.', etapa)
        return outcome('conferencia', 'Resposta aceita pela plataforma. Aguardando a próxima questão.', etapa)
    if quiz.get('incorreta'):
        corrected = read_correction(quiz.get('feedback', ''))
        corrected_option = next((label for label in labels if corrected and label.casefold() == corrected.casefold()), '')
        if submit and corrected_option and state.choice_attempts < 2:
            try:
                pointer = await select_quiz_choice(page, quiz, corrected_option)
                state.choice_answer, state.choice_time = corrected_option, time.monotonic()
                state.choice_attempts += 1
                sent = await _click_unique(page, SAFE_QUIZ_CONFIRM)
                return outcome('quiz_resposta', 'Selecionei a correção que a plataforma exibiu.'+
                               (' Enviei para conferência.' if sent else ' Aguardando conferência.'), etapa,
                               resposta=corrected_option, enviadas=sent, ponteiro=pointer)
            except Exception as exc:
                return outcome('ajuda', 'A correção apareceu, mas não consegui selecionar a opção com segurança: '+str(exc), etapa)
        return outcome('ajuda', 'A plataforma marcou a alternativa como incorreta. Confira a explicação antes de tentar novamente.', etapa)

    if not question or len(labels) < 2:
        return outcome('incerto', 'Quiz reconhecido, mas não encontrei pergunta e opções suficientes para responder com segurança.', etapa)
    if signature != state.choice_question:
        state.choice_question, state.choice_answer = signature, ''
        state.choice_time, state.choice_attempts = 0.0, 0
    if state.choice_answer:
        elapsed = int(time.monotonic() - state.choice_time)
        if elapsed > 30:
            return outcome('ajuda', 'A alternativa foi selecionada, mas o site não mostrou retorno após 30 segundos. Confira a tela.', etapa)
        return outcome('aguardando', f'Alternativa selecionada. Aguardando retorno do quiz ({elapsed}s).', etapa)
    if not ia_status()['configurada']:
        return outcome('sem_ia', 'Quiz de múltipla escolha reconhecido. Configure a IA local para sugerir uma alternativa.', etapa)
    try:
        answer = await run_inference(suggest_quiz_choice, question, labels, quiz.get('texto', ''), runner=state.inference)
    except Exception as exc:
        return outcome('erro_ia', 'IA indisponível para o quiz: '+str(exc)[:160], etapa)
    if answer == '?' or answer.casefold() not in {label.casefold() for label in labels}:
        return outcome('incerto', 'A IA não conseguiu escolher com segurança entre as opções. A questão ficou aberta.', etapa)
    fresh = await inspect_quiz(page)
    fresh_labels = [clean(o.get('text', ''), 180) for o in fresh.get('opcoes', [])]
    if (not fresh.get('ativa') or fresh.get('tipo') != 'multipla_escolha' or
            clean(fresh.get('pergunta', ''), 500) != question or fresh_labels != labels or
            fresh.get('correta') or fresh.get('incorreta') or fresh.get('quiz_concluido')):
        return outcome('aguardando', 'A pergunta mudou durante a análise. Relendo o quiz.', etapa)
    quiz = fresh
    try:
        pointer = await select_quiz_choice(page, quiz, answer)
    except (RuntimeError, ValueError) as exc:
        return outcome('campo', 'As opções do quiz mudaram antes da seleção: '+str(exc), etapa)
    sent = bool(submit and await _click_unique(page, SAFE_QUIZ_CONFIRM))
    state.choice_answer, state.choice_time, state.choice_attempts = answer, time.monotonic(), 1
    return outcome('quiz_resposta', 'Alternativa sugerida pela IA selecionada.'+
                   (' Enviada para conferência.' if sent else ' Aguardando conferência.'), etapa,
                   resposta=answer, enviadas=sent, ponteiro=pointer, quiz_id=quiz_id)


async def _finish_quiz(page, quiz_id, state, etapa, *, submit):
    if state.quiz_failed:
        if submit and await _click_unique(page, {'praticar suas palavras de novo', 'praticar novamente',
                'tentar novamente', 'refazer quiz', 'practice your words again', 'try again', 'retake quiz',
                'revise suas palavras perdidas', 'review your missed words'}):
            state.quiz_failed = False
            state.last_question = state.last_answer = state.choice_question = state.choice_answer = ''
            return outcome('navegacao', 'Houve erro nesta tentativa. Refazendo o quiz com as correções aprendidas.', etapa)
        return outcome('conferencia', 'Este quiz teve erros e continua pendente. Aguardando o botão para refazer.', etapa)
    if not submit:
        return outcome('conferencia', 'Quiz concluído. Ative a confirmação automática para avançar.', etapa)
    course_id = state.real.cursor.course_id
    match = re.search(r'/course/(\d+)', urlparse(page.url).path)
    if match:
        course_id = match.group(1)
    if not re.fullmatch(r'\d+', course_id or ''):
        return outcome('ajuda', 'Quiz concluído. Abra a lista do curso para continuar.', etapa,
                       quiz_concluido=quiz_id)
    await page.goto('https://pt.englishcentral.com/course/' + course_id,
                    wait_until='domcontentloaded', timeout=35000)
    state.last_question = state.last_answer = state.choice_question = state.choice_answer = ''
    return outcome('navegacao', 'Quiz concluído. Voltando ao curso para a próxima atividade pendente.', etapa,
                   quiz_concluido=quiz_id)


async def process_page(page, *, submit: bool = False, allow_word_start: bool = True,
                       engine: EngineState | None = None,
                       modo: ModoEstudo | None = None) -> dict:
    if google_login_url(page.url):
        return {'tipo':'login','mensagem':'Escolha sua conta na aba do Google. O assistente aguarda e retoma quando o curso estiver disponível.',
                'etapa':{'codigo':'login','rotulo':'Aguardando seu login','detalhe':'Nenhuma credencial é lida ou preenchida pelo assistente.'}}
    if not is_englishcentral(page.url):
        return {'tipo': 'fora', 'mensagem': 'Abra uma aula do EnglishCentral. Nenhuma ação feita.',
                'etapa': {'codigo':'fora','rotulo':'Fora do EnglishCentral', 'detalhe':'Nenhuma ação nesta página.'}}
    state = engine if engine is not None else EngineState()
    tour=await dismiss_course_tour(page,allowed=state.course_tour_attempts<2)
    if tour is not None:
        if tour:
            state.course_tour_attempts+=1
            return {'tipo':'navegacao','mensagem':'Tour inicial do curso fechado pelo botão Pular. Relendo as atividades.'}
        return {'tipo':'ajuda','mensagem':'O tour inicial está cobrindo as atividades. Feche o tour para continuar.'}
    state.course_tour_attempts=0
    modo = modo or ModoEstudo(quiz=True)
    state.real.inference = state.inference
    gate = await _page_gate(page)
    if gate.get('login'):
        return outcome('login', 'Faça login na janela do Chrome. Não leio senhas.',
                       {'codigo':'login','rotulo':'Login necessário','detalhe':'Nenhuma senha será lida.'})
    if gate.get('captcha'):
        return outcome('verificacao', 'Verificação humana detectada; precisa de você.',
                       {'codigo':'verificacao','rotulo':'Verificação necessária','detalhe':'Conclua a verificação na janela do Chrome.'})

    # Confira conclusão antes de responder a controles que ficaram no player.
    completed_player = await inspect_ec_player(page)
    if (modo.falar and completed_player.get('mode') == 'speak' and not completed_player.get('speak_complete')
            and (not modo.assistir or completed_player.get('watch_complete'))
            and (not modo.aprender or completed_player.get('learn_complete'))):
        if completed_player.get('lesson_id') and state.real.lesson != completed_player['lesson_id']:
            await process_ec_page(page,state.real,submit=submit,allow_word_start=allow_word_start,
                                  modo=modo,snapshot=completed_player)
        return await _handle_synthetic_speech(page,completed_player,state,submit=submit)
    if completed_player.get('supported') and modo.etapas and all(
        completed_player.get({'assistir':'watch_complete', 'aprender':'learn_complete',
                              'falar':'speak_complete', 'conversar':'chat_complete'}[step]) is True for step in modo.etapas
    ):
        if state.real.lesson != completed_player.get('lesson_id') or not state.real.watch_required_full or state.real.watch_finished_in_session:
            return await process_ec_page(page, state.real, submit=submit,
                                         allow_word_start=allow_word_start, modo=modo, snapshot=completed_player)

    quiz = await inspect_quiz(page)
    # Um formulário com a frase no próprio label pode usar o leitor genérico.
    # A ausência de legendas, vídeo e caixas de letras não deve ocultar esse texto.
    if (quiz.get('ativa') and quiz.get('tipo') == 'lacuna' and not quiz.get('video')
            and not quiz.get('frase') and not quiz.get('trechos') and quiz.get('campos')
            and all(not field.get('group') and field.get('inViewport')
                    and re.search(r'_{2,}', field.get('contexto', '')) for field in quiz['campos'])):
        quiz['ativa'] = False
    review_count = re.search(r'(\d+)\s+palavras?\s+dispon[ií]ve(?:l|is)\s+para\s+(?:o\s+)?quiz', quiz.get('texto',''), re.I)
    start_text = re.search(r'comece\s+(?:o\s+)?quiz|come[çc]ar\s+(?:o\s+)?quiz|iniciar\s+o\s+teste|start\s+(?:test|quiz)', quiz.get('texto',''), re.I)
    if modo.quiz and start_text and (not review_count or int(review_count[1]) > 0):
        if not submit:
            return outcome('conferencia', 'Há palavras pendentes. Ative a confirmação para iniciar a revisão.', {})
        targets=await _quiz_start_buttons(page)
        if len(targets)==1:
            await _recover_quiz_cursor(page,state)
            key=state.real.cursor.pending or page.url
            start_signature=key+'|'+targets[0][1].casefold()
            if state.quiz_start_signature==start_signature and time.monotonic()-state.review_started_at < 5:
                return outcome('aguardando', 'Aguardando o quiz de revisão abrir.', {})
            is_word_list=review_count or re.search(r"comece|come[çc]ar",targets[0][1],re.I)
            if is_word_list:
                await learn_review(page,include_all=True)
                state.quiz_word_list_attempt=key
            elif state.quiz_word_list_attempt!=key:
                word_tabs=await _quiz_start_buttons(page,word_list=True)
                preferred=[tab for tab in word_tabs if re.fullmatch(r'ver palavras|view words',tab[1],re.I)]
                if len(preferred)==1:word_tabs=preferred
                state.quiz_word_list_attempt=key
                if len(word_tabs)==1:
                    await word_tabs[0][0].click(timeout=5000)
                    return outcome('navegacao','Lendo a lista de palavras do quiz antes de começar.',{})
            await targets[0][0].click(timeout=5000)
            state.review_started_at=time.monotonic()
            state.quiz_start_signature=start_signature
            state.quiz_failed=False
            state.last_question=state.last_answer=''
            state.quiz_intro_attempts=0
            return outcome('navegacao', 'Iniciando o quiz com as palavras que ficaram pendentes.' if review_count else 'Iniciando as perguntas do quiz.', {})
        return outcome('aguardando','Aguardando um botão de início disponível no quiz.',{})
    score = re.search(r'acertou\s+(\d+)\s+de\s+(\d+)(?:\s+palavras?)?', quiz.get('texto', ''), re.I)
    if quiz.get('quiz_concluido') and score:
        state.quiz_failed = int(score[1]) < int(score[2])
        if state.quiz_failed:
            return await _finish_quiz(page, '', state, classify_stage({'quiz':quiz}), submit=submit)
        if int(score[2]) > 0:
            cursor=state.real.cursor
            quiz_id=cursor.pending.partition(':')[2] if cursor.pending.startswith('quiz:') else ''
            if not quiz_id:
                from course_flow import inspect_course
                course=await inspect_course(page)
                cards=[c for u in course.get('units',[]) if u.get('active')
                       for c in u.get('cards',[]) if c.get('quiz') and not c.get('locked')]
                if len(cards)==1:
                    quiz_id=cards[0].get('quiz_key','')
                    cursor.course_id=course.get('course_id','')
            if quiz_id:
                return await _finish_quiz(page,quiz_id,state,classify_stage({'quiz':quiz}),submit=submit)
            return await _finish_quiz(page,'',state,classify_stage({'quiz':quiz}),submit=submit)
    if modo.quiz and not quiz.get('video') and (quiz.get('expirou') or quiz.get('incorreta')):
        state.quiz_failed = True
    if modo.quiz and (quiz.get('expirou') or quiz.get('questao_encerrada') or quiz.get('correta')):
        correction = read_correction(quiz.get('feedback', ''))
        if correction and state.last_question:
            store_correction(state.last_question, correction)
        if submit and await _click_unique(page, {'continuar', 'continue'}):
            state.last_question = state.last_answer = ''
            return outcome('navegacao', 'Questão encerrada. Avançando para a próxima pergunta.', classify_stage({'quiz': quiz}))
    # Um clique no cartão pode falhar sem abrir o teste. Não aguarde um quiz inexistente.
    cursor = state.real.cursor
    if (cursor.pending.startswith('quiz:') and not quiz.get('ativa')
            and not quiz.get('campos') and not quiz.get('correta')
            and not re.search(r'iniciar o teste|start test|start quiz|REPORT|continuar|continue', quiz.get('texto', ''), re.I)
            and time.monotonic() - cursor.pending_since > 15):
        from course_flow import inspect_course
        course = await inspect_course(page)
        if course.get('supported') and not course.get('player'):
            cursor.pending = ''
            cursor.pending_attempts = 0
            return outcome('aguardando', 'O quiz não abriu. Relendo o cartão para tentar novamente.', {})
    etapa = classify_stage({'quiz': quiz})
    if quiz.get('quiz_concluido') and state.real.cursor.pending.startswith('quiz:'):
        quiz_id = state.real.cursor.pending.partition(':')[2]
        return await _finish_quiz(page, quiz_id, state, etapa, submit=submit)
    if modo.quiz and quiz.get('questao_encerrada'):
        if submit and await _click_unique(page, {'continuar','continue'}):
            state.last_question = state.last_answer = ''
            return outcome('navegacao', 'Questão encerrada. Avançando para a próxima pergunta do quiz.', etapa)
        return outcome('conferencia', 'Questão encerrada. Aguardando o botão Continuar.', etapa)

    if modo.quiz and submit and state.real.cursor.pending.startswith('quiz:') and not quiz.get('ativa'):
        if re.search(r'\b(?:iniciar o teste|start test|start quiz)\b', quiz.get('texto', ''), re.I):
            key = state.real.cursor.pending
            if state.quiz_intro_key != key:
                state.quiz_intro_key, state.quiz_intro_attempts = key, 0
            if state.quiz_intro_attempts and time.monotonic() - state.quiz_intro_time < 15:
                return outcome('aguardando', 'Aguardando o teste abrir após iniciar.', etapa)
            if state.quiz_intro_attempts >= 2:
                return outcome('ajuda', 'O botão Iniciar o teste não abriu as perguntas após duas tentativas.', etapa)
            targets=[]
            for frame in page.frames[:15]:
                for target in await frame.get_by_text(re.compile(r'^(?:Iniciar o teste|Start test|Start quiz)$',re.I)).all():
                    if await target.is_visible() and await target.is_enabled():
                        targets.append(target)
            if len(targets)==1:
                await targets[0].click(timeout=5000)
                state.quiz_intro_time = time.monotonic()
                state.quiz_intro_attempts += 1
                return outcome('navegacao', 'Iniciando as perguntas do quiz.', etapa)

    if quiz.get('ativa') and quiz.get('tipo') == 'multipla_escolha':
        if not modo.quiz:
            return outcome('aguardando', 'Quizzes ignorados no modo selecionado.', etapa)
        return await _handle_multiple_choice(page, quiz, etapa, state, submit=submit)

    # O quiz sobreposto tem prioridade sobre o player da aula ao fundo.
    if quiz.get('ativa') and quiz.get('tipo') == 'lacuna' and (quiz.get('expirou') or not quiz.get('video')):
        if not modo.quiz:
            return outcome('aguardando', 'Quizzes ignorados no modo selecionado.', etapa)
        if quiz.get('expirou'):
            if submit and await _click_unique(page, {'continuar', 'continue'}):
                state.last_question, state.last_answer = '', ''
                return outcome('navegacao', 'O tempo da questão acabou. Avancei pelo botão Continuar do quiz.', etapa)
            return outcome('conferencia', 'Questão encerrada por tempo. Aguardando Continuar.', etapa)
        return await _handle_video_quiz(page, quiz, etapa, state, submit=submit)

    # O player Angular é mais rápido de consultar que a inspeção genérica dos frames.
    real_result = await process_ec_page(page, state.real, submit=submit,
                                        allow_word_start=allow_word_start, modo=modo, snapshot=completed_player)
    if real_result is not None:
        if real_result.get('tipo') == 'fala' and modo.falar:
            return await _handle_synthetic_speech(page, completed_player, state, submit=submit)
        if real_result.get('tipo') == 'conversa' and getattr(modo, 'conversar', False):
            return await _handle_mimi_conversation(page, completed_player, state, submit=submit)
        return real_result

    info = await inspect_page(page)
    info['quiz'] = quiz
    etapa = classify_stage(info)
    if info['loginDetectado']:
        return outcome('login', 'Faça login na janela do Chrome. Não leio senhas.', etapa)
    text = (info.get('textoVisivel') or '').lower()
    if 'captcha' in text or 'verify you are human' in text or 'não sou um robô' in text:
        return outcome('verificacao', 'Verificação humana detectada; precisa de você.', etapa)

    # Fallback genérico: respeitar o modo selecionado. Enquanto Assistir
    # estiver pendente, não digitar palavras nem avançar para o treino.
    # Quizzes têm controle separado de vocabulário. A lacuna sobre vídeo não
    # deve ser ignorada só porque o treino de palavras está desmarcado.
    if etapa['codigo'] == 'lacuna_video':
        if not modo.quiz:
            return outcome('aguardando', 'Quizzes ignorados no modo selecionado.', etapa)
        return await _handle_video_quiz(page, quiz, etapa, state, submit=submit)

    if not modo.aprender and etapa['codigo'] in ('palavras_selecao', 'palavras'):
        return outcome('aguardando', 'Treino de palavras ignorado no modo selecionado.', etapa)

    # Essa prioridade é essencial: o menu/painel de palavras pode manter o HTML
    # do player do vídeo anterior, mas isso NÃO significa que o vídeo é a etapa ativa.
    if etapa['codigo'] == 'palavras_selecao':
        terms = await inspect_words(page)
        if terms:
            store_words(terms)
        if allow_word_start and etapa['proximo'] == 'iniciar_palavras':
            try:
                pointer = await _start_words(page)
                if pointer:
                    return outcome('navegacao', f'Guardei {len(terms)} palavra(s) visíveis e iniciei o treino. Observando a próxima tela.', etapa,
                                   acao='iniciar_palavras', ponteiro=pointer)
            except Exception:
                pass
        return outcome('palavras', 'Etapa de palavras reconhecida. Observando o exercício; não vou repetir o vídeo.', etapa)

    fields = [f for f in info['campos'] if not f['preenchido'] and f.get('dica')]
    if fields:
        if not ia_status()['configurada']:
            return outcome('configuracao', 'Lacunas encontradas; falta configurar a IA local (Ollama).', etapa)
        selected = fields[:10]
        answers = await run_inference(suggest, selected, info.get('textoVisivel', ''), runner=state.inference)
        filled = 0
        for f, answer in zip(selected, answers):
            if answer.strip().casefold() in ('?', 'não sei', 'unknown'):
                continue
            if page.url != info['url']:
                return outcome('mudou', f'Página mudou após {filled} resposta(s).', etapa)
            try:
                await fill_selected(page, f['frame'], f['id'], answer)
                filled += 1
            except Exception:
                continue
        submitted = bool(submit and filled == len(selected) and len(fields) <= 10 and
                         await _click_unique(page, SAFE_CONFIRM))
        return outcome('lacunas', f'{filled} lacuna(s) preenchida(s).' +
                       (' Enviadas para conferência.' if submitted else ' Aguardando conferência.'), etapa,
                       preenchidas=filled, enviadas=submitted)

    if etapa['codigo'] == 'palavras':
        return outcome('palavras', 'Vocabulário aberto. A atividade não expõe lacunas HTML reconhecíveis.', etapa)
    if etapa['codigo'] == 'fala':
        return outcome('ajuda' if modo.falar else 'audio',
                       'Não consegui identificar a área de gravação com segurança. Reabra a atividade de fala pelo painel.' if modo.falar else
                       'Atividade de fala ignorada conforme as configurações.', etapa)
    if info.get('videoEtapaConcluida') and modo.aprender:
        lesson_key = f"{info['url']}|{info['titulo']}"
        if state.words_opened_key == lesson_key:
            return outcome('aguardando', 'Etapa de palavras já foi aberta; aguardando a tela carregar.', etapa)
        pointer = await _open_words_step(page)
        if pointer:
            state.words_opened_key = lesson_key
            return outcome('navegacao', 'A página indicou o vídeo como concluído. Abri “Aprenda as palavras”.', etapa, ponteiro=pointer)
        return outcome('concluido', 'A página indica que o vídeo foi concluído. Aguardando a etapa de palavras.', etapa)
    if info['videos'] and modo.assistir:
        if len(info['videos']) != 1:
            return outcome('ajuda', 'Há mais de um vídeo visível; confira qual atividade deve ser acompanhada.', etapa)
        video = info['videos'][0]
        now = time.monotonic()
        video_key = f"{info['url']}|{info['titulo']}|{video.get('origem','')}|{video.get('duracao')}"
        if state.last_video_key != video_key:
            state.last_video_key, state.last_video_time = video_key, 0.0
            state.last_video_position = float(video.get('posicao') or 0)
            state.last_video_progress_at, state.last_video_ended_at = now, 0.0
            state.generic_video_replays = state.generic_video_resumes = 0
        if info.get('videoEtapaConcluida'):
            nav = await choose_navigation(page, next_only=True)
            return {**nav, 'etapa': etapa}
        if video.get('erro'):
            return outcome('ajuda', 'O vídeo apresentou erro de mídia. Assistir continua pendente; confira a conexão e reabra a aula.', etapa)
        position = float(video.get('posicao') or 0)
        if position > state.last_video_position + .1:
            state.last_video_position, state.last_video_progress_at = position, now
        replay = False
        if video.get('concluidoNoPlayer'):
            if not state.last_video_ended_at:
                state.last_video_ended_at = now
            elapsed = now-state.last_video_ended_at
            replay = elapsed >= 12 and state.generic_video_replays == 0
            if not replay:
                return outcome('ajuda' if elapsed > 45 else 'aguardando',
                               'A mídia terminou, mas o site ainda não confirmou Assistir. A atividade permanece pendente.', etapa)
        else:
            state.last_video_ended_at = 0.0
        should_start = not video.get('reproduzindo') and (not state.last_video_time or
                       (now-state.last_video_progress_at > 20 and state.generic_video_resumes < 2))
        if replay or should_start:
            try:
                if info.get('paginaVisivel') is False:
                    await page.bring_to_front()
                await toggle_video(page, video['frame'], video['id'], 'play')
                if replay:
                    state.generic_video_replays += 1
                    state.last_video_ended_at = 0.0
                    state.last_video_position = -1.0
                elif state.last_video_time:
                    state.generic_video_resumes += 1
                state.last_video_time = state.last_video_progress_at = now
                return outcome('video', 'Nova tentativa pelo controle oficial; aguardando o registro do site.' if replay else
                               'Acionei a reprodução pela interface. Conferindo se o tempo avança e se o site registra Assistir.', etapa)
            except Exception as exc:
                return outcome('ajuda', 'Não consegui acionar a reprodução com segurança: '+str(exc)[:180], etapa)
        if now-state.last_video_progress_at > 60:
            return outcome('ajuda', 'O tempo do vídeo não avança há mais de 60 segundos. Assistir continua pendente.', etapa)
        return outcome('video', 'Observando o avanço do vídeo e aguardando a confirmação de Assistir pelo site.', etapa)
    if info['audioIgnorado']:
        return outcome('audio', 'Áudio detectado e ignorado.', etapa)
    if modo.aprender and etapa['codigo'] not in ('palavras', 'palavras_selecao', 'lacuna_video'):
        return outcome('aguardando', 'Modo palavras: aguardando identificar a etapa de aprendizado sem reproduzir o vídeo.', etapa)
    nav = await choose_navigation(page)
    return {**nav, 'etapa': etapa}
