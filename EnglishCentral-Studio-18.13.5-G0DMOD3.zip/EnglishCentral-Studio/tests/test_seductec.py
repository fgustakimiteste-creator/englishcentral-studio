"""Compatibilidade SEDUCTEC/Moodle; sem login real nem envio de respostas."""
import asyncio
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import pytest
from fastapi import HTTPException

import servidor
from browser_session import choose_page, session_tab, seductec_url, tab_label
from moodle_adapter import (is_seductec_url, normalize_seductec_url, page_kind,
                            platform_info)


def fake_tab(url, closed=False):
    page = MagicMock()
    page.url = url
    page.is_closed.return_value = closed
    page.goto = AsyncMock()
    page.bring_to_front = AsyncMock()
    return page


def test_seductec_aceita_apenas_origem_https_exata():
    assert is_seductec_url('https://seductec.seduc.pi.gov.br/')
    assert seductec_url('https://seductec.seduc.pi.gov.br/course/view.php?id=7')
    for url in (
        'http://seductec.seduc.pi.gov.br/',
        'https://seductec.seduc.pi.gov.br.evil.example/',
        'https://evil.example/?next=seductec.seduc.pi.gov.br',
        'https://user:pass@seductec.seduc.pi.gov.br/',
        'https://seductec.seduc.pi.gov.br:444/',
    ):
        assert not is_seductec_url(url)


def test_platform_info_falha_fechado_para_origens_desconhecidas():
    assert platform_info('https://pt.englishcentral.com/myclass/232103/0/courses')['id'] == 'englishcentral'
    unknown = platform_info('https://example.org/course/view.php?id=7')
    assert unknown['id'] == 'desconhecida'
    assert unknown['automacao_especifica'] is False
    assert platform_info('http://pt.englishcentral.com/course/123')['id'] == 'desconhecida'


def test_normaliza_remove_fragmento_e_chaves_de_sessao():
    url = normalize_seductec_url(
        'https://seductec.seduc.pi.gov.br/course/view.php?id=42&sesskey=segredo#top')
    assert url == 'https://seductec.seduc.pi.gov.br/course/view.php?id=42'
    with pytest.raises(ValueError):
        normalize_seductec_url('https://seductec.seduc.pi.gov.br.evil.example/')
    with pytest.raises(ValueError):
        normalize_seductec_url('https://seductec.seduc.pi.gov.br/login/logout.php?sesskey=abc')


def test_detecta_tipos_de_pagina_moodle():
    assert page_kind('https://seductec.seduc.pi.gov.br/login/index.php') == 'login'
    assert page_kind('https://seductec.seduc.pi.gov.br/course/view.php?id=12') == 'curso'
    assert page_kind('https://seductec.seduc.pi.gov.br/mod/quiz/view.php?id=15') == 'quiz_inicio'
    assert page_kind('https://seductec.seduc.pi.gov.br/mod/quiz/attempt.php?attempt=15') == 'questionario'
    info = platform_info('https://seductec.seduc.pi.gov.br/mod/forum/view.php?id=16')
    assert info['id'] == 'seductec' and info['tipo_pagina'] == 'forum'
    assert info['automacao_especifica'] is True


def test_moodle_e_reconhecido_na_lista_de_abas_sem_aceitar_hosts_parecidos():
    url = 'https://seductec.seduc.pi.gov.br/course/view.php?id=5'
    page = fake_tab(url)
    assert session_tab(url)
    assert tab_label(url) == 'SEDUCTEC · Curso'
    assert choose_page([page], preferred=url) is page
    assert choose_page([fake_tab('https://seductec.seduc.pi.gov.br.evil.example/')]) is None


def test_target_url_salva_seductec_sem_dados_de_sessao(monkeypatch, tmp_path):
    monkeypatch.setattr(servidor, 'DATA', tmp_path)
    monkeypatch.setattr(servidor, 'LAST_TARGET_FILE', tmp_path / 'ultimo_destino.txt')
    monkeypatch.setattr(servidor, 'COURSE_FILE', tmp_path / 'ultimo_curso.txt')
    incoming = 'https://seductec.seduc.pi.gov.br/course/view.php?id=987&sesskey=privado#secao'
    result = servidor.target_url(incoming)
    assert result == 'https://seductec.seduc.pi.gov.br/course/view.php?id=987'
    assert servidor.target_url() == result
    assert (tmp_path / 'ultimo_destino.txt').read_text() == result


def test_selecionar_ambiente_seductec_abre_aba_separada_sem_fechar_englishcentral(monkeypatch, tmp_path):
    async def run():
        page = fake_tab('https://pt.englishcentral.com/course/8597')
        new_page = fake_tab('about:blank')
        new_page.bring_to_front = AsyncMock()
        async def navigate(target, **kwargs):
            new_page.url = target
        new_page.goto = AsyncMock(side_effect=navigate)
        context = SimpleNamespace(pages=[page, new_page], new_page=AsyncMock(return_value=new_page))
        page.context = context
        new_page.context = context
        monkeypatch.setattr(servidor, 'DATA', tmp_path)
        monkeypatch.setattr(servidor, 'LAST_TARGET_FILE', tmp_path / 'ultimo_destino.txt')
        monkeypatch.setattr(servidor, 'COURSE_FILE', tmp_path / 'ultimo_curso.txt')
        monkeypatch.setattr(servidor, 'current_page', lambda: page)
        monkeypatch.setattr(servidor, 'available_pages', lambda **kwargs: [page, new_page])
        monkeypatch.setattr(servidor, 'page', page)
        monkeypatch.setattr(servidor, 'browser_owned', True)
        monkeypatch.setattr(servidor, 'auto_running', False)
        monkeypatch.setattr(servidor, 'auto_task', None)
        monkeypatch.setattr(servidor, 'lock', asyncio.Lock())
        monkeypatch.setattr(servidor, 'pause_for_manual_action', AsyncMock())
        result = await servidor.select_course(servidor.CourseSelection(
            ano=3, etapa=2,
            url='https://seductec.seduc.pi.gov.br/course/view.php?id=765&sesskey=private#section-1'))
        new_page.goto.assert_awaited_once_with(
            'https://seductec.seduc.pi.gov.br/course/view.php?id=765',
            wait_until='domcontentloaded', timeout=35000)
        assert page.url == 'https://pt.englishcentral.com/course/8597'
        assert 'SEDUCTEC aberto em sua própria aba' in result['mensagem']
        assert result['aba_nova'] is True and result['plataforma'] == 'seductec'
        assert 'sesskey' not in (tmp_path / 'ultimo_destino.txt').read_text()

        back = await servidor.select_course(servidor.CourseSelection(
            ano=3, etapa=2, url='https://pt.englishcentral.com/myclass/232103/0/courses'))
        assert back['aba_nova'] is False and back['plataforma'] == 'englishcentral'
        assert page.goto.await_count == 1
        assert new_page.url == 'https://seductec.seduc.pi.gov.br/course/view.php?id=765'
    asyncio.run(run())


def test_auto_englishcentral_e_bloqueado_no_seductec(monkeypatch):
    async def run():
        page = fake_tab('https://seductec.seduc.pi.gov.br/mod/quiz/view.php?id=1')
        monkeypatch.setattr(servidor, 'current_page', lambda: page)
        monkeypatch.setattr(servidor, 'auto_running', False)
        monkeypatch.setattr(servidor, 'auto_task', None)
        with pytest.raises(HTTPException) as error:
            await servidor._auto_start_locked(servidor.AutoStart(quiz=True))
        assert error.value.status_code == 409
        assert 'SEDUCTEC reconhecido' in error.value.detail
    asyncio.run(run())


def test_resumo_englishcentral_nao_inventa_unidades_para_moodle(monkeypatch):
    async def run():
        page = fake_tab('https://seductec.seduc.pi.gov.br/course/view.php?id=77')
        monkeypatch.setattr(servidor, 'current_page', lambda: page)
        monkeypatch.setattr(servidor, 'lock', asyncio.Lock())
        monkeypatch.setattr(servidor, 'inspect_course', AsyncMock(side_effect=AssertionError('Não usar parser EC')))
        result = await servidor.course_summary()
        assert result['supported'] is False
        assert result['plataforma'] == 'seductec'
    asyncio.run(run())


def test_page_platform_expoe_recursos_moodle():
    info = servidor.page_platform('https://seductec.seduc.pi.gov.br/mod/quiz/attempt.php?attempt=3')
    assert info['id'] == 'seductec'
    assert {'leitura', 'inspecao', 'video'}.issubset(set(info['ferramentas']))
