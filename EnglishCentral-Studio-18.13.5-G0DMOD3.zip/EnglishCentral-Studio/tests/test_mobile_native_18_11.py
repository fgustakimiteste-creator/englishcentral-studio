"""HTTP, service worker, pessoas e áudio reais, com contas de teste locais."""
import asyncio
import base64
import os
from pathlib import Path
import shutil
import signal
import socket
import subprocess
import sys
import time

import httpx
from playwright.async_api import async_playwright, expect
import pytest

from conftest import chromium_launch_options
import fala_sintetica

ROOT = Path(__file__).resolve().parents[1]
TOKEN = 'fixture-server-token-1811'


@pytest.fixture
def native_server(tmp_path):
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0)); port = sock.getsockname()[1]
    env = os.environ.copy()
    for key in ['EC_IA_CHAVE', 'EC_IA_MODELO', 'EC_IA_PROVEDOR', 'EC_IA_URL']:
        env.pop(key, None)
    env.update(EC_DATA_DIR=str(tmp_path / 'data'), EC_PROFILES_ROOT=str(tmp_path / 'data'),
               EC_PANEL_TOKEN=TOKEN, EC_REMOTE_MODE='1', EC_PUBLIC_URL='https://estudos.example.com')
    base = f'http://127.0.0.1:{port}'
    with (tmp_path / 'server.log').open('w') as log:
        options = {'start_new_session': True} if os.name != 'nt' else {'creationflags': subprocess.CREATE_NEW_PROCESS_GROUP}
        process = subprocess.Popen([sys.executable, str(ROOT / 'servidor.py'), '--port', str(port)],
                                   cwd=ROOT, env=env, stdout=log, stderr=log, **options)
        try:
            end = time.monotonic() + 15
            with httpx.Client(trust_env=False, timeout=1) as client:
                while True:
                    try:
                        if client.get(base + '/').status_code == 200: break
                    except httpx.HTTPError: pass
                    if process.poll() is not None or time.monotonic() > end:
                        raise AssertionError('Servidor de teste não iniciou: ' + (tmp_path / 'server.log').read_text())
                    time.sleep(.1)
            yield base
        finally:
            if os.name != 'nt':
                try: os.killpg(process.pid, signal.SIGTERM)
                except ProcessLookupError: pass
            else:
                subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'], capture_output=True, check=False)
            try: process.wait(timeout=10)
            except subprocess.TimeoutExpired: process.kill(); process.wait(timeout=5)


def test_pwa_real_cache_offline_e_acesso_reaberto(native_server):
    async def run():
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(**chromium_launch_options())
            ctx = await browser.new_context(viewport={'width': 390, 'height': 844}, is_mobile=True, has_touch=True)
            errors = []
            p = await ctx.new_page(); p.on('pageerror', lambda e: errors.append(str(e)))
            try:
                await p.goto(native_server + '/#token=' + TOKEN)
                await expect(p.locator('#connection')).to_have_text('Conectado')
                await p.wait_for_function('!!navigator.serviceWorker.controller')
                assert await p.evaluate('isSecureContext')
                await p.locator('button[data-view="tools"]:visible').click()
                await p.locator('#rememberAccess').check()
                await p.close()
                p = await ctx.new_page()
                await p.goto(native_server)
                await expect(p.locator('#connection')).to_have_text('Conectado')
                assert '#' not in p.url
                await p.wait_for_function('!!navigator.serviceWorker.controller')
                await ctx.set_offline(True)
                await p.goto(native_server)
                await expect(p.locator('h1')).to_have_text('Vamos restabelecer a conexão.')
                assert not await p.locator('#toggle').count()
                await ctx.set_offline(False)
                await expect(p.locator('#connection')).to_have_text('Conectado', timeout=10000)
                urls = await p.evaluate('''async()=>{const c=await caches.open('ec-studio-public-18.13.1');return(await c.keys()).map(r=>new URL(r.url).pathname)}''')
                assert '/offline.html' in urls and not any('/api/' in u or u == '/' for u in urls)
                assert not errors
            finally:
                await browser.close()
    asyncio.run(run())


def test_gateway_real_reabre_pessoas_com_tokens_e_fala_separados(native_server):
    with httpx.Client(base_url=native_server, headers={'X-EC-Token': TOKEN}, timeout=30, trust_env=False) as client:
        people = [client.post('/api/profiles', json={'nome': f'Teste remoto {n}'}).json()['perfil'] for n in [1, 2]]
        panels = []
        for person in people:
            response = client.post('/api/profiles/' + person['id'] + '/open')
            assert response.status_code == 200, response.text
            url = response.json()['url']
            assert url.startswith('/p/' + person['id'] + '/#token=')
            panels.append((url.split('#')[0], url.split('#token=')[1]))
        (path1, token1), (path2, token2) = panels
        assert token1 != token2 and token1 != TOKEN
        assert client.get(path1 + 'api/status').status_code == 401
        assert client.get(path2 + 'api/status', headers={'X-EC-Token': token1}).status_code == 401
        r = client.put(path1 + 'api/speech/settings', headers={'X-EC-Token': token1},
                       json={'precisao_minima': 65, 'max_tentativas': 3, 'abaixo_meta': 'retry'})
        assert r.status_code == 200, r.text
        assert client.get(path1 + 'api/speech/settings', headers={'X-EC-Token': token1}).json()['precisao_minima'] == 65
        assert client.get(path2 + 'api/speech/settings', headers={'X-EC-Token': token2}).json()['precisao_minima'] == 80
        # Configurar não chama a API. A chave fictícia só verifica isolamento e
        # persistência em /data, que também funciona com /app somente leitura.
        saved = client.post(path1 + 'api/ia/openai', headers={'X-EC-Token': token1},
                            json={'chave': 'sk-fixture-nonworking-key-1811'})
        assert saved.status_code == 200, saved.text
        assert client.get(path1 + 'api/status', headers={'X-EC-Token': token1}).json()['ia']['configurada']
        assert not client.get(path2 + 'api/status', headers={'X-EC-Token': token2}).json()['ia']['configurada']
        assert client.get(path1 + 'api/status', headers={'X-EC-Token': token1}).json()['perfil']['id'] == people[0]['id']
        assert client.post('/api/profiles/' + people[0]['id'] + '/open').json()['url'] == path1 + '#token=' + token1


@pytest.mark.skipif(os.name == 'nt' or not (shutil.which('espeak-ng') or shutil.which('espeak')),
                    reason='Integração eSpeak requer a dependência de voz do servidor Linux.')
def test_voz_linux_real_chega_ao_mediarecorder(tmp_path, monkeypatch):
    monkeypatch.setattr(fala_sintetica, 'DATA', tmp_path)
    fala_sintetica.synthesize_wav.cache_clear()
    payload, duration = fala_sintetica.synthesize_wav('This is a real speech test.')
    assert payload.startswith(b'RIFF') and 1 < duration < 10
    assert not list(tmp_path.iterdir())

    async def run():
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(**chromium_launch_options())
            try:
                ctx = await browser.new_context()
                await ctx.add_init_script(script=fala_sintetica.SYNTHETIC_MIC_INIT)
                await ctx.route('https://ec-audio.test/**', lambda r: r.fulfill(content_type='text/html', body='<!doctype html><button>Gravar</button>'))
                p = await ctx.new_page(); await p.goto('https://ec-audio.test/')
                recorded = await p.evaluate('''async base64=>{
                  const mic=window.__ecStudioSyntheticMic;mic.setEnabled(true);
                  const stream=await navigator.mediaDevices.getUserMedia({audio:true});
                  const recorder=new MediaRecorder(stream),parts=[];
                  recorder.ondataavailable=e=>parts.push(e.data);recorder.start();
                  if(!await mic.waitForRecording(3000))throw Error('gravador não iniciou');
                  const generation=mic.status().recordingGeneration;
                  const seconds=await mic.feed(base64,{requireRecordingGeneration:generation});
                  await new Promise(resolve=>{recorder.onstop=resolve;recorder.stop()});
                  const bytes=(await new Blob(parts).arrayBuffer()).byteLength;
                  await mic.release();return {seconds,bytes};
                }''', base64.b64encode(payload).decode())
                assert abs(recorded['seconds'] - duration) < .01 and recorded['bytes'] > 2000
            finally:
                await browser.close()
    try:
        asyncio.run(run())
    finally:
        fala_sintetica.synthesize_wav.cache_clear()
