"""Fluxo do player real: observar, digitar por letra e verificar o retorno."""
from __future__ import annotations

from dataclasses import dataclass, field
import re
import logging
import time

from auto_ia import ia_status, suggest, run_inference
from course_flow import CourseCursor, advance_course, lesson_key
from modos import ModoEstudo
from ec_player import inspect_ec_player, click_ec_control, type_ec_answer, PartialAnswerError, ActivityChangedError
from memoria import clean, known_answer, store_correction, store_words


@dataclass
class ECState:
    cursor: CourseCursor = field(default_factory=CourseCursor)
    lesson: str = ''
    question: str = ''
    phrase: str = ''
    answer: str = ''
    pending_correction: str = ''
    attempts: list[str] = field(default_factory=list)
    words: dict[str, list[str]] = field(default_factory=dict)
    last_action: str = ''
    last_action_at: float = 0.0
    action_attempts: int = 0
    awaiting_new_question: bool = False
    waiting_since: float = 0.0
    video_started: bool = False
    video_last_position: float = -1.0
    video_position_at: float = 0.0
    video_resumes: int = 0
    video_ended_since: float = 0.0
    video_replays: int = 0
    video_attention_attempted: bool = False
    video_white_since: float | None = None
    video_white_position: float = 0.0
    video_tracking_signature: str = ''
    video_tracking_replays: int = 0
    video_tracking_exhausted: bool = False
    watch_required_full: bool | None = None
    watch_finished_in_session: bool = False
    inference: object | None = None
    inference_error: str = ''
    partial_question: str = ''
    partial_retries: int = 0
    partial_answer: str = ''
    partial_retry_at: float = 0.0

    def observe_question(self, snapshot: dict) -> None:
        question = snapshot.get('question_id') or ''
        fresh_same_phrase = (self.awaiting_new_question and snapshot.get('question')
                             and not any(snapshot.get(key) for key in ('correct', 'incorrect', 'definition_open'))
                             and all(not slot.get('value') for slot in snapshot.get('letter_slots', [])
                                     if not slot.get('readonly')))
        if question and (question != self.question or fresh_same_phrase):
            self.question = question
            self.phrase = snapshot.get('phrase') or ''
            self.answer = self.pending_correction = ''
            self.attempts.clear()
            self.inference_error = ''
            self.partial_question, self.partial_answer = '', ''
            self.partial_retries = 0
            self.waiting_since = 0.0
            self.last_action = ''
            self.action_attempts = 0
            self.awaiting_new_question = False


def _result(kind: str, message: str, snapshot: dict, **extra) -> dict:
    stage = 'palavras' if snapshot.get('mode') == 'learn' else 'video'
    if snapshot.get('question'):
        stage = 'lacuna_video'
    return {'tipo': kind, 'mensagem': message, 'etapa': {
        'codigo': stage, 'rotulo': 'Aprenda as palavras' if stage != 'video' else 'Assista ao vídeo',
        'detalhe': 'Controles do player EnglishCentral reconhecidos.', 'confianca': 'alta'},
        'aula': snapshot.get('title', ''), 'aula_id': snapshot.get('lesson_id', ''),
        'frame': snapshot.get('frame', 0),
        'verificacao_video': snapshot.get('watch_tracking', {}),
        'progresso_etapas': {'assistir': bool(snapshot.get('watch_complete')) and not snapshot.get('_watch_full_pending', False),
                            'aprender': bool(snapshot.get('learn_complete')),
                            'falar': bool(snapshot.get('speak_complete')),
                            'conversar': bool(snapshot.get('chat_complete'))}, **extra}


def _letters(value: str) -> str:
    return re.sub(r'[^a-z]', '', value.casefold())


def fits_answer(answer: str, snapshot: dict) -> bool:
    if not re.fullmatch(r"[A-Za-z]+(?:[ '\u2019-][A-Za-z]+)*", answer.strip()):
        return False
    letters = _letters(answer)
    if len(letters) != snapshot.get('answer_length'):
        return False
    slots = snapshot.get('letter_slots') or []
    return all(not slot.get('readonly') or
               (i < len(letters) and _letters(slot.get('value', '')) == letters[i])
               for i, slot in enumerate(slots))


def visible_candidates(snapshot: dict, state: ECState) -> list[str]:
    """Só usa vocabulário que foi mostrado para esta aula; não lê o gabarito."""
    choices = []
    for word in state.words.get(state.lesson, []):
        word = word.strip().lower()
        if fits_answer(word, snapshot) and word not in choices and word not in state.attempts:
            choices.append(word)
    return choices


async def _action(page, action: str, snapshot: dict, state: ECState, message: str) -> dict:
    # Alguns controles permanecem no DOM durante a animação de saída.
    signature = '|'.join((state.lesson, state.question, action))
    now = time.monotonic()
    if state.last_action == signature and now - state.last_action_at < 8:
        return _result('aguardando', 'Aguardando o player atualizar após a última ação.', snapshot)
    if state.last_action == signature and state.action_attempts >= 2:
        return _result('ajuda', 'O mesmo controle não alterou a atividade após duas tentativas. Confira a tela antes de retomar.', snapshot)
    pointer = await click_ec_control(page, action)
    if pointer is None:
        return _result('aguardando', 'O controle ainda não está disponível. Observando a próxima atualização.', snapshot)
    state.action_attempts = state.action_attempts + 1 if state.last_action == signature else 1
    state.last_action, state.last_action_at = signature, now
    if action == 'continue':
        state.awaiting_new_question = True
    return _result('navegacao', message, snapshot, ponteiro=pointer,
                   acao='iniciar_palavras' if action == 'start_words' else action)


async def _learn_question(page, snapshot: dict, state: ECState, *, submit: bool) -> dict:
    state.observe_question(snapshot)
    if snapshot.get('correct'):
        if state.answer:
            store_correction(state.phrase, state.answer)
        if not submit:
            return _result('conferencia', 'O site aceitou a palavra. Ative a confirmação automática para continuar.', snapshot)
        return await _action(page, 'continue', snapshot, state, 'Palavra aceita pelo site. Avançando para a próxima.')

    correction = clean(snapshot.get('correction'), 90)
    if correction and snapshot.get('incorrect'):
        # O popup pode ocultar os campos; guarde a correção antes de fechá-lo.
        state.pending_correction = correction.lower()
        if state.phrase:
            store_correction(state.phrase, correction)
        store_words([correction])
        if not submit:
            return _result('correcao', 'Correção da plataforma registrada. Ative a confirmação automática para tentar novamente.', snapshot)
        return await _action(page, 'retry', snapshot, state,
                             'Li a correção mostrada pela plataforma. Preparando a nova tentativa.')
    if snapshot.get('incorrect'):
        if not submit:
            return _result('conferencia', 'A plataforma indicou erro; aguardando a correção.', snapshot)
        if snapshot.get('retry_ready'):
            state.answer = ''
            return await _action(page, 'retry', snapshot, state, 'Reabrindo a lacuna após o erro.')
        return _result('aguardando', 'Aguardando a plataforma exibir a palavra correta.', snapshot)
    if snapshot.get('definition_open'):
        if snapshot.get('continue_ready') and submit:
            return await _action(page, 'continue', snapshot, state,
                                 'Definição da palavra reconhecida. Continuando o treino.')
        if snapshot.get('continue_ready'):
            return _result('conferencia', 'Definição aberta. Ative a confirmação automática para continuar.', snapshot)
        return _result('ajuda', 'Há uma definição aberta sem controle de correção reconhecido. Feche a definição para retomar.', snapshot)
    if not snapshot.get('question'):
        return _result('aguardando', 'Aguardando o próximo trecho e a lacuna do treino.', snapshot)
    if snapshot.get('ambiguous_inputs'):
        return _result('ajuda', 'Há mais de uma lacuna ativa sem foco identificável. Selecione a lacuna desejada.', snapshot)

    if state.partial_question != state.question:
        state.partial_question, state.partial_retries, state.partial_answer = state.question, 0, ''
    if state.partial_retries and time.monotonic() < state.partial_retry_at:
        return _result('aguardando', 'Aguardando os campos estabilizarem antes de conferir a resposta parcial.', snapshot)
    if state.partial_retries >= 3:
        return _result('ajuda', 'Os campos não aceitaram a resposta completa após duas recuperações. Confira a tela.', snapshot)
    if state.pending_correction:
        answer = state.pending_correction
        origin = 'correção visível'
        if not fits_answer(answer, snapshot):
            return _result('ajuda', 'A correção não combina com os campos atuais. Pausei esta tentativa para não digitar na frase errada.', snapshot)
        if state.answer == answer and state.last_action and 'retry' not in state.last_action:
            return _result('aguardando', 'Correção já digitada. Aguardando o retorno da plataforma.', snapshot)
    elif state.partial_answer and fits_answer(state.partial_answer, snapshot):
        answer, origin = state.partial_answer, 'recuperação da digitação'
    elif state.answer:
        if not state.waiting_since:
            state.waiting_since = time.monotonic()
        if time.monotonic() - state.waiting_since > 25:
            return _result('ajuda', 'A resposta não recebeu retorno em 25 segundos. Confira a sessão e a conexão antes de retomar.', snapshot)
        return _result('aguardando', 'Resposta enviada. Aguardando acerto, correção ou mudança da frase.', snapshot)
    else:
        remembered = known_answer(state.phrase)
        answer = remembered if remembered and fits_answer(remembered, snapshot) else ''
        origin = 'memória desta frase'
        candidates = visible_candidates(snapshot, state)
        if not answer and len(candidates) == 1:
            answer, origin = candidates[0], 'vocabulário mostrado na aula'
        if not answer and ia_status()['configurada']:
            state.inference_error = ''
            try:
                suggestions = await run_inference(suggest, [
                    {'contexto': state.phrase, 'label': 'Palavra que falta',
                     'placeholder': f"{snapshot['answer_length']} letras"}],
                    'Palavras desta aula: ' + ', '.join(state.words.get(state.lesson, [])),
                    runner=state.inference)
                suggested = suggestions[0].strip() if suggestions else ''
                if fits_answer(suggested, snapshot) and suggested.lower() not in state.attempts:
                    answer, origin = suggested.lower(), 'IA configurada'
            except Exception as exc:
                state.inference_error = ('A IA local falhou (' + type(exc).__name__ +
                    '). Confira se o Ollama está aberto e o modelo está instalado.')
                logging.getLogger(__name__).warning('Falha na inferência local: %s', type(exc).__name__)
        if not answer and candidates:
            answer, origin = candidates[0], 'candidato do vocabulário da aula'
        if not answer:
            if state.inference_error:
                return _result('erro_ia', state.inference_error, snapshot)
            if not state.words.get(state.lesson) and not state.attempts:
                return await _action(page, 'learn', snapshot, state,
                                     'O assistente iniciou no meio do treino. Abrindo a seleção para ler o vocabulário desta aula.')
            return _result('ajuda', 'Nenhuma palavra do vocabulário desta aula corresponde à lacuna. Abra a seleção de palavras para carregá-la ou configure a IA opcional.', snapshot)

    if len(state.attempts) >= 3 and answer.lower() not in state.attempts:
        return _result('ajuda', 'Três tentativas nesta lacuna não foram aceitas. Aguardando revisão.', snapshot)
    try:
        pointer = await type_ec_answer(page, snapshot, answer, enter=submit)
    except ActivityChangedError:
        state.answer = state.partial_answer = state.pending_correction = ''
        state.partial_retries = 0
        state.awaiting_new_question = True
        return _result('aguardando', 'A atividade mudou. Relendo a tela antes de continuar.', snapshot)
    except PartialAnswerError as exc:
        state.partial_answer = answer
        state.partial_retries += 1
        state.partial_retry_at = time.monotonic() + 2
        return _result('aguardando', 'O site ainda não confirmou todas as letras. Vou conferir novamente antes de continuar.', snapshot)
    except (RuntimeError, ValueError) as exc:
        return _result('ajuda', 'Não consegui digitar na lacuna atual: ' + str(exc), snapshot)
    state.partial_answer, state.partial_retries = '', 0
    state.answer = answer.lower()
    state.pending_correction = ''
    if state.answer not in state.attempts:
        state.attempts.append(state.answer)
    state.waiting_since = time.monotonic()
    state.last_action = 'typed:' + state.question
    return _result('lacuna_video', f'Digitei “{answer}” letra por letra usando {origin}. Conferindo o retorno do site.',
                   snapshot, preenchidas=1, resposta=answer, ponteiro=pointer,
                   enviadas=bool(submit), origem=origin)


async def process_ec_page(page, state: ECState, *, submit: bool, allow_word_start: bool = True,
                          modo: ModoEstudo | None = None, snapshot: dict | None = None) -> dict | None:
    modo = modo or ModoEstudo(quiz=True)
    nav_videos=bool(modo.etapas)
    nav_activities=modo.activities
    snapshot = dict(snapshot) if snapshot is not None else await inspect_ec_player(page)
    if not snapshot.get('supported'):
        nav = await advance_course(page, state.cursor, include_quizzes=modo.quiz,
                                   include_videos=nav_videos, include_activities=nav_activities)
        return None if nav['tipo'] == 'fora_curso' else nav
    if re.search(r'\bactivity\s+\d', snapshot.get('title',''), re.I):
        if not modo.activities and snapshot.get('lesson_id'):
            state.cursor.mark_done(snapshot['lesson_id'])
            return await advance_course(page,state.cursor,include_quizzes=modo.quiz,
                                        include_videos=nav_videos,include_activities=False)
        modo=ModoEstudo(assistir=True,aprender=False,falar=False,quiz=modo.quiz,activities=modo.activities)
    lesson = snapshot.get('lesson_id') or ''
    if not lesson:
        if modo.assistir and snapshot.get('mode') == 'watch' and not snapshot.get('video'):
            return await _watch_only(page, snapshot, state)
        return _result('aguardando', 'Aguardando o identificador da videoaula carregar.', snapshot)
    if lesson != state.lesson:
        state.lesson, state.question, state.phrase = lesson, '', ''
        state.answer = state.pending_correction = state.last_action = ''
        state.attempts.clear()
        state.waiting_since = 0.0
        state.action_attempts = 0
        state.awaiting_new_question = False
        state.video_started, state.video_last_position, state.video_resumes = False, -1.0, 0
        state.video_position_at = time.monotonic()
        state.video_ended_since = 0.0
        state.video_replays = 0
        state.video_attention_attempted = False
        state.video_white_since = None
        state.video_tracking_signature = ''
        state.video_tracking_replays = 0
        state.video_tracking_exhausted = False
        state.watch_required_full = None
        state.watch_finished_in_session = False
        # Uma troca de aula mantém a URL /course/8597. A identidade vem do vídeo.
        return _result('aguardando', 'Videoaula identificada. Aguardando seus indicadores de progresso carregarem.', snapshot)

    if lesson_key(lesson) in state.cursor.skipped_lessons:
        return await advance_course(page,state.cursor,include_quizzes=modo.quiz,include_videos=nav_videos,include_activities=nav_activities)

    # O indicador confirmado pelo site prevalece: não repetir reprodução
    # nem esperar o vídeo terminar quando Assistir já estiver concluído.
    snapshot['_watch_full_pending'] = False
    flags = {'assistir': bool(snapshot.get('watch_complete')),
             'aprender': bool(snapshot.get('learn_complete')),
             'falar': bool(snapshot.get('speak_complete')),
             'conversar': bool(snapshot.get('chat_complete'))}
    if modo.terminou(flags):
        if modo.etapas:
            state.cursor.mark_done(lesson)
        nav = await advance_course(page, state.cursor, include_quizzes=modo.quiz,
                                   include_videos=nav_videos, include_activities=nav_activities)
        if nav['tipo'] == 'fora_curso':
            return _result('escopo_concluido', 'As atividades selecionadas foram confirmadas pelo EnglishCentral.', snapshot, aulas_verificadas=1)
        return {**nav, 'progresso_etapas': flags, 'aula_id': lesson}

    # Quando Assistir está selecionado, jamais resolver Aprender antes da
    # confirmação oficial de Assistir, mesmo se o usuário abriu Aprender.
    if modo.assistir and not flags['assistir']:
        return await _watch_only(page, snapshot, state)

    if modo.aprender and not snapshot.get('learn_complete'):
        if snapshot.get('mode') != 'learn':
            return await _action(page, 'learn', snapshot, state, 'Abrindo Aprender as palavras (Assistir já confirmado ou não selecionado).')
        return await _learn_flow(page, snapshot, state, submit=submit, allow_word_start=allow_word_start)

    if modo.falar and not snapshot.get('speak_complete'):
        if snapshot.get('mode') != 'speak':
            return await _action(page, 'speak', snapshot, state, 'Abrindo a atividade de fala para usar a voz sintética local.')
        return _result('fala', 'Atividade de fala aberta. Preparando a voz sintética.', snapshot,
                       speak_prompt=snapshot.get('speak_prompt', ''))

    if modo.conversar and not snapshot.get('chat_complete'):
        if snapshot.get('mode') != 'chat':
            return await _action(page, 'chat', snapshot, state, 'Abrindo Converse sobre o vídeo (MiMi).')
        return _result('conversa', 'Conversa sobre o vídeo aberta. Preparando respostas com a MiMi de prática.', snapshot)

    return _result('aguardando', 'Verificando os indicadores das atividades selecionadas.', snapshot)


async def _learn_flow(page, snapshot: dict, state: ECState, *, submit: bool,
                      allow_word_start: bool) -> dict:
    if snapshot.get('mode') == 'learn':
        if snapshot.get('context_words'):
            state.words[state.lesson] = snapshot['context_words']
            store_words(snapshot['context_words'])
        if snapshot.get('question') or snapshot.get('correct') or snapshot.get('incorrect') or snapshot.get('definition_open'):
            return await _learn_question(page, snapshot, state, submit=submit)
        if snapshot.get('word_selection') and not snapshot.get('learn_complete'):
            if snapshot.get('start_words') and allow_word_start:
                return await _action(page, 'start_words', snapshot, state, 'Vocabulário da aula lido. Iniciando Aprender as palavras.')
            return _result('aguardando', 'Seleção de palavras identificada. Aguardando o treino estar disponível.', snapshot)
        if snapshot.get('learn_finished') or snapshot.get('learn_complete'):
            if snapshot.get('learn_complete') and not snapshot.get('watch_complete'):
                return await _action(page, 'watch', snapshot, state, 'Aprender concluído. Abrindo Assistir ao vídeo, que ainda está pendente.')
            return _result('aguardando', 'O treino terminou. Aguardando a confirmação de progresso do EnglishCentral.', snapshot)
        return _result('aguardando', 'Reproduzindo o trecho do treino. Aguardando a próxima lacuna.', snapshot)

    return _result('aguardando', 'Aguardando o próximo passo do treino de palavras.', snapshot)


async def _revalidate_watch_action(page, snapshot: dict) -> tuple[dict, dict | None]:
    """Uma transição ou autoplay pode ocorrer entre a leitura e o clique."""
    current = await inspect_ec_player(page)
    if (not current.get('supported') or current.get('lesson_id') != snapshot.get('lesson_id')
            or current.get('frame', 0) != snapshot.get('frame', 0)
            or current.get('player_index', 0) != snapshot.get('player_index', 0) or current.get('mode') != 'watch'):
        return current, _result('aguardando', 'A atividade mudou. Relendo o player antes de acionar a reprodução.', current)
    if current.get('watch_complete'):
        return current, _result('aguardando', 'O site já confirmou Assistir; nenhuma reprodução adicional foi iniciada.', current)
    if not current.get('video') or current['video'].get('error'):
        return current, _result('ajuda', 'A mídia não está pronta para reproduzir. Confira a atividade antes de retomar.', current)
    return current, None


async def _recover_white_bar(page, snapshot: dict, state: ECState, now: float) -> dict | None:
    """A barra branca persistente exige nova leitura e ação na interface oficial."""
    tracking = snapshot.get('watch_tracking') or {}
    video = snapshot.get('video') or {}
    position = float(video.get('position') or 0)
    signature = tracking.get('visual_signature') or ''
    changed = signature != state.video_tracking_signature
    state.video_tracking_signature = signature
    if (not tracking.get('visual_supported') or tracking.get('visual_state') != 'white'
            or video.get('paused') or video.get('seeking') or video.get('ready_state', 4) < 2):
        state.video_white_since = None
        return None
    if changed or state.video_white_since is None or position < state.video_white_position:
        state.video_white_since, state.video_white_position = now, position
        return None
    # Dez segundos de observação e pelo menos quatro segundos de mídia:
    # uma barra branca no início ou durante buffering não provoca reinício.
    if now-state.video_white_since < 10 or position-state.video_white_position < 4:
        return None
    if state.video_tracking_replays >= 2:
        state.video_tracking_exhausted = True
        return _result('video_atencao', 'A barra continua branca após duas tentativas de recuperação. '
                       'Assistir permanece pendente. O assistente está ativo, aguardando ajuste da sessão; '
                       'não repetirá cliques nesta aula.', snapshot, requer_atencao=True)
    fresh, changed_activity = await _revalidate_watch_action(page, snapshot)
    if changed_activity:
        return changed_activity
    fresh_tracking = fresh.get('watch_tracking') or {}
    if (not fresh_tracking.get('visual_supported') or fresh_tracking.get('visual_state') != 'white'
            or fresh_tracking.get('visual_signature') != signature or fresh['video'].get('ended')):
        state.video_white_since = None
        return _result('video', 'A barra mudou durante a conferência. Acompanhando sem reiniciar.', fresh)
    pending = fresh_tracking.get('pending_line_ids') or []
    first = str(pending[0]) if pending else ''
    if not re.fullmatch(r'\d+', first):
        return _result('video_atencao', 'A contagem não avançou, mas não há trecho identificável '
                       'para reiniciar pela interface. Aguardando ajuste sem interromper o assistente.', fresh,
                       requer_atencao=True)
    player = page.frames[fresh['frame']].locator('ec-player-app').nth(fresh['player_index'])
    segment = player.locator('.seek-bar[dialog-line-id="'+first+'"]')
    if await segment.count()!=1 or not await segment.is_visible() or not await segment.is_enabled():
        return _result('video_atencao', 'O trecho para reiniciar não está disponível. '
                       'Aguardando o player carregar.', fresh, requer_atencao=True)
    state.video_tracking_replays += 1
    state.video_white_since = None
    await segment.click(timeout=5000)
    state.video_last_position = -1.0
    state.video_position_at = now
    after, changed_activity = await _revalidate_watch_action(page, fresh)
    if changed_activity:
        return changed_activity
    if after['video'].get('paused') and not after['video'].get('ended'):
        control = player.locator('[data-testid="player-play-pause"]')
        if await control.count()==1 and await control.is_visible() and await control.is_enabled():
            await control.click(timeout=5000)
    return _result('video', f'Barra branca sem contagem. Reabri o primeiro trecho pendente pelo player '
                   f'(recuperação {state.video_tracking_replays}/2). Vou conferir se passa a amarelo ou verde.', after)


async def _watch_only(page, snapshot: dict, state: ECState) -> dict:
    """Reprodução normal. Nunca procura nem preenche lacunas enquanto assiste."""
    if not snapshot.get('watch_complete') or snapshot.get('_watch_full_pending'):
        if snapshot.get('mode') != 'watch':
            return await _action(page, 'watch', snapshot, state, 'Abrindo Assistir ao vídeo.')
        now = time.monotonic()
        if not state.video_position_at:
            state.video_position_at = now
        video = snapshot.get('video')
        if not video:
            return _result('video_atencao' if now-state.video_position_at > 15 else 'aguardando',
                           'O vídeo não está disponível de forma inequívoca. Confira se o player carregou.', snapshot)
        if video.get('error'):
            code = video['error'].get('code', '?') if isinstance(video['error'], dict) else '?'
            return _result('video_atencao', f'A mídia apresentou erro de reprodução (código {code}). Assistir continua pendente; confira a conexão e reabra a aula.', snapshot)
        if snapshot.get('page_visible') is False:
            if not state.video_attention_attempted:
                state.video_attention_attempted = True
                try:
                    await page.bring_to_front()
                except Exception:
                    return _result('ajuda', 'Não consegui exibir a aba do curso. Abra essa aba para acompanhar o registro de Assistir.', snapshot)
                return _result('aguardando', 'Trouxe a aba do curso para frente. Relendo o acompanhamento do site antes de continuar.', snapshot)
            state.video_white_since = None
            return _result('video_atencao', 'A aba do curso está oculta. O assistente continua ativo; '
                           'aguardando a aba ficar visível para conferir a contagem.', snapshot, requer_atencao=True)
        if video.get('ended'):
            if not state.video_ended_since:
                state.video_ended_since = now
            if now-state.video_ended_since >= 12 and not state.video_replays:
                # Reproduza novamente pela interface, sem simular eventos ou conclusão.
                fresh, changed = await _revalidate_watch_action(page, snapshot)
                if changed:
                    return changed
                if not fresh['video'].get('paused') and not fresh['video'].get('ended'):
                    return _result('video', 'O player já retomou a reprodução. Acompanhando o registro sem clicar novamente.', fresh)
                frame = page.frames[snapshot['frame']]
                player = frame.locator('ec-player-app').nth(snapshot['player_index'])
                pending = (fresh.get('watch_tracking') or {}).get('pending_line_ids') or []
                selected = False
                if pending and re.fullmatch(r'\d+', str(pending[0])):
                    segment = player.locator('.seek-bar[dialog-line-id="'+str(pending[0])+'"]')
                    if await segment.count() == 1 and await segment.is_visible() and await segment.is_enabled():
                        try:
                            await segment.click(timeout=5000)
                        except Exception:
                            return _result('ajuda', 'O trecho pendente não respondeu ao clique. Confira a atividade antes de tentar novamente.', snapshot)
                        selected = True
                # A seleção do trecho pode iniciar a reprodução por conta própria.
                paused = True
                if selected:
                    fresh, changed = await _revalidate_watch_action(page, snapshot)
                    if changed:
                        return changed
                    paused = fresh['video']['paused']
                control = player.locator('[data-testid="player-play-pause"]')
                if paused:
                    if await control.count() != 1 or not await control.is_visible() or not await control.is_enabled():
                        return _result('ajuda', 'A mídia terminou sem confirmação e não encontrei o controle oficial para tentar novamente.', snapshot)
                    if snapshot.get('page_visible') is False:
                        await page.bring_to_front()
                    try:
                        await control.click(timeout=5000)
                    except Exception:
                        return _result('ajuda', 'O botão oficial não iniciou a nova tentativa. Assistir continua pendente.', snapshot)
                state.video_replays = 1
                state.video_ended_since = 0.0
                state.video_last_position = -1.0
                state.video_position_at = now
                state.video_started = False
                return _result('video', 'O site ainda não registrou Assistir. Reproduzindo uma vez mais '+('a partir do primeiro trecho sem confirmação.' if selected else 'pelo botão oficial.'), snapshot)
            if now - state.video_ended_since > 45:
                return _result('video_atencao', 'A reprodução terminou, mas o EnglishCentral não confirmou Assistir após a nova tentativa. '
                               'O assistente continua ativo, aguardando ajuste da sessão ou da conexão.', snapshot, requer_atencao=True)
            return _result('aguardando', 'A mídia terminou. Relendo os indicadores do site antes de confirmar Assistir.', snapshot)
        state.video_ended_since = 0.0
        position = float(video.get('position') or 0)
        if state.video_last_position < 0:
            state.video_last_position = position
        elif position > state.video_last_position + .1:
            state.video_last_position, state.video_position_at = position, now
        if not video.get('paused') and position > 0:
            state.video_started = True
        visual_recovery = await _recover_white_bar(page, snapshot, state, now)
        if visual_recovery is not None:
            return visual_recovery
        resume = (video.get('paused') and state.video_started
                  and now - state.video_position_at > 20 and state.video_resumes < 2)
        if video.get('paused') and (not state.video_started or resume):
            # Aciona o controle da UI, preservando os eventos normais do player.
            fresh, changed = await _revalidate_watch_action(page, snapshot)
            if changed:
                return changed
            if not fresh['video'].get('paused'):
                return _result('video', 'O player já começou a reproduzir. Conferindo o avanço sem clicar novamente.', fresh)
            if fresh['video'].get('ended'):
                return _result('aguardando', 'A mídia terminou durante a verificação. Relendo a confirmação do site.', fresh)
            frame = page.frames[snapshot['frame']]
            control = frame.locator('ec-player-app').nth(snapshot['player_index']).locator('[data-testid="player-play-pause"]')
            if await control.count() == 1 and await control.is_visible() and await control.is_enabled():
                if snapshot.get('page_visible') is False:
                    await page.bring_to_front()
                try:
                    await control.click(timeout=5000)
                except Exception:
                    return _result('ajuda', 'O botão oficial não iniciou a reprodução. Confira a janela do curso.', snapshot)
                state.video_started = True
                state.video_position_at = now
                if resume:
                    state.video_resumes += 1
                return _result('video', 'Retomando a reprodução do vídeo.' if resume else 'Vídeo iniciado em reprodução normal.', snapshot)
            return _result('ajuda', 'Não encontrei o controle Reproduzir do vídeo atual.', snapshot)
        if video.get('paused') and state.video_started and now - state.video_position_at > 20:
            return _result('video_atencao', 'A reprodução parou por mais de 20 segundos. Confira o vídeo antes de retomar.', snapshot)
        if not video.get('paused') and now - state.video_position_at > 60:
            return _result('video_atencao', 'O player aparenta reproduzir, mas o tempo não avança há mais de 60 segundos. Assistir continua pendente; confira conexão e reprodução.', snapshot)
        tracking = snapshot.get('watch_tracking') or {}
        visual = tracking.get('visual_state')
        detail = ({'white':' A barra está branca; verificando se a contagem inicia.',
                   'yellow':' A barra está amarela; a contagem está em andamento.',
                   'green':' A barra tem registro verde; acompanhando a confirmação da etapa.'}.get(visual,''))
        detail += (f" O site marcou {tracking.get('lines_done',0)} de {tracking['lines_total']} trechos." if tracking.get('lines_total') else '')
        if snapshot.get('page_visible') is False:
            detail += ' Mantenha a aba do curso visível para acompanhar o registro.'
        return _result('video', 'Acompanhando o avanço da reprodução e a confirmação de Assistir.'+detail, snapshot)
    return _result('aguardando', 'Assistir foi confirmado; avaliando a próxima atividade selecionada.', snapshot)
