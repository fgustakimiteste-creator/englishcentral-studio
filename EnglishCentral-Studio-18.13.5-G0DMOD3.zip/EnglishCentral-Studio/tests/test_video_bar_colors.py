"""Cores efetivamente renderizadas no Chromium, em uma página local de teste."""
import asyncio
import pytest
from playwright.async_api import async_playwright
from conftest import chromium_launch_options
from ec_player import inspect_ec_player

HTML='''<!doctype html><title>Teste local da barra</title><style>
ec-activity-app,ec-player-app,ec-video,ec-activity-list{display:block}
.seek-bar{display:inline-block;width:100px;height:8px;background:rgb(230,230,230);position:relative}
.fill{display:block;height:8px;width:100%}.seek-bar-selected-circle{position:absolute;width:6px;height:6px;background:white;top:1px;left:20px}
</style><ec-activity-app><ec-player-app><div id="activity-app-container" class="watch-mode">
<ec-video><video id="dialog-123" style="width:200px;height:120px"></video></ec-video>
<div class="seek-bar" dialog-line-id="1"><span class="fill"></span><i class="seek-bar-selected-circle"></i></div>
<div class="seek-bar" dialog-line-id="2"></div>
</div></ec-player-app><ec-activity-list><button data-testid="player-activity-button" class="activity-list-watch active">Assistir</button></ec-activity-list></ec-activity-app>'''


def run_case(scenario):
    async def run():
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(**chromium_launch_options())
            try:
                page=await browser.new_page();await page.set_content(HTML);await scenario(page)
            finally:await browser.close()
    asyncio.run(run())


@pytest.mark.parametrize('color,expected',[
    ('rgb(230,230,230)','white'),('rgb(65,150,155)','green'),
    ('rgb(236,195,65)','yellow'),('rgb(40,80,230)','unknown'),
    ('rgba(20,160,80,0)','white')])
def test_cor_renderizada_da_barra(color,expected):
    async def scenario(page):
        await page.locator('.fill').evaluate('(e,color)=>e.style.backgroundColor=color',color)
        result=await inspect_ec_player(page)
        assert result['watch_tracking']['visual_state']==expected
        assert not result['watch_complete'] # cor não fabrica confirmação
    run_case(scenario)


def test_verde_anterior_nao_esconde_branco_no_trecho_atual():
    async def scenario(page):
        await page.locator('.fill').evaluate("e=>e.style.backgroundColor='rgb(65,150,155)'")
        await page.locator('.seek-bar[dialog-line-id="2"]').evaluate('e=>e.append(document.querySelector(".seek-bar-selected-circle"))')
        result=await inspect_ec_player(page)
        assert result['watch_tracking']['visual_state']=='white'
        assert result['watch_tracking']['green_lines']==1
        assert result['watch_tracking']['active_line_id']=='2'
    run_case(scenario)


def test_cor_futura_branca_nao_dispara_no_trecho_verde():
    async def scenario(page):
        await page.locator('.fill').evaluate("e=>e.style.backgroundColor='rgb(65,150,155)'")
        result=await inspect_ec_player(page)
        assert result['watch_tracking']['visual_state']=='green'
    run_case(scenario)


def test_ponteiro_branco_movendo_nao_parece_contagem_nova():
    async def scenario(page):
        first=await inspect_ec_player(page)
        await page.locator('.seek-bar-selected-circle').evaluate("e=>e.style.left='65px'")
        second=await inspect_ec_player(page)
        assert first['watch_tracking']['visual_signature']==second['watch_tracking']['visual_signature']
    run_case(scenario)


def test_amarelo_parcial_e_visual_e_nao_e_conclusao():
    async def scenario(page):
        await page.locator('.fill').evaluate("e=>{e.style.width='20%';e.style.backgroundColor='rgb(236,195,65)'}")
        result=await inspect_ec_player(page)
        assert result['watch_tracking']['visual_state']=='yellow'
        assert not result['watch_complete']
    run_case(scenario)


def test_verde_escondido_nao_conta():
    async def scenario(page):
        await page.locator('.fill').evaluate("e=>{e.style.display='none';e.style.backgroundColor='rgb(65,150,155)'}")
        result=await inspect_ec_player(page)
        assert result['watch_tracking']['visual_state']=='white'
    run_case(scenario)


def test_barra_em_aprender_nao_e_barra_de_assistir():
    async def scenario(page):
        await page.locator('#activity-app-container').evaluate("e=>e.className='learn-mode'")
        await page.locator('.activity-list-watch').evaluate("e=>e.classList.remove('active')")
        result=await inspect_ec_player(page)
        assert not result['watch_tracking']['visual_supported']
    run_case(scenario)
