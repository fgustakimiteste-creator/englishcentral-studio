"""Seleção explícita das atividades que o assistente pode acompanhar.

Quiz, vocabulário e fala são escolhas independentes. A fala pode usar
uma voz sintética enviada diretamente ao fluxo de microfone do navegador.
"""
from dataclasses import dataclass


@dataclass(frozen=True)
class ModoEstudo:
    assistir: bool = True
    aprender: bool = True
    falar: bool = False
    quiz: bool = False
    activities: bool = False
    conversar: bool = False  # Converse sobre o vídeo (MiMi)

    def __post_init__(self):
        if not (self.assistir or self.aprender or self.falar or self.quiz or self.activities or self.conversar):
            raise ValueError('Escolha pelo menos uma atividade.')

    @property
    def etapas(self) -> tuple[str, ...]:
        return tuple(nome for nome, ativo in (
            ('assistir', self.assistir), ('aprender', self.aprender),
            ('falar', self.falar), ('conversar', self.conversar),
        ) if ativo)

    def terminou(self, flags: dict) -> bool:
        return all(bool(flags.get(etapa)) for etapa in self.etapas)
