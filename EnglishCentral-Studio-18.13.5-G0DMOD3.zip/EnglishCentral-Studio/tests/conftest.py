"""Opções compartilhadas para os testes locais, em Windows, macOS ou Linux.

Por padrão usa o Chromium instalado pelo Playwright. Para usar outro navegador
compatível, defina EC_BROWSER_EXECUTABLE com o caminho completo do executável.
EC_CHROMIUM_PATH continua aceito para compatibilidade com os testes anteriores.
"""
from __future__ import annotations

import os
from pathlib import Path


def chromium_launch_options() -> dict:
    options: dict = {"headless": True}
    executable = os.getenv("EC_BROWSER_EXECUTABLE") or os.getenv("EC_CHROMIUM_PATH")
    if executable:
        if not Path(executable).is_file():
            raise FileNotFoundError(f"Navegador configurado não existe: {executable}")
        options["executable_path"] = executable
    if os.name != "nt":
        options["args"] = ["--no-sandbox"]
    return options
