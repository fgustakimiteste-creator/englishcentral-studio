import asyncio
from unittest.mock import AsyncMock, MagicMock, patch
import pytest
from ec_engine import ECState, _recover_white_bar, _watch_only
import servidor
from modos import ModoEstudo


def snapshot(color='white',position=20,**extra):
    data={'supported':True,'lesson_id':'dialog:123','frame':0,'player_index':0,'mode':'watch',
          'watch_complete':False,'page_visible':True,'video':{'paused':False,'ended':False,'position':position,'ready_state':4},
          'watch_tracking':{'visual_supported':True,'visual_state':color,'visual_signature':'1:0:0',
                            'pending_line_ids':['1'],'lines_total':2}}
    data.update(extra);return data


def controls():
    def button():
        b=MagicMock();b.count=AsyncMock(return_value=1);b.is_visible=AsyncMock(return_value=True)
        b.is_enabled=AsyncMock(return_value=True);b.click=AsyncMock();return b
    segment,control=button(),button();player=MagicMock()
    player.locator.side_effect=lambda selector:control if 'play-pause' in selector else segment
    frame=MagicMock();frame.locator.return_value.nth.return_value=player
    page=MagicMock();page.frames=[frame]
    return page,segment,control


def state(**kwargs):
    return ECState(video_white_since=1,video_white_position=1,video_tracking_signature='1:0:0',**kwargs)


@pytest.mark.parametrize('color',['green','yellow','unknown'])
def test_cor_em_andamento_ou_desconhecida_nao_reinicia(color):
    async def run():
        s=state();assert await _recover_white_bar(object(),snapshot(color),s,30) is None
        assert s.video_white_since is None
    asyncio.run(run())


@pytest.mark.parametrize('elapsed,position',[(9,20),(20,1)])
def test_branco_tem_tolerancia_e_exige_avanco_real(elapsed,position):
    asyncio.run(_check_grace(elapsed,position))


async def _check_grace(elapsed,position):
    assert await _recover_white_bar(object(),snapshot(position=position),state(),1+elapsed) is None


@pytest.mark.parametrize('paused',[True,False])
def test_branco_reabre_trecho_e_so_da_play_se_pausado(paused):
    async def run():
        page,segment,control=controls();initial=snapshot();after=snapshot(position=0);after['video']['paused']=paused
        s=state()
        with patch('ec_engine.inspect_ec_player',AsyncMock(side_effect=[initial,after])):
            result=await _recover_white_bar(page,initial,s,15)
        assert result['tipo']=='video' and not result['progresso_etapas']['assistir']
        assert s.video_tracking_replays==1
        segment.click.assert_awaited_once();assert control.click.await_count==int(paused)
    asyncio.run(run())


@pytest.mark.parametrize('fresh',[snapshot('yellow'),snapshot(lesson_id='dialog:999'),snapshot(watch_complete=True)])
def test_revalidacao_impede_reinicio_se_estado_mudou(fresh):
    async def run():
        page,segment,control=controls()
        with patch('ec_engine.inspect_ec_player',AsyncMock(return_value=fresh)):
            await _recover_white_bar(page,snapshot(),state(),15)
        segment.click.assert_not_awaited();control.click.assert_not_awaited()
    asyncio.run(run())


def test_limite_aguarda_sem_cliques_nem_conclusao():
    async def run():
        result=await _recover_white_bar(object(),snapshot(),state(video_tracking_replays=2),15)
        assert result['tipo']=='video_atencao' and result['requer_atencao']
        assert not result['progresso_etapas']['assistir']
    asyncio.run(run())


def test_click_com_timeout_consume_tentativa():
    async def run():
        page,segment,_=controls();segment.click.side_effect=TimeoutError('teste');s=state()
        with patch('ec_engine.inspect_ec_player',AsyncMock(return_value=snapshot())):
            with pytest.raises(TimeoutError):await _recover_white_bar(page,snapshot(),s,15)
        assert s.video_tracking_replays==1 and s.video_white_since is None
    asyncio.run(run())


def test_aba_oculta_aguarda_sem_desligar():
    async def run():
        result=await _watch_only(object(),snapshot(page_visible=False),ECState(video_attention_attempted=True))
        assert result['tipo']=='video_atencao'
    asyncio.run(run())


def test_start_aguarda_finally_antigo(monkeypatch):
    async def run():
        gate=asyncio.Event();started=asyncio.Event()
        async def old():await gate.wait();servidor.auto_running=False
        async def new():started.set();await asyncio.Event().wait()
        monkeypatch.setattr(servidor,'auto_control_lock',asyncio.Lock())
        monkeypatch.setattr(servidor,'auto_running',False)
        monkeypatch.setattr(servidor,'auto_task',asyncio.create_task(old()))
        monkeypatch.setattr(servidor,'auto_worker',new)
        task=asyncio.create_task(servidor.auto_start(servidor.AutoStart(assistir=True,aprender=False,quiz=False)))
        await asyncio.sleep(.01);assert not started.is_set()
        gate.set();await task;await started.wait();assert servidor.auto_running
        await servidor.auto_stop();assert not servidor.auto_running
    asyncio.run(run())


def test_dois_inicios_criam_um_worker(monkeypatch):
    async def run():
        calls=[]
        async def worker():calls.append(1);await asyncio.Event().wait()
        monkeypatch.setattr(servidor,'auto_control_lock',asyncio.Lock())
        monkeypatch.setattr(servidor,'auto_task',None);monkeypatch.setattr(servidor,'auto_running',False)
        monkeypatch.setattr(servidor,'auto_worker',worker)
        a=servidor.AutoStart(assistir=True,aprender=False,quiz=False)
        await asyncio.gather(servidor.auto_start(a),servidor.auto_start(a));await asyncio.sleep(0)
        assert calls==[1] and servidor.auto_running;await servidor.auto_stop()
    asyncio.run(run())


def test_falha_preparacao_limpa_estado(monkeypatch):
    async def run():
        monkeypatch.setattr(servidor,'auto_running',True)
        monkeypatch.setattr(servidor,'_auto_worker_run',AsyncMock(side_effect=RuntimeError('preparação')))
        await servidor.auto_worker()
        assert not servidor.auto_running
        servidor.request_stop_confirmation.assert_awaited_once()
    asyncio.run(run())


def test_worker_atencao_video_permanece_ativo(monkeypatch,tmp_path):
    async def run():
        page=MagicMock(url='https://pt.englishcentral.com/course/8597');page.is_closed.return_value=False;seen=[]
        async def process(*args,**kwargs):
            seen.append(servidor.auto_running)
            return {'tipo':'video_atencao','mensagem':'Aguardando ajuste'} if len(seen)==1 else {'tipo':'escopo_concluido','mensagem':'Fim'}
        for key,value in {'page':page,'auto_running':True,'auto_mode':ModoEstudo(True,False,False,False),
                          'process_page':process,'lock':asyncio.Lock(),'PROGRESS_FILE':tmp_path/'progress.json',
                          'COURSE_FILE':tmp_path/'course.txt','DATA':tmp_path}.items():monkeypatch.setattr(servidor,key,value)
        monkeypatch.setattr(servidor,'request_stop_confirmation',AsyncMock(side_effect=[True,False]))
        with patch.object(servidor.asyncio,'sleep',AsyncMock()):await servidor.auto_worker()
        assert seen==[True,True] and not servidor.auto_running
    asyncio.run(run())


def test_pausar_e_iniciar_concorrentes_aguardam_limpeza(monkeypatch):
    async def run():
        cleanup=asyncio.Event();started=asyncio.Event();restarted=asyncio.Event()
        async def worker():
            if started.is_set():restarted.set()
            started.set()
            try:await asyncio.Event().wait()
            finally:await cleanup.wait();servidor.auto_running=False
        monkeypatch.setattr(servidor,'auto_control_lock',asyncio.Lock())
        monkeypatch.setattr(servidor,'auto_task',None);monkeypatch.setattr(servidor,'auto_running',False)
        monkeypatch.setattr(servidor,'auto_worker',worker)
        a=servidor.AutoStart(assistir=True,aprender=False,quiz=False)
        await servidor.auto_start(a);await started.wait()
        stopping=asyncio.create_task(servidor.auto_stop());await asyncio.sleep(0)
        starting=asyncio.create_task(servidor.auto_start(a));await asyncio.sleep(.01)
        assert not restarted.is_set()
        cleanup.set();await stopping;await starting;await restarted.wait()
        assert servidor.auto_running;await servidor.auto_stop()
    asyncio.run(run())


def test_encerramento_de_audio_travado_nao_bloqueia_pausa(monkeypatch):
    async def run():
        cancelled=asyncio.Event()
        async def hung_release(*args):
            try:await asyncio.Event().wait()
            finally:cancelled.set()
        frame=MagicMock();frame.evaluate=AsyncMock(side_effect=hung_release)
        page=MagicMock();page.frames=[frame];page.is_closed.return_value=False
        monkeypatch.setattr(servidor,'page',page)
        monkeypatch.setattr(servidor,'auto_mode',ModoEstudo(True,False,True,False))
        monkeypatch.setattr(servidor,'MIC_RELEASE_TIMEOUT_SECONDS',.02)
        monkeypatch.setattr(servidor,'_auto_worker_run',AsyncMock())
        monkeypatch.setattr(servidor,'auto_running',True)
        await asyncio.wait_for(servidor.auto_worker(),timeout=.5)
        assert not servidor.auto_running and cancelled.is_set()
    asyncio.run(run())


@pytest.fixture(autouse=True)
def _explicit_decisions_for_legacy_scenarios(monkeypatch):
    monkeypatch.setattr(servidor, 'network_available', AsyncMock(return_value=True))
    monkeypatch.setattr(servidor, 'request_stop_confirmation', AsyncMock(return_value=False))
