import asyncio
from unittest.mock import AsyncMock, patch
import pytest
from auto_fluxo import process_page, EngineState
from modos import ModoEstudo
from ec_player import inspect_ec_player, type_ec_answer
from test_ec_player import run_with_page


@pytest.mark.parametrize('completed', [False, True])
def test_one_player_read_per_cycle(completed):
    page = type('Page', (), {'url':'https://pt.englishcentral.com/course/8571'})()
    state = EngineState()
    state.real.lesson = 'dialog:123'
    snapshot = {'supported':True, 'lesson_id':'dialog:123', 'watch_complete':completed,
                'learn_complete':completed, 'mode':'watch', 'question':False}
    with patch('auto_fluxo._page_gate', AsyncMock(return_value={})), \
         patch('auto_fluxo.inspect_ec_player', AsyncMock(return_value=snapshot)) as read, \
         patch('auto_fluxo.inspect_quiz', AsyncMock(return_value={})), \
         patch('ec_engine.inspect_ec_player', AsyncMock(side_effect=AssertionError('Duplicate DOM read'))), \
         patch('ec_engine._watch_only', AsyncMock(return_value={'tipo':'video'})), \
         patch('ec_engine.advance_course', AsyncMock(return_value={'tipo':'escopo_concluido'})):
        result = asyncio.run(process_page(page, engine=state, modo=ModoEstudo()))
    assert result['tipo'] == ('escopo_concluido' if completed else 'video')
    read.assert_awaited_once()
    assert '_watch_full_pending' not in snapshot  # caller's snapshot remains unchanged


def test_field_disabled_during_typing_is_not_written():
    async def scenario(page):
        snapshot = await inspect_ec_player(page)
        await page.locator('input.char-input').first.evaluate('''e => e.addEventListener('keydown', () => {
            document.querySelectorAll('input.char-input')[1].disabled=true;
        })''')
        with pytest.raises(RuntimeError, match='desabilitado'):
            await type_ec_answer(page, snapshot, 'ride')
        assert await page.evaluate('window.keyCount') == 1
        assert await page.evaluate('window.enterCount') == 0
    run_with_page(scenario)
