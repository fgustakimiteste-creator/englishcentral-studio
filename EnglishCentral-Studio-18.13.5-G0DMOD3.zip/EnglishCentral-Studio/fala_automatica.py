"""Fluxo de fala pela interface, com confirmação do gravador e do resultado."""
from __future__ import annotations

import asyncio
import base64
import re
import time
from dataclasses import dataclass, field

from fala_sintetica import SYNTHETIC_MIC_INIT
from fala_preferencias import SpeechPolicy


@dataclass
class SpeechState:
    phase_key: str = ''
    phase_since: float = 0.0
    selection_clicked: str = ''
    selection_at: float = 0.0
    select_all_at: float = 0.0
    show_all_at: float = 0.0
    sent: str = ''
    sent_at: float = 0.0
    pending: str = ''
    error: str = ''
    error_for: str = ''
    attempts: dict[str, int] = field(default_factory=dict)
    advanced: str = ''
    retried: str = ''
    retried_at: float = 0.0
    observed: str = ''
    force_retry: str = ''
    retry_capture: str = ''


def result(kind, message, **extra):
    return {'tipo':kind, 'mensagem':message,
            'etapa':{'codigo':'fala','rotulo':'Áudio / fala',
                     'detalhe':'Seleção, gravação sintética e retorno do site.'}, **extra}


def lesson(snapshot):
    return snapshot.get('lesson_id') or snapshot.get('aula_id') or ''


def prompt(snapshot):
    return re.sub(r'\s+', ' ', str(snapshot.get('speak_prompt') or '')).strip()


def signature(snapshot):
    return lesson(snapshot)+'|'+str(snapshot.get('speak_line_id') or prompt(snapshot).casefold())


async def prepare_synthetic_mic(page):
    found = False
    deadline=time.monotonic()+10
    for frame in page.frames[:15]:
        if time.monotonic()>=deadline:
            break
        try:
            if not await asyncio.wait_for(frame.evaluate('() => !!window.__ecStudioSyntheticMic'),timeout=min(2,max(.1,deadline-time.monotonic()))):
                await asyncio.wait_for(frame.evaluate(SYNTHETIC_MIC_INIT),timeout=min(2,max(.1,deadline-time.monotonic())))
            enabled = await asyncio.wait_for(frame.evaluate('() => window.__ecStudioSyntheticMic?.setEnabled(true)'),timeout=min(2,max(.1,deadline-time.monotonic())))
            found = bool(enabled) or found
        except Exception:
            continue
    return found


async def _scopes(page, snapshot=None):
    frames = page.frames[:15]
    if snapshot is not None:
        index = snapshot.get('frame', 0)
        if type(index) is not int or not 0 <= index < len(page.frames):
            return []
        frames = [page.frames[index]]
    scopes = []
    for frame in frames:
        players = frame.locator('ec-player-app')
        visible = [p for p in await players.all() if await p.is_visible()]
        if len(visible) == 1:
            scopes.append(visible[0])
        elif not visible and not await frame.locator('ec-activity-app').count():
            # Compatibilidade com páginas locais e gravadores HTML explícitos.
            scopes.append(frame.locator('body'))
    return scopes


async def _usable(loc):
    return (await loc.is_visible() and await loc.is_enabled() and
            await loc.evaluate('''e => {
              if(e.closest('[disabled],[aria-disabled="true"],.disabled,[hidden],[aria-hidden="true"]'))return false;
              for(let node=e;node;node=node.parentElement){const s=getComputedStyle(node);
                if(s.display==='none'||s.visibility==='hidden'||Number(s.opacity)===0)return false;}
              return true;
            }'''))


async def controls(page, action, snapshot=None):
    selectors = {
        'record':'#mic-is-ready,ec-speak-microphone .mic-is-ready,[data-testid="player-record"]',
        'stop':'ec-speak-microphone #mic-is-recording,ec-speak-microphone .mic-is-recording,ec-speak-microphone .record-control:has(.fa-stop),ec-speak-microphone .record-control:has(.fa-stop-circle),[data-testid="player-stop-recording"]',
        'next':'[data-testid="player-next-line"],[data-testid="player-skip-line"],ec-speak-microphone .mic-next-line-button',
        'retry':'[data-testid="player-retry-recording"],ec-speak-microphone .mic-retry-button',
        'start':'ec-speak-interstitial .footer-button',
        'select_all':'ec-speak-interstitial [data-testid="speak-select-all"],ec-speak-interstitial .select-all,ec-speak-interstitial [role="checkbox"]',
        'show_all':'ec-speak-interstitial .btn-filter-all',
    }
    labels = {
        'record':r'^(?:record|record answer|record your (?:answer|voice)|start recording(?: now)?|record now|gravar(?: resposta| sua voz)?|iniciar gravação|começar a gravar)$',
        'stop':r'^(?:stop recording|finish recording|parar gravação|encerrar gravação|finalizar gravação)$',
        'next':r'^(?:pr[óo]xima linha|pr[óo]xima frase|next line|next sentence|continuar|continue|pular(?: linha)?|skip(?: line)?|avan[çc]ar)$',
        'retry':r'^(?:tentar novamente|try again|retry|gravar novamente|repetir grava[çc][ãa]o)$',
        'start':r'^(?:(?:falar|speak)\s+[1-9]\d{0,2}\s+(?:linhas?|lines?)|comece a falar|start speaking)$',
        'select_all':r'^(?:selecionar todas as linhas|selecionar todas|select all lines|select all)$',
        'show_all':r'^(?:todas as linhas|all lines)(?:\s*:\s*\d+)?$',
    }
    found = []
    for scope in await _scopes(page, snapshot):
        if action in {'start','select_all','show_all'}:
            activity=scope.locator('xpath=ancestor::ec-activity-app[1]')
            if await activity.count()==1:
                scope=activity
        specific = scope.locator(selectors[action])
        matches = [x for x in await specific.all() if await _usable(x)]
        if not matches:
            candidate = scope.locator('button,[role="button"],input[type="button"],input[type="submit"],.footer-button')
            # Record/stop labels are only accepted in this unique active player.
            for item in await candidate.all():
                if not await _usable(item):
                    continue
                label = await item.evaluate("e => (e.innerText||e.value||e.getAttribute('aria-label')||e.title||'').replace(/\\s+/g,' ').trim()")
                if re.fullmatch(labels[action], label, re.I):
                    matches.append(item)
        if action == 'select_all' and not matches:
            for item in await scope.get_by_text(re.compile(labels[action], re.I)).all():
                if await _usable(item):
                    matches.append(item)
        if action == 'record' and not matches:
            microphones = scope.locator('.fa-microphone,[data-icon="microphone"]')
            matches = [x for x in await microphones.all() if await _usable(x)]
            if not matches:
                hints=scope.get_by_text(re.compile(r'^(?:CLIQUE AQUI E FALE A FRASE|CLICK HERE AND SPEAK THE LINE|CLICK HERE AND SAY THE SENTENCE)$',re.I))
                matches=[x for x in await hints.all() if await _usable(x)]
        found.extend(matches)
    return found


async def click_control(page, action, snapshot=None):
    found = await controls(page, action, snapshot)
    if len(found) != 1:
        return None
    box = await found[0].bounding_box()
    await found[0].click(timeout=5000)
    pointer = {'acao':{'record':'audio_iniciar','stop':'audio_parar'}.get(action, 'fala_'+action)}
    if box:
        pointer.update(x=round(box['x']+box['width']/2),y=round(box['y']+box['height']/2))
    return pointer


def same_line(old, fresh):
    return (fresh.get('supported') and fresh.get('mode') == 'speak'
            and lesson(old) == lesson(fresh) and old.get('frame',0) == fresh.get('frame',0)
            and prompt(old) == prompt(fresh)
            and (not old.get('speak_line_id') or old.get('speak_line_id') == fresh.get('speak_line_id')))


def speech_score(snapshot):
    value = snapshot.get('speak_score')
    return float(value) if type(value) in (int, float) and 0 <= value <= 100 else None


async def handle_feedback(page, snapshot, engine, *, inspect, now):
    state, policy = engine.speech_flow, getattr(engine, 'speech_policy', SpeechPolicy())
    current = signature(snapshot)
    score = speech_score(snapshot)
    score_text = f'{score:g}%' if score is not None else 'sem nota numérica'
    details = {'precisao': score, 'meta': policy.precisao_minima,
               'tentativas': max(1, state.attempts.get(current, 0))}
    if state.retried == current:
        return result('aguardando' if now-state.retried_at < 15 else 'ajuda',
                      'Aguardando a nova gravação abrir.' if now-state.retried_at < 15 else
                      'O controle de tentar novamente não abriu uma nova gravação.', fala_precisao=details)
    forced = state.force_retry == current
    if score is None and not forced and not (snapshot.get('speak_line_complete') or snapshot.get('speak_result_accepted')):
        return result('ajuda', 'O site mostrou um resultado sem uma nota identificável. Confira antes de avançar.',
                      fala_precisao=details)
    below = score is not None and score < policy.precisao_minima
    if below and policy.abaixo_meta == 'ask' and not forced:
        return result('ajuda', f'Precisão de {score_text}, abaixo da meta de {policy.precisao_minima}%. Escolha tentar novamente ou pular.',
                      fala_precisao=details)
    retry = forced or (below and policy.abaixo_meta == 'retry' and details['tentativas'] < policy.max_tentativas)
    if state.advanced == current:
        return result('aguardando' if now-state.phase_since < 15 else 'ajuda',
                      'Aguardando a próxima linha após o avanço.', fala_precisao=details)
    fresh = await inspect(page)
    if not same_line(snapshot, fresh):
        return result('aguardando', 'A linha mudou após o resultado. Vou conferir a próxima frase.')
    if (speech_score(fresh) != score or
            not (fresh.get('speak_phase') == 'result' or fresh.get('speak_line_complete') or fresh.get('speak_result_accepted'))):
        return result('aguardando', 'Relendo o resultado antes de agir.')
    if retry:
        pointer = await click_control(page, 'retry', fresh)
        if pointer is None and fresh.get('speak_can_record'):
            pointer = await click_control(page, 'record', fresh)
        if pointer is None:
            return result('ajuda', f'Precisão de {score_text}. Não encontrei um controle de nova tentativa nesta linha.', fala_precisao=details)
        state.attempts.setdefault(current, 1)
        state.sent = state.pending = state.error = state.error_for = ''
        state.retried, state.retried_at = current, now
        state.retry_capture = current
        state.force_retry = ''
        return result('navegacao', f'Precisão de {score_text}. Preparando a tentativa {details["tentativas"]+1}/{policy.max_tentativas}.',
                      ponteiro=pointer, fala_precisao=details)
    if not fresh.get('speak_next_ready'):
        return result('aguardando' if now-state.phase_since < 15 else 'ajuda',
                      f'Resultado de {score_text}. Aguardando o botão de próxima linha ficar disponível.', fala_precisao=details)
    pointer = await click_control(page, 'next', fresh)
    if pointer is None:
        return result('aguardando' if now-state.phase_since < 15 else 'ajuda',
                      'Não encontrei um único controle de próxima linha habilitado.', fala_precisao=details)
    state.advanced = current
    message = (f'Precisão de {score_text}, abaixo da meta de {policy.precisao_minima}%. Seguindo para a próxima linha sem repetir.'
               if below else f'Frase registrada ({score_text}). Avançando para a próxima linha.')
    return result('navegacao', message, ponteiro=pointer, fala_precisao=details,
                  fala_evento={**details, 'linha': str(snapshot.get('speak_line_id') or prompt(snapshot)),
                               'estado': 'abaixo_meta' if below else 'meta_atingida' if score is not None else 'registrada_sem_nota',
                               'pulado': below})


async def handle_speech(page, snapshot, engine, *, submit, synthesizer, inspect):
    state = engine.speech_flow
    now = time.monotonic()
    phase = snapshot.get('speak_phase', 'unknown')
    key = lesson(snapshot)+'|'+str(snapshot.get('speak_line_id') or '')+'|'+phase
    if key != state.phase_key:
        state.phase_key, state.phase_since = key, now
    if not submit:
        return result('conferencia','Fala identificada. Ative a confirmação automática para selecionar, gravar e enviar as linhas.')
    await prepare_synthetic_mic(page)
    starters = await controls(page, 'start', snapshot)
    if phase == 'selection' or starters:
        if state.selection_clicked == lesson(snapshot) and state.selection_at:
            return result('aguardando' if now-state.selection_at < 20 else 'ajuda',
                          'Aguardando a seleção abrir a área de fala.' if now-state.selection_at < 20 else 'O botão de linhas não abriu a gravação. Confira a atividade.')
        if len(starters) == 1:
            state.selection_clicked, state.selection_at = lesson(snapshot), now
            engine.speak_selection_started = now
            await starters[0].click(timeout=5000)
            return result('navegacao','Iniciei as linhas selecionadas. Aguardando o trecho e o microfone da frase.')
        if len(starters) > 1:
            return result('ajuda','Há mais de um início de fala visível; não consegui identificar a atividade.')
        if now-state.phase_since < 2:
            return result('aguardando','Aguardando as linhas e a seleção padrão terminarem de carregar.')
        if not snapshot.get('speak_selection_count') and not state.select_all_at:
            clicked=await click_control(page,'select_all',snapshot)
            if clicked:
                state.select_all_at=now
                return result('navegacao','Selecionei as linhas disponíveis para iniciar a fala automática.',ponteiro=clicked)
            if not state.show_all_at:
                clicked=await click_control(page,'show_all',snapshot)
                if clicked:
                    state.show_all_at=now
                    return result('navegacao','Abrindo as linhas disponíveis para preparar a seleção automática.',ponteiro=clicked)
        return result('aguardando' if now-state.phase_since < 15 else 'ajuda',
                      'Aguardando linhas selecionáveis e um botão de início habilitado.')
    engine.speak_selection_started=0.0
    state.selection_clicked=''
    state.selection_at=state.select_all_at=state.show_all_at=0.0
    current_signature = signature(snapshot)
    state.observed = current_signature
    if phase in {'recording', 'processing', 'ready'} and not snapshot.get('speak_result'):
        state.retried = ''
    if phase == 'processing':
        return result('aguardando' if now-state.phase_since < 45 else 'ajuda',
                      'Aguardando o EnglishCentral processar a gravação.' if now-state.phase_since < 45 else 'A plataforma não devolveu o resultado da gravação.')
    if phase == 'result' or (state.retry_capture != current_signature and
                            (snapshot.get('speak_line_complete') or snapshot.get('speak_result_accepted'))):
        return await handle_feedback(page, snapshot, engine, inspect=inspect, now=now)
    if state.error_for == current_signature and state.error:
        return result('ajuda',state.error)
    if state.sent == current_signature:
        return result('fala_sintetica' if now-state.sent_at < 45 else 'ajuda',
                      'Áudio sintético entregue ao gravador; aguardando o resultado da plataforma.' if now-state.sent_at < 45 else 'A plataforma não confirmou essa gravação. A linha continua pendente.')
    text = prompt(snapshot)
    if not text or phase in {'unknown','listening'} and not snapshot.get('speak_can_record'):
        # Páginas locais antigas podem expor um botão Record com inspeção simulada.
        if not text or not await controls(page,'record',snapshot):
            return result('aguardando' if now-state.phase_since < 25 else 'ajuda',
                          'Aguardando o trecho terminar e a frase de gravação aparecer.' if now-state.phase_since < 25 else
                          'A área de gravação desta linha não apareceu em 25 segundos. A atividade permanece pendente.')
    if snapshot.get('speak_prompt_truncated') or len(text)>300:
        return result('ajuda','A frase ultrapassa o limite de 300 caracteres da voz local. Não enviei uma frase cortada.')
    policy = getattr(engine, 'speech_policy', SpeechPolicy())
    if state.attempts.get(current_signature,0) >= policy.max_tentativas:
        return result('ajuda',f'A gravação desta linha não foi confirmada após {policy.max_tentativas} tentativa(s).')
    try:
        audio, _duration = await asyncio.to_thread(synthesizer,text)
        fresh = await inspect(page)
        if not same_line(snapshot,fresh):
            return result('aguardando','A frase ou a aula mudou durante a síntese. Relendo antes de gravar.')
        if fresh.get('speak_phase') in {'selection','processing','result','listening'}:
            return result('aguardando','A área de gravação mudou durante a síntese. Relendo o estado da atividade.')
        frame = page.frames[snapshot.get('frame',0)]
        status = await frame.evaluate('() => window.__ecStudioSyntheticMic?.status?.() || {}')
        baseline = status.get('recordingGeneration',-1) if isinstance(status,dict) else -1
        if not fresh.get('speak_recording'):
            pointer = await click_control(page,'record',fresh)
            if pointer is None:
                return result('ajuda','Não encontrei o controle de gravação dessa frase.')
        else:
            pointer={'acao':'audio_iniciar'}
        state.pending=current_signature
        state.attempts[current_signature]=state.attempts.get(current_signature,0)+1
        deadline=time.monotonic()+8
        ready=False
        while time.monotonic()<deadline:
            current=await inspect(page)
            if not same_line(snapshot,current):
                return result('aguardando','A atividade mudou enquanto preparava o gravador. Não enviei a frase anterior.')
            status=await frame.evaluate('() => window.__ecStudioSyntheticMic?.status?.() || {}')
            status=status if isinstance(status,dict) else {}
            observed=(status.get('recording') and status.get('recordingGeneration',-1)>baseline)
            dom_ready=current.get('speak_recording') is True
            if status.get('enabled') and status.get('liveTracks',0)>0 and (observed or dom_ready):
                ready=True
                break
            await asyncio.sleep(.1)
        if not ready:
            raise RuntimeError('O gravador não confirmou o início da captura. Nenhum áudio sintético foi entregue.')
        fresh=await inspect(page)
        if not same_line(snapshot,fresh):
            return result('aguardando','A frase mudou antes do envio. Relendo a atividade.')
        if (fresh.get('speak_line_complete') and state.retry_capture != current_signature) or fresh.get('speak_phase') in {'processing','result','selection','listening'}:
            return result('aguardando','O gravador mudou de estado antes do envio. Aguardando o retorno da atividade.')
        status=await frame.evaluate('() => window.__ecStudioSyntheticMic?.status?.() || {}')
        status=status if isinstance(status,dict) else {}
        native_recording=status.get('recording') and status.get('recordingGeneration',-1)>baseline
        if (not status.get('enabled') or not status.get('liveTracks',0)
                or not (native_recording or fresh.get('speak_recording') is True)):
            return result('aguardando','A captura encerrou antes do áudio. Relendo o gravador sem anunciar envio.')
        payload={'audio':base64.b64encode(audio).decode('ascii'),
                 'options':{'requireRecordingGeneration':status['recordingGeneration']} if native_recording else {}}
        played=await frame.evaluate('async data => window.__ecStudioSyntheticMic.feed(data.audio,data.options)',payload)
        state.sent, state.sent_at = current_signature,time.monotonic()
        engine.speak_signature,engine.speak_started=current_signature,state.sent_at
        fresh=await inspect(page)
        if same_line(snapshot,fresh) and (not fresh.get('speak_line_complete') or state.retry_capture == current_signature):
            stopped=await click_control(page,'stop',fresh)
            if stopped:
                pointer=stopped
        state.retry_capture = ''
        return result('fala_sintetica',f'Entreguei a frase por voz sintética ao gravador ({float(played):.1f}s). Aguardando o resultado do site.',
                      ponteiro=pointer,duracao=float(played),enviadas=True,origem='voz SAPI local')
    except Exception as exc:
        state.error_for=current_signature
        state.error='Não consegui concluir a gravação automática: '+str(exc)[:220]
        return result('ajuda',state.error)
