@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Preparar IA local - EnglishCentral
set "OLLAMA=ollama"
where ollama >nul 2>nul
if errorlevel 1 (
  if exist "%LOCALAPPDATA%\Programs\Ollama\ollama.exe" (
    set "OLLAMA=%LOCALAPPDATA%\Programs\Ollama\ollama.exe"
  ) else (
    echo Ollama ainda nao foi instalado.
    echo Instale pelo site oficial: https://ollama.com/download/windows
    echo Depois execute este arquivo novamente.
    pause
    exit /b 1
  )
)
echo.
echo O modelo llama3.2:latest pode exigir alguns GB de download e memoria RAM.
choice /M "Deseja instalar o modelo local agora"
if errorlevel 2 exit /b 0
"%OLLAMA%" pull llama3.2:latest
if errorlevel 1 (
  echo Nao foi possivel instalar o modelo. Confira se o aplicativo Ollama esta aberto.
  pause
  exit /b 1
)
if exist "config_ia.local.txt" (
  copy /Y "config_ia.local.txt" "config_ia.local.txt.antes-ia-local.bak" >nul
  if errorlevel 1 (
    echo Nao foi possivel guardar a configuracao anterior. Nenhuma alteracao foi feita.
    pause
    exit /b 1
  )
)
(
 echo # IA local Ollama - dados ficam no seu computador
 echo EC_IA_PROVEDOR=ollama
 echo EC_IA_MODELO=llama3.2:latest
) > "config_ia.local.txt"
if errorlevel 1 (
  echo Falha ao gravar a configuracao. Confira as permissoes da pasta.
  pause
  exit /b 1
)
echo IA configurada. Se o painel ja estiver aberto, reinicie com INICIAR.bat.
pause
