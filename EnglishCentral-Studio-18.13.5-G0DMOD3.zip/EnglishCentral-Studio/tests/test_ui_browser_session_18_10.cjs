const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {JSDOM,VirtualConsole}=require(process.env.EC_JSDOM||'jsdom');
const html=fs.readFileSync(path.join(__dirname,'../web/index.html'),'utf8');
const wait=()=>new Promise(resolve=>setTimeout(resolve,25));
let passed=0;
async function boot({failure=false,deferred=false,opened=false}={}){
 const calls=[],timers=[],errors=[];let release;
 const tabs=[{id:'1111111111111111',rotulo:'Curso 8597',atual:true},{id:'2222222222222222',rotulo:'Entrar com o Google',atual:false}];
 const state={aberto:opened,executando:false,eventos:[],auto:{tipo:'parado'},modo:{assistir:true},navegador:{modo:'existente',mensagem:'Usando o login do seu Chrome/Edge.'}};
 const console=new VirtualConsole();console.on('jsdomError',e=>errors.push(e.message));
 const dom=new JSDOM(html,{url:'http://localhost/#token=fixture-only',runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:console,beforeParse(w){
  w.scrollTo=()=>{};w.setInterval=(fn,delay)=>{timers.push({fn,delay});return timers.length};
  w.HTMLDialogElement.prototype.showModal=function(){this.open=true};w.HTMLDialogElement.prototype.close=function(){this.open=false};
  w.URL.createObjectURL=()=> 'blob:local-fixture';w.URL.revokeObjectURL=()=>{};
  w.fetch=async(url,options={})=>{
   const data=options.body?JSON.parse(options.body):null;calls.push({url,data});
   if(url==='/api/browser/connect'){
    if(deferred)await new Promise(resolve=>{release=resolve});
    if(failure)return{ok:false,status:409,json:async()=>({detail:'Autorize a conexão no próprio Chrome. Nenhum perfil novo foi aberto.'})};
   }
   const result=url==='/api/status'?structuredClone(state):url==='/api/browser/tabs'?{abas:tabs}:{ok:true,mensagem:'Sessão conectada'};
   return{ok:true,json:async()=>result,blob:async()=>new w.Blob(['fixture-image'])};
  };
 }});await wait();assert.deepEqual(errors,[]);
 return{dom,w:dom.window,d:dom.window.document,calls,state,timers,errors,release:()=>release?.(),
  submit:async()=>{dom.window.document.getElementById('browserConnectForm').dispatchEvent(new dom.window.Event('submit',{bubbles:true,cancelable:true}));await wait()}};
}
async function test(name,fn){await fn();passed++;console.log('PASS',name)}
(async()=>{
 await test('Acesso inicial oferece o Chrome já logado e explica a permissão',async()=>{const t=await boot();t.d.getElementById('emptyConnectChrome').click();assert(t.d.getElementById('browserDialog').open);assert(!t.d.getElementById('browserConsent').checked);assert.match(t.d.getElementById('browserDialog').textContent,/chrome:\/\/inspect\/#remote-debugging/);t.dom.window.close()});
 await test('Sem consentimento a interface não inicia conexão',async()=>{const t=await boot();await t.submit();assert(!t.calls.some(c=>c.url==='/api/browser/connect'));t.dom.window.close()});
 await test('Conexão preserva modo escolhido e não dispara duas solicitações',async()=>{const t=await boot({deferred:true});t.d.getElementById('connectChrome').click();t.d.getElementById('browserConsent').checked=true;await t.submit();await t.submit();assert.equal(t.calls.filter(c=>c.url==='/api/browser/connect').length,1);assert.deepEqual(t.calls.find(c=>c.url==='/api/browser/connect').data,{canal:'chrome'});assert(t.d.getElementById('toggle').disabled);t.release();await wait();assert(!t.d.getElementById('browserDialog').open);assert(!t.d.getElementById('open').disabled);t.dom.window.close()});
 await test('Recusa de conexão informa o motivo sem abrir outro perfil',async()=>{const t=await boot({failure:true});t.d.getElementById('connectChrome').click();t.d.getElementById('browserConsent').checked=true;await t.submit();assert(t.d.getElementById('browserDialog').open);assert.match(t.d.getElementById('browserConnectMessage').textContent,/Nenhum perfil novo/);assert(!t.calls.some(c=>c.url==='/api/open'||c.url==='/api/browser/managed'));t.dom.window.close()});
 await test('Porta local opcional é validada e enviada somente quando preenchida',async()=>{const t=await boot();t.d.getElementById('browserConsent').checked=true;t.d.getElementById('chromePort').value='80';await t.submit();assert(!t.calls.some(c=>c.url==='/api/browser/connect'));t.d.getElementById('chromePort').value='9222';await t.submit();assert.deepEqual(t.calls.find(c=>c.url==='/api/browser/connect').data,{canal:'chrome',porta:9222});t.dom.window.close()});
 await test('Outra aba é escolhida por identificador e mantém pausa explícita',async()=>{const t=await boot();t.d.querySelector('[data-view="settings"]').click();await wait();assert.equal(t.d.getElementById('browserTabs').options.length,2);t.d.getElementById('browserTabs').value='2222222222222222';t.d.getElementById('selectBrowserTab').click();await wait();assert.deepEqual(t.calls.find(c=>c.url==='/api/browser/tab').data,{id:'2222222222222222'});assert.equal(t.d.getElementById('toggleLabel').textContent,'Iniciar assistente');t.dom.window.close()});
 await test('Modo separado continua disponível para contas independentes',async()=>{const t=await boot();t.d.getElementById('useManagedBrowser').click();await wait();assert(t.calls.some(c=>c.url==='/api/browser/managed'));assert.match(t.d.getElementById('browserSessionState').textContent,/login do seu Chrome/);t.dom.window.close()});
 await test('Clique na prévia respeita tamanho da aba existente',async()=>{const t=await boot({opened:true});await t.timers.find(timer=>timer.delay===1000).fn();await wait();const img=t.d.getElementById('screen');Object.defineProperty(img,'naturalWidth',{value:1600});Object.defineProperty(img,'naturalHeight',{value:1000});img.getBoundingClientRect=()=>({left:0,top:0,width:800,height:500});img.dispatchEvent(new t.w.Event('load'));img.dispatchEvent(new t.w.MouseEvent('click',{clientX:750,clientY:450,bubbles:true}));await wait();assert.deepEqual(t.calls.find(c=>c.url==='/api/tap').data,{x:1500,y:900});t.dom.window.close()});
 await test('Assistente informa espera cancelada e deixa a execução disponível',async()=>{const t=await boot();t.state.navegador.ultimo_erro={quando:Date.now()/1000,mensagem:'A consulta demorou; a espera foi liberada para retomar.'};await t.timers.find(timer=>timer.delay===1500).fn();await wait();assert(!t.d.getElementById('connectionHint').classList.contains('hide'));assert.match(t.d.getElementById('connectionHint').textContent,/liberada/);t.state.navegador.ultimo_erro.quando-=60;await t.timers.find(timer=>timer.delay===1500).fn();await wait();assert(t.d.getElementById('connectionHint').classList.contains('hide'));assert(!t.calls.some(c=>c.url==='/api/auto/stop'));t.dom.window.close()});
 console.log(`${passed} cenários de navegador e login aprovados (DOM/API simulados).`);
})().catch(error=>{console.error(error);process.exitCode=1});
