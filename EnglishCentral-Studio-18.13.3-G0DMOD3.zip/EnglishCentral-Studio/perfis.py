"""Cadastro expansível de sessões locais com dados e portas independentes."""
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import sys
import time
from urllib.request import Request, urlopen
from arquivos_locais import file_lock, local_token, write_json_atomic


def registry_lock(root):
    return file_lock(Path(root) / 'perfis.lock')


class ProfileManager:
    def __init__(self, root: Path, project: Path):
        self.root, self.project = Path(root), Path(project)
        self.file = self.root / 'perfis.json'

    def _read(self):
        if self.file.exists():
            try:
                data = json.loads(self.file.read_text('utf-8'))
                if not isinstance(data, dict) or not isinstance(data.get('pessoas'), list):
                    raise ValueError('Cadastro inválido')
                ids, ports = set(), set()
                for person in data['pessoas']:
                    if not isinstance(person, dict):
                        raise ValueError('Pessoa inválida')
                    identity, name, port = person.get('id'), person.get('nome'), person.get('porta')
                    if (not isinstance(identity, str) or
                            not re.fullmatch(r'principal|pessoa(?:[2-9]|[1-9]\d+)', identity) or identity in ids or
                            not isinstance(name, str) or not name.strip() or len(name) > 60 or
                            port is not None and (type(port) is not int or not 1 <= port <= 65535 or port in ports)):
                        raise ValueError('Pessoa inválida')
                    ids.add(identity)
                    if port is not None: ports.add(port)
                if 'principal' not in ids or type(data.get('proximo', 2)) is not int or data.get('proximo', 2) < 2:
                    raise ValueError('Cadastro inválido')
                return data
            except (ValueError, TypeError) as exc:
                raise RuntimeError('Não consegui ler o cadastro salvo. Preserve a pasta de dados antes de restaurar sua cópia.') from exc
        people = [{'id': 'principal', 'nome': 'Pessoa principal', 'porta': 8765}]
        if (self.root / 'pessoa2').is_dir():
            people.append({'id': 'pessoa2', 'nome': 'Pessoa 2', 'porta': 8766})
        return {'versao': 1, 'proximo': 3 if len(people) > 1 else 2, 'pessoas': people}

    def _write(self, data):
        write_json_atomic(self.file, data)

    def list(self):
        with registry_lock(self.root):
            data = self._read()
            if not self.file.exists():
                self._write(data)
            return [{'id': p['id'], 'nome': p['nome']} for p in data['pessoas']]

    def current(self, profile_id):
        # A leitura atômica também funciona enquanto outro painel inicia um processo.
        for person in self._read()['pessoas']:
            if person['id'] == profile_id:
                return {'id': profile_id, 'nome': person['nome']}
        return {'id': profile_id, 'nome': 'Pessoa principal' if profile_id == 'principal' else profile_id}

    @staticmethod
    def clean_name(value):
        value = ' '.join(str(value or '').split())
        if not value or len(value) > 60:
            raise ValueError('Use um nome de 1 a 60 caracteres.')
        return value

    def create(self, name=''):
        with registry_lock(self.root):
            data = self._read()
            number = max(2, int(data.get('proximo', 2)))
            ids = {p['id'] for p in data['pessoas']}
            while f'pessoa{number}' in ids or (self.root / f'pessoa{number}').exists():
                number += 1
            person = {'id': f'pessoa{number}', 'nome': self.clean_name(name or f'Pessoa {number}'), 'porta': None}
            (self.root / person['id']).mkdir(parents=True, exist_ok=False)
            data['pessoas'].append(person)
            data['proximo'] = number + 1
            self._write(data)
            return {'id': person['id'], 'nome': person['nome']}

    def rename(self, profile_id, name):
        name = self.clean_name(name)
        with registry_lock(self.root):
            data = self._read()
            person = next((p for p in data['pessoas'] if p['id'] == profile_id), None)
            if person is None:
                raise KeyError('Pessoa não encontrada.')
            person['nome'] = name
            self._write(data)
        return {'id': profile_id, 'nome': name}

    def data_dir(self, profile_id):
        if profile_id == 'principal':
            return self.root
        if not (profile_id.startswith('pessoa') and profile_id[6:].isdecimal() and int(profile_id[6:]) >= 2):
            raise ValueError('Identificador de pessoa inválido.')
        return self.root / profile_id

    @staticmethod
    def _available_port(preferred=None):
        with socket.socket() as sock:
            try:
                sock.bind(('127.0.0.1', preferred or 0))
            except OSError:
                sock.bind(('127.0.0.1', 0))
            return sock.getsockname()[1]

    @staticmethod
    def _ready(port, token, profile_id):
        if type(port) is not int or not 1 <= port <= 65535:
            return False
        try:
            request = Request(f'http://127.0.0.1:{port}/api/health', headers={'X-EC-Token': token})
            with urlopen(request, timeout=.5) as response:
                data = json.loads(response.read(200000))
            return isinstance(data, dict) and isinstance(data.get('perfil'), dict) and data['perfil'].get('id') == profile_id
        except (OSError, ValueError, TypeError):
            return False

    def open(self, profile_id):
        # O lock inclui o início: dois painéis não abrem dois workers para a mesma pessoa.
        with registry_lock(self.root):
            data = self._read()
            person = next((p for p in data['pessoas'] if p['id'] == profile_id), None)
            if person is None:
                raise KeyError('Pessoa não encontrada.')
            directory = self.data_dir(profile_id)
            directory.mkdir(parents=True, exist_ok=True)
            token = local_token(directory / 'token_painel.txt')
            port = person.get('porta')
            if not self._ready(port, token, profile_id):
                other_ports = {p.get('porta') for p in data['pessoas'] if p['id'] != profile_id}
                port = self._available_port(port)
                while port in other_ports:
                    port = self._available_port()
                person['porta'] = port
                self._write(data)
                env = os.environ.copy()
                env.pop('EC_PANEL_TOKEN', None)
                # Segredos/provedor da IA configurados no processo principal não podem
                # vazar para perfis adicionais. Cada perfil lê apenas seu próprio
                # config_ia.local.txt; sem esse arquivo, a IA fica não configurada.
                for inherited_key in tuple(env):
                    if inherited_key.startswith('EC_IA_'):
                        env.pop(inherited_key, None)
                env.update(EC_DATA_DIR=str(directory), EC_PROFILES_ROOT=str(self.root),
                           EC_PROFILE_ID=profile_id, EC_PORT=str(port))
                with (directory / 'iniciar.log').open('a', encoding='utf-8') as stream:
                    process = subprocess.Popen([sys.executable, '-u', str(self.project / 'servidor.py'), '--port', str(port)],
                                               cwd=self.project, env=env, stdout=stream, stderr=stream,
                                               creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
                deadline = time.monotonic() + 20
                while not self._ready(port, token, profile_id):
                    if process.poll() is not None:
                        raise RuntimeError('O painel desta pessoa não iniciou. Consulte o diagnóstico local.')
                    if time.monotonic() >= deadline:
                        raise RuntimeError('O painel está demorando a iniciar. Aguarde e clique em Abrir painel novamente.')
                    time.sleep(.15)
            return {'ok': True, 'perfil': {'id': profile_id, 'nome': person['nome']},
                    'url': f'http://127.0.0.1:{port}/#token={token}',
                    'mensagem': f'Painel de {person["nome"]} pronto. Faça login nessa sessão com a conta correspondente.'}
