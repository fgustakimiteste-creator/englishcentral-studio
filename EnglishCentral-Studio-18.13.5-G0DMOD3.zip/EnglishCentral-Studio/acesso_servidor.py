"""Mostra o acesso privado somente quando o dono solicita no terminal."""
from servidor import REMOTE_CONFIG, get_token


if __name__ == '__main__':
    origin = REMOTE_CONFIG.origin if REMOTE_CONFIG.enabled else 'http://127.0.0.1:8765'
    print('Link privado do painel (não compartilhe):')
    print(origin + '/#token=' + get_token())
