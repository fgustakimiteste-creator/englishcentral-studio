# Testes — EnglishCentral Studio V18.13.0

## Resultado resumido

A suíte contém **492 testes coletados**. Não declaro a suíte integral aprovada: os testes foram executados em baterias separadas e alguns cenários de navegador foram bloqueados pelo ambiente. Os números abaixo são resultados independentes de cada execução; não devem ser somados como quantidade de testes únicos.

| Bateria executada | Resultado |
|---|---:|
| SEDUCTEC, Moodle, multiagente, PDF, perfis, fila e prévia | **69 aprovados** |
| API, seleção de curso e motor/player EnglishCentral | **30 aprovados** |
| Automação/IA/Moodle | **30 aprovados** |
| Quizzes e revisão de respostas | **30 aprovados** |
| Mobile/PWA, perfis, sessões e ciclo de workers | **65 aprovados; 2 bloqueados pelo navegador** |

## Testes específicos adicionados/fortalecidos

- Distribuição de atividades entre agentes simultâneos em páginas distintas.
- Barreira por seção: a Aula 02 não começa antes que todas as atividades da Aula 01 terminem.
- Expansão de seções recolhidas por `aria-expanded` e classe `.collapsed`.
- Detecção de uma seção adicionada tardiamente depois da rolagem.
- Botão “Expandir tudo” sem aria-state: confirma que não é clicado repetidamente e não recolhe o curso.
- Atividade sem URL e URL externa: a fila mantém apenas a atividade com URL oficial válida.
- Seta Voltar: fecha somente o PDF temporário e restaura a página original do curso.
- PDF de teste com 51 páginas: o extrator reporta 51 páginas totais, mas lê exatamente as primeiras 50.
- Prévia de PDF: captura de tela do documento fica disponível depois que a aba temporária fecha.
- MiMi: preferências persistidas por perfil no servidor.
- Quiz: controles radio, essay e select preenchidos e relidos em Chromium local; envio não executado.
- Fórum: discussão e editor acessados em Chromium local; rascunho preenchido e relido; publicação não executada.

## Verificações estáticas

- `python -m compileall -q .` — aprovado.
- `bash -n TERMUX_INICIAR.sh` — aprovado.
- Extração dos scripts inline de `web/index.html` e `node --check` — aprovado.
- Empacotamento ZIP, verificação CRC/estrutura e checagem de arquivos sensíveis — registrado na validação de distribuição.

## Bloqueios e testes não concluídos

- Na bateria mobile/PWA, dois testes falharam antes de executar o fluxo da aplicação: `test_pwa_real_cache_offline_e_acesso_reaberto` e `test_voz_linux_real_chega_ao_mediarecorder`. O Chromium retornou `ERR_BLOCKED_BY_ADMINISTRATOR` ao abrir `http://127.0.0.1:<porta>` e `https://ec-audio.test/`.
- Testes antigos do navegador que navegam para `pt.englishcentral.com` também podem parar antes da fixture local devido a `ERR_BLOCKED_BY_ADMINISTRATOR`.
- `npm run test:ui` não foi validado: o ambiente de trabalho não tem a dependência de desenvolvimento `jsdom` instalada e não havia cache local para ela. A sintaxe JavaScript foi validada com `node --check`.
- A suíte integral foi coletada, mas não terminou integralmente em uma única execução dentro do ambiente de teste.
- Nenhuma conta real SEDUCTEC/EnglishCentral, chave de IA ou credencial foi fornecida. Não foi possível fazer uma execução ponta a ponta no curso mostrado na captura.

## Como reproduzir

Na pasta do projeto:

```bash
python -m compileall -q .
bash -n TERMUX_INICIAR.sh
EC_BROWSER_EXECUTABLE=/usr/bin/chromium python -m pytest -q \
  tests/test_moodle_automation_multiagent_18_13.py \
  tests/test_moodle_execute_18_13.py \
  tests/test_moodle_retry_and_config_18_12.py \
  tests/test_seductec.py \
  tests/test_profiles_18_7.py \
  tests/test_profiles_native_18_7.py \
  tests/test_runtime_queue_18_12_3.py \
  tests/test_live_view.py \
  tests/test_panel_events.py
```

A confirmação definitiva dos seletores e permissões exige abrir o curso real no navegador autenticado do usuário. Os testes com Chromium local executam ações Playwright reais em páginas de fixture, não simulam a resposta da plataforma real.
