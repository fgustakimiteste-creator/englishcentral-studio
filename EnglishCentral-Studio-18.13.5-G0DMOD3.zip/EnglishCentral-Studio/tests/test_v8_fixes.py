"""Regressões V8 sem acesso à conta ou rede."""
import asyncio
import time
from unittest.mock import AsyncMock, patch
import pytest

import servidor
from ec_engine import ECState, process_ec_page
from modos import ModoEstudo

SLEEP=asyncio.sleep


@pytest.fixture(autouse=True)
def isolated_worker(monkeypatch,tmp_path):
    for key,value in {'DATA':tmp_path,'COURSE_FILE':tmp_path/'course.txt','PROGRESS_FILE':tmp_path/'progress.json',
                      'auto_task':None,'auto_running':False,'stop_confirmation':None,'stop_confirmation_event':None,
                      'auto_control_lock':asyncio.Lock(),'lock':asyncio.Lock(),
                      'auto_mode':ModoEstudo(True,False,False,False),
                      'network_available':AsyncMock(return_value=True)}.items():
        monkeypatch.setattr(servidor,key,value)


async def pending_question():
    for _ in range(1000):
        if servidor.stop_confirmation:return servidor.stop_confirmation
        await SLEEP(.001)
    raise AssertionError('O aviso de atenção não apareceu.')


def test_intervencao_manual_para_worker_antes_de_clicar(monkeypatch):
    async def run():
        entered = asyncio.Event()
        released = asyncio.Event()
        class Page:
            url = 'https://pt.englishcentral.com/course/8597'
            def is_closed(self): return False
            @property
            def mouse(self): return self
            async def click(self, x, y):
                assert not servidor.auto_running
                released.set()
        async def slow_process(*args, **kwargs):
            entered.set()
            await asyncio.Event().wait()
        monkeypatch.setattr(servidor, 'page', Page())
        monkeypatch.setattr(servidor, 'process_page', slow_process)
        monkeypatch.setattr(servidor, 'auto_running', True)
        worker = asyncio.create_task(servidor.auto_worker())
        monkeypatch.setattr(servidor, 'auto_task', worker)
        await asyncio.wait_for(entered.wait(),timeout=1)
        await servidor.tap(servidor.Tap(x=150,y=250))
        assert released.is_set() and worker.done() and not servidor.auto_running
    asyncio.run(run())


def test_worker_aguarda_login_e_respeita_parada_manual(monkeypatch):
    async def run():
        page = type('Page', (), {'url':'https://pt.englishcentral.com/course/8597',
                                 'is_closed':lambda self: False})()
        fn = AsyncMock(return_value={'tipo':'login','mensagem':'Faça login.'})
        monkeypatch.setattr(servidor,'page',page)
        monkeypatch.setattr(servidor,'process_page',fn)
        monkeypatch.setattr(servidor,'auto_running',True)
        worker=asyncio.create_task(servidor.auto_worker())
        monkeypatch.setattr(servidor,'auto_task',worker)
        request=await pending_question()
        assert servidor.auto_running and fn.await_count==1 and request['tipo']=='login'
        await servidor.auto_decision(servidor.StopDecision(solicitacao=request['id'],acao='stop'))
        await worker
        assert not servidor.auto_running and fn.await_count == 1
    asyncio.run(run())


def test_worker_interrompe_estagnacao(monkeypatch):
    async def run():
        page=type('Page', (), {'url':'https://pt.englishcentral.com/course/8597',
                                'is_closed':lambda self: False})()
        fn=AsyncMock(return_value={'tipo':'aguardando','mensagem':'Sem mudança no exercício.'})
        monkeypatch.setattr(servidor,'page',page)
        monkeypatch.setattr(servidor,'process_page',fn)
        monkeypatch.setattr(servidor,'auto_running',True)
        monkeypatch.setattr(servidor,'STALL_LIMIT_SECONDS',0.04)
        orig_sleep=asyncio.sleep
        async def quick_sleep(seconds): await orig_sleep(0.025)
        with patch.object(servidor.asyncio,'sleep',side_effect=quick_sleep):
            worker=asyncio.create_task(servidor.auto_worker())
            monkeypatch.setattr(servidor,'auto_task',worker)
            request=await pending_question()
            assert fn.await_count>=2 and request['tipo']=='ajuda'
            await servidor.auto_decision(servidor.StopDecision(solicitacao=request['id'],acao='stop'))
            await asyncio.wait_for(worker,timeout=1)
        assert not servidor.auto_running
    asyncio.run(run())


def test_video_sem_confirmacao_para_apos_repeticao_limitada(monkeypatch):
    async def run():
        state=ECState()
        state.lesson='dialog:123'
        state.video_replays=1
        state.video_ended_since=time.monotonic()-50
        snap={'supported':True, 'lesson_id':'dialog:123', 'title':'Aula', 'mode':'watch',
              'watch_complete':False,'learn_complete':False,
              'video':{'ended':True,'paused':True,'position':10,'duration':10}}
        async def inspect(page): return snap
        monkeypatch.setattr('ec_engine.inspect_ec_player',inspect)
        result=await process_ec_page(object(),state,submit=True)
        assert result['tipo']=='video_atencao'
        assert 'não confirmou' in result['mensagem']
    asyncio.run(run())


def test_iniciador_reconhece_mudanca_de_dependencias():
    import iniciar
    signature=iniciar._requirements_signature()
    assert len(signature)==64
    assert all(x in '0123456789abcdef' for x in signature)
