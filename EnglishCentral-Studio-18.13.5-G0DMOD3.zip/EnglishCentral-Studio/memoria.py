"""Memória local de vocabulário e correções do curso (sem credenciais)."""
from __future__ import annotations
import os
import json
import re
from pathlib import Path
from arquivos_locais import write_json_atomic

ROOT = Path(__file__).resolve().parent
MEMORY_PATH = Path(os.getenv('EC_DATA_DIR', str(ROOT / '.dados_locais'))) / 'memoria_vocabulario.json'
MAX_ITEMS = 400


def clean(value: str, length: int = 320) -> str:
    return re.sub(r'\s+', ' ', str(value or '')).strip()[:length]


def normalized(value: str) -> str:
    return clean(value).casefold()


def _read_state():
    try:
        data = json.loads(MEMORY_PATH.read_text('utf-8'))
    except FileNotFoundError:
        return {'frases': {}, 'palavras': []}, False
    except (ValueError, UnicodeError):
        return {'frases': {}, 'palavras': []}, True
    if not isinstance(data, dict):
        return {'frases': {}, 'palavras': []}, True
    phrases = data.get('frases', {})
    valid_phrases = {key: value for key, value in phrases.items()
                     if isinstance(value, str) and re.fullmatch(r"[A-Za-z][A-Za-z' -]{0,99}", value)} if isinstance(phrases, dict) else {}
    words = data.get('palavras', [])
    valid_words = [value for value in words if isinstance(value, str)
                   and re.fullmatch(r"[A-Za-z][A-Za-z' -]{1,79}", value) and len(value.split()) <= 3] if isinstance(words, list) else []
    changed = phrases != valid_phrases or words != valid_words
    data.update(frases=valid_phrases, palavras=valid_words)
    return data, changed


def read_memory() -> dict:
    return _read_state()[0]


def _save(data: dict) -> None:
    _, recovered = _read_state()
    write_json_atomic(MEMORY_PATH, data, backup=recovered)


def store_words(words: list[str]) -> int:
    data = read_memory()
    found = {normalized(x): x for x in data.get('palavras', []) if x}
    for word in words:
        word = clean(word, 80)
        if re.fullmatch(r"[A-Za-z][A-Za-z' -]{1,79}", word) and len(word.split()) <= 3:
            found[normalized(word)] = word
    data['palavras'] = list(found.values())[-MAX_ITEMS:]
    _save(data)
    return len(data['palavras'])


def store_correction(sentence: str, answer: str) -> None:
    key, value = normalized(sentence), clean(answer, 100)
    if not key or not re.fullmatch(r"[A-Za-z][A-Za-z' -]{0,99}", value):
        return
    data = read_memory()
    data['frases'][key] = value
    if len(data['frases']) > MAX_ITEMS:
        data['frases'] = dict(list(data['frases'].items())[-MAX_ITEMS:])
    _save(data)


def known_answer(sentence: str) -> str | None:
    return read_memory().get('frases', {}).get(normalized(sentence))
