"""Detecta lacunas exibidas sobre o vídeo, sem depender somente de input visível.

Importante: texto gravado dentro dos pixels do próprio vídeo NÃO aparece no DOM;
nesse caso a automação informa que não consegue ler a frase.
"""
from __future__ import annotations
import re
import asyncio

QUIZ_HINT = re.compile(r'digite\s+a\s+resposta\s+correta|digite\s+a\s+palavra\s+que\s+falta|type\s+the\s+missing\s+word|fill\s+in\s+the\s+blank|complete\s+the\s+sentence|palavra\s+que\s+falta', re.I)
CORRECTION = re.compile(r"(?:resposta\s+(?:correta|certa)|palavra\s+correta|correct\s+(?:answer|word)|the\s+answer\s+is)\s*(?:é|is|:|-)?\s*[\"“‘']?([A-Za-z]+(?:[-'][A-Za-z]+)?)", re.I)

# Seleciona o input real mesmo que um jogo esconda a área de digitação em caixas.
QUIZ_JS = r'''() => {
 const clean=(t,n=350)=>String(t??'').replace(/\s+/g,' ').trim().slice(0,n);
 const visible=e=>{const s=getComputedStyle(e),r=e.getBoundingClientRect();return s.display!=='none' && s.visibility!=='hidden' && r.width>0 && r.height>0 && r.bottom>0 && r.right>0 && r.top<innerHeight && r.left<innerWidth};
 const secure=e=>{const meta=[e.type,e.name,e.id,e.getAttribute('autocomplete'),e.getAttribute('aria-label'),e.placeholder].join(' ').toLowerCase();return /password|email|senha|passw|token|otp|verification|c[oó]digo|login|credit|cart[aã]o|tel/.test(meta) || /^(hidden|file|submit|button|radio|checkbox)$/i.test(e.type||'')};
 const video=[...document.querySelectorAll('video')].filter(visible)[0];
 const vr=video?.getBoundingClientRect();
 const prompt=/digite\s+a\s+resposta\s+correta|digite\s+a\s+palavra\s+que\s+falta|type\s+the\s+missing\s+word|fill\s+in\s+the\s+blank|complete\s+the\s+sentence|palavra\s+que\s+falta/i;
 const text=clean(document.body?.innerText||'',9000);
 const quizTextNodes=[...document.querySelectorAll('[class*="caption" i],[class*="subtitle" i],[class*="quiz" i],[class*="sentence" i],[class*="blank" i],[class*="prompt" i],[aria-live],[role="status"],video~div')].filter(e=>visible(e)&&e.children.length<35).map(e=>clean(e.innerText||e.getAttribute('aria-label')||'',400)).filter(t=>t.length>=6);
 let snippets=[...new Set(quizTextNodes)].sort((a,b)=>a.length-b.length).slice(0,48);
 const timedOut=/acabou o tempo|time(?:'s| is) up/i.test(text)&&/resposta (?:certa|correta)|correct answer/i.test(text)&&/\d+\s*\/\s*\d+/.test(text);
 const hasPrompt=prompt.test(text)||snippets.some(t=>prompt.test(t))||timedOut;
 const boxes=[...document.querySelectorAll('[class*="letter" i],[class*="char" i],[class*="blank" i]')].filter(visible).filter(e=>{const r=e.getBoundingClientRect();return r.width>7&&r.width<55&&r.height>7&&r.height<65;});
 let candidates=[];
 const candidateElements=[];
 const editables=[...document.querySelectorAll('input,textarea,[contenteditable="true"],[role="textbox"]')];
 for(const e of editables){
   const angularChar=hasPrompt&&e.classList.contains('char-input');
   const attr=e.getAttribute('readonly');
   const locked=attr!==null&&attr.toLowerCase()!=='false';
   if(secure(e)||e.disabled||(e.readOnly&&!angularChar)) continue;
   const r=e.getBoundingClientRect(),s=getComputedStyle(e);
   const inViewport = r.width>0&&r.height>0&&r.left<innerWidth&&r.right>0&&r.top<innerHeight&&r.bottom>0&&s.display!=='none'&&s.visibility!=='hidden';
   const nearVideo=!!vr && r.x>=vr.left-45&&r.x<=vr.right+45&&r.y>=vr.top-80&&r.y<=vr.bottom+80;
   const active=document.activeElement===e;
   const desc=clean((e.closest('label')?.innerText || e.parentElement?.innerText || e.getAttribute('aria-label') || e.placeholder || ''),240);
   const classMeta=clean(`${e.className||''} ${e.id||''} ${e.name||''}`,180);
   // Jogos podem usar input 1x1/opacity:0 para receber teclado; aceitamos somente
   // se a página exibiu explicitamente o exercício de lacunas.
   if(!inViewport && !(hasPrompt && (active || /answer|blank|typing|guess|letter/i.test(classMeta))))continue;
   const score=(active?7:0)+(nearVideo?5:0)+(inViewport?3:0)+(prompt.test(desc)?6:0)+(/word|answer|blank|input|typing|subtitle|caption|guess/i.test(classMeta)?3:0);
   e.setAttribute('data-ec-quiz-input',String(candidates.length+1));
   candidates.push({id:String(candidates.length+1),score,active,nearVideo, inViewport,
     value:clean(e.value||e.innerText||'',120),rect:{x:Math.round(r.x+r.width/2),y:Math.round(r.y+r.height/2)},
     readonly:locked,angularChar,contexto:desc,limit:e.maxLength>0&&e.maxLength<40?e.maxLength:null});
   candidateElements.push(e);
 }
 // Alguns exercícios representam uma palavra com várias caixas maxlength=1/2.
 // Agrupe apenas caixas próximas na mesma linha para não selecionar só as duas
 // primeiras letras nem digitar uma resposta parcial silenciosamente.
 const claimed=new Set(), letterGroups=[], groupRoots=[];
 for(const e of candidateElements){
   if(claimed.has(e)||!e.maxLength||e.maxLength>2)continue;
   let ancestor=e.parentElement, found=null;
   while(ancestor&&ancestor!==document.body){
     const members=[...ancestor.querySelectorAll('input,textarea,[contenteditable="true"],[role="textbox"]')]
       .filter(x=>candidateElements.includes(x));
     const box=ancestor.getBoundingClientRect();
     if(members.length>=2&&members.length<=16&&members.every(x=>x.maxLength>0&&x.maxLength<=2)&&box.width<=760&&box.height<=220){
       const rects=members.map(x=>x.getBoundingClientRect());
       const sameLine=Math.max(...rects.map(r=>r.top))-Math.min(...rects.map(r=>r.top))<=24;
       const sorted=[...rects].sort((a,b)=>a.left-b.left);
       const close=sorted.every((r,i)=>!i||r.left-sorted[i-1].right<=100);
       if(sameLine&&close){found={ancestor,members,box};break;}
     }
     ancestor=ancestor.parentElement;
   }
   if(!found||found.members.some(x=>claimed.has(x)))continue;
   const id='g'+String(letterGroups.length+1), members=found.members;
   const indexes=members.map(x=>candidateElements.indexOf(x));
   const parts=indexes.map(i=>candidates[i]);
   if(parts.every(x=>x.readonly))continue;
   members.forEach(x=>{x.setAttribute('data-ec-quiz-group',id);claimed.add(x);});
   groupRoots.push(found.ancestor);
   letterGroups.push({id,group:true,field_ids:parts.map(x=>x.id),score:Math.max(...parts.map(x=>x.score))+2,
     pattern:parts.map((x,i)=>x.readonly?x.value.padEnd(members[i].maxLength||1,'_'):'_'.repeat(members[i].maxLength||1)).join(''),
     active:members.includes(document.activeElement),nearVideo:parts.some(x=>x.nearVideo),inViewport:true,
     value:members.map(x=>clean(x.value||'',2)).join(''),
     rect:{x:Math.round(found.box.left+found.box.width/2),y:Math.round(found.box.top+found.box.height/2)},
     contexto:clean(found.ancestor.innerText||'',240),limit:members.reduce((n,x)=>n+(x.maxLength||1),0)});
 }
 candidates=[...candidates.filter((_,i)=>!claimed.has(candidateElements[i])),...letterGroups];
 // O teclado de letras é uma pista do exercício, não parte do enunciado.
 const letterNodes=[...document.querySelectorAll('button,[role="button"],[class*="letter" i],[class*="char" i]')]
   .filter(e=>!e.matches('input,textarea')&&visible(e)&&/^[A-Za-z]$/.test(clean(e.innerText,4))&&
     !groupRoots.some(root=>root.contains(e)));
 const letterBank=letterNodes.filter(e=>!letterNodes.some(child=>child!==e&&e.contains(child)))
   .map(e=>clean(e.innerText,4).toLowerCase());
 for(const group of letterGroups)group.letter_bank=letterBank;
 const highlighted=snippets.find(s=>/\b[A-Za-z][^\n]{3,}\s*_{2,}|\b[A-Za-z][^\n]{3,}\s*□/.test(s))||'';
 const exerciseContext=snippets.filter(t=>prompt.test(t)&&/\b[A-Za-z]+\b.*[.!?]/.test(t)).sort((a,b)=>a.length-b.length)[0]||'';
 let phrase=highlighted || clean(exerciseContext.split(prompt)[0],500) || snippets.filter(s=>!prompt.test(s)&&s.split(' ').length>=5).sort((a,b)=>b.length-a.length)[0] || '';
 // innerText omite as caixas de letras. Preserve a posição da lacuna no enunciado.
 const wordInput=[...document.querySelectorAll('ec-player-word-input')].find(visible);
 const sentence=wordInput?.closest('.player-transcript-row,.caption,.sentence,.quiz-question');
 if(sentence){
   const copy=sentence.cloneNode(true);
   copy.querySelectorAll('ec-player-word-input').forEach(e=>e.replaceWith(document.createTextNode(' ___ ')));
   const reconstructed=clean(copy.textContent,500);
   if(reconstructed.includes('___'))phrase=reconstructed+' | Context: '+phrase;
 }
 // Os quizzes de palavras podem usar char-input diretamente, sem ec-player-word-input.
 // Use o menor ancestral que contenha as caixas e o texto da frase.
 if(!phrase.includes('___')){
   for(const group of [...letterGroups].sort((a,b)=>b.score-a.score)){
     const first=document.querySelector('[data-ec-quiz-input="'+group.field_ids[0]+'"]');
     let root=first?.parentElement;
     while(root&&root!==document.body){
       const source=(root.innerText||'').trim();
       if(source.length>1400)break;
       const clone=root.cloneNode(true);
       const fields=[...clone.querySelectorAll('[data-ec-quiz-group="'+group.id+'"]')];
       if(fields.length===group.field_ids.length){
         fields.forEach((field,i)=>field.replaceWith(document.createTextNode(i?'':' ___ ')));
         clone.querySelectorAll('button,[role="button"],.letter-bank,.char-bank').forEach(e=>e.remove());
         const rebuilt=clean((clone.textContent||'').split(prompt)[0],500);
         const surrounding=rebuilt.replace(/___/g,'').match(/[A-Za-z]+/g)||[];
         if(rebuilt.includes('___')&&surrounding.length>=2){
           phrase=rebuilt+(phrase&&!rebuilt.includes(phrase)?' | Context: '+phrase:'');
           break;
         }
       }
       root=root.parentElement;
     }
     if(phrase.includes('___'))break;
   }
 }
 const feedback=[...document.querySelectorAll('[role="alert"],[aria-live],.correct,.incorrect,[class*="feedback" i],[class*="hint" i]')].filter(visible).map(x=>clean(x.innerText,160)).filter(Boolean).join(' | ').slice(0,650);
  const groups=[...document.querySelectorAll('fieldset,[role="radiogroup"],[class*="quiz" i],[class*="question" i]' )].filter(visible);
  let choice=null;
  for(const group of groups){
    const controls=[...group.querySelectorAll('input[type="radio"],[role="radio"],[data-testid*="option" i],[class*="answer-option" i],button[data-answer],[role="option"]')].filter(e=>!e.disabled&&e.getAttribute('aria-disabled')!=='true');
    if(controls.length<2||controls.length>8)continue;
    const options=[];
    for(const [i,e] of controls.entries()){
      const label=e.labels?.[0]||e.closest('label')||group.querySelector(`label[for="${CSS.escape(e.id||'__none__')}"]`);
      const target=label&&visible(label)?label:e;
      if(!visible(target))continue;
      const value=clean(label?.innerText||e.getAttribute('aria-label')||e.innerText||e.value||'',180);
      if(!value||options.some(o=>o.text.toLocaleLowerCase()===value.toLocaleLowerCase()))continue;
      const id=String(options.length+1);target.setAttribute('data-ec-quiz-choice',id);
      options.push({id,text:value,selected:!!e.checked||e.getAttribute('aria-checked')==='true'});
    }
    const questionNode=[...group.querySelectorAll('[class*="question" i],[data-testid*="question" i],[role="heading"],legend,h1,h2,h3')].find(visible);
    let question=clean(questionNode?.innerText||'',500);
    if(!question){question=clean(group.innerText,900);for(const option of options)question=clean(question.replace(option.text,''),900);}
    if(options.length>=2&&question.length>=6){choice={question,options};break;}
  }
  const negative=/\b(?:incorrect|wrong|not quite|try again|incorret[oa]|errad[oa])\b/i.test(feedback);
  const positive=!negative&&/\b(?:correct|that's right|well done|corret[oa]|muito bem)\b/i.test(feedback);
  const progress=text.match(/(?:question|quest[aã]o)\s*(\d+)\s*(?:of|de)\s*(\d+)/i);
  const quizComplete=/quiz\s+(?:complete|completed|finished)|qu[ií]z\s+(?:conclu[ií]do|finalizado)|resultado\s+final|pr[aá]tica\s+completa|practice\s+complete/i.test(text)||
    [...document.querySelectorAll('[class*="quiz-complete" i],[data-testid*="quiz-complete" i]')].some(visible);
 const questionDone=!candidates.length&&(positive||/(?:resposta\s+(?:certa|correta)|correct\s+answer)/i.test(text))&&/\b(?:continuar|continue)\b/i.test(text);
 return {question_done:questionDone,hasPrompt,frase:phrase,trechos:snippets.slice(0,20),campos:candidates,caixas:boxes.length,letter_bank:letterBank,
      feedback:feedback,expired:timedOut,video:!!video, texto:text.slice(0,3800),choice,
      choice_correct:positive,choice_incorrect:negative,quiz_complete:quizComplete,
      question_number:progress?Number(progress[1]):null,question_total:progress?Number(progress[2]):null};
}'''

WORDS_JS = r'''() => {
 const visible=e=>{const s=getComputedStyle(e),r=e.getBoundingClientRect();return s.display!=='none'&&s.visibility!=='hidden'&&r.width>0&&r.height>0};
 const words=[];
 for(const e of document.querySelectorAll('li,tr,[class*="word" i],[class*="vocab" i]')){
  if(!visible(e))continue;
  const t=(e.innerText||'').trim();
  if(t.length>90||t.length<3)continue;
  const m=t.match(/^([A-Z][A-Z' -]{1,28})(?:\s*\n|\s{2,})([^\n]{1,40})/i);
  if(m)words.push(m[1].trim());
 }
 return [...new Set(words)].slice(0,60);
}'''

async def inspect_quiz(page) -> dict:
    results=[]
    for index, frame in enumerate(page.frames[:15]):
        try:
            data=await frame.evaluate(QUIZ_JS)
            data['frame']=index
            results.append(data)
        except Exception:
            pass
    prompt_frame=max(results, key=lambda x:(bool(x.get('choice')),bool(x.get('quiz_complete')),x['hasPrompt'], x['video'], len(x['frase'])), default={})
    input_frame=prompt_frame if prompt_frame.get('campos') else next((r for r in results if r.get('campos')), prompt_frame)
    multiple_choice=prompt_frame.get('choice') or {}
    found=bool(prompt_frame.get('hasPrompt') and input_frame.get('campos')) or bool(prompt_frame.get('question_done')) or bool(multiple_choice) or bool(prompt_frame.get('quiz_complete')) or bool(prompt_frame.get('expired')) or any(r.get('hasPrompt') and (r.get('video') or re.search(r'digite\s+a\s+resposta\s+correta|digite\s+a\s+palavra\s+que\s+falta|type\s+the\s+missing\s+word', r.get('texto',''), re.I)) for r in results)
    return {'ativa':found,'tipo':'multipla_escolha' if multiple_choice else ('resultado' if prompt_frame.get('quiz_complete') else 'lacuna'),
            'frame':prompt_frame.get('frame',0), 'input_frame':input_frame.get('frame',0),
            'pergunta':multiple_choice.get('question',''), 'opcoes':multiple_choice.get('options',[]),
            'correta':prompt_frame.get('choice_correct',False),'incorreta':prompt_frame.get('choice_incorrect',False),
            'quiz_concluido':prompt_frame.get('quiz_complete',False),
            'questao_encerrada':prompt_frame.get('question_done',False),
            'numero_questao':prompt_frame.get('question_number'),'total_questoes':prompt_frame.get('question_total'),
            'frase':prompt_frame.get('frase','') or input_frame.get('frase',''),
            'trechos':prompt_frame.get('trechos',[]),'campos':input_frame.get('campos',[]),
            'banco_letras':input_frame.get('letter_bank',[]) or prompt_frame.get('letter_bank',[]),
            'feedback':prompt_frame.get('feedback','') or input_frame.get('feedback',''),
            'caixas':prompt_frame.get('caixas',0), 'texto':prompt_frame.get('texto',''),
            'video':prompt_frame.get('video',False),'expirou':prompt_frame.get('expired',False)}


async def select_quiz_choice(page, quiz: dict, answer: str) -> dict:
    """Seleciona uma opção somente quando o texto corresponde a uma resposta única."""
    options=quiz.get('opcoes') or []
    matching=[o for o in options if re.sub(r'\s+',' ',o.get('text','')).strip().casefold()==answer.strip().casefold()]
    if len(matching)!=1:
        raise RuntimeError('A resposta sugerida não corresponde a uma única opção visível.')
    frame_index=quiz.get('frame',0)
    if not isinstance(frame_index,int) or not 0<=frame_index<len(page.frames):
        raise RuntimeError('O frame do quiz mudou; observe a página novamente.')
    loc=page.frames[frame_index].locator('[data-ec-quiz-choice="'+matching[0]['id']+'"]')
    if await loc.count()!=1 or not await loc.is_visible():
        raise RuntimeError('A opção do quiz mudou antes da seleção.')
    box=await loc.bounding_box()
    await loc.click(timeout=5000)
    return {'x':round(box['x']+box['width']/2),'y':round(box['y']+box['height']/2),
            'acao':'quiz_opcao','texto':'Opção selecionada.'} if box else {'acao':'quiz_opcao','texto':'Opção selecionada.'}

async def inspect_words(page) -> list[str]:
    words=[]
    for frame in page.frames[:15]:
        try: words.extend(await frame.evaluate(WORDS_JS))
        except Exception: pass
    return list(dict.fromkeys(words))[:60]


def _same_quiz_prompt(before: str, after: str, answer: str) -> bool:
    def compact(value: str) -> str:
        return re.sub(r'\s+', ' ', re.sub(r'[^a-z0-9]+', ' ', (value or '').casefold())).strip()
    if not before or not after:
        return False
    if compact(before) == compact(after):
        return True
    without_blank = compact(re.sub(r'_{2,}|□+', ' ', before))
    without_answer = compact(re.sub(re.escape(answer), ' ', after, flags=re.I))
    return bool(without_blank and without_blank == without_answer)


def read_correction(feedback: str) -> str | None:
    match=CORRECTION.search(feedback)
    if not match:return None
    # Não considerar frases genéricas longas como uma palavra correta.
    tail=feedback[match.start(1):]
    tail=re.split(r'\||[\r\n.!;]|\b(?:Continuar|Continue|REPORT|Verificar)\b',tail,maxsplit=1,flags=re.I)[0]
    val=tail.strip(' ,:\"“”‘’')
    if not re.fullmatch(r"[A-Za-z]+(?:[-'][A-Za-z]+)*(?: [A-Za-z]+(?:[-'][A-Za-z]+)*){0,2}",val):
        return None
    return val if len(val.split())<=3 else None

async def type_quiz_answer(page, state: dict, answer: str, *, enter: bool=True) -> dict:
    """Seleciona um único input adequado; não clica cegamente no vídeo nem em outras abas."""
    candidates=sorted(state.get('campos',[]),key=lambda f:f['score'], reverse=True)
    if not candidates:
        raise RuntimeError('Campo do jogo não encontrado no DOM; informe uma captura da lacuna ativa.')
    if len(candidates)>1 and candidates[0]['score']==candidates[1]['score']:
        raise RuntimeError('Encontrei vários campos possíveis; evitei digitar no local errado.')
    selected=candidates[0]
    frame_index=state.get('input_frame',state.get('frame',0))
    if not isinstance(frame_index,int) or not 0<=frame_index<len(page.frames):
        raise RuntimeError('O frame do campo mudou; observe a página novamente.')
    frame=page.frames[frame_index]
    if selected.get('group'):
        letters=re.sub(r'[^A-Za-z]','',answer)
        field_ids=selected.get('field_ids') or []
        fields=[]
        for field_id in field_ids:
            item=frame.locator('[data-ec-quiz-input="'+field_id+'"]')
            if await item.count()!=1 or not await item.is_visible() or not await item.is_enabled():
                raise RuntimeError('As caixas de letras do quiz mudaram antes do preenchimento.')
            fields.append(item)
        capacities=[]
        for item in fields:
            raw=await item.get_attribute('maxlength')
            capacities.append(int(raw) if raw and raw.isdigit() else 1)
        if len(letters)>sum(capacities):
            raise ValueError(f'A lacuna aceita {sum(capacities)} letras, menos que as {len(letters)} da resposta.')
        offset=0
        # Valide todas as dicas antes de digitar qualquer letra.
        for item, capacity in zip(fields, capacities):
            readonly = await item.get_attribute('readonly')
            if readonly is not None and readonly.lower() != 'false':
                if (await item.input_value()).casefold() != letters[offset:offset+capacity].casefold():
                    raise ValueError('A resposta não combina com a letra de dica mostrada pelo quiz.')
            offset += capacity
        offset=0
        for item,capacity in zip(fields,capacities):
            segment=letters[offset:offset+capacity]
            readonly=await item.get_attribute('readonly')
            if readonly is not None and readonly.lower()!='false':
                if (await item.input_value()).casefold()!=segment.casefold():
                    raise ValueError('A resposta não combina com a letra de dica mostrada pelo quiz.')
            else:
                for letter in segment:
                    await item.press(letter,timeout=2500)
            offset+=capacity
        observed=''.join([await item.input_value() for item in fields])
        for _ in range(8):
            if observed.casefold()==letters.casefold():
                break
            await asyncio.sleep(.2)
            observed=''.join([await item.input_value() for item in fields])
        if observed.casefold()!=letters.casefold():
            raise RuntimeError(f'O quiz recebeu {len(observed)} de {len(letters)} letras; a resposta parcial não foi enviada.')
        if enter:
            current=await inspect_quiz(page)
            if (current.get('ativa') and current.get('frame')==state.get('frame') and
                    _same_quiz_prompt(state.get('frase',''),current.get('frase',''),answer)):
                await fields[-1].press('Enter',timeout=2500)
        return {'x':selected['rect']['x'],'y':selected['rect']['y'],'acao':'digitacao',
                'texto':'Palavra preenchida em todas as caixas; Enter enviado.' if enter else 'Palavra preenchida em todas as caixas.'}
    loc=frame.locator('[data-ec-quiz-input="'+selected['id']+'"]')
    if await loc.count()!=1:raise RuntimeError('Campo do jogo mudou antes do preenchimento.')
    answer_letters=re.sub(r'[^A-Za-z]','',answer)
    if selected.get('limit') and len(answer_letters)>selected['limit']:
        raise RuntimeError(f'O campo aceita {selected["limit"]} letras, mas a resposta tem {len(answer_letters)}; evitei enviar só o começo da palavra.')
    # Para input visível usa fill; para input de teclado escondido mas focado usa teclado.
    if selected['inViewport'] and await loc.is_visible():
        await loc.fill('',timeout=5000)
        await loc.press_sequentially(answer, delay=80, timeout=8000)
    elif selected['active'] or not selected['inViewport']:
        # O campo oculto identificado pelo exercício pode não ter foco ainda.
        await loc.focus(timeout=2500)
        if not await loc.evaluate('(e)=>document.activeElement===e'):
            raise RuntimeError('O campo do quiz não recebeu foco.')
        await page.keyboard.press('ControlOrMeta+A')
        await page.keyboard.type(answer, delay=80)
    else:
        raise RuntimeError('O campo de texto do jogo não pode receber digitação com segurança.')
    if enter:
        current=await inspect_quiz(page)
        if (current.get('ativa') and current.get('frame')==state.get('frame') and
                _same_quiz_prompt(state.get('frase',''),current.get('frase',''),answer)):
            await loc.press('Enter',timeout=4000)
    return {'x':selected['rect']['x'],'y':selected['rect']['y'],'acao':'digitacao', 'texto':'Resposta preenchida; Enter enviado.' if enter else 'Resposta digitada.'}
