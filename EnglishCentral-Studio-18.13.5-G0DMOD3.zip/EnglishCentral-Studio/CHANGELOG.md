## V18.13.5 — Autorização no PC e publicação do código

- Mensagem de token inválido (HTTP 401) orienta o fluxo real no computador: reiniciar com INICIAR.bat, usar a URL com `#token=` do terminal ou colar o conteúdo de `token_painel.txt`.
- Testes focados (profiles, API, SEDUCTEC multiagente, browser connection): 49 passed.
- Código-fonte publicado no GitHub para versionamento; a automação continua rodando localmente no PC (Playwright + Chrome), não em página estática.

## V18.13.4 — Pessoas: apagar, paralelismo EC+SEDUCTEC e sessões isoladas

- **Apagar pessoa**: botão na lista de pessoas (exceto principal). Remove cadastro e pasta de dados local; tenta encerrar o painel daquela sessão.
- Cada pessoa continua com **processo, porta, token, navegador, IA e automação próprios** — dá para uma estar no EnglishCentral e outra no SEDUCTEC ao mesmo tempo.
- Grade multi-pessoa e textos de ajuda deixam explícito o uso paralelo (EC + SEDUCTEC ou várias no mesmo portal).
- Endpoint `DELETE /api/profiles/{id}` e `POST /api/shutdown` para encerrar workers.
- Foco no uso em computador; nada do motor EnglishCentral ou SEDUCTEC foi removido.

## V18.13.3 — SEDUCTEC: check verde e fila só do pendente

- Detecção ampliada de conclusão no SEDUCTEC: check verde, badge de sucesso, ícones fa-check e cards customizados (além do checkbox padrão Moodle).
- Varredura de atividades reconhece cards/links do tema SEDUCTEC sem duplicar itens.
- Ao iniciar a automação do curso: atividades com conclusão verde ou já processadas são **puladas**; a mensagem informa quantas estão pendentes e quantas já estavam feitas.
- Ao abrir uma atividade já concluída na página, o agente marca como pulada e segue para a próxima.
- EnglishCentral (incluindo Converse sobre o vídeo / MiMi) **não foi alterado** nesta parte.

## V18.13.3 — Converse sobre o vídeo (MiMi) na automação

- Novo modo de atividade **Converse sobre o vídeo** na seleção do EnglishCentral (checkbox separado; nada removido).
- `ModoEstudo.conversar` + detecção `chat` / `chat_complete` no player.
- Automação abre a atividade de conversa e envia respostas geradas pela MiMi de prática (IA configurada).
- Presets e labels atualizados; demais modos (vídeos, palavras, quizzes, fala, activities) intactos.

## V18.13.2 — Clique real de enviar/publicar (opt-in)

- Implementado clique real no botão de **enviar/finalizar tentativa** do quiz quando `enviar_quiz=True`.
- Implementado clique real no botão de **publicar/enviar resposta** do fórum quando `publicar_forum=True`.
- Estados `enviado` e `publicado` passam a contar como sucesso na fila de automação.
- Padrão continua seguro: as opções nascem desligadas; só atuam quando o usuário marca explicitamente nas Configurações SEDUCTEC.
- Prévia resiliente, schema v3 e demais melhorias da revisão anterior mantidas.

## V18.13.2 — Prévia resiliente, opt-in de envio e grade de agentes

- Prévia principal deixa de bloquear 40s quando a automação está com o lock: prioriza a última captura do agente e reduz o timeout, evitando a mensagem prolongada de “navegador ocupado”.
- Configurações SEDUCTEC ganham opt-in explícito **Enviar tentativa de quiz automaticamente** e **Publicar resposta de fórum automaticamente** (padrão desligado, seguro).
- Schema de preferências SEDUCTEC atualizado para versão 3; PUT parcial continua preservando valores omitidos.
- Interface de configurações e persistência JS atualizadas para os novos campos.
- Mantidos multiagente, barreira de seção, seta Voltar de PDF, scroll vertical da prévia, perfis independentes e AutoTune/ULTRAPLINIAN da V18.13.1.
- Nenhum módulo EnglishCentral foi removido.

## V18.13.1 — G0DM0D3 AutoTune/ULTRAPLINIAN, contexto real e estados fechados

- Preservados todos os módulos, recursos, telas, rotas e dados locais da V18.13.0; nenhuma funcionalidade anterior foi deliberadamente removida.
- Fila por seção em duas fases: leitura/coleta de materiais primeiro; quiz/fórum/tarefa depois. O texto extraído do material é passado ao quiz/fórum somente na memória temporária da execução.
- Contexto de materiais mantido na ordem original da aula, limitado a 16 mil caracteres no repasse e eliminado ao fim da seção. Conteúdo bruto não aparece em status, snapshot ou histórico persistido.
- AutoTune classifica o tipo de questão, seleciona trechos de material lexicalmente relevantes e ajusta a temperatura por tarefa.
- Avaliador heurístico inspirado no ULTRAPLINIAN compara ID, índice, preenchimento, validade de opções, relação textual, confiança declarada e repetição. O resultado não comprova correção factual.
- Estados desconhecidos agora são falhas, nunca sucesso. Estados preparados/não enviados ficam em revisão; somente `pdf_lido` e `material_lido` são sucessos confirmados da fila.
- PDF: `paginas_lidas` acompanha páginas realmente examinadas e respeita o limite de 24 mil caracteres.
- Compatibilidade: aliases de tarefa/assignment e destino persistente por diretório de perfil.
- Testes focados Python: 109 aprovados em baterias SEDUCTEC/IA/perfis/navegação/regressões; teste isolado de seleção de curso: 1 aprovado; motor EnglishCentral: 5 aprovados. Verificações compileall, bash -n e node --check também passaram.
- Suíte completa: não concluída neste ambiente devido a bloqueios de rede em testes que navegam para portais reais (`ERR_BLOCKED_BY_ADMINISTRATOR`) e timeouts de testes externos/legados. Não afirmar validação ponta-a-ponta de conta SEDUCTEC real.

## V18.13.0 — Automação de curso, multiagente e painéis paralelos

- Orquestrador Moodle com até quatro workers em abas independentes por perfil.
- Expansão de seções recolhidas e varredura com rolagem para carregar atividades tardias; agentes trabalham em paralelo dentro de cada seção, com barreira antes da próxima aula.
- Cartões ao vivo de agentes com progresso, etapa, status e screenshot atualizado; PDFs abrem em aba temporária própria e fecham após a extração.
- Grade interativa de perfis independentes, com abertura concorrente de contas diferentes.
- Retorno compacto para fechar PDF temporário e controle vertical de rolagem da prévia.
- Preferências da MiMi salvas por perfil no servidor e aplicadas na interface e na chamada do chat.
- Testes novos para distribuição paralela por seção, isolamento de páginas, seções colapsadas/carregadas ao rolar, retorno do PDF e extração real de PDF com limite de 50 páginas.
- A finalização de tentativas e a publicação em fóruns continuam exigindo confirmação humana.

## V18.12.4 — Segurança de origem, PDFs e compatibilidade Termux

- SEDUCTEC: a leitura de PDF aceita somente URLs identificadas entre os recursos visíveis da página atual; ser PDF ou estar no mesmo domínio não basta.
- SEDUCTEC: se a abertura de uma atividade redirecionar para fora do domínio oficial, o Studio tenta restaurar a página de origem e sinaliza o bloqueio.
- Classificação de plataforma: origens não reconhecidas deixam de ser tratadas como EnglishCentral; automação específica fica desabilitada quando a origem não é confiável.
- Termux/desktop: `EC_BROWSER_EXECUTABLE` tem prioridade; `EC_CHROMIUM_PATH` permanece como fallback compatível. O inicializador Termux exporta ambas as variáveis e o servidor valida o arquivo configurado.
- Testes: atualizadas expectativas antigas da fila de navegador; corrigida a fixture que importava o gerador de PDF de forma incorreta; adicionados testes para seleção/validação do executável Chromium.
- A Skill `SKILL.md` continua orientando o ciclo Analyze → Plan → Execute → Test → Fix → Optimize, com automações Moodle/EnglishCentral separadas e envio/publicação final sob ação explícita da pessoa usuária.

## V18.12.3 — Auditoria minuciosa e correções adicionais

- Corrigido vazamento de `EC_IA_*` do processo principal para perfis secundários. Cada perfil usa somente sua própria configuração de IA; a chave principal não é herdada por outra conta.
- Corrigida a correspondência dos índices de alternativas Moodle quando existem controles ocultos/desabilitados; o prompt agora manda usar os índices originais, mesmo quando não são contíguos.
- Adicionada geração de respostas de quiz em lotes de até 25 questões, suportando até 40 questões visíveis por leitura. Se qualquer lote falhar, nenhum campo é preenchido.
- Adicionado fingerprint de enunciados, opções, campos e estado para evitar aplicar respostas geradas a uma página que mudou enquanto a IA respondia.
- O estado de conclusão da disciplina não é inferido por um badge isolado de uma atividade; os estados individuais continuam separados.
- Questões com múltiplos campos, inclusive combinação de campo normal e editor iframe, são explicitamente puladas para evitar preencher só parte da resposta. Questões numéricas aceitam vírgula decimal e releem o valor aplicado.
- Fórum: a listagem abre primeiro uma discussão visível; o rascunho seleciona o mesmo post com resposta disponível; editores em iframe têm o texto relido antes de confirmar o preenchimento.
- PDF: fechamento só é declarado após confirmar que a aba temporária foi fechada e o retorno ao curso é reportado separadamente. Extração `pypdf` é executada fora do event loop/lock do navegador.
- Atualizações parciais das configurações preservam opções omitidas. Adicionado inicializador `TERMUX_INICIAR.sh` para iniciar o servidor no Termux sem tentar instalar Chromium Linux via Playwright.
- Interface e documentação identificam a versão 18.12.3 e distinguem configuração OpenAI em nuvem de configuração de modelo local.

## V18.12.1 — Correção do botão Executar e automação Moodle

- Corrigido rótulo ausente para a rota `quiz_inicio`; a atualização de contexto não falha mais ao abrir a página de instruções do questionário.
- O botão **Executar** agora procura atividades pendentes na página de curso/painel e abre a atividade visível antes de executar sua ação (quiz, fórum ou PDF).
- Separado início da primeira tentativa de quiz da ação de repetir uma tentativa concluída. A opção “Tentar novamente” não bloqueia mais a primeira tentativa.
- Links de início/repetição e resposta de fórum mantêm `sesskey` somente durante a navegação visível necessária ao Moodle; esse parâmetro não é gravado no perfil nem apresentado nos logs.
- Recursos PDF que apontam inicialmente para `mod/resource/view.php` são abertos, inspecionados e resolvidos para o arquivo direto `pluginfile.php` antes da leitura. A ação manual “Ler PDF” também resolve o recurso intermediário.
- Preferências antigas V18.12 que gravavam `preencher_forum=false` como padrão são migradas uma única vez para `true`; a escolha passa a ser respeitada depois que as configurações são salvas com `schema_version=2`.
- Testes com Chromium real e páginas Moodle locais validam o clique do botão Executar para curso → quiz → início de tentativa → preenchimento, curso → recurso → PDF direto, fórum → abrir editor → preencher rascunho, mais inspeção de campos, CSRF temporário e fechar PDF.
- Bateria selecionada de regressão: 112 testes aprovados. A suíte integral não terminou porque testes de navegador que dependem de domínios externos são bloqueados no ambiente (`ERR_BLOCKED_BY_ADMINISTRATOR`). Nenhuma conta autenticada ou chave de API do usuário foi fornecida; não foi possível confirmar o portal real nesta sessão.

## V18.12 — Multicurso, SEDUCTEC ativo e AutoTune

- Verificação de conectividade da IA sem geração: OpenAI confirma o acesso ao modelo; Ollama/LM Studio confirmam servidor e modelo disponível. O painel não confunde configuração salva com conexão funcional.

- Seletor multicurso reforçado: uma aba EnglishCentral e uma aba SEDUCTEC por perfil, ambas dentro do mesmo contexto de sessão; ao alternar, reutiliza a aba correspondente sem fechar a outra. A busca de abas é limitada ao contexto do perfil para não misturar logins de outras contas.

- Mantém o motor existente do EnglishCentral e adiciona seletor superior com o curso MyClass principal (`/myclass/232103/0/courses`) e SEDUCTEC (`seductec.seduc.pi.gov.br`).
- Adaptador Moodle separado para leitura do curso, reconhecimento de questionários/fóruns, estado de atividade e controles visíveis de nova tentativa.
- PDF: identifica recurso, abre em aba temporária, permite extração de texto selecionável com `pypdf` (limite de 20 MB/50 páginas) e restaura a página anterior ao fechar.
- Fórum: extrai discussão atual, gera rascunho via API ou IA local, abre editor e confirma preenchimento sem publicar.
- Quiz: gera sugestões estruturadas, valida ID/índice/quantidade de questões, respeita baixa confiança, preenche somente pendentes e relê os campos para confirmar. Envio final continua explícito na interface Moodle.
- Estado Moodle distingue pendente, parcial, preenchido sem envio, conclusão confirmada e não confirmado.
- Configuração SEDUCTEC por perfil: Tudo/PDF/Fórum/Quiz, preenchimento de quiz/fórum e tentativas limitadas de geração.
- IA Moodle/MiMi aceita API OpenAI, Ollama e servidores locais OpenAI-compatíveis; status e interface mostram quando a geração usa nuvem ou modelo local.
- MiMi de prática contextualizada por vídeo, com distinção explícita da MiMi oficial e tentativa de abrir o controle oficial quando visível.
- Isolamento da chave/configuração de IA por perfil adicional; perfil principal preserva o arquivo legado existente.
- Perfis simultâneos continuam usando servidores/portas/tokens/diretórios independentes; abertura em nova aba não substitui sessão atual e instrui a usar navegador normal quando PWA bloquear pop-ups.
- Novos controles de UI em desktop/celular e cache da PWA atualizado para 18.12.0.
- Skill.md documenta Analyze → Plan → Execute → Test → Fix → Optimize e critérios de evidência.
- Verificação Python/JavaScript e testes de DOM Moodle local aprovados. Portal autenticado real, API com chave do usuário e envio final não foram testados nesta sessão.

# Alterações consolidadas

## V18.11.1 — IA local adaptativa para respostas

- AutoTune identifica o tipo de enunciado (definição, comparação, causas/consequências, resumo, interpretação, opinião, cálculo ou outro) e ajusta a estratégia/temperatura antes da geração.
- Seleção de trechos de material por relevância lexical, reduzindo texto de página sem relação com a pergunta.
- Verificações locais de cobertura, relação com o material, repetição e tamanho; no máximo uma revisão adicional quando há sinais objetivos de baixa qualidade.
- Feedback por categoria ajusta preferências de concisão, detalhamento, especificidade e cautela. O armazenamento contém apenas estatísticas agregadas, sem enunciados, respostas ou materiais.
- Compatibilidade com Ollama e APIs locais OpenAI-compatíveis (LM Studio/llama.cpp) restrita a localhost/127.0.0.1/::1. A função Moodle nunca usa provedor em nuvem.
- A geração prepara rascunhos; preenchimento de campo é escolha explícita e nenhum envio/finalização é acionado.
- Atualização do cache público da PWA e novos testes de classificação, revisão, feedback, persistência privada e endpoint local.

## V18.11 — Compatibilidade SEDUCTEC/Moodle

- Seletor de ambiente aceita links HTTPS do domínio oficial `seductec.seduc.pi.gov.br` e mantém o destino escolhido entre sessões.
- Abas SEDUCTEC/Moodle passam a ser reconhecidas e podem ser reutilizadas no navegador conectado.
- Inspeção somente de leitura identifica páginas de curso, seções, atividades, tipos de recurso, enunciados visíveis e players de vídeo.
- Conteúdo e enunciados Moodle aparecem nas ferramentas de leitura/inspeção; anotações de visita ficam no armazenamento local.
- A automação específica do player EnglishCentral é bloqueada no Moodle e interrompida ao navegar para o SEDUCTEC.
- Respostas, fóruns, tarefas, questionários e envios permanecem sob controle do estudante; não há preenchimento nem submissão automática no Moodle.
- URLs salvas e links listados removem fragmentos e parâmetros conhecidos de sessão; credenciais e cookies não são copiados para o painel.
- Testes focados iniciais da integração: 43 aprovados; validação de sintaxe Python e JavaScript concluída.
- Acesso autenticado a cursos reais do SEDUCTEC não foi validado nesta adaptação; o login é realizado pelo usuário no próprio portal.



## V18.11 — Aplicativo para celular

- PWA com manifesto, ícones, instalação, atualização por escolha e tela offline.
- Ajustes de toque, campos, áreas seguras e teclas do navegador remoto.
- Sincronização ao voltar do segundo plano sem duplicar o início da sessão.
- Persistência opcional do acesso, com armazenamento separado por painel.
- Gateway de pessoas no mesmo domínio HTTPS, sem URLs de loopback no telefone.
- Preparação de servidor Docker/Caddy com Chromium, Xvfb, eSpeak e volume de dados.
- Configuração de IA remota persistida por pessoa; configuração Windows preservada.
- Verificação HTTPS/origem no modo remoto e respostas privadas fora dos caches.
- Raiz HTTP agora aceita HEAD para permitir a reconexão da tela offline.
- Nenhuma mudança no algoritmo de responder quizzes, contar vídeos ou avaliar fala.
- Hospedagem pública, login Google hospedado e construção do contêiner não realizados.

## V18.10 — Sessão e retomada

- Conexão explícita ao Chrome já aberto, seleção de abas, modo salvo por pessoa e alternativa local por porta.
- Conexão recusada/perdida não troca silenciosamente para outro perfil. Desconectar preserva o Chrome pessoal.
- Popups de login acompanhados; retomada quando o curso fica disponível, sem ler ou preencher credenciais.
- Abas fechadas recuperadas no mesmo contexto; outro contexto exige escolha explícita.
- Consultas de navegador com prazo no servidor e liberação do lock; leituras ocupadas não formam fila.
- Preparação de IA limitada; sonda externa não bloqueia uma página funcional.
- Tour inicial tratado pelo título exato e botão oficial, com limite de tentativas.
- Monitor de avanço baseado na atividade e mensagens de espera cancelada no Assistente.
- Encerramento das abas do navegador privado antes de fechar o contexto, preservando seu perfil e permitindo reabertura.
- Coordenadas da prévia adaptadas à dimensão real da aba.
- Playwright mínimo atualizado para 1.62; 31 regressões Python e nove cenários de interface acrescentados.

## V18.9 — Revisão e limpeza

- Quiz atualmente pendente tem precedência sobre o cache antigo, preservando o progresso das demais etapas.
- Leitura de progresso, vocabulário e cadastro validada. Reparos guardam o original antes de gravar.
- Gravação atômica, geração de token e trava local unificadas.
- Nova rota autenticada de saúde para reabrir perfis sem depender da velocidade do navegador.
- Recuperação de conexão durante o tratamento de erros, prazos para requisições e capturas sem fila.
- Preferências de IA preservadas ao atualizar a chave e parâmetros ajustados ao modelo escolhido.
- Dependência Pydantic 2 explicitada, conforme o uso de `model_dump` no servidor.
- Removidos auxiliares sem uso, sete declarações CSS redundantes, documentação duplicada, prints antigos e publicador desatualizado.
- Testes antigos adaptados aos controles atuais e novas regressões para os defeitos encontrados.

## Recursos herdados mantidos

- V18.8: contagem de dez segundos, barra, cancelamento e limite de três tentativas automáticas por problema.
- V18.7: meta de fala, tratamento de nota baixa, múltiplas pessoas e interface responsiva.
- V18.6: reconexão, decisões de repetir/pular/parar e histórico por foco.
- Anteriores: vídeo, palavras, quizzes, fala sintética, leitura visual opcional e controles visíveis da plataforma.

Este documento substitui as notas separadas por versão. Relatos antigos de testes em contas reais não constituem validação da V18.9.

## V18.12.3 — Fila de navegador, prévia móvel e MiMi configurável
- Leituras e capturas aguardam a fila do navegador em vez de exibir repetidamente “navegador ocupado”.
- Barra compacta na prévia com Voltar e rolagem real para cima/baixo.
- Leitura de PDF fecha a aba temporária e retoma a sequência do curso quando a navegação permite.
- Preferências da MiMi (nível, estilo e idioma de apoio) configuráveis e isoladas por perfil.
- Execução concorrente de agentes no mesmo DOM não é habilitada; perfis independentes continuam sendo sessões/processos separados.
