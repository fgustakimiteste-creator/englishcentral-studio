"""Cenários inspirados nas duas capturas: não representam acesso à conta real."""
import asyncio
from unittest.mock import patch

from playwright.async_api import async_playwright
from conftest import chromium_launch_options
from etapas import classify_stage
from integracao import inspect_page
from auto_fluxo import process_page


def test_com_video_no_dom_atividade_ativa_e_palavras():
    info = {'textoVisivel': 'Assista ao vídeo\nAprenda as palavras\nFale as linhas\nTodas as palavras: 264\nPalavras selecionadas: 5\nAprenda estas palavras do vídeo:\nAprenda 5 palavras',
            'videos': [{'id':'1','reproduzindo':False,'concluidoNoPlayer':False}], 'campos':[]}
    etapa = classify_stage(info)
    assert etapa['codigo'] == 'palavras_selecao'
    assert etapa['selecionadas'] == 5
    assert etapa['proximo'] == 'iniciar_palavras'


def test_abre_aprenda_palavras_e_nao_reinicia_video():
    async def run():
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(**chromium_launch_options())
            p = await browser.new_page()
            await p.set_content('''<!doctype html><title>Etapa 3</title>
                <nav>Assista ao vídeo · Aprenda as palavras · Fale as linhas</nav>
                <video width="320" height="240" id="video"></video>
                <section><h2>Palavras selecionadas: 5</h2>
                <p>Aprenda estas palavras do vídeo:</p><p>PREPARATION / CONTRIBUTE / SOCIALIZING</p>
                <button onclick="document.body.dataset.words='started'">Aprenda 5 palavras</button></section>''')
            with patch('auto_fluxo.is_englishcentral', return_value=True):
                result = await process_page(p)
            assert result['etapa']['codigo'] == 'palavras_selecao'
            assert result['tipo'] == 'navegacao'
            assert result.get('acao') == 'iniciar_palavras'
            assert await p.locator('body').get_attribute('data-words') == 'started'
            assert await p.locator('#video').evaluate('v => v.paused') is True
            await browser.close()
    asyncio.run(run())


def test_quando_nao_existe_botao_nao_inventa_acao():
    async def run():
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(**chromium_launch_options())
            p = await browser.new_page()
            await p.set_content('''<p>Todas as palavras: 264</p><p>Palavras selecionadas: 5</p>
                                 <p>Aprenda estas palavras do vídeo</p><video width="250" height="200"></video>''')
            with patch('auto_fluxo.is_englishcentral', return_value=True):
                result = await process_page(p)
            assert result['tipo'] == 'palavras'
            assert result['etapa']['codigo'] == 'palavras_selecao'
            assert await p.locator('video').evaluate('v => v.paused') is True
            await browser.close()
    asyncio.run(run())


def test_texto_depois_de_650_caracteres_e_login_oculto():
    async def run():
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(**chromium_launch_options())
            p = await browser.new_page()
            filler = 'informação ' * 90
            await p.set_content(f'<section>{filler}</section><p>Palavras selecionadas: 5</p><button>Aprenda 5 palavras</button><input type="password" hidden>')
            info = await inspect_page(p)
            assert len(info['textoVisivel']) > 650
            assert 'Palavras selecionadas: 5' in info['textoVisivel']
            assert info['loginDetectado'] is False
            await browser.close()
    asyncio.run(run())
