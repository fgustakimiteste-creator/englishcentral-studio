import os
from unittest.mock import AsyncMock
from fastapi.testclient import TestClient
import servidor

os.environ['EC_PANEL_TOKEN'] = 'token-so-para-testes-12345'


def test_screenshot_jpeg_real_e_autenticacao(monkeypatch):
    fake = type('DummyPage', (), {})()
    fake.is_closed = lambda: False
    fake.screenshot = AsyncMock(return_value=b'\xff\xd8\xff\xd9')
    monkeypatch.setattr(servidor, 'page', fake)
    with TestClient(servidor.app) as client:
        assert client.get('/api/screenshot').status_code == 401
        resp = client.get('/api/screenshot', headers={'X-EC-Token':'token-so-para-testes-12345'})
        assert resp.status_code == 200
        assert resp.headers['content-type'].startswith('image/jpeg')
        assert 'no-store' in resp.headers['cache-control']
    fake.screenshot.assert_awaited_once()


def test_etapa_palavras_nao_faz_passar_video():
    from etapas import classify_stage
    info={'textoVisivel':'Palavras selecionadas: 5\nAprenda 5 palavras',
          'videos':[{'reproduzindo':False,'concluidoNoPlayer':False}],
          'campos':[]}
    assert classify_stage(info)['codigo'] == 'palavras_selecao'
