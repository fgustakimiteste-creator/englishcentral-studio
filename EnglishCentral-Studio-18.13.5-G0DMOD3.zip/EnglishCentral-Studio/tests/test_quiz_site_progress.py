import asyncio
from unittest.mock import AsyncMock,patch,MagicMock
from course_flow import CourseCursor,_advance_course,course_progress
from test_course_flow import prepare
from playwright.async_api import async_playwright

def test_pending_site_quiz_overrides_saved_completion():
    cursor=CourseCursor(seen_quizzes={'1:q1'},verified_units={'1'})
    snapshot={'supported':True,'course_id':'6128','units':[{'id':'1','index':0,'active':True,'visible':True,'ready':True,'cards':[{'quiz':True,'quiz_key':'1:q1','title':'Quiz 1','index':1,'visible':True,'pending':True}]}]}
    with patch('course_flow._click',AsyncMock(return_value={'tipo':'navegacao'})):
        result=asyncio.run(_advance_course(MagicMock(),cursor,snapshot=snapshot,include_videos=False,include_quizzes=True))
    assert result['quiz_id']=='1:q1' and '1:q1' not in cursor.seen_quizzes
    assert course_progress(snapshot,cursor,include_quizzes=True)['unidades'][0]['estado']=='pendente'

def test_site_checkmark_and_pending_arrow_are_read():
    from course_flow import inspect_course
    async def run():
        async with async_playwright() as pw:
            browser,page=await prepare(pw)
            try:
                await page.evaluate("openUnit(document.getElementById('1'))")
                card=page.locator('ec-course-unit-activity').nth(1)
                await card.evaluate("e=>e.insertAdjacentHTML('beforeend','<div class=course-unit-activity-progress><i class=fa-check></i></div>')")
                info=await inspect_course(page)
                assert info['units'][0]['cards'][1]['completed']
                await card.locator('i').evaluate("e=>e.className='fa-chevron-right'")
                info=await inspect_course(page)
                assert info['units'][0]['cards'][1]['pending'] and not info['units'][0]['cards'][1]['completed']
            finally:
                await browser.close()
    asyncio.run(run())

def test_loading_unit_retry_gets_new_loading_window():
    cursor=CourseCursor(visited_units={'1'},blocked_units={'1'},card_loading_since={'1:0':1})
    snapshot={'supported':True,'course_id':'6128','units':[{'id':'1','index':0,'active':True,'visible':True,'ready':True,'cards':[{'index':0,'loading':True}]}]}
    result=asyncio.run(_advance_course(None,cursor,snapshot=snapshot))
    assert result['tipo']=='aguardando' and not cursor.card_loading_since
