# Relatório de testes — EnglishCentral Studio V18.13.1

As baterias focadas executadas registraram 115 testes aprovados (110 de SEDUCTEC/IA/perfis/navegação/regressões e 5 do motor EnglishCentral). Compilação Python, sintaxe do inicializador Termux e sintaxe do JavaScript inline também passaram.

A suíte completa não foi declarada aprovada. Consulte `TESTES_G0DM0D3_EnglishCentral_Studio_V18.13.1.md` para os comandos/grupos, limites e testes bloqueados por navegação externa.
