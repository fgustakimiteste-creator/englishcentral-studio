"""Regressões de leitura de quizzes independentes e campos em iframes."""
import asyncio
from playwright.async_api import async_playwright
from conftest import chromium_launch_options
from exercicio import inspect_quiz, type_quiz_answer


def test_lacuna_sem_video_em_iframe_e_campo_oculto():
    async def run():
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(**chromium_launch_options())
            try:
                page = await browser.new_page()
                await page.set_content('<div class="quiz">Complete the sentence</div><div class="caption">She has a ____.</div><iframe></iframe>')
                await page.frames[1].set_content('<input class="answer" maxlength="4">')
                quiz = await inspect_quiz(page)
                assert quiz['ativa'] and quiz['input_frame'] == 1 and quiz['frame'] == 0
                await type_quiz_answer(page, quiz, 'book', enter=False)
                assert await page.frames[1].locator('input').input_value() == 'book'
                await page.set_content('<div class="quiz">Complete the sentence</div><div class="caption">She has a ____.</div><input class="answer" style="width:0;height:0;opacity:0;border:0;padding:0">')
                quiz = await inspect_quiz(page)
                assert quiz['ativa']
                await type_quiz_answer(page, quiz, 'book', enter=False)
                assert await page.locator('input').input_value() == 'book'
            finally:
                await browser.close()
    asyncio.run(run())


def test_reconhece_prompt_sem_video_e_preserva_frame_do_input():
    from types import SimpleNamespace
    from unittest.mock import AsyncMock
    prompt = {'hasPrompt': True, 'video': False, 'frase': 'She has a ____.', 'campos': []}
    field = {'hasPrompt': False, 'video': False, 'frase': '', 'campos': [{'id': '1', 'score': 3}]}
    page = SimpleNamespace(frames=[SimpleNamespace(evaluate=AsyncMock(return_value=prompt)),
                                   SimpleNamespace(evaluate=AsyncMock(return_value=field))])
    quiz = asyncio.run(inspect_quiz(page))
    assert quiz['ativa'] and quiz['frame'] == 0 and quiz['input_frame'] == 1


def test_pergunta_mudou_durante_inferencia_nao_clica():
    from types import SimpleNamespace
    from unittest.mock import AsyncMock, patch
    from auto_fluxo import EngineState, _handle_multiple_choice
    quiz = {'ativa': True, 'tipo': 'multipla_escolha', 'pergunta': 'Where is it?',
            'opcoes': [{'id': '1', 'text': 'Here'}, {'id': '2', 'text': 'There'}]}
    async def run():
        with patch('auto_fluxo.ia_status', return_value={'configurada': True}), \
             patch('auto_fluxo.run_inference', AsyncMock(return_value='Here')), \
             patch('auto_fluxo.inspect_quiz', AsyncMock(return_value={**quiz, 'pergunta': 'Who is it?'})), \
             patch('auto_fluxo.select_quiz_choice', AsyncMock()) as click:
            result = await _handle_multiple_choice(SimpleNamespace(), quiz, {}, EngineState(), submit=True)
            assert result['tipo'] == 'aguardando'
            click.assert_not_awaited()
    asyncio.run(run())
