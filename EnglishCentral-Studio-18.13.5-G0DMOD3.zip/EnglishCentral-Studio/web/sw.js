/* O worker atende somente arquivos públicos. Atividades continuam no Python. */
'use strict';
const CACHE = 'ec-studio-public-18.13.1';
const PUBLIC = ['/offline.html', '/pwa.js', '/mobile.css', '/manifest.webmanifest',
  '/icons/icon-192.png', '/icons/icon-512.png', '/icons/maskable-512.png',
  '/icons/apple-touch-icon.png', '/icons/icon.svg'];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(PUBLIC)));
  // A versão nova aguarda a escolha do usuário; não recarrega uma sessão ativa.
});
self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    for (const name of await caches.keys()) {
      if (name.startsWith('ec-studio-public-') && name !== CACHE) await caches.delete(name);
    }
    await self.clients.claim();
  })());
});
self.addEventListener('message', event => {
  if (event.data?.type === 'ACTIVATE_UPDATE') self.skipWaiting();
});
self.addEventListener('fetch', event => {
  const request = event.request, url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin ||
      request.headers.has('X-EC-Token') || url.search ||
      !['http:', 'https:'].includes(url.protocol)) return;
  // Não interceptar API, capturas, login, mensagens ou formulários.
  const panel = url.pathname === '/' || /^\/p\/(principal|pessoa(?:[2-9]|[1-9]\d+))\/$/.test(url.pathname);
  if (request.mode === 'navigate' && panel) {
    event.respondWith((async () => {
      const controller = new AbortController(), timer = setTimeout(() => controller.abort(), 6000);
      try {
        const response = await fetch(request, {signal: controller.signal});
        if (response.status < 500) return response;
      } catch {} finally { clearTimeout(timer); }
      return (await caches.open(CACHE)).match('/offline.html');
    })());
  } else if (PUBLIC.includes(url.pathname)) {
    event.respondWith((async () => {
      const cache = await caches.open(CACHE), cached = await cache.match(url.pathname);
      return cached || fetch(request);
    })());
  }
});
