"""Regressão V9: modo por etapa, confirmação e progresso durável."""
import asyncio
from unittest.mock import AsyncMock, patch

import pytest

from modos import ModoEstudo
from progresso import ProgressoVerificado
from ec_engine import ECState, process_ec_page


def test_modos_rejeitam_vazio():
    with pytest.raises(ValueError):
        ModoEstudo(False, False, False)
    assert ModoEstudo(True, False, False).etapas == ('assistir',)
    assert ModoEstudo(True, True, True).etapas == ('assistir', 'aprender', 'falar')
    assert ModoEstudo(True, False, False).terminou({'assistir': True, 'aprender': False})
    assert not ModoEstudo(True, True, False).terminou({'assistir': True, 'aprender': False})
    quiz_only = ModoEstudo(False, False, False, True)
    assert quiz_only.quiz and quiz_only.etapas == () and quiz_only.terminou({})


def test_persistencia_escopo_apos_reinicio(tmp_path):
    path = tmp_path / 'progress.json'
    progress = ProgressoVerificado(path)
    assert progress.confirmar('8597', 'dialog:999', {'assistir': True})
    assert progress.confirmar('8597', 'dialog:999', {'aprender': True})
    assert not progress.confirmar('8597', 'dialog:999', {'assistir': True})
    reread = ProgressoVerificado(path)
    assert reread.concluidas('8597', ('assistir',)) == {'999'}
    assert reread.concluidas('8597', ('assistir', 'aprender')) == {'999'}
    assert reread.concluidas('8597', ('assistir', 'aprender', 'falar')) == set()
    assert reread.concluidas('OTHER', ('assistir',)) == set()
    assert not reread.confirmar('8597', '/course/8597', {'assistir': True})
    assert not reread.confirmar('8597', '123', {'assistir': False, 'aprender': False})


def _snapshot(**extra):
    return {'supported': True, 'lesson_id': 'dialog:333', 'title': 'Aula',
            'mode': 'learn', 'watch_complete': False, 'learn_complete': False,
            'speak_complete': False, 'question': True, 'question_id': 'q1',
            'frame': 0, 'player_index': 0, **extra}


def test_watch_prioritario_nao_responde_lacuna():
    async def run():
        state = ECState(lesson='dialog:333')
        with patch('ec_engine.inspect_ec_player', AsyncMock(return_value=_snapshot())), \
             patch('ec_engine._action', AsyncMock(return_value={'tipo': 'navegacao', 'acao': 'watch'})) as action, \
             patch('ec_engine._learn_question', AsyncMock()) as answer:
            result = await process_ec_page(object(), state, submit=True, modo=ModoEstudo(True, True, False))
            assert result['acao'] == 'watch'
            assert action.await_args.args[1] == 'watch'
            answer.assert_not_awaited()
    asyncio.run(run())


def test_videos_apenas_pula_aprender_pendente_e_avanca():
    async def run():
        state = ECState(lesson='dialog:333')
        snap = _snapshot(watch_complete=True, learn_complete=False)
        with patch('ec_engine.inspect_ec_player', AsyncMock(return_value=snap)), \
             patch('ec_engine.advance_course', AsyncMock(return_value={'tipo': 'escopo_concluido'})) as next_lesson, \
             patch('ec_engine._learn_question', AsyncMock()) as answer:
            result = await process_ec_page(object(), state, submit=True, modo=ModoEstudo(True, False, False))
            assert result['tipo'] == 'escopo_concluido'
            next_lesson.assert_awaited_once()
            answer.assert_not_awaited()
            assert state.cursor.seen == {'333'}
    asyncio.run(run())


def test_audio_usa_prompt_visivel_para_preparar_voz_sintetica():
    async def run():
        state = ECState(lesson='dialog:333')
        snap = _snapshot(mode='speak', watch_complete=True, learn_complete=True, speak_complete=False)
        with patch('ec_engine.inspect_ec_player', AsyncMock(return_value=snap)), \
             patch('ec_engine.advance_course', AsyncMock()) as next_lesson:
            result = await process_ec_page(object(), state, submit=True, modo=ModoEstudo(True, True, True))
            assert result['tipo'] == 'fala'
            assert result['speak_prompt'] == ''
            assert 'sintética' in result['mensagem']
            next_lesson.assert_not_awaited()
    asyncio.run(run())


def test_avanca_assim_que_site_confirma_assistir():
    async def run():
        state = ECState(lesson='dialog:333')
        pending = _snapshot(mode='watch', question=False, watch_complete=False,
                            video={'paused': False, 'ended': False, 'position': 10, 'duration': 100})
        premature = _snapshot(mode='watch', question=False, watch_complete=True,
                              video={'paused': False, 'ended': False, 'position': 30, 'duration': 100})
        ended = _snapshot(mode='watch', question=False, watch_complete=True,
                          video={'paused': True, 'ended': True, 'position': 100, 'duration': 100})
        with patch('ec_engine.inspect_ec_player', AsyncMock(side_effect=[pending, premature, ended])), \
             patch('ec_engine._learn_question', AsyncMock()) as answer, \
             patch('ec_engine._action', AsyncMock(return_value={'tipo':'navegacao','acao':'learn'})) as action:
            first = await process_ec_page(object(), state, submit=True)
            assert first['tipo'] == 'video'
            second = await process_ec_page(object(), state, submit=True)
            assert second['acao'] == 'learn'
            answer.assert_not_awaited()
            action.assert_awaited_once()
    asyncio.run(run())


def test_persistencia_ignora_dados_invalidos(tmp_path):
    path = tmp_path / 'progress.json'
    path.write_text('não é json', encoding='utf-8')
    assert ProgressoVerificado(path).concluidas('8597', ('assistir',)) == set()


def test_unidades_verificadas_nao_reabrem_no_mesmo_dia(tmp_path):
    path = tmp_path / 'progress.json'
    progress = ProgressoVerificado(path)
    assert progress.confirmar_unidades('8597', ('assistir',), {'unit_1', 'unit_2'})
    reread = ProgressoVerificado(path)
    assert reread.unidades('8597', ('assistir',)) == {'unit_1', 'unit_2'}
    assert reread.unidades('8597', ('assistir','aprender')) == set()
    assert not reread.confirmar_unidades('8597', ('assistir',), {'unit_1'})
