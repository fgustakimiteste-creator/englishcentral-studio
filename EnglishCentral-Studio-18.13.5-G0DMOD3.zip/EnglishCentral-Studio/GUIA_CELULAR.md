## V18.13.1 — correções G0DM0D3 e automação paralela

No celular, a área Pessoas permite abrir a grade de sessões. Cada quadro usa o perfil e o login próprios; o Android pode limitar a memória ao mostrar várias sessões ao mesmo tempo. Na Sala de estudos, a seta compacta fecha o PDF temporário e o controle vertical à direita movimenta a página real do navegador.

# Guia para celular — Android/Termux e acesso remoto

## Como funciona

O aplicativo web é a interface. Python, Playwright e o navegador precisam rodar no computador ou no próprio celular via Termux. Instalar o PWA não executa o motor no telefone por conta própria.

1. Extraia o ZIP em uma pasta acessível pelo Termux.
2. Confira Python e Node.js com `python --version` e `node --version`.
3. Para usar o Chromium do Termux: `pkg install x11-repo && pkg install chromium`.
4. Inicie com `bash TERMUX_INICIAR.sh`. O script verifica as dependências Python e não executa `playwright install chromium`, pois no Termux o navegador deve vir do pacote do sistema.
5. Mantenha o Termux aberto e acesse `http://127.0.0.1:8765` no navegador do celular.

Caso prefira o Chrome já instalado no Android, é necessário configurar a depuração remota autorizada. Sem Chromium no Termux ou uma conexão autorizada ao Chrome do telefone, o servidor pode abrir, mas a sessão de automação do navegador não estará disponível.


## Correção de automação — V18.12.4 (mantida na V18.13.1)

Na página do curso, selecione **Tudo**, **PDF**, **Fórum** ou **Quiz** e toque em **Executar ação Moodle**. O Studio procura um link de atividade visível e pendente, abre a página oficial e então executa a etapa compatível. Em quiz, inicia a primeira tentativa pelo botão visível; a opção **Tentar novamente** controla somente a repetição após uma tentativa. O assistente preenche os campos disponíveis e relê os valores. Em fórum, gera o rascunho, abre a discussão/resposta e preenche o editor. Em PDF, abre recursos intermediários, localiza o arquivo direto e lê seu texto; **Fechar PDF** encerra a aba temporária e retorna ao curso.

Se nada for encontrado, abra a seção que contém a atividade e execute novamente. Se o Moodle pedir login, permissão, confirmação ou bloqueio de atividade, resolva isso no próprio portal. O mecanismo não pode contornar permissões, CAPTCHA ou condições definidas pelo professor. O botão executar nunca clica em Publicar/Enviar/Finalizar.

A atualização migra o antigo padrão de fórum desativado para habilitado uma vez. Confira **Configurações do SEDUCTEC** após atualizar; ao salvar, sua escolha explícita será mantida.

## EnglishCentral e SEDUCTEC

No seletor superior, escolha EnglishCentral ou SEDUCTEC. O link principal do EnglishCentral é `https://pt.englishcentral.com/myclass/232103/0/courses`; o portal Moodle é `https://seductec.seduc.pi.gov.br/`. Faça login no próprio navegador do Studio.

No SEDUCTEC, configure o modo em **Configurações → Configurações do SEDUCTEC**: Tudo, PDF, Fórum ou Quiz. O botão Executar processa a próxima atividade visível e compatível por clique, não percorre a disciplina inteira em uma única execução. Para PDF, selecione um recurso detectado, use Ler PDF ou Abrir PDF e depois Fechar PDF. A leitura funciona quando o PDF contém texto selecionável; documentos digitalizados são sinalizados. Para fórum, abra uma discussão, gere o rascunho e preencha o editor; revise e publique no Moodle. Para quiz, analise as perguntas pendentes, confira as respostas preenchidas e faça o envio final no portal.

O estado é relido no Moodle. O Studio diferencia rascunho preenchido de atividade enviada/concluída. Nova tentativa só é acionada quando o botão aparece na página oficial. A IA pode usar API OpenAI ou um modelo local no mesmo host que executa o servidor.

## MiMi no EnglishCentral

Abra um vídeo. A área **Conversar com a MiMi** usa título, legendas e texto visível como contexto. É uma companheira do Studio, não a MiMi oficial e não registra XP. O botão MiMi oficial só abre o controle se ele estiver disponível na interface do EnglishCentral.

## Várias contas ao mesmo tempo

Adicione perfis na área Pessoas. Cada perfil cria um servidor local em porta distinta, token e diretório de dados separados, incluindo preferências SEDUCTEC e configuração IA. Abra cada perfil em uma nova aba e entre com a conta correspondente. No Android, alguns modos PWA bloqueiam pop-ups; nesse caso, abra o painel no Chrome/Firefox normal, permita novas abas e não feche a sessão anterior.

## Limitações importantes

- A API OpenAI envia para a nuvem os trechos de enunciado/material e mensagens que você envia à IA; revise antes de compartilhar informações pessoais.
- O modelo local deve estar disponível no mesmo computador/servidor do Studio. Um modelo instalado somente no celular não atende um servidor remoto.
- O Studio não lê senhas/cookies, não quebra CAPTCHA e não contorna controles de acesso.
- Ele pode preencher campos e preparar rascunhos. Publicação de fórum e envio/finalização de quiz permanecem ações finais no Moodle após sua revisão.
- A conclusão só é apresentada como confirmada quando há evidência visível do Moodle; senão aparece “não confirmado”.


## Prévia móvel e execução sequencial — V18.12.4

Na prévia, use **Voltar** para retornar à página anterior e as setas para rolar a página real. Durante uma operação longa, a captura aguarda a fila do navegador em vez de exibir repetidamente “navegador ocupado”. Na leitura de PDF, o Studio abre uma aba temporária, lê o texto, fecha essa aba e tenta retornar à lista do curso.

A execução mantém as ações do navegador serializadas para impedir que agentes concorrentes disputem o mesmo foco e DOM. Para contas diferentes, use perfis separados, cada um com seu próprio painel/porta e sessão.
