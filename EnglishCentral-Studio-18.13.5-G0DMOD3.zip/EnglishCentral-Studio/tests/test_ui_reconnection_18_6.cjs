const fs=require('fs'),path=require('path'),assert=require('node:assert/strict');
const {JSDOM,VirtualConsole}=require(process.env.EC_JSDOM||'jsdom');
const html=fs.readFileSync(path.join(__dirname,'../web/index.html'),'utf8');
const wait=()=>new Promise(r=>setTimeout(r,25));
async function fixture({question=null,reconnecting=false,history=[]}={}){
 const timers=[],calls=[],errors=[];let fail=0;
 const data={aberto:false,executando:true,eventos:[],modo:{assistir:true,aprender:false,quiz:false,falar:false},confirmacao_parada:question,auto:{tipo:reconnecting?'reconectando':'video',mensagem:reconnecting?'Aguardando conexão':'Acompanhando'}};
 const vc=new VirtualConsole();vc.on('jsdomError',e=>errors.push(e.message));
 const dom=new JSDOM(html,{url:'http://localhost/#token=fixture-only',runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:vc,beforeParse(w){
  w.scrollTo=()=>{};w.setInterval=(fn,delay)=>{timers.push({fn,delay});return timers.length};
  w.fetch=async(url,options={})=>{
   calls.push({url,body:options.body?JSON.parse(options.body):null});
   if(url==='/api/status'&&fail){if(fail===401)return {ok:false,status:401,json:async()=>({detail:'Token inválido'})};throw new TypeError('rede indisponível')}
   if(url==='/api/auto/decision'){const action=JSON.parse(options.body).acao;data.confirmacao_parada=null;data.executando=action!=='stop';data.auto={tipo:action==='stop'?'parado':'video'};return {ok:true,json:async()=>({executando:data.executando})}}
   return {ok:true,json:async()=>url==='/api/status'?data:url==='/api/history'?{curso:'8597',unidades:history,eventos:[]}:{} };
  };
 }});await wait();assert.deepEqual(errors,[]);
 return {dom,w:dom.window,d:dom.window.document,data,calls,errors,poll:async()=>{await timers.find(t=>t.delay===1500).fn();await wait()},fail:v=>{fail=v}};
}
const q=(extra={})=>({id:'request-1',motivo:'Erro ao responder o quiz',categoria:'quiz',pode_pular:true,mostrar_novamente:true,...extra});
let count=0;
async function test(name,fn){await fn();count++;console.log('PASS',name)}
(async()=>{
 await test('Aviso aparece no Assistente com tentar novamente, pular e parar',async()=>{const t=await fixture({question:q()});assert(!t.d.getElementById('stopQuestion').classList.contains('hide'));assert.equal(t.d.getElementById('assistantState').textContent,'Aguardando decisão');assert.equal(t.calls.filter(c=>c.url==='/api/auto/stop').length,0);for(const id of ['keepWorking','skipActivity','confirmStop'])assert(!t.d.getElementById(id).disabled);t.dom.window.close()});
 await test('Tentar novamente envia escolha e preferência sem duplicar',async()=>{const t=await fixture({question:q()});t.d.getElementById('showWarningAgain').checked=false;t.d.getElementById('keepWorking').click();t.d.getElementById('keepWorking').click();await wait();const calls=t.calls.filter(c=>c.url==='/api/auto/decision');assert.equal(calls.length,1);assert.deepEqual(calls[0].body,{solicitacao:'request-1',acao:'retry',mostrar_novamente:false});assert.equal(t.d.getElementById('toggleLabel').textContent,'Pausar assistente');t.dom.window.close()});
 await test('Pular e parar usam decisões explícitas diferentes',async()=>{for(const [id,action] of [['skipActivity','skip'],['confirmStop','stop']]){const t=await fixture({question:q()});t.d.getElementById(id).click();await wait();assert.equal(t.calls.find(c=>c.url==='/api/auto/decision').body.acao,action);if(action==='stop')assert.equal(t.d.getElementById('toggleLabel').textContent,'Iniciar assistente');t.dom.window.close()}});
 await test('Aviso suprimido fica recolhido, com acesso às opções',async()=>{const t=await fixture({question:q({mostrar_novamente:false})});assert(t.d.getElementById('stopQuestion').classList.contains('hide'));assert(!t.d.getElementById('compactWarning').classList.contains('hide'));assert(t.d.getElementById('notice').classList.contains('hide'));t.d.getElementById('showWarningOptions').click();assert(!t.d.getElementById('stopQuestion').classList.contains('hide'));t.dom.window.close()});
 await test('Reconectando tem animação e desaparece quando a rede volta',async()=>{const t=await fixture({reconnecting:true});assert(!t.d.getElementById('reconnectPanel').classList.contains('hide'));assert.equal(t.d.getElementById('assistantState').textContent,'Reconectando…');assert(t.d.querySelector('.reconnectSpinner'));t.data.auto={tipo:'video',mensagem:'Retomando'};await t.poll();assert(t.d.getElementById('reconnectPanel').classList.contains('hide'));assert.equal(t.d.getElementById('toggleLabel').textContent,'Pausar assistente');assert.equal(t.calls.filter(c=>c.url==='/api/auto/stop').length,0);t.dom.window.close()});
 await test('Queda de acesso ao painel preserva execução e tenta reconectar',async()=>{const t=await fixture();t.fail(500);await t.poll();assert(!t.d.getElementById('reconnectPanel').classList.contains('hide'));t.fail(0);await t.poll();assert(t.d.getElementById('reconnectPanel').classList.contains('hide'));assert.equal(t.d.getElementById('toggleLabel').textContent,'Pausar assistente');t.dom.window.close()});
 await test('Eventos offline e online não enviam parada',async()=>{const t=await fixture();Object.defineProperty(t.w.navigator,'onLine',{configurable:true,value:false});t.w.dispatchEvent(new t.w.Event('offline'));assert(!t.d.getElementById('reconnectPanel').classList.contains('hide'));Object.defineProperty(t.w.navigator,'onLine',{configurable:true,value:true});t.w.dispatchEvent(new t.w.Event('online'));await wait();assert(t.d.getElementById('reconnectPanel').classList.contains('hide'));assert(!t.calls.some(c=>c.url==='/api/auto/stop'));t.dom.window.close()});
 await test('Conexão lenta é informada sem substituir o erro da atividade',async()=>{const t=await fixture({question:q()});t.data.conexao={estado:'lenta',latencia_ms:2400};await t.poll();assert(!t.d.getElementById('connectionHint').classList.contains('hide'));assert(t.d.getElementById('stopReason').textContent.includes('quiz'));t.dom.window.close()});
 await test('Histórico mostra três etapas feitas e Fala pendente',async()=>{const t=await fixture({history:[{id:'1',titulo:'Unidade 1',etapas:{assistir:true,aprender:true,quizzes:true,falar:false}}]});t.d.querySelector('[data-view="progress"]').click();await wait();const cells=[...t.d.querySelectorAll('#savedHistoryBody tr td')].map(c=>c.textContent);assert.deepEqual(cells,['Feito','Feito','Feito','Pendente','Pendente']);t.dom.window.close()});
 await test('Não permite pular uma tela sem alvo identificado',async()=>{const t=await fixture({question:q({pode_pular:false})});assert(t.d.getElementById('skipActivity').disabled);t.dom.window.close()});
 console.log(count+' cenários de reconexão e avisos aprovados (DOM/API simulados).');
})().catch(e=>{console.error(e);process.exitCode=1});
