from test_ec_player import run_with_page
from fala_automatica import click_control

def test_actual_record_hint_starts_recording():
    async def scenario(page):
        await page.set_content('<div onclick="window.recording=true"><span>CLIQUE AQUI E FALE A FRASE</span></div>')
        result=await click_control(page,'record')
        assert result['acao']=='audio_iniciar'
        assert await page.evaluate('window.recording') is True
    run_with_page(scenario)
