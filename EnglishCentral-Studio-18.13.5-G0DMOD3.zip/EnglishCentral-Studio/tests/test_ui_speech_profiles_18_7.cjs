const fs=require('node:fs'),assert=require('node:assert/strict');
const {JSDOM,VirtualConsole}=require(process.env.EC_JSDOM||'jsdom');
const html=fs.readFileSync(require('node:path').join(__dirname,'../web/index.html'),'utf8');
const wait=()=>new Promise(r=>setTimeout(r,50));let passed=0;
async function boot({running=false,blocked=false,policy={precisao_minima:80,max_tentativas:2,abaixo_meta:'next'}}={}){
 const calls=[],errors=[],popup={document:{body:{},title:''},closed:false,location:{},close(){this.closed=true}};
 const people=Array.from({length:8},(_,n)=>({id:n?'pessoa'+(n+1):'principal',nome:n?'Pessoa '+(n+1):'Pessoa principal'}));
 const vc=new VirtualConsole();vc.on('jsdomError',e=>errors.push(e.message));
 const state={aberto:false,executando:running,eventos:[],perfil:people[0],modo:{assistir:false,aprender:false,falar:true,quiz:false,activities:false},auto:{fala_precisao:{precisao:70,meta:80,tentativas:1}}};
 const dom=new JSDOM(html,{url:'http://localhost:8765/#token=test-only',runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:vc,beforeParse(w){
  w.scrollTo=()=>{};w.HTMLElement.prototype.scrollIntoView=()=>{};w.open=()=>blocked?null:popup;
  w.HTMLDialogElement.prototype.showModal=function(){this.open=true};w.HTMLDialogElement.prototype.close=function(){this.open=false;this.dispatchEvent(new w.Event('close'))};
  w.fetch=async(url,opts={})=>{
   const method=opts.method||'GET',data=opts.body?JSON.parse(opts.body):null;calls.push({url,method,data});let result={ok:true};
   if(url==='/api/status')result=state;
   if(url==='/api/speech/settings'){if(method==='PUT')policy=data;result=policy}
   if(url==='/api/profiles'&&method==='GET')result={atual:'principal',pessoas:people};
   if(url==='/api/profiles'&&method==='POST'){const p={id:'pessoa9',nome:data.nome||'Pessoa 9'};people.push(p);result={perfil:p}}
   if(/^\/api\/profiles\/[^/]+\/open$/.test(url))result={url:'http://127.0.0.1:41999/#token=fixture-profile-token',mensagem:'Painel pronto'};
   if(/^\/api\/profiles\/[^/]+$/.test(url)&&method==='PATCH'){const p=people.find(p=>url.endsWith('/'+p.id));p.nome=data.nome;result={perfil:p}}
   if(url==='/api/history')result={unidades:[],eventos:[],linhas_fala:[{aula:'123',linha:'101',precisao:70,meta:80,pulado:true,estado:'abaixo_meta'}]};
   if(url==='/api/auto/start')result={executando:true};
   return{ok:true,json:async()=>result};
  };
 }});await wait();assert.deepEqual(errors,[]);return{dom,w:dom.window,d:dom.window.document,calls,people,popup,state};
}
async function test(name,fn){await fn();passed++;console.log('PASS',name)}
(async()=>{
 await test('Preferências salvas preenchem meta e limite de tentativas',async()=>{const t=await boot({policy:{precisao_minima:65,max_tentativas:3,abaixo_meta:'retry'}});assert.equal(t.d.getElementById('speechPrecision').value,'65');assert.equal(t.d.getElementById('speechAttempts').value,'3');assert(!t.d.getElementById('speechAttemptField').hidden);t.dom.window.close()});
 await test('Precisão numérica e controle deslizante permanecem sincronizados',async()=>{const t=await boot();const number=t.d.getElementById('speechPrecisionValue');number.value='70';number.dispatchEvent(new t.w.Event('input'));assert.equal(t.d.getElementById('speechPrecision').value,'70');assert.match(t.d.getElementById('speechPolicySummary').textContent,/70%/);t.dom.window.close()});
 await test('Salvar fala envia política escolhida sem iniciar assistente',async()=>{const t=await boot();t.d.getElementById('speechPrecisionValue').value='75';t.d.getElementById('speechBelow').value='retry';t.d.getElementById('speechAttempts').value='3';t.d.getElementById('speechSettingsForm').dispatchEvent(new t.w.Event('submit',{cancelable:true}));await wait();const put=t.calls.find(c=>c.method==='PUT');assert.deepEqual(put.data,{precisao_minima:75,max_tentativas:3,abaixo_meta:'retry'});assert(!t.calls.some(c=>c.url==='/api/auto/start'));t.dom.window.close()});
 await test('Assistente ativo bloqueia preferências e mantém pausa disponível',async()=>{const t=await boot({running:true});assert(t.d.getElementById('speechPrecisionValue').disabled);assert(t.d.getElementById('speechBelow').disabled);assert(!t.d.getElementById('toggle').disabled);t.dom.window.close()});
 await test('Iniciar fala salva preferências antes de executar',async()=>{const t=await boot();for(const id of ['watch','learn','quiz','activities'])t.d.getElementById(id).checked=false;t.d.getElementById('speak').checked=true;t.d.getElementById('speak').dispatchEvent(new t.w.Event('change'));t.d.getElementById('toggle').click();await wait();const save=t.calls.findIndex(c=>c.url==='/api/speech/settings'&&c.method==='PUT'),start=t.calls.findIndex(c=>c.url==='/api/auto/start');assert(save>=0&&start>save);t.dom.window.close()});
 await test('Nota real de 70% aparece sem se tornar 100%',async()=>{const t=await boot();assert.equal(t.d.getElementById('speechScoreValue').textContent,'70%');assert.equal(t.d.getElementById('speechScoreBar').value,70);t.dom.window.close()});
 await test('Pessoas exibe mais de cinco perfis sem truncar',async()=>{const t=await boot();t.d.querySelector('[data-view="people"]').click();await wait();assert.equal(t.d.querySelectorAll('.personCard').length,8);assert.match(t.d.getElementById('profileCount').textContent,/8 pessoas/);assert.equal(t.d.querySelectorAll('[data-panel]:not([hidden])').length,1);t.dom.window.close()});
 await test('Criar pessoa abre endereço independente sem rota fixa da pessoa 2',async()=>{const t=await boot();t.d.querySelector('[data-view="people"]').click();await wait();t.d.getElementById('profileName').value='Nova pessoa';t.d.getElementById('addPersonForm').dispatchEvent(new t.w.Event('submit',{cancelable:true}));await wait();assert(t.calls.some(c=>c.url==='/api/profiles'&&c.method==='POST'));assert(t.calls.some(c=>c.url==='/api/profiles/pessoa9/open'));assert.equal(t.popup.location.href,'http://127.0.0.1:41999/#token=fixture-profile-token');assert(!t.calls.some(c=>c.url==='/api/auto/stop'));t.dom.window.close()});
 await test('Reabrir pessoa existente preserva o perfil e não cria outro',async()=>{const t=await boot();t.d.querySelector('[data-view="people"]').click();await wait();t.d.querySelectorAll('.personCard')[7].querySelector('button').click();await wait();assert(t.calls.some(c=>c.url==='/api/profiles/pessoa8/open'));assert(!t.calls.some(c=>c.url==='/api/profiles'&&c.method==='POST'));t.dom.window.close()});
 await test('Janela bloqueada informa o motivo antes de criar perfil',async()=>{const t=await boot({blocked:true});t.d.getElementById('addPersonForm').dispatchEvent(new t.w.Event('submit',{cancelable:true}));await wait();assert.match(t.d.getElementById('profileMessage').textContent,/Permita abrir/);assert(!t.calls.some(c=>c.method==='POST'));t.dom.window.close()});
 await test('Busca encontra pessoa e renomear mantém o identificador',async()=>{const t=await boot();t.d.querySelector('[data-view="people"]').click();await wait();const search=t.d.getElementById('profileSearch');search.value='Pessoa 8';search.dispatchEvent(new t.w.Event('input'));assert.equal(t.d.querySelectorAll('.personCard').length,1);t.d.querySelector('.renamePerson').click();t.d.getElementById('profileRenameName').value='Outro nome';t.d.getElementById('profileRenameForm').dispatchEvent(new t.w.Event('submit',{cancelable:true}));await wait();assert.deepEqual(t.calls.find(c=>c.method==='PATCH'),{url:'/api/profiles/pessoa8',method:'PATCH',data:{nome:'Outro nome'}});t.dom.window.close()});
 await test('Histórico de fala conserva nota e indica avanço abaixo da meta',async()=>{const t=await boot();t.d.querySelector('[data-view="progress"]').click();await wait();const history=t.d.getElementById('savedSpeech').textContent;assert.match(history,/70%/);assert.match(history,/abaixo da meta/);assert.doesNotMatch(history,/100%/);t.dom.window.close()});
 console.log(`${passed} cenários V18.7 aprovados (DOM e API simulados).`);
})().catch(error=>{console.error(error);process.exitCode=1});
