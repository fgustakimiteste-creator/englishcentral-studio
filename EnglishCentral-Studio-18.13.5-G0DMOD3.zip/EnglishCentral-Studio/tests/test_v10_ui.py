"""Smoke tests V10: menu, gavetas e responsividade, sem simular curso."""
import asyncio
import json
from pathlib import Path

from playwright.async_api import async_playwright
from conftest import chromium_launch_options


HTML = (Path(__file__).resolve().parents[1] / 'web' / 'index.html').read_text('utf-8')
STATUS = {'aberto': False, 'executando': False, 'eventos': [],
          'auto': {'tipo': 'parado', 'mensagem': 'Pronto para iniciar.'}}
INJECT = """<script>
  location.hash='#token=teste-somente-local';
  window.fetch = async function(url) {
    if(String(url).includes('/api/status'))
      return new Response(__STATUS__,{status:200,headers:{'Content-Type':'application/json'}});
    return new Response('{}',{status:200,headers:{'Content-Type':'application/json'}});
  };
  </script>""".replace('__STATUS__', json.dumps(json.dumps(STATUS)))


def test_v10_menu_abre_gavetas_e_preset_funciona():
    async def run():
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(**chromium_launch_options())
            try:
                page = await browser.new_page(viewport={'width': 1500, 'height': 1000})
                errors = []
                page.on('pageerror', lambda e: errors.append(str(e)))
                await page.set_content(HTML.replace('<script>', INJECT+'<script>', 1))
                await page.locator('#connection').get_by_text('Conectado').wait_for()
                await page.get_by_role('button',name='Ferramentas',exact=True).click()
                await page.locator('#extraDrawer > summary').click()
                assert not await page.locator('#extraDrawer').evaluate('(e)=>e.open')
                await page.locator('#extraDrawer > summary').click()
                assert await page.locator('#extraDrawer').evaluate('(e)=>e.open')
                await page.get_by_role('button',name='Configurações',exact=True).click()
                await page.locator('#settingsDrawer > summary').click()
                assert not await page.locator('#settingsDrawer').evaluate('(e)=>e.open')
                await page.locator('#settingsDrawer > summary').click()
                assert await page.locator('#settingsDrawer').evaluate('(e)=>e.open')
                await page.locator('[data-preset=videos]').click()
                assert await page.locator('#watch').is_checked()
                assert not await page.locator('#learn').is_checked()
                assert not await page.locator('#quiz').is_checked()
                await page.locator('[data-preset=words]').click()
                assert await page.locator('#learn').is_checked()
                assert not await page.locator('#quiz').is_checked()
                await page.locator('[data-preset=usual]').click()
                assert await page.locator('#learn').is_checked()
                assert not await page.locator('#quiz').is_checked()
                assert not await page.locator('#speak').is_checked()
                await page.locator('[data-preset=all]').click()
                assert await page.locator('#quiz').is_checked()
                assert await page.locator('#speak').is_checked()
                await page.locator('#learn').uncheck()
                assert await page.locator('#quiz').is_checked()
                await page.locator('#quiz').uncheck()
                assert await page.locator('#speak').is_checked()
                assert await page.locator('#openLabel').inner_text() == 'Abrir curso'
                assert await page.locator('#iaPointer').evaluate("e=>getComputedStyle(e,'::after').content") == 'none'
                assert not errors
            finally:
                await browser.close()
    asyncio.run(run())


def test_v10_tela_cheia_funciona():
    async def run():
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(**chromium_launch_options())
            try:
                page = await browser.new_page()
                await page.set_content(HTML.replace('<script>', INJECT+'<script>', 1))
                await page.locator('#fullscreen').click()
                await page.wait_for_function('document.fullscreenElement?.id === "preview"')
                await page.wait_for_function('document.querySelector("#fullscreenLabel").textContent === "Sair da tela cheia"')
                assert await page.evaluate('document.fullscreenElement?.id') == 'preview'
                assert await page.locator('#fullscreenLabel').inner_text() == 'Sair da tela cheia'
                assert await page.locator('#preview').evaluate("e=>getComputedStyle(e).position") == 'fixed'
                await page.locator('#fullscreen').click()
                await page.wait_for_function('!document.fullscreenElement')
                await page.wait_for_function('document.querySelector("#fullscreenLabel").textContent === "Tela cheia"')
                assert not await page.evaluate('!!document.fullscreenElement')
            finally:
                await browser.close()
    asyncio.run(run())


def test_v10_mobile_sem_rolagem_horizontal():
    async def run():
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(**chromium_launch_options())
            try:
                page = await browser.new_page(viewport={'width': 390, 'height': 844}, is_mobile=True,has_touch=True)
                await page.set_content(HTML.replace('<script>', INJECT+'<script>', 1))
                assert await page.evaluate('document.documentElement.scrollWidth <= innerWidth + 2')
                assert await page.locator('#screen').count() == 1
            finally:
                await browser.close()
    asyncio.run(run())


def test_dashboard_conecta_foco_busca_e_abertura_do_assistente():
    async def run():
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(**chromium_launch_options())
            try:
                page = await browser.new_page(viewport={'width': 1360, 'height': 900})
                errors = []
                page.on('pageerror', lambda error: errors.append(str(error)))
                script = """<script>
                  location.hash='#token=teste-somente-local';
                  window.calls=[];
                  window.fetch=async function(url, options={}) {
                    window.calls.push({url:String(url),body:options.body||''});
                    if(String(url).includes('/api/status'))
                      return new Response(__STATUS__,{status:200,headers:{'Content-Type':'application/json'}});
                    if(String(url).includes('/api/text'))
                      return new Response(JSON.stringify({texto:'We practice English words today.'}),{status:200,headers:{'Content-Type':'application/json'}});
                    return new Response('{}',{status:200,headers:{'Content-Type':'application/json'}});
                  };
                  </script>""".replace('__STATUS__', json.dumps(json.dumps(STATUS)))
                await page.set_content(HTML.replace('<script>', script+'<script>', 1))
                await page.get_by_text('Conectado', exact=True).wait_for()
                await page.locator('[data-study-focus=words]').click()
                assert await page.locator('#learn').is_checked()
                assert not await page.locator('#watch').is_checked()
                await page.locator('#toggle').click()
                await page.wait_for_function("window.calls.some(call=>call.url.includes('/api/auto/start'))")
                start = await page.evaluate("window.calls.find(call=>call.url.includes('/api/auto/start'))")
                assert json.loads(start['body'])['aprender'] is True
                assert await page.locator('#toggleLabel').inner_text() == 'Iniciar assistente'
                await page.get_by_role('button',name='Conteúdo',exact=True).click()
                await page.locator('#courseSearch').fill('English')
                await page.locator('#courseSearch').press('Enter')
                await page.get_by_text('Encontrado no conteúdo da página', exact=False).wait_for(timeout=3000)
                assert not errors
            finally:
                await browser.close()
    asyncio.run(run())
