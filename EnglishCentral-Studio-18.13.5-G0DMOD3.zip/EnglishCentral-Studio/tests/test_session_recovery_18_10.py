"""Regressões de bloqueios e recuperação de abas; nenhuma conta é conectada."""
import asyncio
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, Mock

import pytest
from fastapi import HTTPException
import network_probe
import servidor
from modos import ModoEstudo
from auto_fluxo import EngineState,process_page
from browser_session import choose_page, google_login_url, platform_url, public_url


def tab(url='https://pt.englishcentral.com/course/8597',closed=False):
    p=MagicMock();p.url=url;p.is_closed.return_value=closed
    p.goto=AsyncMock();p.add_init_script=AsyncMock();p.bring_to_front=AsyncMock()
    return p


def test_consulta_travada_termina_e_libera_controle(monkeypatch):
    async def run():
        async def blocked(_):await asyncio.Event().wait()
        monkeypatch.setattr(servidor,'lock',asyncio.Lock())
        monkeypatch.setattr(servidor,'current_page',lambda:tab())
        monkeypatch.setattr(servidor,'inspect_course',blocked)
        monkeypatch.setattr(servidor,'BROWSER_READ_TIMEOUT',.02,raising=False)
        with pytest.raises(HTTPException) as error:
            await asyncio.wait_for(servidor.course_summary(),timeout=.12)
        assert error.value.status_code==504 and not servidor.lock.locked()
        monkeypatch.setattr(servidor,'inspect_course',AsyncMock(return_value={'supported':False}))
        assert await servidor.course_summary()=={'supported':False,'unidades':[]}
    asyncio.run(run())


def test_consulta_aguarda_na_fila_quando_worker_usa_navegador(monkeypatch):
    async def run():
        browser_lock=asyncio.Lock()
        monkeypatch.setattr(servidor,'lock',browser_lock)
        monkeypatch.setattr(servidor,'current_page',lambda:tab())
        inspect=AsyncMock(return_value={'supported':False})
        monkeypatch.setattr(servidor,'inspect_course',inspect)
        await browser_lock.acquire()
        queued=asyncio.create_task(servidor.course_summary())
        try:
            await asyncio.sleep(.06)
            assert not queued.done(), 'A leitura deve esperar o worker liberar o navegador.'
        finally:
            browser_lock.release()
        result=await asyncio.wait_for(queued,timeout=1)
        assert result=={'supported':False,'unidades':[]}
        inspect.assert_awaited_once()
    asyncio.run(run())


def test_aba_fechada_reutiliza_curso_aberto_no_mesmo_contexto(monkeypatch):
    closed,opened=tab(closed=True),tab('https://pt.englishcentral.com/course/8597?restored=1')
    monkeypatch.setattr(servidor,'page',closed)
    monkeypatch.setattr(servidor,'context',SimpleNamespace(pages=[closed,opened]))
    assert servidor.current_page() is opened and servidor.page is opened


def test_abrir_nao_cria_outro_navegador_se_contexto_ainda_existe(monkeypatch):
    async def run():
        closed,opened=tab(closed=True),tab()
        monkeypatch.setattr(servidor,'page',closed)
        monkeypatch.setattr(servidor,'context',SimpleNamespace(pages=[opened]))
        monkeypatch.setattr(servidor,'lock',asyncio.Lock())
        start=Mock(side_effect=AssertionError('Não deve criar outro perfil'))
        monkeypatch.setattr('playwright.async_api.async_playwright',start)
        result=await servidor.open_browser()
        assert result['ok'] and servidor.page is opened
        opened.goto.assert_not_awaited();start.assert_not_called()
    asyncio.run(run())


def test_sonda_externa_bloqueada_nao_impede_pagina_funcional(monkeypatch):
    async def run():
        p=SimpleNamespace(is_closed=lambda:False,
            evaluate=AsyncMock(return_value={'online':True,'usable':True,'error':False}))
        probe=Mock(return_value=False);monkeypatch.setattr(network_probe,'_public_site_available',probe)
        assert await network_probe.network_available(p) is True
        probe.assert_not_called()
    asyncio.run(run())


@pytest.mark.parametrize('url',['https://evil.example/course/8597','https://englishcentral.com.evil.example/',
                              'http://pt.englishcentral.com/course/8597','file:///course/8597'])
def test_abas_fora_da_plataforma_nao_sao_adotadas(url):
    assert not platform_url(url) and not google_login_url(url)
    assert choose_page([tab(url)]) is None


def test_rotulo_publico_nao_expoe_callback_do_login():
    assert public_url('https://accounts.google.com/signin?code=nao-expor#state=privado')=='https://accounts.google.com/signin'


def test_google_email_e_tratado_como_login_sem_ler_campos():
    async def run():
        p=tab('https://accounts.google.com/v3/signin/identifier')
        p.frames=property(lambda _: (_ for _ in ()).throw(AssertionError('Não ler credenciais')))
        result=await process_page(p)
        assert result['tipo']=='login'
        p.get_by_role.assert_not_called()
    asyncio.run(run())


def test_preparacao_ia_lenta_nao_bloqueia_primeira_leitura(monkeypatch,tmp_path):
    async def run():
        async def blocked(*_,**__):await asyncio.Event().wait()
        p=tab();p.frames=[]
        for key,value in {'DATA':tmp_path,'COURSE_FILE':tmp_path/'course.txt','PROGRESS_FILE':tmp_path/'progress.json',
            'page':p,'context':None,'auto_running':True,'auto_mode':ModoEstudo(True,True,False,False),
            'lock':asyncio.Lock(),'MODEL_WARMUP_TIMEOUT':.01,'network_available':AsyncMock(return_value=True),
            'process_page':AsyncMock(return_value={'tipo':'escopo_concluido'}),
            'request_stop_confirmation':AsyncMock(return_value=False)}.items():monkeypatch.setattr(servidor,key,value)
        monkeypatch.setattr(servidor.asyncio,'to_thread',blocked)
        await asyncio.wait_for(servidor.auto_worker(),timeout=.15)
        servidor.process_page.assert_awaited_once()
    asyncio.run(run())


def test_login_concluido_retoma_sem_clique_em_tentar_novamente(monkeypatch,tmp_path):
    async def run():
        p=tab();p.evaluate=AsyncMock(side_effect=[False,True])
        for key,value in {'page':p,'context':None,'auto_running':True,'DATA':tmp_path,
            'auto_control_lock':asyncio.Lock(),'lock':asyncio.Lock(),'LOGIN_CHECK_SECONDS':.001,
            'stop_confirmation':None,'stop_confirmation_event':None}.items():monkeypatch.setattr(servidor,key,value)
        result=await asyncio.wait_for(servidor.request_stop_confirmation({'tipo':'login','mensagem':'Escolha a conta'}),timeout=.2)
        assert result is True and p.evaluate.await_count==2 and servidor.stop_confirmation is None
    asyncio.run(run())


def test_login_nao_retoma_so_porque_url_voltou_ao_curso(monkeypatch,tmp_path):
    async def run():
        p=tab();p.evaluate=AsyncMock(return_value=False)
        for key,value in {'page':p,'context':None,'auto_running':True,'DATA':tmp_path,
            'auto_control_lock':asyncio.Lock(),'lock':asyncio.Lock(),'LOGIN_CHECK_SECONDS':.001,
            'stop_confirmation':None,'stop_confirmation_event':None}.items():monkeypatch.setattr(servidor,key,value)
        task=asyncio.create_task(servidor.request_stop_confirmation({'tipo':'login','mensagem':'Login pendente'}))
        try:
            await asyncio.sleep(.02)
            assert not task.done() and servidor.stop_confirmation is not None
        finally:
            task.cancel();await asyncio.gather(task,return_exceptions=True)
    asyncio.run(run())


def test_digitar_durante_login_preserva_worker_aguardando(monkeypatch):
    async def run():
        monkeypatch.setattr(servidor,'auto_running',True)
        monkeypatch.setattr(servidor,'stop_confirmation',{'tipo':'login'})
        stop=AsyncMock();monkeypatch.setattr(servidor,'auto_stop',stop)
        await servidor.pause_for_manual_action();stop.assert_not_awaited()
    asyncio.run(run())


def test_desconectar_navegador_pessoal_nao_fecha_contexto(monkeypatch):
    async def run():
        c=SimpleNamespace(close=AsyncMock());driver=SimpleNamespace(stop=AsyncMock())
        for key,value in {'context':c,'browser_driver':driver,'browser_owned':False,'browser_lease':None,
                          'browser_tabs':{},'browser_parents':{},'browser_events':set()}.items():monkeypatch.setattr(servidor,key,value)
        await servidor.dispose_browser_session()
        c.close.assert_not_awaited();driver.stop.assert_awaited_once()
    asyncio.run(run())


def test_mensagem_de_espera_variavel_nao_parece_progresso():
    engine=EngineState()
    before=servidor.progress_signature({'tipo':'aguardando','mensagem':'Esperando 1 segundo'},engine,'curso')
    after=servidor.progress_signature({'tipo':'navegacao','mensagem':'Esperando 2 segundos'},engine,'curso')
    assert before==after
    engine.last_question='nova pergunta'
    assert servidor.progress_signature({},engine,'curso')!=after
