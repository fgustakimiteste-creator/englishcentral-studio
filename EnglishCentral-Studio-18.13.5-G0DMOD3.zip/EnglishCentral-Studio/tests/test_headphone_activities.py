import asyncio
from unittest.mock import AsyncMock,patch
from ec_engine import ECState,process_ec_page
from modos import ModoEstudo

def test_completed_audio_does_not_wait_for_nonexistent_words_or_speech():
    snapshot={'supported':True,'lesson_id':'321','title':'[Boost Full 4] Activity 2.2','watch_complete':True,'learn_complete':False,'speak_complete':False}
    state=ECState(lesson='321')
    with patch('ec_engine.advance_course',AsyncMock(return_value={'tipo':'navegacao'})) as nav:
        result=asyncio.run(process_ec_page(None,state,submit=True,snapshot=snapshot,
                       modo=ModoEstudo(assistir=True,aprender=True,falar=True,activities=True)))
    assert nav.await_count==1 and '321' in state.cursor.seen
    assert result['tipo']=='navegacao'

def test_audio_is_ignored_when_option_is_off():
    snapshot={'supported':True,'lesson_id':'321','title':'Activity 2.1','watch_complete':False}
    with patch('ec_engine.advance_course',AsyncMock(return_value={'tipo':'navegacao'})) as nav:
        asyncio.run(process_ec_page(None,ECState(),submit=True,snapshot=snapshot,
                    modo=ModoEstudo(quiz=True,activities=False)))
    assert nav.await_args.kwargs['include_activities'] is False
