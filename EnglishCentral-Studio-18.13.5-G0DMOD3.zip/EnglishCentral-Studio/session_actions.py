"""Pular exige alvo observável e nunca confirma progresso."""
from ec_player import inspect_ec_player
from exercicio import inspect_quiz
from course_flow import inspect_course, lesson_key


async def issue_context(page,engine,course,result):
    kind=result.get('tipo','')
    if kind in {'login','verificacao','fora','escopo_concluido','escopo_pulado'}:
        return {'categoria':'curso','pode_pular':False}
    try:
        cursor=engine.real.cursor
        quiz=await inspect_quiz(page)
        quiz_mode=cursor.pending.startswith('quiz:') or 'quiz' in kind or 'quiz' in str((result.get('etapa') or {}).get('codigo',''))
        if quiz.get('ativa') and quiz_mode:
            if cursor.pending.startswith('quiz:'):
                return {'tipo':'quiz','id':cursor.pending[5:],'curso':course,'categoria':'quiz','pode_pular':True,
                        'rotulo':'Quiz atual','pergunta':quiz.get('pergunta')}
            return {'categoria':'quiz','pode_pular':False}
        real=await inspect_ec_player(page)
        key=lesson_key(real.get('lesson_id'))
        if real.get('supported') and key:
            category={'watch':'video','learn':'palavras','speak':'fala'}.get(real.get('mode'),'geral')
            if category == 'fala' and real.get('speak_line_id'):
                return {'tipo': 'linha_fala', 'id': key, 'linha_id': real['speak_line_id'],
                        'curso': course, 'categoria': 'fala', 'pode_pular': real.get('speak_next_ready') is True,
                        'rotulo': 'Linha ' + str(real['speak_line_id']), 'pergunta': real.get('speak_prompt')}
            return {'tipo':'aula','id':key,'curso':course,'categoria':category,'pode_pular':True,'rotulo':real.get('title') or 'Aula '+key}
        if cursor.pending.startswith('unit:'):
            unit=cursor.pending[5:]
            info=await inspect_course(page)
            if info.get('course_id')==course and any(u.get('id')==unit for u in info.get('units',[])):
                return {'tipo':'unidade','id':unit,'curso':course,'categoria':'curso','pode_pular':True,'rotulo':unit}
    except Exception:
        pass
    return {'categoria':'ia' if 'ia' in kind else 'geral','pode_pular':False}


async def skip_issue(page,engine,context):
    info=await inspect_course(page)
    if not info.get('supported') or str(info.get('course_id'))!=str(context.get('curso')):return False
    cursor=engine.real.cursor;kind=context.get('tipo');key=context.get('id')
    if kind == 'linha_fala':
        real = await inspect_ec_player(page)
        if (lesson_key(real.get('lesson_id')) != key or real.get('mode') != 'speak'
                or real.get('speak_line_id') != context.get('linha_id')
                or real.get('speak_prompt') != context.get('pergunta') or not real.get('speak_next_ready')):
            return False
        from fala_automatica import click_control, signature
        if not await click_control(page, 'next', real):
            return False
        engine.speech_flow.advanced = signature(real)
        return True
    if kind=='aula':
        real=await inspect_ec_player(page)
        if lesson_key(real.get('lesson_id'))!=key:return False
        cursor.skipped_lessons.add(key)
    elif kind=='quiz':
        quiz=await inspect_quiz(page)
        if not quiz.get('ativa') or quiz.get('pergunta')!=context.get('pergunta') or cursor.pending!='quiz:'+key:return False
        cursor.skipped_quizzes.add(key)
    elif kind=='unidade':
        if not any(u.get('id')==key for u in info.get('units',[])):return False
        cursor.skipped_units.add(key)
        cursor.blocked_units.discard(key)
    else:return False
    cursor.pending='';cursor.pending_attempts=0
    # Navegação normal de volta ao curso, preservando todas as confirmações.
    # Se a rede cair durante goto, o worker repete apenas este retorno, não a atividade pulada.
    engine.skip_return_url='https://pt.englishcentral.com/course/'+str(context['curso'])
    return True
