import asyncio
from types import SimpleNamespace
from unittest.mock import AsyncMock

import httpx
import pytest
import servidor


@pytest.fixture
def app(monkeypatch,tmp_path):
    monkeypatch.setattr(servidor,'DATA',tmp_path)
    monkeypatch.setattr(servidor,'PROFILES_ROOT',tmp_path)
    monkeypatch.setattr(servidor,'PROFILE_ID','principal')
    monkeypatch.setattr(servidor,'auto_running',False)
    monkeypatch.setattr(servidor,'auto_control_lock',asyncio.Lock())
    servidor.app.dependency_overrides[servidor.require_auth]=lambda:True
    yield servidor.app
    servidor.app.dependency_overrides.pop(servidor.require_auth,None)


def test_preferencias_validadas_salvas_e_bloqueadas_durante_execucao(app,monkeypatch):
    async def run():
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app),base_url='http://local') as client:
            assert (await client.get('/api/speech/settings')).json()['precisao_minima']==80
            assert (await client.put('/api/speech/settings',json={'precisao_minima':101})).status_code==422
            assert (await client.put('/api/speech/settings',json={'precisao_minima':65,'abaixo_meta':'retry','max_tentativas':3})).status_code==200
            assert (await client.get('/api/speech/settings')).json()['precisao_minima']==65
            monkeypatch.setattr(servidor,'auto_running',True)
            assert (await client.put('/api/speech/settings',json={'precisao_minima':50})).status_code==409
    asyncio.run(run())


def test_rota_de_criar_pessoa_nao_e_capturada_por_navegacao_generica(app):
    async def run():
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app),base_url='http://local') as client:
            people=[]
            for n in range(7):
                response=await client.post('/api/profiles',json={'nome':f'Estudante {n}'})
                assert response.status_code==200,response.text
                people.append(response.json()['perfil'])
            data=(await client.get('/api/profiles')).json()
            assert len(data['pessoas'])==8 and data['atual']=='principal'
            identity=people[0]['id']
            assert (await client.patch('/api/profiles/'+identity,json={'nome':'Nome atualizado'})).status_code==200
            assert (await client.get('/api/profiles')).json()['pessoas'][1]['id']==identity
    asyncio.run(run())


def test_erro_sem_autenticacao_nao_libera_cadastro(monkeypatch,tmp_path):
    monkeypatch.setattr(servidor,'get_token',lambda:'token-de-teste')
    async def run():
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=servidor.app),base_url='http://local') as client:
            assert (await client.get('/api/profiles')).status_code==401
            assert (await client.put('/api/speech/settings',json={})).status_code==401
    asyncio.run(run())
