# Guia da V18.13.1 — Automação de curso + sessões paralelas

Para instalação no celular ou servidor, leia [GUIA_CELULAR.md](GUIA_CELULAR.md). Este guia mantém as instruções do modo de computador.

## Correções da V18.13.1 (G0DM0D3)

A fila do SEDUCTEC agora separa a seção em duas fases: leitura de materiais/PDFs e, depois, ações de quiz/fórum/tarefa. O texto lido é enviado somente como contexto temporário da mesma seção. O AutoTune classifica as questões, seleciona trechos relevantes e ajusta a geração; a avaliação ULTRAPLINIAN-inspired compara estrutura e relação textual, sem atestar acerto. Um estado desconhecido nunca é contado como sucesso. Preserve a pasta `.dados_locais` durante a atualização.

## Atualizar preservando o login e o histórico

1. Pause todos os assistentes e feche os processos da versão anterior, incluindo os painéis de outras pessoas.
2. Faça uma cópia da instalação.
3. Substitua o código pelos arquivos deste ZIP.
4. Preserve `.dados_locais`, `.venv` e `config_ia.local.txt`, se existir.
5. Execute `INICIAR.bat` e confira pessoas, histórico e modo de navegador.

É necessário Python 3.10 ou superior. O inicializador prepara o ambiente e atualiza as dependências quando `requirements.txt` muda. Esta versão usa Playwright 1.62 ou superior. Node é opcional e serve apenas aos testes de interface.

Extração em outra pasta cria uma instalação independente. Ela não transfere o histórico ou o login anterior automaticamente. Os dados da sua instalação não acompanham o ZIP.

## Escolher como abrir o navegador

| Opção | Login e comportamento |
| --- | --- |
| Usar meu Chrome já aberto | Conecta ao Chrome autorizado e reutiliza uma aba existente do curso ou do login Google. Usa as contas já conectadas nesse Chrome. |
| Usar sessão do assistente | Abre o perfil privado da pessoa no painel. O login é feito nessa janela e permanece no perfil salvo para as próximas execuções. |

A escolha é salva por pessoa. Se você escolheu Chrome existente e a conexão falhar, o programa informa o problema; ele não troca silenciosamente para um Google vazio.

### Chrome já conectado

1. Abra seu Chrome normalmente e acesse o curso com a conta desejada.
2. No Chrome 144 ou superior, abra `chrome://inspect/#remote-debugging` e habilite a conexão.
3. No painel: Configurações → Navegador e login → Usar meu Chrome já aberto.
4. Confira a explicação de acesso, marque sua autorização e clique em Conectar meu Chrome.
5. Aceite a solicitação apresentada pelo próprio Chrome.
6. Confira a aba na prévia e inicie o assistente.

Essa autorização permite ao programa acessar a sessão do navegador. A operação ocorre no seu computador; não é necessário enviar senha pelo chat. Se a organização desabilitar essa função no Chrome, o aplicativo não contorna a política.

O campo de porta local é uma alternativa para quem já preparou um navegador para conexão local. Ele aceita somente uma porta local; o programa conecta a `127.0.0.1`. Não é uma forma de forçar acesso ao perfil padrão de versões antigas do Chrome. Consulte a documentação oficial antes de preparar esse modo.

Se já existe uma aba adequada, ela é reutilizada sem navegar de volta ao início. Se não existe, uma aba do curso pode ser criada dentro da mesma sessão autorizada. Em Escolher outra aba do curso, atualize a lista e escolha uma aba do EnglishCentral ou do login Google. A seleção pausa o assistente para você conferir a conta antes de iniciar.

O assistente acompanha popups de login relacionados à aba selecionada. Ao voltar ao curso, ele exige um componente do curso/player visível e ausência de campos ou diálogo de login. Enquanto aguarda o login, a digitação manual pela prévia não cancela a espera. Não há preenchimento automático de credenciais.

Em Ferramentas, Fechar sessão desconecta o Chrome pessoal e mantém suas abas abertas. O encerramento do painel também não fecha o Chrome que você conectou. As janelas criadas pela opção de sessão do assistente são encerradas pelo programa.

### Pessoas e várias contas

Use uma pessoa do painel para cada conta e seu histórico. Mudar a conta Google dentro de um Chrome não identifica automaticamente outra pessoa para o histórico local. Selecione a pessoa correspondente antes de usar outra conta.

Não há limite fixo para o cadastro de pessoas. A quantidade de sessões simultâneas depende do PC. Uma única conexão ao navegador pessoal é mantida por instalação para evitar dois painéis controlando a mesma sessão ao mesmo tempo. Os demais podem usar sessões privadas do assistente, com dados e logins separados.

## Iniciar, pausar e recuperar

Abra o curso, escolha o foco e clique em Iniciar assistente. Vídeos, Palavras, Quizzes, Fala e Activities com fone têm controles separados. Pausar assistente interrompe a execução. Fechar uma aba do painel não substitui a pausa.

O cartão Assistente apresenta a etapa, a conexão e os avisos. Consultas de leitura ocupadas retornam sem formar fila. Quando uma consulta excede seu prazo, o servidor cancela a espera, libera o controle e apresenta a ocorrência no Assistente. Isso não marca atividade como concluída.

Quando a conexão cai, Reconectando mantém a sessão e aguarda acesso. Com o navegador e o programa abertos, o motor relê a atividade e continua após a recuperação. Se o próprio Chrome for encerrado ou sua autorização for revogada, reconecte pelo painel e confira a conta antes de iniciar.

Como deseja continuar oferece Tentar novamente, Pular e Parar. A barra de dez segundos pode repetir até três vezes o mesmo problema identificado. Aguardar minha escolha cancela aquela tentativa automática. Login, verificação humana, fim do foco e erros que exigem alteração de chave/créditos aguardam uma decisão ou a condição específica de recuperação. Desmarcar Mostrar este aviso novamente recolhe os próximos avisos sem remover o acesso às opções.

O programa monitora mudanças da atividade, em vez de contar mensagens diferentes como progresso. Esperas sem avanço podem abrir o aviso após 45 segundos. Vídeo, áudio e confirmações manuais mantêm seus controles próprios. Um envio sem confirmação não é declarado correto pelo assistente.

## Vídeos e histórico

A barra branca exige verificar o registro. Amarelo e verde ajudam a identificar trechos registrados; movimento da mídia sozinho não comprova conclusão. O programa exige o indicador da plataforma.

O histórico separa as etapas. Uma unidade feita em vídeos/palavras/quizzes pode continuar com Fala pendente. Quizzes explicitamente pendentes contradizem o cache antigo sem apagar outras confirmações. Registros locais inválidos são tratados com cópia do original antes de uma gravação de recuperação.

## Falar linhas

Em Configurações → Falar linhas, escolha a precisão mínima entre 0% e 100%. O padrão é 80%. As opções abaixo da meta são:

| Política | Efeito |
| --- | --- |
| Avançar sem repetir | Usa a próxima linha oficial disponível, inclusive após nota abaixo da meta. |
| Repetir e avançar no limite | Respeita o total de uma a cinco tentativas configuradas e depois procura o avanço permitido. |
| Perguntar antes de continuar | Apresenta as opções no Assistente. |

Uma nota de 70% permanece 70%. A meta não modifica a avaliação da plataforma nem inventa conclusão. É necessária uma voz inglesa SAPI instalada no Windows. Os resultados por linha ficam no histórico. Pause para alterar as preferências durante uma execução.

## IA, diagnóstico e limites

Alguns fluxos usam vocabulário e correções visíveis da aula sem IA externa. Outros exigem modelo configurado e conteúdo legível. A preparação de IA tem limite de espera; não impede indefinidamente a leitura inicial da página. Os configuradores opcionais de IA local fazem cópia da configuração anterior antes de alterá-la.

### EnglishCentral e SEDUCTEC em ambientes separados

No seletor de curso no topo, escolha **EnglishCentral** ou **SEDUCTEC**. O Studio mantém uma aba de navegador para cada plataforma na mesma sessão: mudar de uma para a outra reutiliza a aba correspondente e não fecha a anterior. O EnglishCentral permanece como ambiente principal e mantém seu motor de vídeos, palavras, fala, quizzes e histórico. SEDUCTEC usa um adaptador Moodle independente e configurações próprias.

No SEDUCTEC, abra Configurações → Configurações do SEDUCTEC e escolha: **Tudo**, **Somente PDF**, **Somente Fórum** ou **Somente Quiz**. Os campos de preenchimento de fórum e quiz podem ser ligados separadamente. O modo não altera as preferências do EnglishCentral.

- **PDF:** selecione um PDF detectado no curso, clique em Abrir PDF para abrir uma aba temporária e use Fechar PDF para voltar à página anterior. Ler PDF extrai texto selecionável até 20 MB e 50 páginas; PDF digitalizado é sinalizado como não extraível neste fluxo.
- **Fórum:** abra uma discussão, use Gerar rascunho e, quando permitido nas configurações, Preencher editor. O texto é relido para confirmar o preenchimento; Publicar continua manual.
- **Quiz:** o Studio identifica perguntas, alternativas/campos, respostas já presentes e conclusão. Assistente gera sugestões com API ou modelo local, preenche apenas as questões pendentes e relê os campos. A tela diferencia pendente, parcial, preenchido sem envio, concluído e não confirmado. Tentar novamente só aparece quando o Moodle mostra um controle visível e disponível. Enviar/Finalizar permanece manual.

### Assistente de respostas — API ou IA local

Acesse Configurações → Inteligência artificial → **Configurar API OpenAI** para informar uma chave da API. A chave fica no arquivo de configuração privado do perfil atual, não no ZIP. A API envia o enunciado, trechos relevantes do material e mensagens explicitamente fornecidos ao assistente; use apenas conteúdo que pode compartilhar. A utilização pode gerar cobrança e depende de internet, chave válida e cota.

Também é possível executar a IA localmente. Copie `config_ia.exemplo.txt` para `config_ia.local.txt` no diretório do perfil e escolha um único provedor. Exemplos:

**Ollama:**

```ini
EC_IA_PROVEDOR=ollama
EC_IA_MODELO=qwen2.5:3b
EC_IA_URL=http://127.0.0.1:11434
```

**LM Studio/llama.cpp:**

```ini
EC_IA_PROVEDOR=local_openai
EC_IA_MODELO=nome-do-modelo-carregado
EC_IA_URL=http://127.0.0.1:1234/v1
```

O modelo local precisa estar executando no mesmo computador/servidor que roda o Studio. Endereços de provedores locais são limitados a loopback. O painel informa se a IA está usando API na nuvem ou modelo local.

O AutoTune classifica o comando, seleciona trechos do material, escolhe parâmetros de geração e revisa uma vez quando as verificações indicam problemas. A confiança é uma estimativa heurística, não uma garantia de acerto. Feedback ajusta preferências agregadas sem armazenar perguntas, respostas ou materiais.

### Conversar com a MiMi no EnglishCentral

Abra um vídeo e selecione **Conversar com a MiMi**. A companheira de prática do Studio usa título, legendas e texto visível para conversar sobre o vídeo, explicar vocabulário e praticar inglês. Ela não é a MiMi oficial e não registra XP. O botão **Abrir MiMi oficial** tenta acionar o controle do próprio EnglishCentral quando ele aparece na página.

### Várias contas ao mesmo tempo

Na área Pessoas, adicione um perfil por conta e abra cada um em uma nova aba/painel. Cada perfil usa servidor/porta, token, diretório de dados, sessão de navegador, histórico, preferências SEDUCTEC e configuração de IA próprios. Uma chave de API não é copiada de um perfil para outro. A capacidade simultânea depende dos recursos do computador. Em dispositivos móveis, use Chrome/Firefox normal quando o modo PWA bloquear a abertura de novas abas.


`DIAGNOSTICO.bat` gera um relatório local de versões e disponibilidade, sem cookies, senha ou token. [TESTES.md](TESTES.md) explica a validação. `python empacotar.py` cria uma distribuição sem dados pessoais.

A validação desta revisão foi feita em Linux/Chromium e em páginas Moodle locais de teste. O login autenticado do SEDUCTEC e do EnglishCentral, o acesso com a sua chave de API, os editores específicos do curso e a disponibilidade de tentativas precisam ser confirmados no seu ambiente real; os testes locais não fingem ser uma conta ou uma atividade oficial.
