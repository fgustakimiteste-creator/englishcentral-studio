"""Escolha de abas da plataforma sem ler contas, cookies ou credenciais."""
import re
from urllib.parse import urlparse


def platform_url(url):
    try:
        parsed=urlparse(str(url))
        return parsed.scheme=='https' and (parsed.hostname=='englishcentral.com' or
            (parsed.hostname or '').endswith('.englishcentral.com'))
    except ValueError:
        return False


def seductec_url(url):
    """Somente a origem HTTPS oficial do ambiente SEDUCTEC/Moodle."""
    try:
        parsed=urlparse(str(url))
        return (parsed.scheme=='https' and parsed.hostname=='seductec.seduc.pi.gov.br'
                and parsed.username is None and parsed.password is None
                and parsed.port in (None,443))
    except (TypeError,ValueError):
        return False


def supported_platform_url(url):
    return platform_url(url) or seductec_url(url)


def google_login_url(url):
    try:
        parsed=urlparse(str(url))
        return parsed.scheme=='https' and parsed.hostname=='accounts.google.com'
    except ValueError:
        return False


def session_tab(url):
    return supported_platform_url(url) or google_login_url(url)


def choose_page(pages,current=None,preferred=''):
    if current is not None and not current.is_closed():
        return current
    available=[p for p in pages if not p.is_closed() and session_tab(p.url)]
    preferred_host=urlparse(str(preferred)).hostname if preferred else None
    course=re.search(r'/course/(\d+)',str(preferred))
    if preferred_host and (platform_url(preferred) or seductec_url(preferred)):
        preferred_parsed=urlparse(str(preferred))
        matching=[p for p in available if urlparse(p.url).hostname==preferred_host and
                  (not course or re.match(r'/course/'+course.group(1)+r'(?:/|$)',urlparse(p.url).path))]
        if matching:return matching[-1]
    return next((p for p in reversed(available) if supported_platform_url(p.url)),available[-1] if available else None)


def tab_label(url):
    if google_login_url(url):return 'Entrar com o Google'
    if seductec_url(url):
        path=urlparse(str(url)).path
        if path.startswith('/mod/quiz/'):return 'SEDUCTEC · Questionário'
        if path.startswith('/mod/forum/'):return 'SEDUCTEC · Fórum'
        if path.startswith('/mod/assign/'):return 'SEDUCTEC · Tarefa'
        if path.startswith('/course/'):return 'SEDUCTEC · Curso'
        if path.startswith('/login/'):return 'SEDUCTEC · Login'
        return 'SEDUCTEC'
    course=re.search(r'/course/(\d+)',str(url))
    return 'Curso '+course.group(1) if course else 'EnglishCentral'


def public_url(url):
    """Não devolva query/fragmentos de callbacks de autenticação ao painel."""
    parsed=urlparse(str(url))
    return parsed.scheme+'://'+parsed.netloc+parsed.path


LOGIN_READY_JS=r'''() => {
  const shown=e=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);
    return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'};
  const blocked=[...document.querySelectorAll('input[type="password"],input[type="email"],iframe[src*="recaptcha"],iframe[src*="hcaptcha"]')].some(shown);
  const authDialog=[...document.querySelectorAll('[role="dialog"],.login-modal,ec-login-form,ec-login-modal')]
    .some(e=>shown(e)&&/entrar|login|sign\s*in/i.test(e.innerText||''));
  return !blocked&&!authDialog&&[...document.querySelectorAll('ec-course-app,ec-player-app')].some(shown);
}'''


async def dismiss_course_tour(page,*,allowed=True):
    """Pular apenas o tour com título exato, nunca uma atividade do curso."""
    try:
        heading=page.get_by_role('heading',name='Bem-vindo ao seu Curso!',exact=True)
        if await heading.count()!=1 or not await heading.is_visible():return None
        if not allowed:return False
        skip=page.get_by_role('button',name='Pular',exact=True)
        if await skip.count()!=1 or not await skip.is_visible() or not await skip.is_enabled():return False
        if not await heading.is_visible():return None
        await skip.click(timeout=2500)
        return True
    except Exception:
        return None
