"""Adaptador SEDUCTEC/Moodle com inspeção DOM e ações verificáveis.

Opera na sessão autenticada que o próprio usuário abriu no navegador. Não
acessa endpoints privados, não copia cookies e não submete questionários,
fóruns ou tarefas. Ações de preenchimento produzem rascunhos editáveis.
"""
from __future__ import annotations

import re
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

SEDUCTEC_HOST = 'seductec.seduc.pi.gov.br'
SEDUCTEC_HOME = f'https://{SEDUCTEC_HOST}/'
_BLOCKED_QUERY_KEYS = {
    'sesskey', 'token', 'password', 'passwd', 'authorization', 'authkey',
    'logintoken', 'moodlesession', 'phpsessid',
}


def is_seductec_url(url: str) -> bool:
    try:
        parsed = urlparse(str(url))
        return (parsed.scheme == 'https' and parsed.hostname == SEDUCTEC_HOST
                and parsed.username is None and parsed.password is None
                and parsed.port in (None, 443))
    except (TypeError, ValueError):
        return False


def normalize_seductec_url(url: str) -> str:
    """Valida a origem e remove fragmentos/parâmetros de sessão sensíveis."""
    if not is_seductec_url(url):
        raise ValueError('O endereço precisa pertencer ao domínio oficial do SEDUCTEC.')
    parsed = urlparse(str(url).strip())
    if parsed.path.casefold().startswith('/login/logout'):
        raise ValueError('Use a página inicial ou do curso, não um link de saída da conta.')
    kept = [(key, value) for key, value in parse_qsl(parsed.query, keep_blank_values=True)
            if key.casefold() not in _BLOCKED_QUERY_KEYS]
    return urlunparse(('https', SEDUCTEC_HOST, parsed.path or '/', parsed.params,
                       urlencode(kept, doseq=True), ''))


def page_kind(url: str) -> str:
    if not is_seductec_url(url):
        return 'externa'
    path = urlparse(url).path.casefold()
    if path.startswith('/login/'):
        return 'login'
    if path.startswith('/mod/quiz/review.php'):
        return 'quiz_revisao'
    if path.startswith('/mod/quiz/summary.php'):
        return 'quiz_resumo'
    # Moodle usa view.php como página de instruções/início, não como tentativa ativa.
    # Classificá-la como questionário fazia o botão Executar tentar preencher questões
    # antes de o usuário iniciar uma tentativa.
    if path.rstrip('/') == '/mod/quiz/view.php':
        return 'quiz_inicio'
    if path.startswith('/mod/quiz/attempt.php'):
        return 'questionario'
    if path.startswith('/mod/quiz/'):
        return 'quiz_inicio'
    if path.startswith('/mod/forum/'):
        return 'forum'
    if path.startswith('/mod/assign/'):
        return 'tarefa'
    if path.startswith(('/mod/resource/', '/mod/page/', '/mod/url/', '/mod/book/')):
        return 'material'
    if path.startswith('/pluginfile.php/'):
        return 'material'
    if path.startswith('/course/'):
        return 'curso'
    if path.startswith('/my/'):
        return 'painel'
    return 'seductec'


def platform_info(url: str) -> dict:
    if not is_seductec_url(url):
        try:
            parsed = urlparse(str(url))
            host = (parsed.hostname or '').casefold()
            is_englishcentral = (
                parsed.scheme == 'https'
                and (host == 'englishcentral.com' or host.endswith('.englishcentral.com'))
                and parsed.username is None and parsed.password is None
                and parsed.port in (None, 443)
            )
        except (TypeError, ValueError):
            is_englishcentral = False
        if is_englishcentral:
            return {'id': 'englishcentral', 'nome': 'EnglishCentral', 'modo': 'automacao_especifica'}
        return {'id': 'desconhecida', 'nome': 'Página não reconhecida',
                'automacao_especifica': False, 'ferramentas': ['inspecao']}
    kind = page_kind(url)
    names = {
        'login': 'Login do SEDUCTEC', 'quiz_inicio': 'Início do questionário',
        'questionario': 'Questionário do SEDUCTEC',
        'quiz_revisao': 'Revisão do questionário', 'quiz_resumo': 'Resumo do questionário',
        'forum': 'Fórum do SEDUCTEC', 'tarefa': 'Tarefa do SEDUCTEC',
        'material': 'Material do SEDUCTEC', 'curso': 'Curso do SEDUCTEC',
        'painel': 'Painel do SEDUCTEC', 'seductec': 'SEDUCTEC',
    }
    return {'id': 'seductec', 'nome': names.get(kind, 'SEDUCTEC'), 'tipo_pagina': kind,
            'automacao_especifica': True,
            'ferramentas': ['navegacao', 'leitura', 'inspecao', 'abrir_pdf', 'fechar_pdf',
                            'rascunho_forum', 'preencher_forum', 'assistencia_quiz',
                            'verificacao_conclusao', 'video']}


def is_direct_moodle_pdf(url: str) -> bool:
    """Reconhece apenas URLs Moodle que apontam para o arquivo PDF, não a tela resource/view."""
    try:
        parsed = urlparse(normalize_seductec_url(url))
        path = parsed.path.casefold()
        return path.endswith('.pdf') or (path.startswith('/pluginfile.php/') and '.pdf' in path)
    except (TypeError, ValueError):
        return False


def _visible_action_target(base_url: str, href: str, allowed_prefix: str) -> str:
    """Valida navegação visível e preserva CSRF temporário necessário ao Moodle."""
    from urllib.parse import urljoin
    target = urljoin(str(base_url), str(href or ''))
    if not is_seductec_url(target):
        raise ValueError('O controle Moodle apontou para uma origem não permitida.')
    parsed = urlparse(target)
    if not parsed.path.casefold().startswith(allowed_prefix.casefold()):
        raise ValueError('O controle Moodle apontou para uma rota não permitida.')
    if parsed.path.casefold().startswith('/login/logout'):
        raise ValueError('Não é permitido acionar a saída da conta.')
    # Fragmentos não são necessários à ação; a query é preservada só em memória.
    return target.split('#', 1)[0]


MOODLE_OVERVIEW_JS = r'''() => {
  const clean=(v,n=300)=>String(v??'').replace(/\s+/g,' ').trim().slice(0,n);
  const visible=e=>{if(!e)return false;const s=getComputedStyle(e),r=e.getBoundingClientRect();
    return s.display!=='none'&&s.visibility!=='hidden'&&r.width>0&&r.height>0&&!e.closest('[hidden],[aria-hidden="true"]');};
  const safeHref=e=>{try{const u=new URL(e.href,location.href);if(u.protocol!=='https:'||u.hostname!==location.hostname)return null;
    for(const key of [...u.searchParams.keys()])if(['sesskey','token','password','passwd','authorization','authkey','logintoken','moodlesession','phpsessid'].includes(key.toLowerCase()))u.searchParams.delete(key);
    u.hash='';return u.origin+u.pathname+u.search;}catch{return null;}};
  const heading=[...document.querySelectorAll('.page-header-headings h1,h1#page-header,h1')].find(visible);
  const sections=[],activities=[],pdfs=[];
  for(const [sectionIndex,section] of [...document.querySelectorAll('li.section,.course-section,[data-for="section"]')].filter(visible).slice(0,60).entries()){
    const titleNode=[...section.querySelectorAll('.sectionname,.course-section-header h3,h3,h4')].find(visible);
    const title=clean(titleNode?.innerText||section.getAttribute('aria-label')||'Seção',180),items=[];
    const nodes=[...section.querySelectorAll('li.activity,.activity,.activity-item,[data-activityname],.card.activity,.modtype_resource,.modtype_forum,.modtype_quiz,.modtype_assign,[class*="activity-card"],a.aalink')].filter(visible).slice(0,120);
    // Evita duplicar o mesmo link se o card e o li.activity forem capturados juntos.
    const seenNodes=new Set();

    for(const [activityIndex,node] of nodes.entries()){
      if(seenNodes.has(node)) continue;
      seenNodes.add(node);
      const link=node.matches('a[href]')&&visible(node)?node:[...node.querySelectorAll('.activityname a,.activityinstance a,a.aalink,a[href],a.card-link')].find(visible);
      let name=clean(link?.innerText||node.querySelector('.activityname,.instancename,.card-title,h3,h4,h5')?.innerText||node.innerText,180);
      const href=link?safeHref(link):null;
      if(href && seenNodes.has(href)) continue;
      if(href) seenNodes.add(href);
      const typeClass=[...node.classList].find(x=>x.startsWith('modtype_'))||'';
      const type=typeClass.replace('modtype_','')||'atividade';
      const isPdf=!!href&&(/\.pdf(?:$|[?#])/i.test(href)||/\bpdf\b/i.test(name)||/application\/pdf/i.test(node.getAttribute('data-type')||''));
      const comp=node.querySelector('.completion-info,.activity-completion,.completionprogress,.completion,[data-region="completion-info"],.activity-information,[data-region="activity-information"]');
      const compText=clean(comp?.innerText||comp?.getAttribute('aria-label')||comp?.getAttribute('title')||'',180).toLowerCase();
      const compClass=String(comp?.className||'').toLowerCase();
      const checked=!!node.querySelector('.completioncheckbox input[type="checkbox"]:checked,.completion-complete input[type="checkbox"]:checked,input[type="checkbox"].completion-checkbox:checked');
      // Tema SEDUCTEC / cards customizados: check verde, badge de sucesso, ícone fa-check.
      const greenDone=!!node.querySelector(
        '.text-success,.badge-success,.bg-success,.completion-complete,.complete,.is-complete,'+
        '[class*="completed"],[class*="complete"],svg.text-success,i.fa-check,i.fa-check-circle,'+
        '.fa-check,.fa-check-circle,[aria-label*="conclu" i],[title*="conclu" i],' +
        '[aria-label*="completed" i],[title*="completed" i],[aria-label*="done" i]'
      );
      const greenStyle=[...node.querySelectorAll('svg,i,span,div,img')].some(el=>{
        try{
          const st=getComputedStyle(el); const c=(st.color||'')+(st.fill||'')+(st.backgroundColor||'');
          const cls=String(el.className||'').toLowerCase();
          const label=String(el.getAttribute('aria-label')||el.getAttribute('title')||el.textContent||'').toLowerCase();
          const looksCheck=/check|conclu|complete|done|success|feito/.test(cls+' '+label);
          const looksGreen=/rgb\(\s*0*([1-9]?\d|1\d\d)\s*,\s*0*(1[5-9]\d|2[0-5]\d)\s*,\s*0*([0-9]{1,2}|1[0-2]\d)\s*\)/.test(c) || /#0[a-f0-9]{2}[89a-f][0-9a-f]{3}|#28a745|#198754|#22c55e|#16a34a|#4caf50/i.test(c);
          return looksCheck && (looksGreen || /success|complete|done|conclu/.test(cls+' '+label));
        }catch{return false;}
      });
      let completion='nao_confirmado';
      if(/\b(not done|not completed|to do|incomplete)\b|n[aã]o conclu[ií]d[oa]|a fazer|pendente|incomplete/.test(compText+' '+compClass))completion='pendente';
      else if(checked||greenDone||greenStyle||/\b(done|completed|conclu[ií]d[oa]|feito|complete)\b/.test(compText+' '+compClass))completion='concluido';
      if(name){const item={nome:name,url:href,tipo:type,pdf:isPdf,conclusao:completion,evidencia:compText,secao_indice:sectionIndex,atividade_indice:activityIndex,secao:title};items.push(item);activities.push(item);if(isPdf)pdfs.push(item);}
    }
    if(items.length||title!=='Seção')sections.push({titulo:title,atividades:items});
  }
  // Recursos Moodle frequentemente apontam primeiro para /mod/resource/view.php;
  // a URL do arquivo PDF só aparece dentro da própria página do recurso.
  const pdfSeen=new Set(pdfs.map(item=>item.url));
  const pdfNodes=[...document.querySelectorAll('a[href],iframe[src],object[data],embed[src]')].filter(visible).slice(0,160);
  for(const node of pdfNodes){
    const raw=node.href||node.src||node.data||'';
    const href=safeHref({href:raw});
    const label=clean(node.innerText||node.getAttribute('title')||node.getAttribute('aria-label')||node.getAttribute('type')||'',160);
    const looksPdf=/\.pdf(?:$|[?#])/i.test(raw)||/application\/pdf/i.test(raw+' '+label)||/\.pdf\b/i.test(label);
    if(href&&looksPdf&&!pdfSeen.has(href)){pdfSeen.add(href);pdfs.push({nome:label||raw.split('/').pop()||'PDF',url:href,tipo:'resource',pdf:true,conclusao:'nao_confirmado',evidencia:'Link/visualizador PDF visível nesta página'});}
  }
  const currentPath=location.pathname.toLowerCase();
  if(/\.pdf$/i.test(currentPath)||/\/pluginfile\.php\//i.test(currentPath)&&/\.pdf(?:$|\/)/i.test(decodeURIComponent(currentPath))){
    const current=safeHref({href:location.href});
    if(current&&!pdfSeen.has(current))pdfs.push({nome:clean(document.title||'PDF aberto',160),url:current,tipo:'resource',pdf:true,conclusao:'nao_confirmado',evidencia:'PDF atualmente aberto'});
  }
  const qnodes=[...document.querySelectorAll('.que')].filter(visible).slice(0,40);
  const questions=qnodes.map((q,i)=>{
    const prompt=[...q.querySelectorAll('.qtext,.formulation .qtext')].find(visible);
    // O índice é a posição real no conjunto de controles habilitados, não a
    // posição após filtrar opções visíveis. O aplicador usa a mesma ordem DOM.
    const allChoiceInputs=[...q.querySelectorAll('input[type="radio"],input[type="checkbox"]')].filter(input=>!input.disabled);
    const qinputs=allChoiceInputs.filter(input=>{const label=input.id?[...q.querySelectorAll('label')].find(l=>l.htmlFor===input.id):input.closest('label');return visible(input)||visible(label)||visible(input.parentElement)});
    const options=qinputs.map(input=>{
      const label=input.id?[...q.querySelectorAll('label')].find(l=>l.htmlFor===input.id):input.closest('label');
      return {indice:allChoiceInputs.indexOf(input),tipo:input.type,valor:clean(input.value,160),texto:clean(label?.innerText||label?.textContent||input.value,240),selecionada:!!input.checked,desabilitada:false};
    }).filter(o=>o.texto);
    const textFields=[...q.querySelectorAll('input:not([type="hidden"]):not([type="radio"]):not([type="checkbox"]):not([type="password"]):not([type="email"]),textarea,select,[contenteditable="true"]')].filter(visible).map((el,j)=>({indice:j,tipo:el.tagName.toLowerCase(),inputType:el.type||'',placeholder:clean(el.getAttribute('placeholder'),100),opcoes:el.tagName==='SELECT'?[...el.options].filter(o=>o.value!=='' && !o.disabled).slice(0,40).map(o=>clean(o.textContent,160)):[],preenchido:el.tagName==='SELECT'?!!el.value:el.isContentEditable?!!clean(el.innerText,10):!!clean(el.value,10)}));
    const iframeEditors=[...q.querySelectorAll('iframe')].filter(visible).map((frame,j)=>{let filled=false;try{filled=!!clean(frame.contentDocument?.body?.innerText||'',10)}catch{}return {indice:textFields.length+j,tipo:'iframe_editor',inputType:'iframe',placeholder:clean(frame.title||frame.getAttribute('title'),100),opcoes:[],preenchido:filled}});
    const classes=String(q.className||'');
    const allFields=[...textFields,...iframeEditors];
    const filledFields=allFields.filter(f=>f.preenchido).length;
    const partialFields=allFields.length>1&&filledFields>0&&filledFields<allFields.length;
    const choiceTypes=new Set(options.map(o=>o.tipo));
    const unsupportedMixedChoices=choiceTypes.has('radio')&&choiceTypes.has('checkbox');
    const hasDraft=options.some(o=>o.selecionada)||filledFields>0;
    const state=!q.id||unsupportedMixedChoices?'invalida':/state-gradedright/.test(classes)?'correta':/state-gradedwrong/.test(classes)?'incorreta':/state-invalid/.test(classes)?'invalida':partialFields?'parcial':hasDraft?'respondida_nao_enviada':'nao_respondida';
    return {indice:i,id:q.id||`moodle-question-${i+1}`,texto:clean(prompt?.innerText||'',1800),tipo:(classes.match(/qtype-([a-z0-9_]+)/i)||[])[1]||'desconhecido',opcoes:options,campos:allFields,estado:state};
  }).filter(q=>q.texto);
  const editors=[...document.querySelectorAll('textarea,input:not([type="hidden"]):not([type="password"]):not([type="email"]),[contenteditable="true"]')].filter(visible).map((e,i)=>{
    const labels=[...document.querySelectorAll('label[for]')].filter(l=>l.htmlFor===e.id&&visible(l));
    const label=labels[0]?.innerText||e.getAttribute('aria-label')||e.getAttribute('placeholder')||e.name||e.id||'';
    const inForum=!!e.closest('#page-mod-forum-discuss,.forum-post-container,#region-main form,.forumpost');
    return {indice:i,id:e.id||'',name:e.name||'',tag:e.tagName.toLowerCase(),tipo:e.type||'',rotulo:clean(label,120),forum:inForum,
      preenchido:e.isContentEditable?!!clean(e.innerText,5):!!clean(e.value,5),readonly:!!e.readOnly,disabled:!!e.disabled};
  }).filter(e=>e.id||e.name||e.rotulo);
  const posts=[...document.querySelectorAll('.forumpost,article.forumpost,.discussion,.forum-post-container')].filter(visible).slice(0,25).map((post,i)=>{
    const reply=[...post.querySelectorAll('a,button,input[type=submit]')].filter(visible).find(e=>{
      const label=clean(e.innerText||e.value||e.getAttribute('aria-label'),100),href=String(e.getAttribute('href')||'');
      return /responder|reply|post reply|adicionar resposta/i.test(label)||/\/mod\/forum\/post\.php.*(?:reply=|parent=)/i.test(href);
    });
    return {indice:i,titulo:clean(post.querySelector('.subject,.topic,.discussionname,h3,h4')?.innerText||'',180),texto:clean(post.innerText||'',1200),podeResponder:!!reply};
  });
  const replyLinks=[...document.querySelectorAll('a,button,input[type="submit"]')].filter(visible).filter(e=>/responder|reply|post reply|adicionar resposta/i.test(clean(e.innerText||e.value||e.getAttribute('aria-label'),100))).slice(0,10).map(e=>({texto:clean(e.innerText||e.value||e.getAttribute('aria-label'),80),url:e.tagName==='A'?safeHref(e):null,tag:e.tagName.toLowerCase()}));
  const completionTexts=[...document.querySelectorAll('.completion-info,.activity-completion,.completionprogress,.completion,.activity-information,.badge,.alert,.notifications')].filter(visible).map(e=>clean(e.innerText,180)).filter(Boolean).slice(0,50);
  const retryButtons=[...document.querySelectorAll('a,button,input[type="submit"]')].filter(visible).filter(e=>/tentar novamente|tentar (?:responder|iniciar).*question[aá]rio|nova tentativa|re-attempt|retry|attempt quiz now|start (?:a )?new attempt|reopen attempt/i.test(clean(e.innerText||e.value||e.getAttribute('aria-label'),100))).slice(0,8).map(e=>({texto:clean(e.innerText||e.value||e.getAttribute('aria-label'),90),url:e.tagName==='A'?safeHref(e):null,tag:e.tagName.toLowerCase(),desabilitado:!!e.disabled}));
  const body=clean(document.body?.innerText||'',9000);
  const pagePath=location.pathname.toLowerCase();
  let pageCompletion='nao_confirmado';
  const compText=completionTexts.join(' ').toLowerCase();
  // Em páginas de curso, textos globais podem ser badges de atividades individuais.
  const courseOverview=pagePath==='/'||pagePath.startsWith('/course/')||pagePath.startsWith('/my/');
  if(pagePath.includes('/mod/quiz/review.php')||(!courseOverview&&/tentativa conclu[ií]da|revis[aã]o da tentativa|nota final/.test(body.toLowerCase())))pageCompletion='concluido';
  else if(pagePath.includes('/mod/quiz/attempt.php')||pagePath.includes('/mod/quiz/summary.php'))pageCompletion='em_andamento';
  else if(pagePath.endsWith('/mod/quiz/view.php'))pageCompletion='pendente';
  else if(!courseOverview&&/n[aã]o conclu[ií]do|ainda n[aã]o conclu[ií]da|not completed|to do|incomplete/.test(compText))pageCompletion='pendente';
  else if(!courseOverview&&/atividade conclu[ií]da|conclu[ií]do|completed|completion-complete|done/.test(compText))pageCompletion='concluido';
  else if(!courseOverview){
    const greenBadge=[...document.querySelectorAll('.text-success,.badge-success,.bg-success,.completion-complete,[class*="completed"],i.fa-check,i.fa-check-circle,.fa-check,[aria-label*="conclu" i],[title*="conclu" i]')].some(visible);
    if(greenBadge) pageCompletion='concluido';
  }
  const quizSummary=clean([...document.querySelectorAll('.quizattemptsummary,.quizsummary,.generalbox,.quizinfo')].filter(visible).map(e=>e.innerText).join(' '),1200);
  const descriptionSelectors=['.activity-description','#intro','.activity-header .no-overflow','.box.generalbox .no-overflow'];
  let activityDescription='';for(const selector of descriptionSelectors){const candidate=[...document.querySelectorAll(selector)].find(visible);const value=clean(candidate?.innerText||'',3000);if(value.length>30){activityDescription=value;break;}}
  const videos=[...document.querySelectorAll('video')].filter(visible).slice(0,12).map((v,i)=>({id:i+1,reproduzindo:!v.paused&&!v.ended,duracao:Number.isFinite(v.duration)?v.duration:null,posicao:Number(v.currentTime||0),concluidoNoPlayer:!!v.ended}));
  const title=clean(heading?.innerText||document.title,180);
  return {titulo:title,curso:clean(document.querySelector('.page-header-headings h1,.course-header h1,.coursename')?.innerText||'',180),
    secoes:sections,atividades:activities,pdfs,questoes:questions,campos:editors,forum:{posts,replyLinks,editorDetectado:editors.some(e=>e.forum||/message|reply|subject/i.test(e.name+' '+e.id))},
    conclusao:{estado:pageCompletion,evidencias:completionTexts.slice(0,12),resumoQuiz:quizSummary},
    tentarNovamente:retryButtons,
    enunciadoAtividade:activityDescription,videos,texto:body};
}'''


async def expand_moodle_course_sections(page, max_sections: int = 60) -> dict:
    """Expande seções recolhidas do curso usando apenas controles de expansão explícitos.

    A página permanece no curso autenticado. Scroll progressivo aciona lazy-load;
    cada seção é reavaliada após o clique, sem inferir que um cartão oculto foi lido.
    """
    if not is_seductec_url(getattr(page, 'url', '')) or page_kind(page.url) != 'curso':
        raise ValueError('A expansão automática só funciona na página oficial de um curso SEDUCTEC.')
    max_sections = max(1, min(60, int(max_sections)))
    before = await page.evaluate('() => document.querySelectorAll("li.section,.course-section,[data-for=section]").length')
    expanded = 0
    attempts = 0
    previous_count = int(before or 0)
    previous_height = 0
    for _ in range(8):
        result = await page.evaluate(r'''(limit) => {
          const visible=el=>{if(!el)return false;const r=el.getBoundingClientRect(),s=getComputedStyle(el);return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'&&!el.closest('[hidden],[aria-hidden="true"]')};
          let allClicked=0;
          const expandAll=[...document.querySelectorAll('button,a,[role="button"]')].filter(visible).filter(el=>/^(expand all|show all sections|expand sections|mostrar todas as se[cç][oõ]es|expandir todas as se[cç][oõ]es|mostrar tudo)$/i.test((el.innerText||el.getAttribute('aria-label')||'').trim())).slice(0,2);
          for(const control of expandAll){if(!control.disabled&&control.dataset.ecStudioExpanded!=='true'&&control.getAttribute('aria-expanded')!=='true'){control.click();control.dataset.ecStudioExpanded='true';allClicked++;}}
          const sections=[...document.querySelectorAll('li.section,.course-section,[data-for="section"]')].slice(0,limit);
          let clicked=0;
          for(const section of sections){
            const controls=[...section.querySelectorAll(
              'button,a,[role="button"],.section-collapser,.section-toggle,[data-region="section-toggler"],'+
              '[data-action="toggleSection"],[data-toggle="collapse"],.sectionname.collapsed'
            )];
            const control=controls.find(el=>{
              if(el.disabled||el.getAttribute('aria-disabled')==='true'||el.dataset.ecStudioExpanded==='true')return false;
              if(el.getAttribute('aria-expanded')==='true')return false;
              if(el.getAttribute('aria-expanded')==='false')return true;
              const target=el.getAttribute('data-target')||el.getAttribute('href');
              if(target&&target.startsWith('#')){
                let panel=null;try{panel=section.querySelector(target)}catch{}
                if(panel&&(panel.hidden||getComputedStyle(panel).display==='none'||panel.getAttribute('aria-hidden')==='true'))return true;
              }
              const label=[el.innerText,el.getAttribute('aria-label'),el.getAttribute('title'),el.getAttribute('data-toggle')].filter(Boolean).join(' ').toLowerCase();
              if(/collapsed|expand|show section|mostrar|expandir|exibir/.test(label)||el.classList.contains('collapsed'))return true;
              const panel=section.querySelector('.content,.section-content,.course-section-content,[data-region="sectioncontent"]');
              const contentHidden=!!panel&&(panel.hidden||getComputedStyle(panel).display==='none'||panel.getAttribute('aria-hidden')==='true');
              const isHeadingToggle=el.matches('.sectionname,.sectionname a,.section-toggle,.section-collapser,[data-region="section-toggler"],[data-action="toggleSection"]');
              return contentHidden&&isHeadingToggle;
            });
            if(!control)continue;
            section.scrollIntoView({block:'center',behavior:'instant'});
            control.click(); control.dataset.ecStudioExpanded='true'; clicked++;
          }
          return {clicked,allClicked,sections:sections.length,height:document.documentElement.scrollHeight};
        }''', max_sections)
        attempts += int(result.get('clicked', 0)) + int(result.get('allClicked', 0))
        expanded += int(result.get('clicked', 0)) + int(result.get('allClicked', 0))
        height = int(result.get('height', 0) or 0)
        viewport = await page.evaluate('() => Math.max(400,window.innerHeight||600)')
        for y in range(0, max(height, 0), max(300, int(viewport * 0.8))):
            await page.evaluate('(y)=>window.scrollTo(0,y)', y)
            try:
                await page.wait_for_timeout(100)
            except Exception:
                pass
        stats = await page.evaluate(r'''() => ({
          sections:document.querySelectorAll('li.section,.course-section,[data-for="section"]').length,
          height:document.documentElement.scrollHeight
        })''')
        current_count = int(stats.get('sections', 0) or 0)
        current_height = int(stats.get('height', 0) or 0)
        no_clicks = int(result.get('clicked', 0)) == 0 and int(result.get('allClicked', 0)) == 0
        if no_clicks and current_count <= previous_count and current_height <= previous_height:
            break
        previous_count, previous_height = current_count, current_height
    await page.evaluate('() => window.scrollTo(0,0)')
    await page.wait_for_timeout(150)
    after = await page.evaluate('() => document.querySelectorAll("li.section,.course-section,[data-for=section]").length')
    return {'secoes_detectadas_antes': int(before or 0), 'secoes_detectadas_depois': int(after or 0),
            'controles_acionados': expanded, 'passagens': attempts, 'rolagem_completa': True}


async def inspect_moodle_page(page) -> dict:
    """Inspeciona curso, fóruns, questionários, recursos PDF e conclusão visível."""
    if not is_seductec_url(page.url):
        return {'ativo': False}
    try:
        data = await page.main_frame.evaluate(MOODLE_OVERVIEW_JS)
    except Exception as exc:
        return {'ativo': True, 'tipo_pagina': page_kind(page.url),
                'erro': f'Não foi possível ler a estrutura desta página ({type(exc).__name__}).'}
    data.update({'ativo': True, 'tipo_pagina': page_kind(page.url),
                 'url': normalize_seductec_url(page.url)})
    return data


async def open_moodle_pdf(page, url: str):
    """Abre o arquivo PDF real em nova aba, resolvendo antes links resource/view do Moodle."""
    target = normalize_seductec_url(url)
    overview = await inspect_moodle_page(page)
    allowed = {item.get('url') for item in overview.get('pdfs', []) if item.get('url')}
    parsed = urlparse(target)
    direct_pdf = is_direct_moodle_pdf(target)
    if target not in allowed:
        raise ValueError('Esse recurso não foi identificado como PDF na página atual.')
    if not (direct_pdf or parsed.path.startswith(('/mod/resource/', '/pluginfile.php/'))):
        raise ValueError('O link selecionado não é um recurso PDF Moodle permitido.')
    new_page = await page.context.new_page()
    try:
        await new_page.goto(target, wait_until='domcontentloaded', timeout=35000)
        await new_page.wait_for_timeout(500)
        if not is_seductec_url(new_page.url):
            raise ValueError('O recurso redirecionou para um domínio externo; a abertura foi bloqueada.')
        if not is_direct_moodle_pdf(new_page.url):
            # Moodle costuma servir o documento dentro da própria página de recurso. Procura
            # a URL do pluginfile exposta no iframe/object/embed/link visível dessa página.
            resource_overview = await inspect_moodle_page(new_page)
            candidates = [item.get('url') for item in resource_overview.get('pdfs', [])
                          if item.get('url') and is_direct_moodle_pdf(item.get('url'))]
            if not candidates:
                raise ValueError('Abri a página do recurso, mas não encontrei o arquivo PDF direto. Confira se o material terminou de carregar e tente novamente.')
            await new_page.goto(candidates[0], wait_until='domcontentloaded', timeout=35000)
            await new_page.wait_for_timeout(500)
            if not is_seductec_url(new_page.url) or not is_direct_moodle_pdf(new_page.url):
                raise ValueError('O endereço final não confirmou um PDF do domínio SEDUCTEC.')
        return new_page
    except Exception:
        try:
            await new_page.close()
        except Exception:
            pass
        raise


async def open_moodle_discussion_from_listing(page):
    """Abre uma discussão visível na listagem do fórum, sem iniciar publicação."""
    if page_kind(page.url) != 'forum' or not urlparse(page.url).path.casefold().endswith('/mod/forum/view.php'):
        return {'ok': True, 'url': normalize_seductec_url(page.url), 'ja_estava_em_discussao': True}
    links = page.locator('a[href*="/mod/forum/discuss.php"]')
    for index in range(min(await links.count(), 40)):
        link = links.nth(index)
        try:
            if not await link.is_visible() or not await link.is_enabled():
                continue
            href = await link.get_attribute('href')
            if not href:
                continue
            target = _visible_action_target(page.url, href, '/mod/forum/')
            await page.goto(target, wait_until='domcontentloaded', timeout=30000)
            if page_kind(page.url) != 'forum' or not urlparse(page.url).path.casefold().endswith('/mod/forum/discuss.php'):
                raise ValueError('O link não abriu uma discussão válida do SEDUCTEC.')
            return {'ok': True, 'url': normalize_seductec_url(page.url),
                    'ja_estava_em_discussao': False,
                    'mensagem': 'Discussão aberta. O Studio ainda não publicou nem iniciou uma resposta.'}
        except ValueError:
            raise
        except Exception:
            continue
    raise ValueError('A listagem do fórum não contém uma discussão visível para abrir.')


async def open_moodle_forum_reply(page):
    """Abre a área oficial de resposta em uma discussão visível do Moodle."""
    if page_kind(page.url) != 'forum':
        raise ValueError('Abra primeiro uma discussão de fórum do SEDUCTEC.')
    posts = page.locator('.forumpost, article.forumpost, .discussion, .forum-post-container')
    candidate_groups = []
    post_count = await posts.count()
    if post_count:
        # Alguns fóruns não permitem responder ao último post, mas permitem a
        # resposta em um post anterior. Tenta do mais recente para o mais antigo.
        for post_index in reversed(range(min(post_count, 25))):
            candidate_groups.append(posts.nth(post_index).locator('a,button,input[type="submit"]'))
    candidate_groups.append(page.locator('a,button,input[type="submit"]'))
    for candidates in candidate_groups:
        for i in range(min(await candidates.count(), 120)):
            item = candidates.nth(i)
            try:
                if not await item.is_visible() or not await item.is_enabled():
                    continue
                label = (await item.inner_text(timeout=1000)).strip() if await item.evaluate('(e)=>e.tagName!=="INPUT"') else str(await item.get_attribute('value') or '')
                label = label or str(await item.get_attribute('aria-label') or '')
                href_hint = str(await item.get_attribute('href') or '')
                is_reply_link = bool(re.search(r'/mod/forum/post\.php.*(?:reply=|parent=)', href_hint, re.I))
                if not is_reply_link and not re.search(r'responder|reply|post reply|adicionar resposta', label, re.I):
                    continue
                href = await item.get_attribute('href')
                if href:
                    target = _visible_action_target(page.url, href, '/mod/forum/')
                    await page.goto(target, wait_until='domcontentloaded', timeout=30000)
                else:
                    await item.click(timeout=5000)
                await page.wait_for_timeout(250)
                return {'ok': True, 'url': normalize_seductec_url(page.url),
                        'editor': await forum_editor_detected(page), 'mensagem': 'Área de resposta aberta. Revise antes de publicar.'}
            except Exception:
                continue
    # Na página de listagem do fórum Moodle, abrir uma discussão visível antes de responder.
    if urlparse(page.url).path.casefold().endswith('/mod/forum/view.php'):
        discussion_links = page.locator('a[href*="/mod/forum/discuss.php"]')
        for index in range(min(await discussion_links.count(), 40)):
            link = discussion_links.nth(index)
            try:
                if await link.is_visible() and await link.is_enabled():
                    href = await link.get_attribute('href')
                    if href:
                        target = _visible_action_target(page.url, href, '/mod/forum/')
                        await page.goto(target, wait_until='domcontentloaded', timeout=30000)
                        return await open_moodle_forum_reply(page)
            except Exception:
                continue
    raise ValueError('Não encontrei uma discussão com resposta disponível. Abra uma discussão do fórum e tente novamente.')


async def retry_moodle_quiz(page):
    """Aciona apenas um controle visível do Moodle explicitamente rotulado para nova tentativa.

    Não submete a tentativa atual e não usa endpoints internos.
    """
    origin_url = page.url
    current_path = urlparse(origin_url).path.casefold()
    is_quiz_landing = current_path.rstrip('/') == '/mod/quiz/view.php'
    if page_kind(page.url) not in ('quiz_resumo', 'quiz_revisao') and not is_quiz_landing:
        raise ValueError('Abra a página do questionário, o resumo ou a revisão antes de tentar novamente.')
    candidates = page.locator('a,button,input[type="submit"]')
    pattern = re.compile(r'tentar novamente|tentar (?:responder|iniciar).*question[aá]rio|nova tentativa|recomeçar|iniciar (?:uma )?tentativa|re-attempt|retry|attempt quiz now|start (?:a )?new attempt|reopen attempt', re.I)
    for index in range(min(await candidates.count(), 100)):
        item = candidates.nth(index)
        try:
            if not await item.is_visible() or not await item.is_enabled():
                continue
            tag = await item.evaluate('(e)=>e.tagName')
            label = await item.evaluate("(e)=>e.innerText||e.value||e.getAttribute('aria-label')||''")
            if not pattern.search(str(label or '')):
                continue
            href = await item.get_attribute('href')
            if href:
                # Preserva sesskey no endereço temporário de navegação; o Moodle pode
                # exigir esse CSRF para iniciar/reiniciar a tentativa. Nunca o registra.
                target = _visible_action_target(page.url, href, '/mod/quiz/')
                await page.goto(target, wait_until='domcontentloaded', timeout=30000)
            else:
                await item.click(timeout=6000)
                await page.wait_for_load_state('domcontentloaded', timeout=15000)
            if not is_seductec_url(page.url) or not urlparse(page.url).path.startswith('/mod/quiz/'):
                # Uma resposta HTTP ou script do portal não deve deixar a sessão em outra origem.
                try:
                    await page.goto(origin_url, wait_until='domcontentloaded', timeout=15000)
                except Exception:
                    pass
                raise ValueError('A navegação não permaneceu no questionário do SEDUCTEC; a página original foi restaurada quando possível.')
            return {'ok': True, 'url': normalize_seductec_url(page.url),
                    'mensagem': 'Nova tentativa aberta pelo controle visível do Moodle. Nenhuma resposta foi enviada.'}
        except ValueError:
            raise
        except Exception:
            continue
    raise ValueError('O Moodle não exibiu um botão disponível de nova tentativa. Confira a disponibilidade no curso ou fale com o professor.')


async def forum_editor_detected(page) -> bool:
    selectors = [
        'textarea[name*="message"]', 'textarea[id*="message"]',
        '[contenteditable="true"][id*="message"]', '.editor_atto_content[contenteditable="true"]',
        'iframe[id*="message_editoreditable_ifr"]',
    ]
    for selector in selectors:
        locator = page.locator(selector)
        for i in range(min(await locator.count(), 6)):
            try:
                if await locator.nth(i).is_visible():
                    return True
            except Exception:
                continue
    return False


async def fill_moodle_forum_editor(page, text: str) -> dict:
    """Preenche um editor do Moodle; não aciona o botão de publicação."""
    if page_kind(page.url) != 'forum':
        raise ValueError('A página atual não é uma discussão de fórum do SEDUCTEC.')
    content = str(text or '').strip()
    if not 1 <= len(content) <= 6000:
        raise ValueError('O rascunho do fórum precisa ter entre 1 e 6000 caracteres.')
    selectors = [
        'textarea[name*="message"]', 'textarea[id*="message"]',
        '[contenteditable="true"][id*="message"]', '.editor_atto_content[contenteditable="true"]',
    ]
    for selector in selectors:
        locator = page.locator(selector)
        for i in range(min(await locator.count(), 8)):
            field = locator.nth(i)
            try:
                if not await field.is_visible() or await field.is_disabled():
                    continue
                if await field.evaluate('(e)=>e.isContentEditable'):
                    await field.fill(content)
                else:
                    await field.fill(content)
                check = await field.evaluate('(e)=>e.isContentEditable ? e.innerText : e.value')
                if str(check or '').strip() == content:
                    return {'ok': True, 'preenchido': True, 'enviado': False,
                            'mensagem': 'Rascunho preenchido no editor. O botão Publicar/Enviar não foi acionado.'}
            except Exception:
                continue
    # TinyMCE/Atto podem expor o editor dentro de um iframe.
    for frame in page.frames:
        if frame == page.main_frame:
            continue
        try:
            body = frame.locator('body[contenteditable="true"],body.mce-content-body')
            if await body.count() and await body.first.is_visible():
                await body.first.fill(content)
                observed = (await body.first.inner_text()).strip()
                if observed == content:
                    return {'ok': True, 'preenchido': True, 'enviado': False,
                            'mensagem': 'Rascunho preenchido e relido no editor incorporado. Publicação permanece manual.'}
        except Exception:
            continue
    raise ValueError('Editor do fórum não encontrado. Clique em Responder e abra o editor antes de preencher.')


async def apply_moodle_quiz_suggestions(page, suggestions: list[dict]) -> dict:
    """Aplica rascunhos aos controles Moodle visíveis com interações Playwright reais.

    Não envia o formulário do questionário. Cada campo é relido depois do preenchimento.
    """
    if page_kind(page.url) != 'questionario':
        raise ValueError('Abra uma tentativa ativa de questionário do Moodle antes de preencher respostas.')
    if not isinstance(suggestions, list) or not 1 <= len(suggestions) <= 40:
        raise ValueError('A lista de sugestões está vazia ou excede o limite.')

    result = {'preenchidas': 0, 'confirmadas': 0, 'puladas': [], 'detalhes': [], 'enviadas': False}
    for item in suggestions:
        qid = str(item.get('id') or '')
        if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]{0,120}', qid):
            result['puladas'].append(qid or str(item.get('indice')))
            result['detalhes'].append({'id': qid, 'estado': 'id_invalido', 'confirmada': False})
            continue
        question = page.locator(f'.que[id="{qid}"]')
        try:
            if await question.count() != 1 or not await question.is_visible():
                result['puladas'].append(qid)
                result['detalhes'].append({'id': qid, 'estado': 'questao_nao_visivel', 'confirmada': False})
                continue
            done = False
            evidence = ''
            selected = item.get('selecionadas') if isinstance(item.get('selecionadas'), list) else []
            radios = question.locator('input[type="radio"]:not([disabled])')
            checks = question.locator('input[type="checkbox"]:not([disabled])')
            radio_count = await radios.count()
            check_count = await checks.count()
            if radio_count and check_count:
                result['puladas'].append(qid)
                result['detalhes'].append({'id': qid, 'estado': 'tipo_controle_misto_nao_suportado', 'confirmada': False})
                continue
            if radio_count or check_count:
                pool = question.locator('input[type="radio"]:not([disabled]),input[type="checkbox"]:not([disabled])')
                count = await pool.count()
                eligible_indices = await question.evaluate(r'''q => {
                  const shown=e=>{if(!e)return false;const r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'&&!e.closest('[hidden],[aria-hidden="true"]')};
                  const all=[...q.querySelectorAll('input[type="radio"],input[type="checkbox"]')].filter(e=>!e.disabled);
                  return all.map((e,i)=>{const label=e.id?[...q.querySelectorAll('label')].find(l=>l.htmlFor===e.id):e.closest('label');return {i,ok:shown(e)||shown(label)||shown(e.parentElement)}}).filter(x=>x.ok).map(x=>x.i);
                }''')
                if selected and all(type(index) is int and index in eligible_indices and 0 <= index < count for index in selected) and len(set(selected)) == len(selected):
                    # Nas questões pendentes não deve haver marcação anterior. Ainda assim,
                    # não desmarca respostas existentes: apenas marca as opções sugeridas.
                    for index in selected:
                        option = pool.nth(index)
                        if not await option.is_checked():
                            try:
                                if await option.is_visible():
                                    await option.check(timeout=3000)
                                else:
                                    option_id = await option.get_attribute('id')
                                    label = question.locator(f'label[for="{option_id}"]') if option_id else option.locator('xpath=ancestor::label[1]')
                                    if await label.count() and await label.first.is_visible():
                                        await label.first.click(timeout=3000)
                                    else:
                                        raise ValueError('A opção não tem rótulo visível para interação segura.')
                            except Exception:
                                if not await option.is_checked():
                                    raise
                    actual = [index for index in range(count) if await pool.nth(index).is_checked()]
                    done = actual == sorted(selected) if radio_count else set(actual) == set(selected)
                    evidence = 'opções relidas: ' + ','.join(map(str, actual))
            else:
                text = str(item.get('texto') or '').strip()
                if text:
                    candidates = question.locator('textarea:visible:not([disabled]),input[type="text"]:visible:not([disabled]),input[type="number"]:visible:not([disabled]),select:visible:not([disabled]),[contenteditable="true"]:visible')
                    candidate_count = await candidates.count()
                    # Um editor TinyMCE/Atto pode coexistir com um textarea/campo.
                    # Contá-lo antes da ação evita preencher só um de vários campos.
                    frames = question.locator('iframe')
                    editable_frames = []
                    for frame_index in range(await frames.count()):
                        try:
                            frame_body = question.frame_locator(f'iframe:nth-of-type({frame_index + 1})').locator('body[contenteditable="true"],body.mce-content-body')
                            if await frame_body.count() and await frame_body.first.is_visible():
                                editable_frames.append((frame_index, frame_body))
                        except Exception:
                            continue
                    if candidate_count + len(editable_frames) > 1:
                        result['puladas'].append(qid)
                        result['detalhes'].append({'id': qid, 'estado': 'multiplos_campos_requerem_resposta_por_campo', 'confirmada': False})
                        continue
                    for index in range(candidate_count):
                        field = candidates.nth(index)
                        try:
                            if await field.get_attribute('readonly') is not None:
                                continue
                            tag = await field.evaluate('(e)=>e.tagName.toLowerCase()')
                            number_field = False
                            fill_value = text
                            if tag == 'select':
                                choices = await field.locator('option').evaluate_all('(items)=>items.map(o=>({value:o.value,label:(o.textContent||"").trim(),disabled:o.disabled}))')
                                match = next((choice for choice in choices if not choice['disabled'] and choice['value'] and choice['label'].casefold()==text.casefold()), None)
                                if match:
                                    await field.select_option(value=match['value'], timeout=3000)
                                    observed = (await field.locator('option:checked').inner_text()).strip()
                                else:
                                    observed = ''
                            else:
                                number_field = tag == 'input' and (await field.get_attribute('type') or '').lower() == 'number'
                                if number_field:
                                    fill_value = text.replace(',', '.')
                                    if not re.fullmatch(r'-?(?:\d+(?:\.\d*)?|\.\d+)', fill_value):
                                        continue
                                await field.fill(fill_value, timeout=3000)
                                observed = await field.evaluate('(e)=>e.isContentEditable ? e.innerText : e.value')
                            matches = (bool(observed) and abs(float(observed)-float(fill_value)) < 1e-9) if number_field else str(observed or '').strip() == text
                            if matches:
                                done = True
                                evidence = 'campo de texto relido'
                                break
                        except Exception:
                            continue
                    # Moodle Atto/TinyMCE pode manter o editor em iframe dentro da questão.
                    if not done and candidate_count == 0 and len(editable_frames) == 1:
                        _, frame_body = editable_frames[0]
                        try:
                            await frame_body.first.fill(text, timeout=3000)
                            observed = await frame_body.first.inner_text()
                            if observed.strip() == text:
                                done = True
                                evidence = 'editor incorporado relido'
                        except Exception:
                            pass
            detail = {'id': qid, 'estado': 'preenchida' if done else 'nao_aplicada',
                      'confirmada': bool(done), 'evidencia': evidence}
            result['detalhes'].append(detail)
            if done:
                result['preenchidas'] += 1
                result['confirmadas'] += 1
            else:
                result['puladas'].append(qid)
        except Exception as exc:
            result['puladas'].append(qid)
            result['detalhes'].append({'id': qid, 'estado': 'erro', 'confirmada': False,
                                       'erro': type(exc).__name__})

    result['enviadas'] = False
    result['estado'] = 'preenchido' if result['confirmadas'] else 'nao_confirmado'
    result['mensagem'] = f"{result['confirmadas']} de {len(suggestions)} questão(ões) tiveram campos preenchidos e relidos. Nada foi enviado."
    return result



async def submit_moodle_quiz_attempt(page) -> dict:
    """Clica no botão real de envio/finalização da tentativa se estiver visível e habilitado.

    Só deve ser chamado quando a configuração enviar_quiz=True e o preenchimento
    já foi confirmado. Não inventa botões: só interage com controles presentes.
    """
    if page_kind(page.url) not in ('questionario', 'quiz_resumo', 'quiz_revisao'):
        return {'enviado': False, 'mensagem': 'Página atual não é uma tentativa de quiz ativa.'}

    # Padrões comuns do Moodle (pt-BR e en) para finalizar/enviar tentativa.
    patterns = [
        r'enviar\s*(tudo\s*e\s*)?(finalizar|terminar)?\s*(a\s*)?(tentativa|question[aá]rio)?',
        r'finalizar\s*(a\s*)?(tentativa|question[aá]rio)',
        r'submit\s*(all\s*and\s*)?(finish|end)?',
        r'finish\s*attempt',
        r'end\s*test',
        r'submit',
    ]
    combined = re.compile('|'.join(f'(?:{p})' for p in patterns), re.I)

    candidates = page.locator('button, input[type="submit"], a.btn, a.button')
    count = await candidates.count()
    for i in range(min(count, 40)):
        el = candidates.nth(i)
        try:
            if not await el.is_visible() or await el.is_disabled():
                continue
            label = await el.evaluate(
                '''(e) => (e.innerText || e.value || e.getAttribute('aria-label') || e.getAttribute('title') || '').trim()'''
            )
            name = (label or '').strip()
            if not name or not combined.search(name):
                continue
            # Evita botões de "próxima página" / "anterior" / "salvar sem enviar".
            if re.search(r'pr[oó]xima|anterior|next|previous|salvar\s*sem|save\s*without|voltar', name, re.I):
                continue
            await el.click(timeout=5000)
            await page.wait_for_timeout(800)
            # Confirmação de diálogo Moodle (sim/continuar).
            confirm = page.locator(
                'button:has-text("Enviar"), button:has-text("Submit"), '
                'button:has-text("Sim"), button:has-text("Yes"), '
                'button:has-text("Continuar"), button:has-text("Continue"), '
                'input[type="submit"][value*="Enviar"], input[type="submit"][value*="Submit"]'
            )
            for j in range(min(await confirm.count(), 6)):
                btn = confirm.nth(j)
                try:
                    if await btn.is_visible() and not await btn.is_disabled():
                        await btn.click(timeout=4000)
                        await page.wait_for_timeout(600)
                        break
                except Exception:
                    continue
            return {
                'enviado': True,
                'botao': name[:120],
                'mensagem': f'Botão de envio clicado: “{name[:80]}”. Confira o status da tentativa no Moodle.',
            }
        except Exception:
            continue
    return {
        'enviado': False,
        'mensagem': 'Nenhum botão de enviar/finalizar tentativa visível e habilitado foi encontrado.',
    }


async def publish_moodle_forum_post(page) -> dict:
    """Clica no botão real de publicar/enviar resposta do fórum se estiver visível.

    Só deve ser chamado com publicar_forum=True e após o editor ter sido preenchido.
    """
    if page_kind(page.url) != 'forum':
        return {'publicado': False, 'mensagem': 'Página atual não é uma discussão de fórum.'}

    patterns = [
        r'publicar\s*(a\s*)?(resposta|postagem|mensagem)?',
        r'enviar\s*(a\s*)?(resposta|postagem|mensagem)?',
        r'post\s*(to\s*forum|reply)?',
        r'submit',
        r'reply',
    ]
    combined = re.compile('|'.join(f'(?:{p})' for p in patterns), re.I)

    candidates = page.locator('button, input[type="submit"], a.btn, a.button')
    count = await candidates.count()
    for i in range(min(count, 40)):
        el = candidates.nth(i)
        try:
            if not await el.is_visible() or await el.is_disabled():
                continue
            label = await el.evaluate(
                '''(e) => (e.innerText || e.value || e.getAttribute('aria-label') || e.getAttribute('title') || '').trim()'''
            )
            name = (label or '').strip()
            if not name or not combined.search(name):
                continue
            if re.search(r'cancelar|cancel|rascunho|draft|pré-visualizar|preview|voltar|back', name, re.I):
                continue
            await el.click(timeout=5000)
            await page.wait_for_timeout(900)
            return {
                'publicado': True,
                'botao': name[:120],
                'mensagem': f'Botão de publicação clicado: “{name[:80]}”. Confira se a mensagem apareceu no fórum.',
            }
        except Exception:
            continue
    return {
        'publicado': False,
        'mensagem': 'Nenhum botão de publicar/enviar resposta visível e habilitado foi encontrado.',
    }
