"""Gravação atômica e locks locais compartilhados pelos dados do aplicativo."""
from contextlib import contextmanager
from datetime import datetime, timezone
import errno
import json
import os
from pathlib import Path
import secrets
import shutil
import tempfile
import time


# Sistemas de arquivos como o armazenamento compartilhado do Android (/storage/emulated/0)
# não implementam flock: nesses casos usamos um arquivo-marcador de criação exclusiva.
_LOCK_UNSUPPORTED = {errno.ENOSYS, errno.ENOTSUP, errno.EOPNOTSUPP, errno.ENOLCK}


def _pid_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except OSError:
        return True
    return True


def _take_marker(path: Path, deadline: float) -> Path:
    marker = path.with_name(path.name + '.excl')
    while True:
        try:
            descriptor = os.open(marker, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
            try:
                os.write(descriptor, str(os.getpid()).encode())
            finally:
                os.close(descriptor)
            return marker
        except FileExistsError:
            try:
                owner = int(marker.read_text().strip() or 0)
            except (OSError, ValueError):
                owner = 0
            if owner and not _pid_alive(owner):
                marker.unlink(missing_ok=True)  # dono encerrou sem soltar a trava
                continue
            if time.monotonic() >= deadline:
                raise RuntimeError('O arquivo de dados está ocupado. Tente novamente.')
            time.sleep(.05)


def _chmod(path: Path, mode: int):
    try:
        os.chmod(path, mode)
    except OSError:
        pass  # armazenamento sem permissões POSIX


@contextmanager
def file_lock(path: Path, timeout: float = 30):
    path = Path(path)
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    with path.open('a+b') as stream:
        stream.seek(0, 2)
        if not stream.tell():
            stream.write(b'0')
            stream.flush()
        deadline = time.monotonic() + timeout
        marker = None
        while True:
            try:
                stream.seek(0)
                if os.name == 'nt':
                    import msvcrt
                    msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except OSError as exc:
                if os.name != 'nt' and exc.errno in _LOCK_UNSUPPORTED:
                    marker = _take_marker(path, deadline)
                    break
                if time.monotonic() >= deadline:
                    raise RuntimeError('O arquivo de dados está ocupado. Tente novamente.')
                time.sleep(.05)
        try:
            yield
        finally:
            if marker is not None:
                marker.unlink(missing_ok=True)
            else:
                stream.seek(0)
                if os.name == 'nt':
                    import msvcrt
                    msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(stream.fileno(), fcntl.LOCK_UN)


def write_text_atomic(path: Path, text: str, *, backup: bool = False):
    path = Path(path)
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=path.parent,
                                     prefix=path.name+'-', suffix='.tmp', delete=False) as stream:
        temporary = Path(stream.name)
        try:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        except BaseException:
            stream.close()
            temporary.unlink(missing_ok=True)
            raise
    try:
        if backup and path.exists():
            stamp = datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f')
            copy = path.with_name(path.name+'.recuperacao-'+stamp+'-'+secrets.token_hex(3)+'.bak')
            shutil.copyfile(path, copy)
            _chmod(copy, 0o600)
        _chmod(temporary, 0o600)
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


def write_json_atomic(path: Path, data, *, backup: bool = False):
    write_text_atomic(path, json.dumps(data, ensure_ascii=False, indent=2), backup=backup)


def local_token(path: Path) -> str:
    path = Path(path)
    with file_lock(path.with_suffix('.lock')):
        try:
            value = path.read_text('utf-8').strip()
        except FileNotFoundError:
            value = ''
        if value:
            return value
        value = secrets.token_urlsafe(32)
        write_text_atomic(path, value, backup=path.exists())
        return value
