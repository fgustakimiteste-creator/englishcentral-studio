from concurrent.futures import ThreadPoolExecutor
import json
from unittest.mock import Mock

import pytest
from perfis import ProfileManager
import perfis


def test_cadastra_mais_de_cinco_sem_limite_e_persiste(tmp_path):
    manager = ProfileManager(tmp_path / 'dados', tmp_path)
    for n in range(12): manager.create(f'Estudante {n}')
    saved = ProfileManager(manager.root, tmp_path).list()
    assert len(saved) == 13 and len({p['id'] for p in saved}) == 13
    assert saved[-1]['nome'] == 'Estudante 11'
    assert all(set(p) == {'id', 'nome'} for p in saved)


def test_cadastros_simultaneos_nao_duplicam_ids(tmp_path):
    manager = ProfileManager(tmp_path / 'dados', tmp_path)
    with ThreadPoolExecutor(max_workers=6) as executor:
        people = list(executor.map(lambda n: manager.create(f'Pessoa {n}'), range(12)))
    assert len({p['id'] for p in people}) == 12
    assert len(manager.list()) == 13


def test_preserva_pessoa2_antiga_e_dados(tmp_path):
    (tmp_path / 'pessoa2').mkdir()
    original = tmp_path / 'pessoa2' / 'progresso_verificado.json'
    original.write_text('{"legacy":true}')
    manager = ProfileManager(tmp_path, tmp_path)
    assert manager.list()[1]['id'] == 'pessoa2'
    assert manager.create()['id'] == 'pessoa3'
    assert original.read_text() == '{"legacy":true}'


def test_renomear_preserva_id_diretorio_e_historico(tmp_path):
    manager = ProfileManager(tmp_path / 'dados', tmp_path)
    person = manager.create('Antes'); directory = manager.data_dir(person['id'])
    (directory / 'history.json').write_text('original')
    assert manager.rename(person['id'], 'Depois')['id'] == person['id']
    assert (directory / 'history.json').read_text() == 'original'
    assert manager.current(person['id'])['nome'] == 'Depois'


@pytest.mark.parametrize('profile_id', ['../escape', '/tmp/test', 'pessoa1', 'pessoa-3'])
def test_caminho_arbitrario_rejeitado(tmp_path, profile_id):
    with pytest.raises(ValueError): ProfileManager(tmp_path, tmp_path).data_dir(profile_id)


def test_cadastro_corrompido_nao_e_sobrescrito(tmp_path):
    (tmp_path / 'perfis.json').write_text('broken')
    with pytest.raises(RuntimeError): ProfileManager(tmp_path, tmp_path).create()
    assert (tmp_path / 'perfis.json').read_text() == 'broken'


def test_processos_usam_dados_tokens_e_portas_distintos_e_reutilizam_painel(tmp_path, monkeypatch):
    manager = ProfileManager(tmp_path / 'dados', tmp_path)
    one, two = manager.create('Um'), manager.create('Dois')
    live = set(); launches = []
    ports = iter([41001, 41002])
    monkeypatch.setenv('EC_PANEL_TOKEN', 'token-do-pai-que-nao-deve-ser-herdado')
    monkeypatch.setenv('EC_IA_PROVEDOR', 'openai')
    monkeypatch.setenv('EC_IA_CHAVE', 'sk-segredo-do-perfil-principal')
    monkeypatch.setenv('EC_IA_MODELO', 'modelo-do-perfil-principal')
    monkeypatch.setattr(manager, '_available_port', lambda preferred=None: next(ports))
    monkeypatch.setattr(manager, '_ready', lambda port, token, profile_id: (port, profile_id) in live)
    def spawn(command, **kwargs):
        env = kwargs['env']; launches.append(kwargs)
        live.add((int(env['EC_PORT']), env['EC_PROFILE_ID']))
        return Mock(poll=Mock(return_value=None))
    monkeypatch.setattr(perfis.subprocess, 'Popen', spawn)
    first, second = manager.open(one['id']), manager.open(two['id'])
    assert manager.open(one['id'])['url'] == first['url'] and len(launches) == 2
    assert first['url'] != second['url']
    assert launches[0]['env']['EC_DATA_DIR'] != launches[1]['env']['EC_DATA_DIR']
    assert all('EC_PANEL_TOKEN' not in item['env'] for item in launches)
    assert all(not any(key.startswith('EC_IA_') for key in item['env']) for item in launches)
    assert (manager.data_dir(one['id']) / 'token_painel.txt').read_text() != (manager.data_dir(two['id']) / 'token_painel.txt').read_text()


def test_falha_de_inicio_nao_remove_perfil(tmp_path, monkeypatch):
    manager = ProfileManager(tmp_path / 'dados', tmp_path); person = manager.create()
    monkeypatch.setattr(manager, '_available_port', lambda preferred=None: 41001)
    monkeypatch.setattr(manager, '_ready', lambda *_: False)
    monkeypatch.setattr(perfis.subprocess, 'Popen', lambda *_, **__: Mock(poll=Mock(return_value=1)))
    with pytest.raises(RuntimeError): manager.open(person['id'])
    assert person in manager.list()
