import asyncio
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch
import pytest
from progresso import ProgressoVerificado
from course_flow import CourseCursor, _advance_course
from modos import ModoEstudo
from auto_fluxo import EngineState
from assistant_preferences import read_preferences, set_warning_preference
from servidor import restore_saved_scope
import session_actions

def test_foco_sem_fala_persiste_e_fala_continua_pendente(tmp_path):
    path=tmp_path/'progress.json';p=ProgressoVerificado(path)
    p.confirmar('8597','101',{'assistir':True,'aprender':True})
    p.confirmar_quiz('8597','unit1:q2')
    p.confirmar_unidades('8597',('assistir','aprender','quizzes'),{'unit1'},{'unit1':'Unidade 1'})
    p=ProgressoVerificado(path)
    assert p.unidades('8597',('assistir','aprender','quizzes'))=={'unit1'}
    assert not p.unidades('8597',('falar',))
    row=p.resumo_unidades('8597')[0]
    assert row['titulo']=='Unidade 1' and row['etapas']['quizzes'] and not row['etapas']['falar']
    cursor=CourseCursor();restore_saved_scope(cursor,p,'8597',ModoEstudo(True,True,False,True))
    assert cursor.verified_units=={'unit1'} and cursor.saved_scope_lessons=={'101'}
    speech=CourseCursor();restore_saved_scope(speech,p,'8597',ModoEstudo(False,False,True,False))
    assert not speech.verified_units and not speech.seen

def test_confirmacoes_nao_expiram_e_focos_separados_se_combinam(tmp_path):
    p=ProgressoVerificado(tmp_path/'progress.json')
    with patch('progresso.time.time',return_value=100):p.confirmar_unidades('8597',('assistir',),{'1'})
    p.confirmar_unidades('8597',('aprender','quizzes'),{'1'})
    assert p.unidades('8597',('quizzes','assistir','aprender'))=={'1'}
    assert not p.unidades('9999',('assistir',))

def test_invalidar_uma_unidade_e_etapa_preserva_as_outras(tmp_path):
    p=ProgressoVerificado(tmp_path/'progress.json')
    p.confirmar('8597','101',{'assistir':True,'aprender':True,'falar':True})
    p.confirmar_unidades('8597',('assistir','aprender','falar'),{'1','2'})
    p.invalidar('8597','101',('falar',),'1')
    assert p.unidades('8597',('assistir','aprender'))=={'1','2'}
    assert p.unidades('8597',('falar',))=={'2'}

def test_unidade_salva_no_foco_nao_reabre_por_pendencia_agregada():
    async def run():
        cursor=CourseCursor(seen={'101'},saved_scope_lessons={'101'},seen_quizzes={'u1:q1'},
                            verified_units={'u1'},visited_units={'u1'})
        info={'supported':True,'course_id':'8597','player':False,'units':[{'id':'u1','index':0,'title':'Unidade 1',
          'visible':True,'active':False,'ready':True,'cards':[{'video':True,'lesson_id':'101','pending':True},
          {'quiz':True,'quiz_key':'u1:q1','completed':True}]}]}
        result=await _advance_course(object(),cursor,include_quizzes=True,snapshot=info)
        assert result['tipo']=='escopo_concluido' and 'u1' in cursor.verified_units
    asyncio.run(run())

def test_pular_nao_confirma_atividade_nem_unidade():
    async def run():
        engine=EngineState();page=object()
        with patch('session_actions.inspect_course',AsyncMock(return_value={'supported':True,'course_id':'8597'})), \
             patch('session_actions.inspect_ec_player',AsyncMock(return_value={'lesson_id':'dialog:101'})):
            assert await session_actions.skip_issue(page,engine,{'tipo':'aula','id':'101','curso':'8597'})
        assert engine.real.cursor.skipped_lessons=={'101'}
        assert not engine.real.cursor.seen and not engine.real.cursor.verified_units
        assert engine.skip_return_url=='https://pt.englishcentral.com/course/8597'
    asyncio.run(run())

def test_tela_mudou_nao_pula_atividade_errada():
    async def run():
        engine=EngineState()
        with patch('session_actions.inspect_course',AsyncMock(return_value={'supported':True,'course_id':'8597'})), \
             patch('session_actions.inspect_ec_player',AsyncMock(return_value={'lesson_id':'dialog:999'})):
            assert not await session_actions.skip_issue(object(),engine,{'tipo':'aula','id':'101','curso':'8597'})
        assert not engine.real.cursor.skipped_lessons
    asyncio.run(run())

def test_quiz_tem_prioridade_sobre_video_de_fundo():
    async def run():
        engine=EngineState();engine.real.cursor.pending='quiz:u1:q2'
        with patch('session_actions.inspect_quiz',AsyncMock(return_value={'ativa':True,'pergunta':'Question'})), \
             patch('session_actions.inspect_ec_player',AsyncMock()) as player:
            result=await session_actions.issue_context(object(),engine,'8597',{'tipo':'ajuda'})
        assert result['tipo']=='quiz' and result['pode_pular'];player.assert_not_awaited()
    asyncio.run(run())

def test_pular_unidade_nao_a_marca_completa():
    async def run():
        cursor=CourseCursor(skipped_units={'1'})
        info={'supported':True,'course_id':'8597','player':False,'units':[{'id':'1','visible':True,'active':False,'cards':[]}]}
        result=await _advance_course(object(),cursor,snapshot=info)
        assert result['tipo']=='escopo_pulado' and not cursor.verified_units
    asyncio.run(run())

def test_preferencia_de_aviso_persiste_sem_escolher_acao(tmp_path):
    path=tmp_path/'prefs.json'
    set_warning_preference(path,'quiz',False)
    assert read_preferences(path)=={'quiz':False}
    set_warning_preference(path,'fala',True)
    assert read_preferences(path)=={'quiz':False,'fala':True}

def test_ocorrencias_sao_salvas_separadas_de_conclusao(tmp_path):
    path=tmp_path/'progress.json';p=ProgressoVerificado(path)
    p.registrar_evento('8597','pular','Aula 101','Erro no quiz')
    p=ProgressoVerificado(path)
    assert p.historico('8597')[0]['acao']=='pular'
    assert not p.unidades('8597',('quizzes',)) and not p.concluidas('8597',('assistir',))
