"""PWA e acesso remoto na mesma origem, sem mudar o motor de atividades."""
from __future__ import annotations

import asyncio
import hmac
import os
import re
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlsplit

import httpx
from fastapi import HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse, Response

PROFILE_ID = re.compile(r'principal|pessoa(?:[2-9]|[1-9]\d+)')
ASSETS = {
    'manifest.webmanifest': 'application/manifest+json',
    'sw.js': 'text/javascript',
    'pwa.js': 'text/javascript',
    'mobile.css': 'text/css',
    'offline.html': 'text/html',
    'icons/icon-192.png': 'image/png',
    'icons/icon-512.png': 'image/png',
    'icons/maskable-512.png': 'image/png',
    'icons/apple-touch-icon.png': 'image/png',
    'icons/icon.svg': 'image/svg+xml',
}


@dataclass(frozen=True)
class RemoteConfig:
    enabled: bool = False
    origin: str = ''

    @classmethod
    def from_env(cls):
        if os.getenv('EC_REMOTE_MODE', '0') != '1':
            return cls()
        raw = os.getenv('EC_PUBLIC_URL', '').strip().rstrip('/')
        parsed = urlsplit(raw)
        if (parsed.scheme != 'https' or not parsed.hostname or parsed.username or
                parsed.password or parsed.path or parsed.query or parsed.fragment or
                not re.fullmatch(r'[A-Za-z0-9.-]+(?::\d{1,5})?', parsed.netloc)):
            raise RuntimeError('No modo remoto, configure EC_PUBLIC_URL com a origem HTTPS do painel, sem caminho ou credenciais.')
        try:
            port = parsed.port
        except ValueError as exc:
            raise RuntimeError('A porta da origem HTTPS é inválida.') from exc
        return cls(True, 'https://' + parsed.hostname.lower() + (f':{port}' if port and port != 443 else ''))

    def describe(self):
        return {'remoto': self.enabled, 'execucao': 'servidor' if self.enabled else 'computador',
                'continua_sem_painel': True, 'versao': '18.13.1'}


class PanelBoundary:
    """Protege a publicação e evita que respostas privadas entrem em caches."""
    def __init__(self, app, config: RemoteConfig):
        self.app, self.config = app, config

    async def __call__(self, scope, receive, send):
        if scope['type'] != 'http':
            return await self.app(scope, receive, send)
        request = Request(scope)
        host = request.url.hostname or ''
        # Apenas chamadas internas de fato, não um Host forjado vindo da rede.
        local = (host in {'localhost', '127.0.0.1', '::1'} and
                 request.client is not None and request.client.host in {'127.0.0.1', '::1'})
        origin = request.headers.get('origin')
        expected = self.config.origin if self.config.enabled and not local else str(request.base_url).rstrip('/')
        error = None
        if self.config.enabled and not local:
            if host != urlsplit(self.config.origin).hostname:
                error = (400, 'Endereço do painel inválido.')
            elif request.url.scheme != 'https':
                error = (426, 'Abra este painel pelo endereço HTTPS configurado.')
        if (not error and request.method not in {'GET', 'HEAD', 'OPTIONS'} and
                origin and origin != expected and origin != 'null'):
            error = (403, 'Esta ação precisa partir do próprio painel.')
        elif not error and origin == 'null' and request.method not in {'GET', 'HEAD', 'OPTIONS'}:
            error = (403, 'Abra o painel diretamente para realizar esta ação.')

        async def headers(message):
            if message['type'] == 'http.response.start':
                values = list(message.get('headers', []))
                names = {name.lower() for name, _ in values}
                private = '/api/' in scope['path']
                if private:
                    values = [(k, v) for k, v in values if k.lower() != b'cache-control']
                    values.append((b'cache-control', b'no-store'))
                for name, value in [(b'x-content-type-options', b'nosniff'),
                                    (b'referrer-policy', b'no-referrer')]:
                    if name not in names:
                        values.append((name, value))
                message = {**message, 'headers': values}
            await send(message)

        if error:
            return await JSONResponse({'detail': error[1]}, status_code=error[0])(scope, receive, headers)
        return await self.app(scope, receive, headers)


def asset_response(root: Path, asset: str):
    if asset not in ASSETS:
        raise HTTPException(404, 'Arquivo não encontrado.')
    headers = {'Cache-Control': 'no-cache'}
    if asset == 'sw.js':
        headers['Service-Worker-Allowed'] = '/'
    return FileResponse(root / 'web' / asset, media_type=ASSETS[asset], headers=headers)


def install_mobile_routes(app, root: Path, manager_factory, config: RemoteConfig):
    app.add_middleware(PanelBoundary, config=config)

    for name in ASSETS:
        # A fábrica mantém um único argumento de rota, sem parâmetros públicos extras.
        def endpoint(asset):
            async def serve():
                return asset_response(root, asset)
            return serve
        app.add_api_route('/' + name, endpoint(name), methods=['GET', 'HEAD'], include_in_schema=False)

    @app.api_route('/p/{profile_id}/{path:path}', methods=['GET', 'HEAD', 'POST', 'PUT', 'PATCH', 'DELETE'])
    async def profile_panel(profile_id: str, path: str, request: Request):
        if not config.enabled or not PROFILE_ID.fullmatch(profile_id):
            raise HTTPException(404, 'Painel não encontrado.')
        manager = manager_factory()
        people = await asyncio.to_thread(manager.list)
        if profile_id not in {p['id'] for p in people}:
            raise HTTPException(404, 'Pessoa não encontrada.')
        if request.method in {'GET', 'HEAD'} and path == '':
            return FileResponse(root / 'web' / 'index.html', media_type='text/html', headers={'Cache-Control': 'no-store'})
        # Somente a API conhecida; nunca um proxy de destino ou arquivo arbitrário.
        if not path.startswith('api/') or '..' in path or '\\' in path or '?' in path or '#' in path:
            raise HTTPException(404, 'Endereço não encontrado.')
        token_file = manager.data_dir(profile_id) / 'token_painel.txt'
        try:
            expected = token_file.read_text('utf-8').strip()
        except OSError:
            expected = ''
        token = request.headers.get('x-ec-token', '')
        if not expected or not token or not hmac.compare_digest(token, expected):
            raise HTTPException(401, 'Token inválido para esta pessoa.')
        # Autenticar antes de criar/reabrir qualquer processo. A porta vem apenas
        # do cadastro local; nenhum endereço recebido do cliente chega ao httpx.
        try:
            info = await asyncio.to_thread(manager.open, profile_id)
            parsed = urlsplit(info['url'])
            if parsed.hostname != '127.0.0.1' or not parsed.port:
                raise ValueError('Endereço interno inválido')
            body = bytearray()
            async for chunk in request.stream():
                body.extend(chunk)
                if len(body) > 65536:
                    raise HTTPException(413, 'Solicitação muito grande.')
            headers = {'X-EC-Token': token}
            if request.headers.get('content-type'):
                headers['Content-Type'] = request.headers['content-type']
            async with httpx.AsyncClient(timeout=55, trust_env=False, follow_redirects=False) as client:
                response = await client.request(request.method, f'http://127.0.0.1:{parsed.port}/' + path,
                                                params=request.query_params, headers=headers, content=bytes(body))
            return Response(response.content, status_code=response.status_code,
                            media_type=response.headers.get('content-type'), headers={'Cache-Control': 'no-store'})
        except HTTPException:
            raise
        except (OSError, ValueError, RuntimeError, httpx.HTTPError) as exc:
            raise HTTPException(502, 'O painel desta pessoa está indisponível. Tente novamente; o histórico permanece salvo.') from exc
