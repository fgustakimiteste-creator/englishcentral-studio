"""Restrições visíveis das caixas; não decide o significado da resposta."""
import re


def fits_quiz(answer, field):
    if not isinstance(answer,str) or not re.fullmatch(r"[A-Za-z]+(?:[' -][A-Za-z]+){0,5}",answer.strip()):
        return False
    letters=re.sub(r'[^a-z]','',answer.casefold())
    if field.get('group'):
        pattern=field.get('pattern','').casefold()
        if field.get('limit') and len(letters)!=field['limit']:
            return False
        if pattern and (len(pattern)!=len(letters) or any(p!='_' and p!=a for p,a in zip(pattern,letters))):
            return False
    elif field.get('limit') and len(letters)>field['limit']:
        return False
    return True
