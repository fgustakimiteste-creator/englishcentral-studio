# Relatório de testes — EnglishCentral Studio V18.13.1

## Resumo verificável

**115 testes aprovados nas baterias focadas executadas a partir da extração limpa do ZIP**: 110 testes de SEDUCTEC/IA/perfis/navegação/regressões + 5 testes isolados do motor EnglishCentral. Além disso, passaram as verificações de compilação Python, sintaxe do inicializador Termux e sintaxe do JavaScript embutido em `web/index.html`.

Esse número não representa a suíte inteira. A suíte global não foi concluída neste ambiente.

## Baterias executadas

As cinco execuções abaixo foram feitas em `/mnt/data/ec131_finalcheck`, pasta recém-extraída da distribuição final, com `EC_BROWSER_EXECUTABLE=/usr/bin/chromium`. A separação em grupos menores evita que um único teste lento esconda resultados de outros grupos.

| Bateria | Resultado |
|---|---:|
| `test_moodle_automation_multiagent_18_13.py` + `test_auto_ia_moodle.py` | 31 passed |
| `test_moodle_execute_18_13.py`, `test_moodle_retry_and_config_18_12.py`, `test_seductec.py`, `test_profiles_18_7.py`, `test_profiles_native_18_7.py`, `test_runtime_queue_18_12_3.py`, `test_live_view.py`, `test_panel_events.py`, `test_moodle_ai.py` | 64 passed |
| `test_audit_fixes_18_12_2.py` | 14 passed |
| `test_course_selection.py` | 1 passed |
| `test_ec_engine.py` (execução isolada) | 5 passed |
| **Total das baterias focadas** | **115 passed** |

## Cobertura específica acrescentada

- A fase de leitura de materiais precede quiz/fórum na mesma seção.
- O contexto temporário extraído é passado para a fase seguinte sem vazar em snapshots/estados persistidos.
- A próxima seção aguarda a conclusão da seção anterior.
- Estados desconhecidos nunca são contados como sucesso.
- Sugestões têm avaliação heurística explícita; o teste confirma que ela não se apresenta como prova de correção.
- AutoTune escolhe temperatura conforme a categoria da pergunta e busca trecho de material relevante.
- PDF respeita teto de páginas/caracteres; `paginas_lidas` reflete a quantidade realmente examinada quando o teto de caracteres é atingido.
- Compatibilidade de seleção de curso, perfis, navegação, preview e eventos regressivos.

## Verificações estáticas

| Comando/validação | Resultado |
|---|---|
| `python -m compileall` | Aprovado |
| `bash -n TERMUX_INICIAR.sh` | Aprovado |
| Extração do JavaScript inline e `node --check` | Aprovado |
| Integridade ZIP (`ZipFile.testzip`) | Aprovada no pacote final e após extração limpa |

## Testes que não puderam ser contabilizados

- Testes de browser que dependem de navegar ao portal público EnglishCentral/Seductec falham antes de executar o cenário por bloqueio do navegador/rede (`net::ERR_BLOCKED_BY_ADMINISTRATOR`).
- Alguns testes históricos adicionais excederam o limite de execução quando rodados em lote; por isso, não são considerados aprovados.
- Não houve sessão autenticada do usuário no SEDUCTEC disponível para testar a sequência real completa em produção.
- A suíte completa não foi finalizada. Não declarar que todos os testes do repositório passaram.

## Critério de interpretação

Um teste local de DOM/Playwright comprova somente o comportamento exercitado na página de teste. Não comprova compatibilidade com todo curso real nem que respostas geradas por IA estejam factualmente corretas. “Preenchido” não significa “enviado”; “rascunho preparado” não significa “publicado”; “PDF extraído” não significa “atividade concluída”.
