import asyncio
from types import SimpleNamespace
from unittest.mock import AsyncMock,patch

import auto_ia
from auto_fluxo import EngineState,process_page,_handle_video_quiz
from test_ec_player import run_with_page


def test_red_review_button_nested_text_and_optional_article():
    async def scenario(page):
        await page.set_content('''<div class="red-start" onclick="window.started=(window.started||0)+1"><span>Comece&nbsp;o<br>Quiz</span></div>
            <div>6 palavras disponíveis para Quiz</div><div>Only If<br>Adverb: sómente<br>Aulas perdidas</div>''')
        state=EngineState()
        with patch('auto_fluxo.is_englishcentral',return_value=True):
            result=await process_page(page,engine=state,submit=True)
            assert result['tipo']=='navegacao'
            await process_page(page,engine=state,submit=True)
        assert await page.evaluate('window.started')==1
    run_with_page(scenario)


def test_start_test_recovers_identity_when_quiz_was_opened_manually():
    async def scenario(page):
        await page.set_content('<div class="button" onclick="window.started=true">Iniciar o teste</div>')
        state=EngineState()
        course={'course_id':'6128','units':[{'id':'44245','active':True,'cards':[{'quiz':True,'quiz_key':'44245:q15'}]}]}
        with patch('auto_fluxo.is_englishcentral',return_value=True),patch('course_flow.inspect_course',AsyncMock(return_value=course)):
            result=await process_page(page,engine=state,submit=True)
        assert result['tipo']=='navegacao'
        assert state.real.cursor.pending=='quiz:44245:q15'
        assert await page.evaluate('window.started') is True
    run_with_page(scenario)


def test_repeated_bad_suggestion_does_not_lock_quiz_in_cache(monkeypatch):
    auto_ia._INFERENCE_CACHE.clear()
    monkeypatch.setattr(auto_ia,'settings',lambda:{'EC_IA_PROVEDOR':'ollama','EC_IA_MODELO':'local-test'})
    quiz={'ativa':True,'tipo':'lacuna','frase':'Adverb:sómente She says, "___ you are having some yourself."',
          'banco_letras':['i','y','f','l','n'], 'campos':[{'id':'g1','group':True,'limit':6,'pattern':'o_____','score':15}]}
    runner=AsyncMock(side_effect=[['only'],['only'],['only if']])
    typer=AsyncMock(return_value={})
    async def scenario():
        state=EngineState(inference=runner)
        for _ in range(2):
            result=await _handle_video_quiz(SimpleNamespace(),quiz,{},state,submit=True)
            assert result['tipo']=='incerto'
        result=await _handle_video_quiz(SimpleNamespace(),quiz,{},state,submit=True)
        assert result['tipo']=='lacuna_video'
    with patch('auto_fluxo.inspect_quiz',AsyncMock(return_value=quiz)),patch('auto_fluxo.ia_status',return_value={'configurada':True}),patch('auto_fluxo.known_answer',return_value=None),patch('auto_fluxo.review_answer',return_value=None),patch('auto_fluxo.read_memory',return_value={'palavras':[]}),patch('auto_fluxo.type_quiz_answer',typer):
        asyncio.run(scenario())
    assert runner.await_count==3
    assert runner.await_args.args[1][0]['rejeitadas']==['only']
    assert runner.await_args.args[1][0]['letras_disponiveis']=='iyfln'
    assert typer.await_count==1 and typer.await_args.args[2]=='only if'
    auto_ia._INFERENCE_CACHE.clear()


def test_quiz_reads_word_list_before_start_and_does_not_loop(tmp_path,monkeypatch):
    import memoria
    from revisao_quiz import review_answer
    monkeypatch.setattr(memoria,'MEMORY_PATH',tmp_path/'memory.json')
    async def scenario(page):
        await page.set_content('<div id="wordTab"><span>Ver palavras</span></div><div id="start">Iniciar o teste</div>')
        await page.evaluate('''() => {
          window.actions=[];
          document.querySelector('#wordTab').onclick=()=>{
            actions.push('words');
            document.body.innerHTML='<button id="reviewStart">Comece o Quiz</button><p>1 palavra disponível para o Quiz</p><div>Only If<br>Adverb: sómente<br>Correto!</div>';
            document.querySelector('#reviewStart').onclick=()=>{
              actions.push('review');
              document.body.innerHTML='<span>Ver palavras</span><button id="start">Iniciar o teste</button>';
              document.querySelector('#start').onclick=()=>{actions.push('test');document.body.innerHTML='Pergunta aberta';};
            };
          };
        }''')
        state=EngineState()
        state.real.cursor.pending='quiz:1:q4'
        with patch('auto_fluxo.is_englishcentral',return_value=True):
            result=await process_page(page,engine=state,submit=True)
            assert result['tipo']=='navegacao'
            await process_page(page,engine=state,submit=True)
            state.review_started_at=0
            await process_page(page,engine=state,submit=True)
        assert await page.evaluate('window.actions')==['words','review','test']
        assert review_answer('Adverb:sómente She says ...',{'group':True,'limit':6,'pattern':'o_____'})=='only if'
    run_with_page(scenario)


def test_perfect_result_without_word_suffix_returns_to_course():
    page=SimpleNamespace(url='https://pt.englishcentral.com/course/6128',goto=AsyncMock())
    state=EngineState()
    quiz={'quiz_concluido':True,'texto':'Prática completa VOCÊ CONSEGUIU UMA NOTA PERFEITA! Você acertou 8 de 8 Voltar ao curso'}
    course={'course_id':'6128','units':[{'id':'44245','active':True,'cards':[{'quiz':True,'quiz_key':'44245:q15'}]}]}
    with patch('auto_fluxo._page_gate',AsyncMock(return_value={})),patch('auto_fluxo.inspect_ec_player',AsyncMock(return_value={})),patch('auto_fluxo.inspect_quiz',AsyncMock(return_value=quiz)),patch('course_flow.inspect_course',AsyncMock(return_value=course)):
        result=asyncio.run(process_page(page,engine=state,submit=True))
    assert result['quiz_concluido']=='44245:q15'
    page.goto.assert_awaited_once_with('https://pt.englishcentral.com/course/6128',wait_until='domcontentloaded',timeout=35000)
