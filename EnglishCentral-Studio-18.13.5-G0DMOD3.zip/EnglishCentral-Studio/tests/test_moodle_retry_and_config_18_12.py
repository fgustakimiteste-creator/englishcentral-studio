import asyncio
import os
from unittest.mock import AsyncMock, MagicMock

from fastapi.testclient import TestClient

import auto_ia
import servidor
from moodle_adapter import MOODLE_OVERVIEW_JS, retry_moodle_quiz


def test_retry_aceita_rotulo_portugues_do_moodle():
    async def run():
        page = MagicMock()
        page.url = 'https://seductec.seduc.pi.gov.br/mod/quiz/view.php?id=45'
        button = MagicMock()
        button.is_visible = AsyncMock(return_value=True)
        button.is_enabled = AsyncMock(return_value=True)
        button.evaluate = AsyncMock(side_effect=['BUTTON', 'Tentar responder ao questionário agora'])
        button.get_attribute = AsyncMock(return_value=None)

        async def click(timeout):
            page.url = 'https://seductec.seduc.pi.gov.br/mod/quiz/attempt.php?attempt=17'
        button.click = AsyncMock(side_effect=click)
        buttons = MagicMock()
        buttons.count = AsyncMock(return_value=1)
        buttons.nth.return_value = button
        page.locator.return_value = buttons
        page.wait_for_load_state = AsyncMock()
        result = await retry_moodle_quiz(page)
        assert result['ok'] is True
        assert '/mod/quiz/attempt.php' in result['url']
        button.click.assert_awaited_once()

    asyncio.run(run())


def test_js_de_inspecao_reconhece_botao_portugues_de_nova_tentativa():
    assert 'tentar (?:responder|iniciar).*question[aá]rio' in MOODLE_OVERVIEW_JS


def test_api_openai_responses_request_has_store_disabled_and_auth(monkeypatch):
    calls = []

    def fake_post(url, payload, headers, timeout=12):
        calls.append((url, payload, headers, timeout))
        return {'status': 'completed', 'output': [
            {'type': 'message', 'content': [{'type': 'output_text', 'text': '{"resposta":"ok"}'}]}
        ]}

    monkeypatch.setattr(auto_ia, '_post_json', fake_post)
    result = auto_ia._request_text('conteúdo de teste', {
        'EC_IA_PROVEDOR': 'openai', 'EC_IA_MODELO': 'gpt-5.4-mini', 'EC_IA_CHAVE': 'sk-' + 'x' * 32,
    }, schema={'type': 'object'})
    assert result == '{"resposta":"ok"}'
    url, payload, headers, _ = calls[0]
    assert url == 'https://api.openai.com/v1/responses'
    assert payload['store'] is False
    assert payload['model'] == 'gpt-5.4-mini'
    assert headers['Authorization'].startswith('Bearer sk-')


def test_configuracoes_seductec_persistem_no_perfil(monkeypatch, tmp_path):
    monkeypatch.setenv('EC_PANEL_TOKEN', 'token-config-test-123456789')
    settings_file = tmp_path / 'preferencias_seductec.json'
    monkeypatch.setattr(servidor, 'MOODLE_SETTINGS_FILE', settings_file)
    headers = {'X-EC-Token': 'token-config-test-123456789'}
    with TestClient(servidor.app) as client:
        saved = client.put('/api/moodle/settings', headers=headers, json={
            'modo': 'quiz', 'preencher_quiz': True, 'preencher_forum': False,
            'tentar_novamente': True, 'max_tentativas': 3,
        })
        assert saved.status_code == 200
        read = client.get('/api/moodle/settings', headers=headers)
        assert read.status_code == 200
        assert read.json()['configuracao']['modo'] == 'quiz'
        assert read.json()['configuracao']['max_tentativas'] == 3
    assert settings_file.exists()


def test_quiz_resumo_nao_e_confundido_com_resposta_preenchida(monkeypatch):
    async def run():
        page = MagicMock()
        page.url = 'https://seductec.seduc.pi.gov.br/mod/quiz/summary.php?attempt=12'
        monkeypatch.setattr(servidor, 'current_page', lambda: page)
        monkeypatch.setattr(servidor, 'inspect_moodle_page', AsyncMock(return_value={
            'ativo': True, 'url': page.url, 'tipo_pagina': 'quiz_resumo',
            'questoes': [], 'conclusao': {'estado': 'em_andamento', 'evidencias': []},
            'pdfs': [], 'forum': {}, 'atividades': [], 'tentarNovamente': [],
        }))
        monkeypatch.setattr(servidor, 'lock', asyncio.Lock())
        result = await servidor.moodle_status()
        assert result['estado'] == 'em_andamento'
    asyncio.run(run())


def test_probe_openai_confirma_acesso_ao_modelo_sem_gerar_resposta(monkeypatch, tmp_path):
    class FakeResponse:
        def __enter__(self):
            return self
        def __exit__(self, *args):
            return False
        def read(self, amount):
            return b'{"id":"gpt-5.4-mini"}'

    calls = []
    def fake_urlopen(request, timeout=0):
        calls.append((request.full_url, request.headers, timeout))
        return FakeResponse()

    monkeypatch.setattr(auto_ia, 'CONFIG', tmp_path / 'config_ia.local.txt')
    auto_ia.CONFIG.write_text('EC_IA_PROVEDOR=openai\nEC_IA_MODELO=gpt-5.4-mini\nEC_IA_CHAVE=sk-test-key\n')
    monkeypatch.setattr(auto_ia, 'urlopen', fake_urlopen)
    result = auto_ia.probe_provider()
    assert result['pronto'] is True and result['conectado'] is True
    assert calls[0][0] == 'https://api.openai.com/v1/models/gpt-5.4-mini'
    assert calls[0][2] == 8
    assert 'Bearer sk-test-key' in str(calls[0][1])


def test_probe_ollama_nao_marca_como_pronto_quando_modelo_nao_esta_instalado(monkeypatch, tmp_path):
    class FakeResponse:
        def __enter__(self):
            return self
        def __exit__(self, *args):
            return False
        def read(self, amount):
            return b'{"models":[{"name":"llama3.2:latest"}]}'

    monkeypatch.setattr(auto_ia, 'CONFIG', tmp_path / 'config_ia.local.txt')
    auto_ia.CONFIG.write_text('EC_IA_PROVEDOR=ollama\nEC_IA_MODELO=qwen2.5:3b\nEC_IA_URL=http://127.0.0.1:11434\n')
    monkeypatch.setattr(auto_ia, 'urlopen', lambda request, timeout=0: FakeResponse())
    result = auto_ia.probe_provider()
    assert result['pronto'] is False and result['conectado'] is True
    assert 'não está instalado' in result['mensagem']
