const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const { JSDOM, VirtualConsole } = require(process.env.EC_JSDOM || 'jsdom');
const html = fs.readFileSync(path.join(__dirname, '../web/index.html'), 'utf8');
const wait = () => new Promise(resolve => setTimeout(resolve, 30));

async function boot() {
  let nextId = 1;
  const timeouts = new Map(), intervals = new Map(), plans = new Map(), calls = [], errors = [];
  const state = { aberto: true, executando: false, eventos: [], modo: { assistir: true, aprender: false, falar: false, quiz: false }, auto: { tipo: 'parado' } };
  const vc = new VirtualConsole();
  vc.on('jsdomError', error => errors.push(error.message));
  const dom = new JSDOM(html, { url: 'http://localhost/#token=fixture-only', runScripts: 'dangerously', pretendToBeVisual: true, virtualConsole: vc, beforeParse(w) {
    w.scrollTo = () => {};
    w.URL.createObjectURL = () => 'blob:local-test-' + nextId++;
    w.URL.revokeObjectURL = () => {};
    const nativeSet = w.setTimeout.bind(w), nativeClear = w.clearTimeout.bind(w);
    w.setTimeout = (fn, delay, ...args) => {
      if (![6000, 14000, 45000].includes(delay)) return nativeSet(fn, delay, ...args);
      const id = 'audit-' + nextId++; timeouts.set(id, { fn, delay }); return id;
    };
    w.clearTimeout = id => { if (!timeouts.delete(id)) nativeClear(id); };
    w.setInterval = (fn, delay) => { const id = nextId++; intervals.set(id, { fn, delay }); return id; };
    w.clearInterval = id => intervals.delete(id);
    const blocked = signal => new Promise((_, reject) => {
      const abort = () => reject(new w.DOMException('Request aborted', 'AbortError'));
      if (signal.aborted) abort(); else signal.addEventListener('abort', abort, { once: true });
    });
    w.fetch = async (url, options = {}) => {
      calls.push({ url, token: options.headers?.['X-EC-Token'] });
      const plan = plans.get(url);
      if (plan === 'headers') return blocked(options.signal);
      const value = url === '/api/status' ? structuredClone(state) : url === '/api/history'
        ? { curso: '8597', unidades: [], eventos: [], avisos: ['Registros inválidos foram recuperados com cópia do original.'] } : {};
      return { ok: true, json: () => plan === 'json' ? blocked(options.signal) : Promise.resolve(value),
        blob: () => plan === 'blob' ? blocked(options.signal) : Promise.resolve(new w.Blob(['image-test'])) };
    };
  } });
  await wait(); assert.deepEqual(errors, []);
  const tick = async delay => { for (const timer of [...intervals.values()]) if (timer.delay === delay) timer.fn(); await wait(); };
  const expire = async delay => {
    const timers = [...timeouts.values()].filter(timer => timer.delay === delay);
    assert(timers.length > 0, 'A requisição deve ter um prazo ativo de ' + delay + ' ms');
    for (const timer of timers) timer.fn(); await wait();
  };
  return { dom, w: dom.window, d: dom.window.document, plans, calls, errors, timeouts, tick, expire };
}

let passed = 0;
async function test(name, fn) { await fn(); passed++; console.log('PASS', name); }
(async () => {
  for (const stage of ['headers', 'json']) await test('Status recupera após bloqueio em ' + stage, async () => {
    const t = await boot();
    t.plans.set('/api/status', stage); await t.tick(1500); await t.expire(6000);
    assert(!t.d.getElementById('reconnectPanel').classList.contains('hide'));
    t.plans.delete('/api/status'); await t.tick(1500);
    assert(t.d.getElementById('reconnectPanel').classList.contains('hide'));
    assert(t.calls.filter(call => call.url === '/api/status').every(call => call.token === 'fixture-only'));
    assert(!t.calls.some(call => call.url === '/api/auto/stop')); assert.equal(t.timeouts.size, 0);
    t.dom.window.close();
  });
  for (const stage of ['headers', 'blob']) await test('Prévia volta a capturar após bloqueio em ' + stage, async () => {
    const t = await boot();
    t.plans.set('/api/screenshot', stage); await t.tick(1000);
    assert.equal(t.calls.filter(call => call.url === '/api/screenshot').length, 1);
    await t.tick(1000); assert.equal(t.calls.filter(call => call.url === '/api/screenshot').length, 1);
    await t.expire(14000);
    assert.match(t.d.getElementById('screenStatus').textContent, /próxima tentativa é automática/);
    t.plans.delete('/api/screenshot'); await t.tick(1000);
    const img = t.d.getElementById('screen'); img.dispatchEvent(new t.w.Event('load'));
    assert.equal(t.calls.filter(call => call.url === '/api/screenshot').length, 2);
    assert(!img.classList.contains('hide')); assert.match(t.d.getElementById('screenStatus').textContent, /Sessão real/);
    assert.equal(t.timeouts.size, 0); t.dom.window.close();
  });
  await test('Ação expirada libera os controles para nova tentativa', async () => {
    const t = await boot(); t.plans.set('/api/focus', 'headers');
    t.d.getElementById('open').click(); await wait(); assert(t.d.getElementById('open').disabled);
    await t.expire(45000);
    assert(!t.d.getElementById('open').disabled); assert.match(t.d.getElementById('activityMsg').textContent, /demorou a responder/);
    t.plans.delete('/api/focus'); t.d.getElementById('open').click(); await wait();
    assert.equal(t.calls.filter(call => call.url === '/api/focus').length, 2);
    assert(!t.d.getElementById('open').disabled); assert.equal(t.timeouts.size, 0); t.dom.window.close();
  });
  await test('Histórico apresenta aviso de recuperação sem ocultar a tabela', async () => {
    const t = await boot(); t.d.querySelector('[data-view="progress"]').click(); await wait();
    assert.match(t.d.getElementById('savedHistoryMessage').textContent, /Registros inválidos foram recuperados/);
    assert(t.d.getElementById('savedHistoryBody')); assert.deepEqual(t.errors, []); t.dom.window.close();
  });
  console.log(`${passed} cenários de recuperação aprovados (DOM/API simulados).`);
})().catch(error => { console.error(error); process.exitCode = 1; });
