"""Contratos de publicação, isolamento e cache; sem login em contas reais."""
import asyncio
import json
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock
import wave

import httpx
import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

import mobile_app
from mobile_app import RemoteConfig, install_mobile_routes
import fala_sintetica
import servidor
import auto_ia
from perfis import ProfileManager

ROOT = Path(servidor.__file__).parent


@pytest.mark.parametrize('value', ['', 'http://estudos.example.com', 'https://u:p@example.com',
                                  'https://example.com/path', 'https://example.com?q=1',
                                  'https://example.com/#token=private', 'https://*.example.com'])
def test_remoto_exige_origem_https_valida(value, monkeypatch):
    monkeypatch.setenv('EC_REMOTE_MODE', '1')
    monkeypatch.setenv('EC_PUBLIC_URL', value)
    with pytest.raises(RuntimeError):
        RemoteConfig.from_env()


def test_config_local_nao_exige_dominio(monkeypatch):
    monkeypatch.delenv('EC_REMOTE_MODE', raising=False)
    assert RemoteConfig.from_env() == RemoteConfig()


def make_app(tmp_path, *, remote=True):
    app = FastAPI()
    manager = ProfileManager(tmp_path / 'data', ROOT)
    config = RemoteConfig(remote, 'https://estudos.example.com' if remote else '')

    @app.post('/api/action')
    async def action():
        return {'ok': True}

    install_mobile_routes(app, ROOT, lambda: manager, config)
    return app, manager


def test_arquivos_publicos_tem_mime_e_nao_expoem_codigo(tmp_path):
    app, _ = make_app(tmp_path, remote=False)
    with TestClient(app) as client:
        for path, mime in mobile_app.ASSETS.items():
            response = client.get('/' + path)
            assert response.status_code == 200, path
            assert response.headers['content-type'].startswith(mime)
        manifest = client.get('/manifest.webmanifest').json()
        assert manifest['display'] == 'standalone' and manifest['start_url'] == '/'
        assert client.get('/sw.js').headers['service-worker-allowed'] == '/'
        assert client.get('/servidor.py').status_code == 404
        assert client.get('/.dados_locais/token_painel.txt').status_code == 404
        assert client.get('/web/../servidor.py').status_code == 404


def test_origem_https_e_host_sao_conferidos_no_remoto(tmp_path):
    app, _ = make_app(tmp_path)
    with TestClient(app, base_url='https://estudos.example.com') as client:
        assert client.post('/api/action', headers={'Origin': 'https://estudos.example.com'}).status_code == 200
        assert client.post('/api/action', headers={'Origin': 'https://outro.example.com'}).status_code == 403
        assert client.post('/api/action', headers={'Origin': 'null'}).status_code == 403
        assert client.get('/manifest.webmanifest', headers={'Host': 'outro.example.com'}).status_code == 400
        assert client.get('http://estudos.example.com/manifest.webmanifest').status_code == 426
        response = client.post('/api/action')
        assert response.headers['cache-control'] == 'no-store'
        assert response.headers['referrer-policy'] == 'no-referrer'


def test_pessoa_sem_token_nao_abre_processo(tmp_path, monkeypatch):
    app, manager = make_app(tmp_path)
    person = manager.create('Teste')
    spawn = Mock(side_effect=AssertionError('não deve iniciar processo'))
    monkeypatch.setattr(manager, 'open', spawn)
    with TestClient(app, base_url='https://estudos.example.com') as client:
        assert client.get(f'/p/{person["id"]}/').status_code == 200
        assert client.get(f'/p/{person["id"]}/api/status').status_code == 401
        assert client.get('/p/pessoa999/api/status').status_code == 404
        assert client.get(f'/p/{person["id"]}/servidor.py').status_code == 404
    spawn.assert_not_called()


def test_gateway_conserva_token_rota_e_resposta_sem_redirecionar(tmp_path, monkeypatch):
    app, manager = make_app(tmp_path)
    person = manager.create('Pessoa isolada')
    token = 'fixture-profile-token-1811'
    (manager.data_dir(person['id']) / 'token_painel.txt').write_text(token)
    opened = Mock(return_value={'url': 'http://127.0.0.1:41234/#token=' + token})
    monkeypatch.setattr(manager, 'open', opened)
    requests = []

    class InternalClient:
        def __init__(self, **options):
            assert options['trust_env'] is False and options['follow_redirects'] is False
        async def __aenter__(self): return self
        async def __aexit__(self, *_): pass
        async def request(self, method, url, **options):
            requests.append((method, url, options))
            return httpx.Response(409, json={'detail': 'Consulta ocupada'})

    monkeypatch.setattr(mobile_app.httpx, 'AsyncClient', InternalClient)
    with TestClient(app, base_url='https://estudos.example.com') as client:
        url = f'/p/{person["id"]}/api/key'
        assert client.post(url, headers={'X-EC-Token': 'outro-token'}, json={'key': 'Enter'}).status_code == 401
        assert not requests and not opened.called
        response = client.post(url, headers={'X-EC-Token': token}, json={'key': 'Enter'})
    assert response.status_code == 409 and response.headers['cache-control'] == 'no-store'
    method, url, options = requests[0]
    assert method == 'POST' and url == 'http://127.0.0.1:41234/api/key'
    assert options['headers']['X-EC-Token'] == token
    assert json.loads(options['content']) == {'key': 'Enter'}


def test_link_de_pessoa_no_remoto_usa_mesma_origem(monkeypatch):
    token = 'fixture-child-token'
    manager = SimpleNamespace(open=Mock(return_value={'url': 'http://127.0.0.1:41999/#token=' + token}))
    monkeypatch.setattr(servidor, 'profile_manager', lambda: manager)
    monkeypatch.setattr(servidor, 'REMOTE_CONFIG', RemoteConfig(True, 'https://estudos.example.com'))
    result = asyncio.run(servidor.open_profile_response('pessoa7'))
    assert result['url'] == '/p/pessoa7/#token=' + token


def test_remoto_nao_tenta_conectar_chrome_do_telefone(monkeypatch):
    monkeypatch.setattr(servidor, 'REMOTE_CONFIG', RemoteConfig(True, 'https://estudos.example.com'))
    with pytest.raises(servidor.HTTPException) as error:
        asyncio.run(servidor.connect_browser(servidor.BrowserConnect()))
    assert error.value.status_code == 409 and 'telefone' in error.value.detail


def test_voz_linux_envia_frase_por_stdin_e_remove_arquivo(tmp_path, monkeypatch):
    monkeypatch.setattr(fala_sintetica, 'DATA', tmp_path)
    monkeypatch.setattr(fala_sintetica.shutil, 'which', lambda _: '/usr/bin/espeak-ng')
    calls = []
    def synthesize(args, **options):
        calls.append((args, options))
        output = Path(args[args.index('-w') + 1])
        with wave.open(str(output), 'wb') as audio:
            audio.setnchannels(1); audio.setsampwidth(2); audio.setframerate(16000)
            audio.writeframes(b'\x10\x00' * 16000)
        return SimpleNamespace(returncode=0)
    monkeypatch.setattr(fala_sintetica.subprocess, 'run', synthesize)
    phrase = 'This is a test sentence.'
    payload, duration = fala_sintetica._synthesize_portable(phrase)
    assert duration == 1 and payload.startswith(b'RIFF')
    assert calls[0][1]['input'] == phrase and phrase not in calls[0][0]
    assert not list(tmp_path.iterdir())


def test_voz_linux_timeout_nao_deixa_audio_temporario(tmp_path, monkeypatch):
    monkeypatch.setattr(fala_sintetica, 'DATA', tmp_path)
    monkeypatch.setattr(fala_sintetica.shutil, 'which', lambda _: '/usr/bin/espeak-ng')
    monkeypatch.setattr(fala_sintetica.subprocess, 'run', Mock(side_effect=fala_sintetica.subprocess.TimeoutExpired('tts', 24)))
    with pytest.raises(RuntimeError, match='24 segundos'):
        fala_sintetica._synthesize_portable('Hello.')
    assert not list(tmp_path.iterdir())


def test_voz_linux_sem_dependencia_informa_acao(monkeypatch):
    monkeypatch.setattr(fala_sintetica.shutil, 'which', lambda _: None)
    with pytest.raises(RuntimeError, match='espeak-ng'):
        fala_sintetica._synthesize_portable('Hello.')


def test_configuracao_ia_remota_fica_no_volume_e_windows_preserva_local(tmp_path, monkeypatch):
    monkeypatch.setenv('EC_REMOTE_MODE', '1')
    monkeypatch.setenv('EC_DATA_DIR', str(tmp_path))
    assert auto_ia.config_path() == tmp_path / 'config_ia.local.txt'
    monkeypatch.setenv('EC_REMOTE_MODE', '0')
    assert auto_ia.config_path() == auto_ia.ROOT / 'config_ia.local.txt'
