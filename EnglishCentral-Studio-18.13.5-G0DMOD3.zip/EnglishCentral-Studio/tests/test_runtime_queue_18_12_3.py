import asyncio
from pathlib import Path
import re

import servidor


def test_read_only_waits_for_browser_instead_of_returning_busy_409(monkeypatch):
    async def run():
        original_lock = servidor.lock
        queued_lock = asyncio.Lock()
        monkeypatch.setattr(servidor, 'lock', queued_lock)

        @servidor.browser_deadline('BROWSER_READ_TIMEOUT', read_only=True)
        async def read_route():
            async with servidor.lock:
                return {'ok': True, 'read': 'after-action'}

        async def release():
            await asyncio.sleep(0.05)
            queued_lock.release()

        await queued_lock.acquire()
        releaser = asyncio.create_task(release())
        try:
            result = await read_route()
            assert result == {'ok': True, 'read': 'after-action'}
        finally:
            await releaser
            monkeypatch.setattr(servidor, 'lock', original_lock)
    asyncio.run(run())


def test_mobile_preview_has_back_and_scroll_controls():
    html = Path('web/index.html').read_text(encoding='utf-8')
    assert 'id="previewBack"' in html
    assert 'id="previewScrollUp"' in html
    assert 'id="previewScrollDown"' in html
    assert "api('back','POST',{})" in html
    assert "api('scroll','POST',{amount:-620})" in html
    assert "api('scroll','POST',{amount:620})" in html


def test_mimi_preferences_are_profile_scoped_and_sent_to_api():
    html = Path('web/index.html').read_text(encoding='utf-8')
    assert "ec_mimi_prefs:'+panelBase" in html
    assert "estilo:mimiPrefs.estilo" in html
    assert "idioma_apoio:mimiPrefs.idioma_apoio" in html


def test_version_metadata_updated():
    html = Path('web/index.html').read_text(encoding='utf-8')
    assert 'V18.13.2' in html
