"""Painel renderizado no Chromium com fetch simulado, sem navegação externa."""
import asyncio
import json
from pathlib import Path

from playwright.async_api import async_playwright, expect
from conftest import chromium_launch_options


def test_painel_mostra_texto_do_historico_do_servidor():
    async def run():
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(**chromium_launch_options())
            try:
                page = await browser.new_page()
                payload = {'aberto': False, 'executando': False,
                    'eventos': [{'horario': '2026-10-27T16:49:00Z',
                                 'evento': 'Palavra aceita pelo site. Avançando para a próxima.'}],
                    'auto': {'tipo': 'escopo_concluido', 'mensagem': 'Duas etapas verificadas.'}}
                stub = """<script>
                  location.hash='#token=token-local-apenas-teste';
                  window.fetch=async function(url){
                    if(String(url).includes('/api/status'))return new Response(__PAYLOAD__,{status:200,headers:{'Content-Type':'application/json'}});
                    return new Response('{}',{status:200,headers:{'Content-Type':'application/json'}});
                  };
                  </script>""".replace('__PAYLOAD__', json.dumps(json.dumps(payload)))
                html = (Path(__file__).resolve().parents[1] / 'web' / 'index.html').read_text('utf-8')
                await page.set_content(html.replace('<script>',stub+'<script>',1))
                await page.get_by_role('button',name='Progresso',exact=True).click()
                await page.locator('#workDrawer .compactHistory > summary').click()
                await page.get_by_text('Palavra aceita pelo site. Avançando para a próxima.', exact=True).wait_for(timeout=4000)
                assert await page.locator('#activityTitle').inner_text() == 'Atividades selecionadas verificadas'
                assert await page.locator('#events li span').inner_text() != ''
                assert await page.locator('#workDrawer').get_attribute('open') is not None
                await page.locator('#workDrawer > summary').click()
                assert await page.locator('#workDrawer').get_attribute('open') is None
            finally:
                await browser.close()
    asyncio.run(run())


def test_painel_reconecta_sem_exigir_novo_token_em_falha_temporaria():
    async def run():
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(**chromium_launch_options())
            try:
                page = await browser.new_page()
                payload = {'aberto': False, 'executando': False, 'eventos': [],
                           'auto': {'tipo': 'parado', 'mensagem': 'Pronto para iniciar.'}}
                stub = """<script>
                  location.hash='#token=token-local-apenas-teste';
                  let failedOnce=false;
                  window.fetch=async function(url){
                    if(String(url).includes('/api/status')){
                      if(!failedOnce){failedOnce=true;throw new TypeError('Falha temporária de rede');}
                      return new Response(__PAYLOAD__,{status:200,headers:{'Content-Type':'application/json'}});
                    }
                    return new Response('{}',{status:200,headers:{'Content-Type':'application/json'}});
                  };
                  </script>""".replace('__PAYLOAD__', json.dumps(json.dumps(payload)))
                html = (Path(__file__).resolve().parents[1] / 'web' / 'index.html').read_text('utf-8')
                await page.set_content(html.replace('<script>', stub + '<script>', 1))
                await expect(page.locator('#connection')).to_have_text('Reconectando…',timeout=3000)
                assert await page.locator('#auth').evaluate("(e)=>e.classList.contains('hide')")
                assert await page.locator('#connection').inner_text() == 'Reconectando…'
                await page.get_by_text('Conectado', exact=True).wait_for(timeout=4000)
                assert await page.locator('#auth').evaluate("(e)=>e.classList.contains('hide')")
            finally:
                await browser.close()
    asyncio.run(run())
