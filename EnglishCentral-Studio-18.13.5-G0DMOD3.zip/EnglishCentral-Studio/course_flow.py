"""Navegação do curso a partir dos cartões e estados visíveis do EnglishCentral.

``advance_course`` executa no máximo um clique por chamada. O chamador só deve
chamar ``cursor.mark_done(lesson_id)`` depois de observar as etapas selecionadas concluídas
no player. A cor do progresso agregado do cartão nunca é usada como conclusão.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import re
import time


def lesson_key(value: str | None) -> str:
    """Normaliza o identificador do diálogo exposto no DOM do vídeo/cartão."""
    text = str(value or "").strip()
    if text.isdigit():
        return text
    tagged = re.fullmatch(r"dialog:(\d+)", text)
    if tagged:
        return tagged.group(1)
    found = re.search(r"(?:/dialogs/|ns-dialog-|(?:thumb|videoh264)_)(\d+)", text)
    return found.group(1) if found else ""


@dataclass
class CourseCursor:
    seen: set[str] = field(default_factory=set)
    saved_scope_lessons: set[str] = field(default_factory=set)
    skipped_lessons: set[str] = field(default_factory=set)
    skipped_quizzes: set[str] = field(default_factory=set)
    skipped_units: set[str] = field(default_factory=set)
    session_verified_lessons: set[str] = field(default_factory=set)
    seen_quizzes: set[str] = field(default_factory=set)
    visited_units: set[str] = field(default_factory=set)
    verified_units: set[str] = field(default_factory=set)
    unit_reports: dict = field(default_factory=dict)
    empty_since: dict = field(default_factory=dict)
    card_loading_since: dict = field(default_factory=dict)
    ignored_units: set[str] = field(default_factory=set)
    reread_units: set[str] = field(default_factory=set)
    current: str = ""
    current_unit: str = ""
    course_id: str = ""
    pending: str = ""
    pending_since: float = 0.0
    pending_attempts: int = 0
    last_action: str = ""
    blocked_units: set[str] = field(default_factory=set)

    def mark_done(self, value: str) -> None:
        key = lesson_key(value)
        if key:
            self.seen.add(key)
            self.session_verified_lessons.add(key)
            if self.pending == "lesson:" + key:
                self.pending = ""
                self.pending_attempts = 0

    def mark_quiz_done(self, value: str) -> None:
        key = str(value or "").strip()
        if re.fullmatch(r"[A-Za-z0-9:_-]{1,100}", key):
            self.seen_quizzes.add(key)
            if self.pending == "quiz:" + key:
                self.pending = ""
                self.pending_attempts = 0

    def reset(self) -> None:
        self.seen.clear()
        self.saved_scope_lessons.clear()
        self.skipped_lessons.clear()
        self.skipped_quizzes.clear()
        self.skipped_units.clear()
        self.session_verified_lessons.clear()
        self.seen_quizzes.clear()
        self.visited_units.clear()
        self.verified_units.clear()
        self.blocked_units.clear()
        self.unit_reports.clear()
        self.empty_since.clear()
        self.card_loading_since.clear()
        self.ignored_units.clear()
        self.reread_units.clear()
        self.current = self.current_unit = self.course_id = self.pending = self.last_action = ""
        self.pending_since = 0.0
        self.pending_attempts = 0


COURSE_SCAN_JS = r"""() => {
 const text=e=>(e?.innerText||'').replace(/\s+/g,' ').trim();
 const visible=e=>{if(!e)return false;const r=e.getBoundingClientRect(),s=getComputedStyle(e);
   return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'&&Number(s.opacity)!==0};
 const app=document.querySelector('ec-course-app');
 if(!app)return {supported:false};
 const unitContainer=app.querySelector('ec-course-unit');
 if(!unitContainer)return {supported:false};
 const player=[...unitContainer.querySelectorAll('ec-player-app')].find(visible);
 const v=player?.querySelector('ec-video video,video');
 const playerVideo=v?([v.getAttribute('src')||'',v.id||''].find(s=>/\/dialogs\/\d+|ns-dialog-\d+/.test(s))||''):'';
 const backs=[...app.querySelectorAll('.course-unit-activity-back-button-wrapper')]
   .map((e,index)=>({index,label:text(e),visible:visible(e)})).filter(x=>x.visible&&/^(voltar|back)$/i.test(x.label));
 const units=[...unitContainer.querySelectorAll('.unit[id]')].map((u,index)=>{
   const header=u.querySelector('.unit-header');
   const cards=[...u.querySelectorAll('ec-course-unit-activity')].map((c,index)=>{
      const thumb=c.querySelector('.course-unit-activity-thumbnail');
      const image=thumb?.getAttribute('style')||'';
      const match=image.match(/\/dialogs\/(\d+)\//);
      const wrapper=c.querySelector('.course-unit-activity-thumbnail-title-wrapper');
       const title=text(c.querySelector('.course-unit-activity-title'));
       const quiz=!!thumb?.classList.contains('quiz-thumbnail')||/\bquiz\b/i.test(title);
       const progress=c.querySelector('.course-unit-activity-progress');
       const status=[c.className,progress?.className,progress?.getAttribute('aria-label'),
         progress?.getAttribute('title'),c.getAttribute('data-status'),c.getAttribute('aria-label')].join(' ');
       const pending=/(?:incomplete|not[-_ ]complete|pending|pendente|n[aã]o conclu)/i.test(status)||c.getAttribute('data-completed')==='false'||(!!progress?.querySelector('.fa-chevron-right')&&!progress?.querySelector('.fa-check'));
       return {index,lesson_id:match?.[1]||'',quiz_key:u.id+':q'+index,title,activity:/\bactivity\s+\d/i.test(title),
         loading:!!c.querySelector('ec-loading-ring')||!wrapper||!thumb,
         pending,video:!!match&&!quiz,quiz,completed:!pending&&(/(?:^|[\s_-])(?:completed?|done|conclu[ií]d[oa]|success)(?:$|[\s_-])/i.test(status)||c.getAttribute('data-completed')==='true'||!!progress?.querySelector('.fa-check')),visible:visible(wrapper),
         locked:c.classList.contains('locked')||!!c.querySelector('.fa-lock')};
   });
   return {id:u.id,index,title:text(u.querySelector('.unit-name')),active:u.classList.contains('active'),
      visible:visible(header),locked:u.classList.contains('locked')||u.classList.contains('course-locked')||
        !!header?.querySelector('.fa-lock'),ready:!!u.querySelector('.unit-activities'),cards};
 });
 const route=location.pathname.match(/\/course\/(\d+)/);
 return {supported:true,course_id:route?.[1]||app.getAttribute('data-course-id')||'',player:!!player,player_video:playerVideo,backs,units};
}"""


def _result(tipo: str, mensagem: str, **extras) -> dict:
    return {"tipo": tipo, "mensagem": mensagem, **extras}


async def inspect_course(page) -> dict:
    """Lê somente a árvore DOM da lista do curso, sem tokens nem estado Angular."""
    try:
        return await page.main_frame.evaluate(COURSE_SCAN_JS)
    except Exception:
        return {"supported": False}


async def _click(locator, action: str, title: str) -> dict:
    if await locator.count() != 1 or not await locator.is_visible():
        return _result("aguardando", "A lista de aulas mudou; vou observar novamente.")
    try:
        box = await locator.bounding_box()
        await locator.click(timeout=5000)
    except Exception:
        return _result("aguardando", "O controle da aula ainda não está disponível; vou observar novamente.")
    pointer = ({"x": round(box["x"] + box["width"] / 2),
                "y": round(box["y"] + box["height"] / 2), "texto": title,
                "acao": "navegacao"} if box else None)
    return _result("navegacao", title, acao=action, ponteiro=pointer)


async def _advance_course(page, cursor: CourseCursor, *, include_quizzes: bool = False,
                         include_videos: bool = True, include_activities: bool = False, snapshot: dict | None = None) -> dict:
    """Abre a próxima videoaula do curso ou retorna ``escopo_concluido``.

    IDs em ``seen`` correspondem apenas às etapas selecionadas e verificadas pelo chamador.
    Um player desconhecido ou uma aula ainda pendente não são fechados. Depois de
    uma navegação, a chamada seguinte sempre relê o DOM antes de escolher um alvo.
    """
    info = snapshot if snapshot is not None else await inspect_course(page)
    if not info.get("supported") or not info.get("course_id"):
        return _result("fora_curso", "A lista do curso EnglishCentral não está aberta.")
    if cursor.course_id and cursor.course_id != info["course_id"]:
        cursor.reset()
    cursor.course_id = info["course_id"]
    units = info.get("units", [])

    # Um cartão pendente contradiz apenas o cache de sessões anteriores.
    # Uma aula recém-conferida no player pode continuar com cartão pendente
    # por etapas que não fazem parte do modo atual (por exemplo, Falar).
    for unit in units:
        if unit['id'] in cursor.verified_units and unit.get('ready'):
            new_video=any(c.get('video') and (include_activities if c.get('activity') else include_videos)
                          and lesson_key(c.get('lesson_id')) not in cursor.seen for c in unit.get('cards',[]))
            new_quiz=include_quizzes and any(c.get('quiz') and c.get('quiz_key') not in cursor.seen_quizzes
                                             and not c.get('completed') for c in unit.get('cards',[]))
            if new_video or new_quiz:
                cursor.verified_units.discard(unit['id']);cursor.visited_units.discard(unit['id'])
        for card in unit.get('cards', []):
            if include_quizzes and card.get('quiz') and card.get('pending'):
                cursor.seen_quizzes.discard(card.get('quiz_key', ''))
                cursor.verified_units.discard(unit['id'])
                cursor.visited_units.discard(unit['id'])
            selected = card.get('video') and (include_activities if card.get('activity') else include_videos)
            key = lesson_key(card.get('lesson_id'))
            if selected and card.get('pending') and key and key not in cursor.session_verified_lessons and key not in cursor.saved_scope_lessons:
                cursor.seen.discard(key)
                cursor.verified_units.discard(unit['id'])
                cursor.visited_units.discard(unit['id'])

    if info.get("player"):
        current_id = lesson_key(info.get("player_video"))
        # Não sair de um preview, player sem identidade ou de uma aula pendente.
        if not current_id or (include_videos and current_id not in cursor.seen and current_id not in cursor.skipped_lessons):
            return _result("aguardando", "A aula aberta ainda precisa das atividades selecionadas verificadas.",
                           aula=current_id)
        backs = info.get("backs", [])
        if len(backs) != 1:
            return _result("ajuda", "As atividades selecionadas foram verificadas, mas não encontrei uma saída única para a lista do curso.")
        marker = "back:" + current_id
        if cursor.pending == marker and time.monotonic() - cursor.pending_since < 2:
            return _result("aguardando", "Aguardando a lista do curso reaparecer.")
        if cursor.pending == marker and cursor.pending_attempts >= 2:
            return _result("ajuda", "O botão Voltar não fechou o player após duas tentativas; pausei os cliques nessa tela.")
        back = page.locator("ec-course-app .course-unit-activity-back-button-wrapper").nth(backs[0]["index"])
        result = await _click(back, "voltar_lista", "Etapas verificadas. Voltando à lista do curso.")
        if result["tipo"] == "navegacao":
            attempts = cursor.pending_attempts + 1 if cursor.pending == marker else 1
            cursor.pending, cursor.pending_since, cursor.pending_attempts = marker, time.monotonic(), attempts
            cursor.last_action = marker
        return result

    # Um quiz pode abrir em uma rota ou sobreposição sem um player de vídeo.
    # Nunca clique novamente no cartão enquanto o quiz anterior ainda está aberto.
    if cursor.pending.startswith("quiz:") and cursor.pending[5:] not in cursor.skipped_quizzes:
        quiz_key = cursor.pending.partition(":")[2]
        quiz_card = next((c for u in units for c in u.get("cards", [])
                          if c.get("quiz_key") == quiz_key), None)
        if quiz_card and quiz_card.get("completed") and not quiz_card.get('pending'):
            cursor.mark_quiz_done(quiz_key)
        else:
            elapsed = time.monotonic() - cursor.pending_since
            if elapsed < 90:
                return _result("aguardando", "Quiz aberto. Aguardando o exercício terminar e a plataforma confirmar o resultado.", quiz_id=quiz_key)
            return _result("aguardando", "O quiz continua aberto. Relendo a atividade antes de decidir o próximo passo.", quiz_id=quiz_key)

    # Evita repetir um clique enquanto a abertura de player/unidade ainda carrega.
    now = time.monotonic()
    if cursor.pending.startswith("lesson:") and now - cursor.pending_since < 12:
        return _result("aguardando", "Aguardando o player da aula selecionada carregar.")
    if cursor.pending.startswith("unit:"):
        unit_id = cursor.pending.partition(":")[2]
        loading = next((u for u in units if u["id"] == unit_id), None)
        if loading and not (loading.get("active") and loading.get("ready")) and now - cursor.pending_since < 12:
            return _result("aguardando", "Aguardando as aulas da unidade carregarem.")
    if cursor.pending.startswith("back:"):
        cursor.pending = ""
        cursor.pending_attempts = 0

    active = [u for u in units if u.get("active") and u.get("visible") and not u.get("locked") and u["id"] not in cursor.blocked_units and u['id'] not in cursor.verified_units and u['id'] not in cursor.skipped_units]
    if len(active) > 1:
        return _result("ajuda", "Encontrei mais de uma unidade ativa; aguardando a lista estabilizar.")
    if active:
        unit = active[0]
        cursor.current_unit = unit["id"]
        if not unit.get("ready"):
            return _result("aguardando", "A unidade abriu; aguardando a lista de atividades.")
        if not unit.get('cards'):
            since = cursor.empty_since.setdefault(unit['id'], now)
            if now - since < 20:
                return _result('aguardando', 'Aguardando as atividades da unidade carregarem; ainda não foi verificada.')
            cursor.blocked_units.add(unit['id'])
            cursor.visited_units.add(unit['id'])
            return _result('aguardando', 'Esta unidade não carregou. Vou verificar as outras pendentes.')
        cursor.empty_since.pop(unit['id'], None)
        loading=next((c for c in unit.get('cards',[]) if c.get('loading')),None)
        if loading:
            key=unit['id']+':'+str(loading['index'])
            if key not in cursor.card_loading_since:
                cursor.card_loading_since[key]=now
                await page.locator('ec-course-unit .unit[id]').nth(unit['index']).locator('ec-course-unit-activity').nth(loading['index']).scroll_into_view_if_needed(timeout=5000)
            if now-cursor.card_loading_since[key] < 20:
                return _result('aguardando','Carregando os cartões da unidade antes de procurar o quiz.')
            cursor.blocked_units.add(unit['id'])
            cursor.visited_units.add(unit['id'])
            return _result('aguardando','Um cartão não carregou. Vou conferir as outras unidades e reavaliar esta depois.')
        videos = [c for c in unit.get("cards", []) if (include_activities if c.get("activity") else include_videos) and c.get("video") and not c.get("locked")]
        # A conclusão agregada do cartão não comprova cada etapa selecionada.
        # Abra o player até o chamador observar e confirmar o modo atual.
        remaining = [c for c in videos if c["lesson_id"] not in cursor.seen and c["lesson_id"] not in cursor.skipped_lessons]
        if remaining:
            card = remaining[0]
            if not card.get("visible"):
                return _result("aguardando", "A próxima aula ainda não está disponível na lista.")
            marker = "lesson:" + card["lesson_id"]
            attempts = cursor.pending_attempts if cursor.pending == marker else 0
            if attempts >= 2:
                return _result("ajuda", "A aula selecionada não abriu após duas tentativas; verifique a sessão do navegador.")
            unit_loc = page.locator("ec-course-unit .unit[id]").nth(unit["index"])
            target = unit_loc.locator("ec-course-unit-activity").nth(card["index"]).locator(".course-unit-activity-thumbnail-title-wrapper")
            result = await _click(target, "abrir_aula", "Abrindo a aula: " + card["title"] + ".")
            if result["tipo"] == "navegacao":
                cursor.current = card["lesson_id"]
                cursor.pending, cursor.pending_since, cursor.pending_attempts = marker, now, attempts + 1
                cursor.last_action = marker
                result["aula"] = card["lesson_id"]
            return result
        quizzes = [c for c in unit.get("cards", []) if c.get("quiz") and not c.get("locked")]
        for card in quizzes:
            if card.get('pending'):
                cursor.seen_quizzes.discard(card.get('quiz_key',''))
                cursor.verified_units.discard(unit['id'])
            elif card.get("completed"):
                cursor.mark_quiz_done(card.get("quiz_key", ""))
        remaining_quizzes = [c for c in quizzes if c.get("quiz_key") not in cursor.seen_quizzes and c.get("quiz_key") not in cursor.skipped_quizzes]
        if include_quizzes and remaining_quizzes:
            card = remaining_quizzes[0]
            if not card.get("visible"):
                return _result("aguardando", "O próximo quiz ainda não está disponível na lista.")
            marker = "quiz:" + card["quiz_key"]
            target = page.locator("ec-course-unit .unit[id]").nth(unit["index"]).locator("ec-course-unit-activity").nth(card["index"]).locator(".course-unit-activity-thumbnail-title-wrapper")
            result = await _click(target, "abrir_quiz", "Abrindo o quiz: " + (card["title"] or "Quiz") + ".")
            if result["tipo"] == "navegacao":
                cursor.pending, cursor.pending_since, cursor.pending_attempts = marker, now, 1
                cursor.last_action = marker
                result["quiz_id"] = card["quiz_key"]
            return result
        cursor.visited_units.add(unit["id"])
        # Unidade completamente observada neste modo: todos os vídeos visíveis
        # foram confirmados e nenhum vídeo da unidade está bloqueado/sem ID.
        # Apenas estas unidades podem ser reutilizadas com segurança em outra sessão.
        all_videos = [c for c in unit.get("cards", []) if (include_activities if c.get("activity") else include_videos) and c.get("video")]
        selected_cards = all_videos + ([c for c in unit.get("cards", []) if c.get("quiz")] if include_quizzes else [])
        if not selected_cards and all(c.get('video') or c.get('quiz') for c in unit.get('cards', [])):
            cursor.ignored_units.add(unit['id'])
        if selected_cards and all(
            (not c.get('locked') and c.get('lesson_id') in cursor.seen) if c.get('video')
            else (not c.get('locked') and c.get('quiz_key') in cursor.seen_quizzes)
            for c in selected_cards
        ):
            cursor.verified_units.add(unit["id"])
        if selected_cards and all(
            (c.get('lesson_id') in cursor.seen or c.get('lesson_id') in cursor.skipped_lessons) if c.get('video')
            else (c.get('quiz_key') in cursor.seen_quizzes or c.get('quiz_key') in cursor.skipped_quizzes)
            for c in selected_cards) and unit['id'] not in cursor.verified_units:
            cursor.skipped_units.add(unit['id'])
        # Se outra unidade não abriu, a anterior pode continuar ativa e pronta.
        # Preservar a tentativa pendente evita reiniciar o contador a cada ciclo.
        if not cursor.pending.startswith("unit:") or cursor.pending == "unit:" + unit["id"]:
            cursor.pending, cursor.pending_attempts = "", 0

    visible_units = [u for u in units if u.get("visible")]
    cursor.blocked_units.update(u["id"] for u in visible_units if u.get("locked"))
    available = [u for u in visible_units if not u.get("locked")]
    unopened = [u for u in available if u["id"] not in cursor.visited_units and u["id"] not in cursor.verified_units and u["id"] not in cursor.skipped_units and not u.get("active")]
    if unopened:
        unit = unopened[0]
        marker = "unit:" + unit["id"]
        attempts = cursor.pending_attempts if cursor.pending == marker else 0
        if attempts >= 2:
            return _result("ajuda", "A unidade não abriu após duas tentativas; verifique a sessão do navegador.")
        target = page.locator("ec-course-unit .unit[id]").nth(unit["index"]).locator(".unit-header")
        result = await _click(target, "abrir_unidade", "Abrindo " + (unit["title"] or "a próxima unidade") + ".")
        if result["tipo"] == "navegacao":
            cursor.pending, cursor.pending_since, cursor.pending_attempts = marker, now, attempts + 1
            cursor.last_action = marker
        return result

    # Uma leitura transitória não transforma visita em conclusão. Reabra uma vez
    # as unidades visitadas que ainda não tiveram suas atividades confirmadas.
    retry = [u for u in available if u['id'] in cursor.visited_units
             and u['id'] not in cursor.verified_units and u['id'] not in cursor.ignored_units
             and u['id'] not in cursor.reread_units and u['id'] not in cursor.skipped_units]
    if retry:
        unit = retry[0]
        cursor.reread_units.add(unit['id'])
        cursor.visited_units.discard(unit['id'])
        cursor.blocked_units.discard(unit['id'])
        cursor.empty_since.pop(unit['id'], None)
        cursor.card_loading_since={key:since for key,since in cursor.card_loading_since.items()
                                   if not key.startswith(unit['id']+':')}
        return _result('aguardando', 'Rechecando a unidade que ainda não confirmou suas atividades.')

    if not visible_units:
        return _result("aguardando", "Aguardando a lista de unidades do curso.")
    if cursor.blocked_units - cursor.skipped_units:
        return _result("ajuda", "As aulas acessíveis foram verificadas, mas há unidades bloqueadas no curso.",
                       aulas_verificadas=len(cursor.seen), unidades_bloqueadas=len(cursor.blocked_units))
    if available and all(u["id"] in cursor.verified_units or u["id"] in cursor.ignored_units for u in available):
        return _result("escopo_concluido", "As atividades selecionadas foram verificadas nas videoaulas acessíveis do curso.",
                       aulas_verificadas=len(cursor.seen), unidades_verificadas=len(cursor.verified_units))
    if available and all(u['id'] in cursor.verified_units or u['id'] in cursor.ignored_units or u['id'] in cursor.skipped_units for u in available):
        return _result('escopo_pulado','As atividades acessíveis foram percorridas. Há atividades puladas que continuam pendentes.')
    if available and all(u["id"] in cursor.visited_units for u in available):
        return _result("ajuda", "Há unidades visitadas sem confirmação de todas as atividades selecionadas. Confira atividades bloqueadas ou não reconhecidas.")
    return _result("aguardando", "Aguardando a lista do curso estabilizar.")


def course_progress(info, cursor, *, include_videos=True, include_quizzes=False, include_activities=False):
    def confirmed(card):
        return bool((card.get('lesson_id') in cursor.seen and
                     (not card.get('pending') or card.get('lesson_id') in cursor.session_verified_lessons or
                      card.get('lesson_id') in cursor.saved_scope_lessons)) if card.get('video') else
                    not card.get('pending') and (card.get('quiz_key') in cursor.seen_quizzes or card.get('completed')))
    units = []
    for unit in info.get('units', []):
        cards = [c for c in unit.get('cards', [])
                 if ((include_activities if c.get('activity') else include_videos) and c.get('video')) or (include_quizzes and c.get('quiz'))]
        done = sum(confirmed(c) for c in cards)
        blocked = unit.get('locked') or any(c.get('locked') for c in cards)
        verified = unit['id'] in cursor.verified_units and not any(
            c.get('pending') and (not c.get('video') or c.get('lesson_id') not in cursor.session_verified_lessons and c.get('lesson_id') not in cursor.saved_scope_lessons)
            for c in cards)
        status = 'bloqueada' if blocked else ('concluida' if verified else
                 ('pendente' if cards else 'nao_verificada'))
        if unit['id'] in cursor.ignored_units:
            status = 'fora_escopo'
        report = {'id': unit['id'], 'titulo': unit.get('title', ''), 'estado': status,
                  'atividades_lidas': len(cards), 'confirmadas': done,
                  'videos_pendentes': any(c.get('video') and not c.get('activity') and not confirmed(c) for c in cards),
                  'quizzes_pendentes': any(c.get('quiz') and not confirmed(c) for c in cards),
                  'activities_pendentes': any(c.get('activity') and not confirmed(c) for c in cards)}
        if cards:
            cursor.unit_reports[unit['id']] = report.copy()
        elif unit['id'] in cursor.unit_reports:
            report = {**cursor.unit_reports[unit['id']], 'estado': status}
        units.append(report)
    return {'curso': info.get('course_id', ''), 'unidades': units}


async def advance_course(page, cursor: CourseCursor, *, include_quizzes=False, include_videos=True, include_activities=False):
    snapshot = await inspect_course(page)
    result = await _advance_course(page, cursor, include_quizzes=include_quizzes,
                                   include_videos=include_videos, include_activities=include_activities, snapshot=snapshot)
    result['progresso_curso'] = course_progress(snapshot, cursor,
                          include_videos=include_videos, include_quizzes=include_quizzes, include_activities=include_activities)
    return result
