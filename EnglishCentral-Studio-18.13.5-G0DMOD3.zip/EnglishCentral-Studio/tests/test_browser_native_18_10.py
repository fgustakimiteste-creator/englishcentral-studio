"""Chromium real, contas fictícias e conexão CDP local em perfil de teste."""
import asyncio
import time
from types import SimpleNamespace

from playwright.async_api import async_playwright
from conftest import chromium_launch_options
import servidor
from auto_fluxo import EngineState,process_page
from modos import ModoEstudo
from browser_session import dismiss_course_tour
from test_course_flow import COURSE_HTML

FIXTURE='''<!doctype html><html><meta charset="utf-8"><style>ec-course-app{display:block;padding:30px}</style>
<body><ec-course-app><h1>TESTE LOCAL — sessão fictícia</h1>
<button id="login" onclick="window.open('https://accounts.google.com/v3/signin/identifier?fixture=1')">Login de teste</button>
<button id="target" style="position:absolute;left:1400px;top:900px" onclick="this.textContent='Clique recebido'">Alvo</button>
</ec-course-app></body></html>'''


def isolated(monkeypatch,tmp_path):
    for key,value in {'DATA':tmp_path,'PROFILES_ROOT':tmp_path,'PROFILE':tmp_path/'perfil_chromium',
        'COURSE_FILE':tmp_path/'course.txt','PROGRESS_FILE':tmp_path/'progress.json',
        'context':None,'page':None,'browser_driver':None,'connected_browser':None,'browser_owned':True,
        'browser_lease':None,'browser_tabs':{},'browser_parents':{},'browser_events':set(),
        'auto_task':None,'auto_running':False,'stop_confirmation':None,'stop_confirmation_event':None,
        'lock':asyncio.Lock(),'auto_control_lock':asyncio.Lock(),'LOGIN_CHECK_SECONDS':.02}.items():
        monkeypatch.setattr(servidor,key,value)


async def until(predicate,timeout=4):
    end=asyncio.get_running_loop().time()+timeout
    while not predicate():
        if asyncio.get_running_loop().time()>end:raise AssertionError('O estado esperado não apareceu')
        await asyncio.sleep(.02)


def test_cdp_reutiliza_sessao_popup_e_desconecta_sem_fechar_chrome(monkeypatch,tmp_path):
    async def run():
        isolated(monkeypatch,tmp_path)
        async with async_playwright() as pw:
            profile=tmp_path/'chrome-ja-aberto'
            options=chromium_launch_options();options['args']=[*options.get('args',[]),'--remote-debugging-port=0']
            original=await pw.chromium.launch_persistent_context(str(profile),viewport={'width':1600,'height':1000},**options)
            async def platform_fixture(route):
                html=FIXTURE
                if 'returned=1' in route.request.url:
                    html=html.replace('</body>','<div role="dialog"><button id="finish-login" onclick="this.parentElement.remove()">Entrar com o Google (fixture)</button></div></body>')
                await route.fulfill(content_type='text/html; charset=utf-8',body=html)
            await original.route('https://pt.englishcentral.com/**',platform_fixture)
            await original.route('https://accounts.google.com/**',lambda r:r.fulfill(content_type='text/html',body='<h1>LOGIN FICTÍCIO</h1>'))
            await original.route('https://unrelated.invalid/**',lambda r:r.fulfill(content_type='text/html',body='<h1>FORA DO CURSO</h1>'))
            p=original.pages[0];await p.goto('https://pt.englishcentral.com/course/8597')
            other=await original.new_page();await other.goto('https://unrelated.invalid/')
            await original.add_cookies([{'name':'fixture_session','value':'only-local-test','domain':'pt.englishcentral.com',
                                        'path':'/','httpOnly':True,'secure':True,'expires':time.time()+3600}])
            portfile=profile/'DevToolsActivePort'
            await until(portfile.exists)
            port=int(portfile.read_text().splitlines()[0])
            try:
                await servidor.connect_browser(servidor.BrowserConnect(porta=port))
                assert len(original.pages)==2 and servidor.page.url.endswith('/course/8597')
                assert await servidor.page.locator('#target').count()==1
                await servidor.tap(servidor.Tap(x=1430,y=910))
                assert await p.locator('#target').inner_text()=='Clique recebido'
                assert len((await servidor.session_tabs())['abas'])==1
                assert any(c['name']=='fixture_session' for c in await original.cookies())
                async with original.expect_page() as opened:
                    await p.locator('#login').click()
                popup=await opened.value;await popup.wait_for_load_state('domcontentloaded')
                await until(lambda:servidor.page is not None and 'accounts.google.com' in servidor.page.url)
                servidor.auto_running=True
                watch=asyncio.create_task(servidor.request_stop_confirmation({'tipo':'login','mensagem':'LOGIN DE TESTE'}))
                await until(lambda:servidor.stop_confirmation is not None)
                assert not watch.done()
                await popup.goto('https://pt.englishcentral.com/course/8597?returned=1')
                await asyncio.sleep(.05)
                assert not watch.done()  # URL do curso sozinha não comprova fim do login.
                await popup.locator('#finish-login').click()
                assert await asyncio.wait_for(watch,timeout=3) is True
                await servidor.close_browser()
                assert not p.is_closed() and not popup.is_closed() and not other.is_closed()
                assert await p.locator('h1').inner_text()=='TESTE LOCAL — sessão fictícia'
                assert any(c['name']=='fixture_session' for c in await original.cookies())
            finally:
                await servidor.dispose_browser_session()
                await original.close()
    asyncio.run(run())


def test_perfil_persistente_reabre_e_preserva_login_ficticio(monkeypatch,tmp_path):
    async def run():
        isolated(monkeypatch,tmp_path)
        monkeypatch.setenv('EC_HEADLESS','1')
        original_factory=async_playwright;launches=[]
        async def start():
            driver=await original_factory().start()
            async def launch(**kwargs):
                options=chromium_launch_options()
                if options.get('executable_path'):kwargs['executable_path']=options['executable_path']
                kwargs['args']=[*kwargs['args'],*options.get('args',[])]
                c=await driver.chromium.launch_persistent_context(**kwargs);launches.append(c)
                await c.route('https://pt.englishcentral.com/**',lambda r:r.fulfill(content_type='text/html',body=FIXTURE))
                return c
            return SimpleNamespace(chromium=SimpleNamespace(launch_persistent_context=launch),stop=driver.stop)
        monkeypatch.setattr('playwright.async_api.async_playwright',lambda:SimpleNamespace(start=start))
        try:
            await servidor.open_browser()
            await servidor.context.add_cookies([{'name':'fixture_saved_login','value':'test-only','domain':'pt.englishcentral.com',
                'path':'/','secure':True,'httpOnly':True,'expires':time.time()+3600}])
            first=servidor.page;other=await servidor.context.new_page()
            await other.goto('https://pt.englishcentral.com/course/8597?kept=1')
            await first.close();await servidor.open_browser()
            assert servidor.page is other and len(launches)==1
            await servidor.close_browser()
            await servidor.open_browser()
            assert len(launches)==2
            assert any(c['name']=='fixture_saved_login' for c in await servidor.context.cookies())
        finally:await servidor.dispose_browser_session()
    asyncio.run(run())


def test_tour_real_de_dom_e_fechado_sem_pular_atividade():
    async def run():
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(**chromium_launch_options())
            try:
                p=await browser.new_page()
                tour='<div id="tour" style="position:fixed;inset:0;background:white;z-index:999"><h2>Bem-vindo ao seu Curso!</h2><p>Tour inicial</p><button onclick="document.getElementById(\'tour\').remove()">Pular</button></div>'
                await p.route('https://pt.englishcentral.com/**',lambda r:r.fulfill(content_type='text/html',body=COURSE_HTML.replace('<script>',tour+'<script>',1)))
                await p.goto('https://pt.englishcentral.com/course/8597')
                engine=EngineState();mode=ModoEstudo(True,False,False,False)
                result=await process_page(p,engine=engine,modo=mode,submit=True)
                assert result['tipo']=='navegacao' and await p.locator('#tour').count()==0
                result=await process_page(p,engine=engine,modo=mode,submit=True)
                assert result.get('acao')=='abrir_unidade'
                assert await p.evaluate('window.actions')==['unit:1']
                await p.set_content('<h2>Atividade de fala</h2><button onclick="window.wrong=true">Pular</button>',wait_until='domcontentloaded')
                assert await dismiss_course_tour(p) is None
                assert not await p.evaluate('!!window.wrong')
            finally:await browser.close()
    asyncio.run(run())
