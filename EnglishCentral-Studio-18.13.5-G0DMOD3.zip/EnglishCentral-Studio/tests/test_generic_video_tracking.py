"""Controles e conclusão do leitor genérico, em páginas locais de teste."""
import asyncio
import io
import wave

import pytest
from playwright.async_api import async_playwright

from conftest import chromium_launch_options
from integracao import inspect_page, toggle_video


def _audio_wav():
    stream = io.BytesIO()
    with wave.open(stream, 'wb') as audio:
        audio.setnchannels(1)
        audio.setsampwidth(2)
        audio.setframerate(16000)
        audio.writeframes(b'\0\0' * 48000)
    return stream.getvalue()


def _with_page(scenario):
    async def run():
        async with async_playwright() as pw:
            options = chromium_launch_options()
            options['args'] = [*options.get('args', []), '--mute-audio']
            browser = await pw.chromium.launch(**options)
            try:
                page = await browser.new_page()
                await page.route('https://ec-generic.test/audio.wav', lambda route: route.fulfill(
                    content_type='audio/wav', body=_audio_wav()))
                await scenario(page)
            finally:
                await browser.close()
    asyncio.run(run())


def test_conclusao_exige_sinal_afirmativo_no_controle_de_assistir():
    async def scenario(page):
        cases = [
            ('<button class="incomplete">Assista ao vídeo</button>', False),
            ('<button aria-label="Watch the video not yet completed">Assista ao vídeo</button>', False),
            ('<button class="completed" data-completed="false">Assista ao vídeo</button>', False),
            ('<div class="completed"><button>Assista ao vídeo</button></div>', False),
            ('<div><button>Assista ao vídeo</button><button class="completed">Aprenda as palavras</button></div>', False),
            ('<button data-status="completed">Assista ao vídeo</button>', True),
            ('<button aria-label="Assista ao vídeo concluído">Assista ao vídeo</button>', True),
            ('<button data-completed="true">Assista ao vídeo</button>', True),
            ('<ec-activity-list><button data-testid="player-activity-button" class="activity-list-watch completed">Assistir</button></ec-activity-list>', True),
            ('<ec-activity-list><button data-testid="player-activity-button" class="activity-list-watch">Assistir<span class="activity-progress-indicator"><span class="inner completed">100%</span></span></button></ec-activity-list>', True),
            ('<ec-activity-list><button data-testid="player-activity-button" class="activity-list-watch">Assistir<span class="points-icon-wrap"><i class="fa-check">✓</i></span></button></ec-activity-list>', True),
            ('<ec-activity-list><button data-testid="player-activity-button" class="activity-list-watch incomplete">Assistir<span class="activity-progress-indicator"><span class="inner completed">100%</span></span></button></ec-activity-list>', False),
            ('<ec-activity-list><button data-testid="player-activity-button" class="activity-list-watch">Assistir<span class="activity-progress-indicator"><span class="inner bg-success">50%</span></span></button></ec-activity-list>', False),
            ('<button class="completed">Assista ao vídeo</button><button>Assista ao vídeo</button>', False),
            ('<div aria-hidden="true"><button class="completed">Assista ao vídeo</button></div>', False),
        ]
        for html, expected in cases:
            await page.set_content('<style>ec-activity-list{display:block}</style>' + html)
            result = await inspect_page(page)
            assert result['videoEtapaConcluida'] is expected, html
    _with_page(scenario)


def test_reproduzir_e_pausar_usam_botao_oficial_e_nao_repetem_clique():
    async def scenario(page):
        await page.set_content('''<style>ec-player-app{display:block}</style>
          <ec-player-app><video width="320" height="180" src="https://ec-generic.test/audio.wav"></video>
          <button data-testid="player-play-pause" onclick="window.siteClicks++;const v=document.querySelector('video');if(v.paused)v.play();else v.pause()">Play/Pause</button>
          </ec-player-app><script>window.siteClicks=0;</script>''')
        await page.wait_for_function('document.querySelector("video").readyState>=1')
        await inspect_page(page)
        result = await toggle_video(page, 0, '1', 'play')
        assert result['controle'] == 'site' and result['alterado']
        await page.wait_for_function('!document.querySelector("video").paused')
        result = await toggle_video(page, 0, '1', 'play')
        assert result['controle'] == 'observado' and not result['alterado']
        assert await page.evaluate('window.siteClicks') == 1
        result = await toggle_video(page, 0, '1', 'pause')
        assert result['controle'] == 'site' and not result['reproduzindo']
        assert await page.evaluate('window.siteClicks') == 2
    _with_page(scenario)


def test_englishcentral_sem_controle_oficial_nao_usa_play_nativo():
    async def scenario(page):
        await page.route('https://pt.englishcentral.com/course/123', lambda route: route.fulfill(
            content_type='text/html', body='<video width="320" height="180"></video><script>window.nativeCalls=0;document.querySelector("video").play=async()=>window.nativeCalls++;</script>'))
        await page.goto('https://pt.englishcentral.com/course/123')
        await inspect_page(page)
        with pytest.raises(RuntimeError, match='controle Reproduzir/Pausar'):
            await toggle_video(page, 0, '1', 'play')
        assert await page.evaluate('window.nativeCalls') == 0
    _with_page(scenario)


def test_player_englishcentral_com_controles_ambiguos_nao_inicia_video():
    async def scenario(page):
        await page.set_content('''<style>ec-player-app{display:block}</style><ec-player-app>
          <video width="320" height="180"></video><button data-testid="player-play-pause">Um</button>
          <button data-testid="player-play-pause">Dois</button></ec-player-app>
          <script>window.nativeCalls=0;document.querySelector('video').play=async()=>window.nativeCalls++;</script>''')
        await inspect_page(page)
        with pytest.raises(RuntimeError, match='controle Reproduzir/Pausar'):
            await toggle_video(page, 0, '1', 'play')
        assert await page.evaluate('window.nativeCalls') == 0
    _with_page(scenario)


def test_video_generico_mantem_fallback_nativo_e_diagnostico_sem_confirmar():
    async def scenario(page):
        await page.set_content('<video width="320" height="180" src="https://ec-generic.test/audio.wav"></video>')
        await page.wait_for_function('document.querySelector("video").readyState>=1')
        result = await inspect_page(page)
        video = result['videos'][0]
        assert result['paginaVisivel'] is True
        assert not result['videoEtapaConcluida']
        assert video['duracao'] == 3 and video['posicao'] == 0
        assert video['pronto'] >= 1 and isinstance(video['rede'], int)
        assert video['erro'] is None and video['origem'].endswith('/audio.wav')
        played = await toggle_video(page, 0, '1', 'play')
        assert played['controle'] == 'nativo' and played['reproduzindo']
        await page.wait_for_function('document.querySelector("video").currentTime>0')
        assert (await inspect_page(page))['videos'][0]['posicao'] > 0
        paused = await toggle_video(page, 0, '1', 'pause')
        assert paused['controle'] == 'nativo' and not paused['reproduzindo']
        assert not (await inspect_page(page))['videoEtapaConcluida']
    _with_page(scenario)
