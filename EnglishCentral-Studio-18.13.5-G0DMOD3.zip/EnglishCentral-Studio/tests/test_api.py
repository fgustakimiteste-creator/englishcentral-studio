from unittest.mock import AsyncMock
import asyncio
import os
os.environ['EC_PANEL_TOKEN'] = 'token-so-para-testes-12345'
from fastapi.testclient import TestClient
import servidor
from servidor import app


def test_pagina_inicial():
    with TestClient(app) as client:
        r = client.get('/')
        assert r.status_code == 200
        assert 'EnglishCentral Studio' in r.text


def test_autenticacao():
    with TestClient(app) as client:
        assert client.get('/api/status').status_code == 401
        assert client.get('/api/status', headers={'X-EC-Token': 'invalido'}).status_code == 401
        r = client.get('/api/status', headers={'X-EC-Token': 'token-so-para-testes-12345'})
        assert r.status_code == 200
        assert r.json()['aberto'] is False


def test_sessao_precisa_estar_aberta():
    with TestClient(app) as client:
        assert client.get('/api/screenshot', headers={'X-EC-Token': 'token-so-para-testes-12345'}).status_code == 409


def test_dashboard_uses_real_course_units_and_saved_progress(monkeypatch, tmp_path):
    monkeypatch.setattr(servidor, 'PROGRESS_FILE', tmp_path / 'progress.json')
    progress = servidor.ProgressoVerificado(servidor.PROGRESS_FILE)
    progress.confirmar('8597', '123', {'assistir': True, 'aprender': True})
    monkeypatch.setattr(servidor, 'current_page', lambda: object())
    monkeypatch.setattr(servidor, 'inspect_course', AsyncMock(return_value={
        'supported': True,
        'course_id': '8597',
        'units': [{
            'id': 'unit-1',
            'title': 'Unit one',
            'locked': False,
            'cards': [{'video': True, 'quiz': False, 'lesson_id': '123',
                       'completed': False, 'locked': False}],
        }],
    }))
    with TestClient(app) as client:
        response = client.get('/api/course', headers={'X-EC-Token': 'token-so-para-testes-12345'})
    assert response.status_code == 200
    result = response.json()
    assert result['supported'] is True
    assert result['aulas_verificadas'] == 1
    assert result['atividades_confirmadas'] == 1
    assert result['atividades_total'] == 1
    assert result['unidades'][0]['titulo'] == 'Unit one'


def test_dashboard_reports_unsupported_page_without_inventing_units(monkeypatch):
    monkeypatch.setattr(servidor, 'current_page', lambda: object())
    monkeypatch.setattr(servidor, 'inspect_course', AsyncMock(return_value={'supported': False}))
    with TestClient(app) as client:
        response = client.get('/api/course', headers={'X-EC-Token': 'token-so-para-testes-12345'})
    assert response.status_code == 200
    assert response.json() == {'supported': False, 'unidades': []}


def test_recommended_unit_opens_only_the_matching_unlocked_unit(monkeypatch):
    clicks = []

    class Header:
        async def count(self):
            return 1

        async def is_visible(self):
            return True

        async def click(self, timeout):
            clicks.append(timeout)

    class Unit:
        def locator(self, selector):
            assert selector == '.unit-header'
            return Header()

    class Units:
        def nth(self, index):
            assert index == 2
            return Unit()

    class Page:
        def locator(self, selector):
            assert selector == 'ec-course-unit .unit[id]'
            return Units()

    async def inspect(_page):
        return {'supported': True, 'units': [
            {'id': 'unit-3', 'index': 2, 'title': 'Unit three',
             'locked': False, 'active': False},
        ]}

    monkeypatch.setattr(servidor, 'current_page', lambda: Page())
    monkeypatch.setattr(servidor, 'inspect_course', inspect)
    monkeypatch.setattr(servidor, 'auto_running', False)
    monkeypatch.setattr(servidor, 'auto_task', None)

    result = asyncio.run(servidor.open_course_unit(servidor.CourseUnit(id='unit-3')))

    assert result['ok'] is True
    assert 'Unit three' in result['mensagem']
    assert clicks == [5000]
