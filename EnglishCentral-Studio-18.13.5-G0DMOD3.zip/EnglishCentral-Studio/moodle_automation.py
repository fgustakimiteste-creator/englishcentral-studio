"""Orquestrador paralelo de atividades Moodle em abas autenticadas isoladas.

Cada lane possui uma Page própria no BrowserContext do perfil. Cookies de login
são compartilhados pelo contexto autenticado, mas o DOM e a navegação não são.
O texto dos materiais é temporário em memória e descartado ao terminar cada seção.
O módulo não publica fóruns nem envia/finaliza tentativas de quiz.
"""
from __future__ import annotations

import asyncio
import uuid
from datetime import datetime, timezone
from typing import Awaitable, Callable

Processor = Callable[[object, dict, dict], Awaitable[dict]]

# Lista permitida: nenhum estado desconhecido pode virar sucesso.
SUCCESS_STATES = {'pdf_lido', 'material_lido', 'enviado', 'publicado'}
REVIEW_STATES = {
    'preenchido_nao_enviado', 'parcial_nao_enviado', 'rascunho_nao_publicado',
    'nao_extraivel', 'precisa_acao_manual', 'aguardando_revisao',
    'nao_confirmado', 'aguardando', 'parcial', 'tarefa_nao_enviada',
}
SKIPPED_STATES = {'pulado', 'fora_escopo'}
FAILED_STATES = {'falhou', 'erro'}
ACTION_TYPES = {'quiz', 'forum', 'assign', 'assignment', 'tarefa'}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class MoodleAutomation:
    def __init__(self) -> None:
        self._lock = asyncio.Lock()
        self._task: asyncio.Task | None = None
        self._stop = asyncio.Event()
        self._context = None
        self._queue: asyncio.Queue | None = None
        self._processor: Processor | None = None
        self._run: dict = {}
        self._lanes: dict[str, dict] = {}
        self._section_materials: list[tuple[int, str]] = []
        self._material_lock = asyncio.Lock()

    @property
    def running(self) -> bool:
        return self._task is not None and not self._task.done()

    async def start(self, context, course_url: str, activities: list[dict],
                    processor: Processor, workers: int = 1) -> dict:
        async with self._lock:
            if self.running:
                raise RuntimeError('Já existe uma automação de curso ativa neste perfil. Acompanhe-a ou pare-a antes de iniciar outra.')
            valid = []
            seen = set()
            for item in activities:
                if not isinstance(item, dict):
                    continue
                url = str(item.get('url') or '').strip()
                if not url or url in seen or item.get('conclusao') == 'concluido':
                    continue
                seen.add(url)
                valid.append(dict(item))
            if not valid:
                raise ValueError('Não encontrei atividades pendentes com endereço válido nesta página do curso.')
            worker_count = max(1, min(4, int(workers)))
            self._stop = asyncio.Event()
            self._context = context
            self._processor = processor
            self._queue = None
            self._section_materials = []
            run_id = uuid.uuid4().hex[:12]

            grouped: dict[tuple[int, str], list[dict]] = {}
            for index, item in enumerate(valid):
                item['_queue_index'] = index
                section_index = item.get('secao_indice')
                try:
                    section_index = int(section_index)
                except (TypeError, ValueError):
                    section_index = 0
                section_name = str(item.get('secao') or f'Seção {section_index + 1}')[:120]
                grouped.setdefault((section_index, section_name), []).append(item)
            self._section_batches = [
                {'indice': key[0], 'nome': key[1], 'atividades': rows}
                for key, rows in sorted(grouped.items(), key=lambda pair: pair[0][0])
            ]
            self._run = {
                'id': run_id, 'curso_url': course_url, 'estado': 'executando',
                'iniciado_em': _now(), 'finalizado_em': None,
                'total': len(valid), 'processadas': 0, 'sucesso': 0,
                'revisao': 0, 'falhas': 0, 'puladas': 0, 'nao_confirmadas': 0,
                'secoes_total': len(self._section_batches), 'secao_atual': 0,
                'secao_nome': self._section_batches[0]['nome'], 'fase_atual': 'Preparando agentes',
                'mensagem': 'Agentes trabalhando em paralelo dentro da primeira seção.',
                'limite_agentes': worker_count,
            }
            self._lanes = {
                f'agente-{i+1}': {
                    'id': f'agente-{i+1}', 'nome': f'Agente {i+1}', 'responsabilidade': 'Aguardando distribuição',
                    'estado': 'inicializando', 'atividade': 'Aguardando tarefa',
                    'tipo': 'aguardando', 'progresso': 0, 'url': '',
                    'iniciado_em': None, 'atualizado_em': _now(),
                    'resultado': None, 'erro': None, 'page': None,
                } for i in range(worker_count)
            }
            self._task = asyncio.create_task(self._run_workers(), name=f'moodle-course-{run_id}')
            return self.snapshot()

    async def _run_phase(self, ready_lanes: list[dict], section: dict,
                         activities: list[dict], phase_name: str,
                         material_context: str = '') -> None:
        if not activities or self._stop.is_set():
            return
        work_queue: asyncio.Queue = asyncio.Queue()
        for item in activities:
            await work_queue.put(item)
        self._run['fase_atual'] = phase_name
        self._run['mensagem'] = (
            f'Seção {self._run["secao_atual"]}/{self._run["secoes_total"]}: '
            f'{section["nome"]} · {phase_name}. Os agentes trabalham em paralelo.'
        )
        await asyncio.gather(*(
            self._worker(lane, work_queue, section, material_context=material_context)
            for lane in ready_lanes
        ))

    async def _run_workers(self) -> None:
        try:
            ready_lanes = []
            for lane in self._lanes.values():
                try:
                    page = await self._context.new_page()
                    lane['page'] = page
                    lane['estado'] = 'ocioso'
                    lane['atualizado_em'] = _now()
                    ready_lanes.append(lane)
                except Exception as exc:
                    lane['estado'] = 'falhou'
                    lane['erro'] = f'Não foi possível criar aba independente: {type(exc).__name__}: {str(exc)[:150]}'
                    self._run['falhas'] += 1
            if not ready_lanes:
                self._run['estado'] = 'falhou'
                self._run['mensagem'] = 'Nenhum agente conseguiu iniciar uma aba de execução. Confira o navegador e tente novamente.'
                return

            for section_number, section in enumerate(self._section_batches, start=1):
                if self._stop.is_set():
                    break
                self._run['secao_atual'] = section_number
                self._run['secao_nome'] = section['nome']
                self._section_materials = []

                # Primeiro Analyze/Read/Collect; depois Execute/Answer.
                # Assim o PDF da seção é lido antes do quiz/fórum, mesmo com vários workers.
                preparation, actions = [], []
                for item in section['atividades']:
                    kind = str(item.get('tipo') or 'atividade').strip().lower()
                    if item.get('pdf') or kind not in ACTION_TYPES:
                        preparation.append(item)
                    else:
                        actions.append(item)

                await self._run_phase(ready_lanes, section, preparation, 'Leitura dos materiais')
                if self._stop.is_set():
                    self._section_materials = []
                    break
                async with self._material_lock:
                    material_context = '\n\n'.join(text for _, text in sorted(self._section_materials, key=lambda row: row[0]))[-16000:]
                await self._run_phase(ready_lanes, section, actions,
                                      'Questionários, fóruns e tarefas', material_context)
                # Descarte explícito do conteúdo de PDF/material: memória da seção apenas.
                self._section_materials = []
                for lane in ready_lanes:
                    lane.pop('_material_context', None)

                if self._stop.is_set():
                    break
                for lane in ready_lanes:
                    if lane['estado'] not in ('falhou', 'parado'):
                        lane['estado'] = 'aguardando_proxima_secao'
                        lane['atividade'] = f'Seção concluída: {section["nome"]}'
                        lane['progresso'] = 100
                        lane['atualizado_em'] = _now()

        except asyncio.CancelledError:
            self._run['estado'] = 'interrompida'
            self._run['mensagem'] = 'Execução interrompida pelo usuário.'
            raise
        except Exception as exc:
            self._run['estado'] = 'falhou'
            self._run['mensagem'] = f'Falha do orquestrador: {type(exc).__name__}: {str(exc)[:180]}'
        finally:
            self._section_materials = []
            for lane in self._lanes.values():
                lane.pop('_material_context', None)
            if self._run:
                if self._stop.is_set():
                    self._run['estado'] = 'interrompida'
                    self._run['mensagem'] = 'Execução parada. Campos já preenchidos foram preservados para revisão.'
                elif self._run.get('estado') == 'executando':
                    if self._run.get('processadas', 0) == 0 and self._run.get('falhas', 0):
                        self._run['estado'] = 'falhou'
                        self._run['mensagem'] = 'Nenhum agente conseguiu executar atividades. Confira o navegador e tente novamente.'
                    elif self._run.get('falhas', 0):
                        self._run['estado'] = 'concluida_com_erros'
                        self._run['mensagem'] = 'A fila terminou com erros em algumas atividades. Confira as falhas e revise os itens preparados.'
                    elif self._run.get('revisao', 0) or self._run.get('puladas', 0) or self._run.get('nao_confirmadas', 0):
                        self._run['estado'] = 'aguardando_revisao'
                        self._run['mensagem'] = 'A fila percorreu as seções, mas há atividades que precisam de revisão ou não foram confirmadas. Não considere o curso concluído.'
                    else:
                        self._run['estado'] = 'processada'
                        self._run['mensagem'] = 'Todos os materiais selecionados foram lidos e confirmados. Isso não significa que quizzes foram enviados ou que o curso foi concluído no Moodle.'
                self._run['finalizado_em'] = _now()
            for lane in self._lanes.values():
                if lane['estado'] in ('trabalhando', 'aguardando_proxima_secao', 'inicializando'):
                    lane['estado'] = 'parado' if self._stop.is_set() else 'finalizado'
                    lane['atualizado_em'] = _now()

    async def _worker(self, lane: dict, work_queue: asyncio.Queue, section: dict,
                      *, material_context: str = '') -> None:
        page = lane.get('page')
        if page is None:
            return
        while not self._stop.is_set():
            try:
                item = work_queue.get_nowait()
            except asyncio.QueueEmpty:
                break
            kind = str(item.get('tipo') or 'atividade').lower()
            focus = 'Leitura e PDFs' if item.get('pdf') or kind == 'resource' else 'Questionários' if kind == 'quiz' else 'Fóruns' if kind == 'forum' else 'Materiais e tarefas' if kind in ('page', 'book', 'url', 'assign', 'assignment', 'tarefa') else 'Agente geral'
            lane.update({
                'estado': 'trabalhando', 'responsabilidade': focus, 'atividade': str(item.get('nome') or 'Atividade')[:180],
                'tipo': str(item.get('tipo') or 'atividade')[:40], 'url': str(item.get('url') or ''),
                'progresso': 0, 'iniciado_em': _now(), 'atualizado_em': _now(),
                'resultado': None, 'erro': None, 'secao': section['nome'],
                'preview_page': None, 'last_preview_bytes': None,
                '_material_context': material_context,
            })
            try:
                result = await self._processor(page, item, lane)
                result = result if isinstance(result, dict) else {'estado': 'nao_confirmado'}
                state = str(result.get('estado') or 'nao_confirmado').strip().lower()
                private_material = str(result.get('_contexto_material') or '').strip()
                if private_material:
                    async with self._material_lock:
                        self._section_materials.append((int(item.get('_queue_index', 0)), private_material[:24000]))
                lane['resultado'] = {k: v for k, v in result.items()
                                     if k not in ('texto', 'resposta', 'sugestoes', '_contexto_material')}
                if state in SUCCESS_STATES:
                    lane['estado'] = 'concluido'
                    lane['progresso'] = 100
                    self._run['sucesso'] += 1
                elif state in REVIEW_STATES:
                    lane['estado'] = 'aguardando_revisao'
                    lane['progresso'] = 80
                    self._run['revisao'] += 1
                    if state in ('nao_confirmado', 'aguardando'):
                        self._run['nao_confirmadas'] += 1
                elif state in SKIPPED_STATES:
                    lane['estado'] = 'pulado'
                    lane['progresso'] = 0
                    self._run['puladas'] += 1
                else:
                    lane['estado'] = 'falhou'
                    lane['progresso'] = 0
                    lane['erro'] = (f'Estado de atividade não reconhecido: {state[:60]}'
                                    if state not in FAILED_STATES else str(result.get('mensagem') or state)[:200])
                    self._run['falhas'] += 1
                lane['atualizado_em'] = _now()
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                lane['estado'] = 'falhou'
                lane['erro'] = f'{type(exc).__name__}: {str(exc)[:200]}'
                lane['atualizado_em'] = _now()
                self._run['falhas'] += 1
            finally:
                self._run['processadas'] += 1
                work_queue.task_done()
        if lane['estado'] == 'ocioso':
            lane['estado'] = 'finalizado' if not self._stop.is_set() else 'parado'
            lane['atividade'] = 'Seção concluída' if not self._stop.is_set() else 'Execução parada'
            lane['atualizado_em'] = _now()

    async def stop(self) -> dict:
        self._stop.set()
        task = self._task
        if task and not task.done():
            try:
                await asyncio.wait_for(asyncio.shield(task), timeout=20)
            except asyncio.TimeoutError:
                return {'ok': False, 'mensagem': 'A parada foi solicitada; um agente está terminando a ação atual.', **self.snapshot()}
        return {'ok': True, **self.snapshot()}

    async def screenshot(self, lane_id: str) -> bytes | None:
        lane = self._lanes.get(lane_id)
        if not lane:
            return None
        preview_page = lane.get('preview_page')
        if preview_page is not None:
            try:
                if not preview_page.is_closed():
                    return await preview_page.screenshot(type='jpeg', quality=55, animations='disabled', timeout=8000)
            except Exception:
                pass
        cached = lane.get('last_preview_bytes')
        if isinstance(cached, bytes):
            return cached
        page = lane.get('page')
        if page is not None:
            try:
                if not page.is_closed():
                    return await page.screenshot(type='jpeg', quality=55, animations='disabled', timeout=8000)
            except Exception:
                pass
        return None

    def snapshot(self) -> dict:
        run = dict(self._run)
        lanes = []
        for lane in self._lanes.values():
            lanes.append({k: v for k, v in lane.items()
                          if k not in ('page', 'preview_page', 'last_preview_bytes', '_material_context')})
        run['agentes'] = lanes
        run['secoes'] = [{'indice': row['indice'], 'nome': row['nome'], 'atividades': len(row['atividades'])}
                         for row in getattr(self, '_section_batches', [])]
        run['ativo'] = self.running
        return run

    async def close_pages(self) -> int:
        closed = 0
        for lane in self._lanes.values():
            pages = []
            lane['last_preview_bytes'] = None
            for key in ('preview_page', 'page'):
                page = lane.get(key)
                if page is not None and all(page is not current for current in pages):
                    pages.append(page)
                lane[key] = None
            for page in pages:
                try:
                    if not page.is_closed():
                        await page.close()
                        closed += 1
                except Exception:
                    pass
        return closed

    async def shutdown(self) -> None:
        if self.running:
            await self.stop()
        await self.close_pages()
