"""Regressões descobertas pela auditoria minuciosa da V18.12.1."""
import asyncio
from pathlib import Path

import pytest

import servidor
from moodle_adapter import MOODLE_OVERVIEW_JS, inspect_moodle_page, apply_moodle_quiz_suggestions, fill_moodle_forum_editor
from tests.test_moodle_execute_18_13 import MoodlePageProxy, SED


@pytest.mark.skipif(not Path('/usr/bin/chromium').exists(), reason='Chromium não instalado neste ambiente')
def test_opcao_moodle_preserva_indice_original_ao_filtrar_controle_invisivel():
    from playwright.async_api import async_playwright

    async def run():
        html = '''<!doctype html><html><body>
          <div class="que qtype_multichoice" id="question-501-1">
            <div class="qtext">Qual é a resposta?</div>
            <div style="display:none"><input type="radio" id="hidden-option" name="q501" value="x"><label for="hidden-option">Opção não visível</label></div>
            <div><input style="display:none" type="radio" id="visible-option" name="q501" value="b"><label for="visible-option">Resposta B</label></div>
          </div>
        </body></html>'''
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox'])
            raw = await browser.new_page()
            await raw.set_content(html)
            page = MoodlePageProxy(raw, f'{SED}/mod/quiz/attempt.php?attempt=501')
            overview = await inspect_moodle_page(page)
            options = overview['questoes'][0]['opcoes']
            assert len(options) == 1 and options[0]['indice'] == 1, options
            result = await apply_moodle_quiz_suggestions(page, [
                {'id': 'question-501-1', 'indice': 0, 'selecionadas': [1], 'texto': ''},
            ])
            assert result['confirmadas'] == 1, result
            assert await raw.locator('#visible-option').is_checked()
            assert not await raw.locator('#hidden-option').is_checked()
            await browser.close()
    asyncio.run(run())


@pytest.mark.skipif(not Path('/usr/bin/chromium').exists(), reason='Chromium não instalado neste ambiente')
def test_moodle_curso_nao_e_marcado_concluido_por_um_badge_de_atividade():
    from playwright.async_api import async_playwright

    async def run():
        html = '''<!doctype html><html><body>
          <ul class="sections">
            <li class="section">
              <h3 class="sectionname">Unidade 1</h3>
              <span class="alert">Nota final disponível</span>
              <ul>
                <li class="activity modtype_quiz">
                  <span class="completion-info">Atividade concluída</span>
                  <span class="activityname"><a href="/mod/quiz/view.php?id=1">Quiz concluído</a></span>
                </li>
                <li class="activity modtype_forum">
                  <span class="completion-info">Não concluído</span>
                  <span class="activityname"><a href="/mod/forum/view.php?id=2">Fórum pendente</a></span>
                </li>
              </ul>
            </li>
          </ul>
        </body></html>'''
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox'])
            raw = await browser.new_page()
            await raw.set_content(html)
            page = MoodlePageProxy(raw, f'{SED}/course/view.php?id=90')
            # Simula apenas a localização Moodle na expressão JS, pois o ambiente
            # bloqueia até navegação a 127.0.0.1 pelo Chromium de teste.
            script = MOODLE_OVERVIEW_JS.replace(
                'const pagePath=location.pathname.toLowerCase();',
                "const pagePath='/course/view.php';")
            overview = await raw.evaluate(script)
            assert overview['conclusao']['estado'] == 'nao_confirmado'
            states = {activity['nome']: activity['conclusao'] for activity in overview['atividades']}
            assert states['Quiz concluído'] == 'concluido'
            assert states['Fórum pendente'] == 'pendente'
            await browser.close()
    asyncio.run(run())


@pytest.mark.skipif(not Path('/usr/bin/chromium').exists(), reason='Chromium não instalado neste ambiente')
def test_moodle_multicampos_nao_repete_uma_resposta_unica_em_todos_os_campos():
    from playwright.async_api import async_playwright

    async def run():
        html = '''<!doctype html><html><body>
          <div class="que qtype_shortanswer" id="question-502-1">
            <div class="qtext">Complete as duas lacunas.</div>
            <input type="text" name="blank1"><input type="text" name="blank2">
          </div>
        </body></html>'''
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox'])
            raw = await browser.new_page()
            await raw.set_content(html)
            page = MoodlePageProxy(raw, f'{SED}/mod/quiz/attempt.php?attempt=502')
            result = await apply_moodle_quiz_suggestions(page, [
                {'id': 'question-502-1', 'indice': 0, 'selecionadas': [], 'texto': 'Uma resposta única'},
            ])
            assert result['confirmadas'] == 0
            assert result['detalhes'][0]['estado'] == 'multiplos_campos_requerem_resposta_por_campo'
            assert await raw.locator('input[name="blank1"]').input_value() == ''
            assert await raw.locator('input[name="blank2"]').input_value() == ''
            await browser.close()
    asyncio.run(run())


def test_moodle_quiz_fingerprint_detecta_alteracao_de_opcoes_e_estado():
    q = [{'id': 'q1', 'indice': 0, 'texto': 'Enunciado', 'tipo': 'multichoice', 'estado': 'nao_respondida',
          'opcoes': [{'indice': 0, 'tipo': 'radio', 'texto': 'A', 'valor': 'a', 'selecionada': False}],
          'campos': []}]
    baseline = servidor._moodle_quiz_fingerprint(q)
    changed_prompt = [{**q[0], 'texto': 'Enunciado alterado'}]
    changed_choice = [{**q[0], 'opcoes': [{'indice': 0, 'tipo': 'radio', 'texto': 'B', 'valor': 'b', 'selecionada': False}]}]
    changed_state = [{**q[0], 'estado': 'respondida_nao_enviada'}]
    assert baseline != servidor._moodle_quiz_fingerprint(changed_prompt)
    assert baseline != servidor._moodle_quiz_fingerprint(changed_choice)
    assert baseline != servidor._moodle_quiz_fingerprint(changed_state)


def test_put_parcial_de_configuracao_preserva_opcoes_omitidas(monkeypatch, tmp_path):
    settings_file = tmp_path / 'preferencias_seductec.json'
    monkeypatch.setattr(servidor, 'MOODLE_SETTINGS_FILE', settings_file)
    servidor.save_moodle_settings(servidor.MoodleSettingsRequest(
        modo='tudo', preencher_quiz=True, preencher_forum=True, tentar_novamente=True, max_tentativas=3))
    updated = servidor.save_moodle_settings(servidor.MoodleSettingsRequest(modo='quiz'))
    assert updated['modo'] == 'quiz'
    assert updated['preencher_forum'] is True
    assert updated['preencher_quiz'] is True
    assert updated['max_tentativas'] == 3


@pytest.mark.skipif(not Path('/usr/bin/chromium').exists(), reason='Chromium não instalado neste ambiente')
def test_forum_iframe_so_confirma_preenchimento_depois_de_relertudo():
    from playwright.async_api import async_playwright

    async def run():
        html = '''<!doctype html><html><body>
          <form><iframe title="Editor" srcdoc="<body contenteditable='true' class='mce-content-body'></body>"></iframe></form>
        </body></html>'''
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox'])
            raw = await browser.new_page()
            await raw.set_content(html)
            page = MoodlePageProxy(raw, f'{SED}/mod/forum/post.php?reply=7')
            result = await fill_moodle_forum_editor(page, 'Texto verificado no iframe.')
            assert result['preenchido'] is True
            frame_body = page.frame_locator('iframe').locator('body[contenteditable="true"]')
            assert (await frame_body.inner_text()).strip() == 'Texto verificado no iframe.'
            await browser.close()
    asyncio.run(run())


@pytest.mark.skipif(not Path('/usr/bin/chromium').exists(), reason='Chromium não instalado neste ambiente')
def test_questao_numerica_aceita_ponto_ou_virgula_e_relere_valor():
    from playwright.async_api import async_playwright

    async def run():
        html = '''<!doctype html><html><body>
          <div class="que qtype_numerical" id="question-503-1">
            <div class="qtext">Informe o resultado numérico.</div>
            <input type="number" step="any" name="numero">
          </div>
        </body></html>'''
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox'])
            raw = await browser.new_page()
            await raw.set_content(html)
            page = MoodlePageProxy(raw, f'{SED}/mod/quiz/attempt.php?attempt=503')
            result = await apply_moodle_quiz_suggestions(page, [
                {'id': 'question-503-1', 'indice': 0, 'selecionadas': [], 'texto': '1,5'},
            ])
            assert result['confirmadas'] == 1, result
            assert await raw.locator('input[name="numero"]').input_value() == '1.5'
            await browser.close()
    asyncio.run(run())


@pytest.mark.skipif(not Path('/usr/bin/chromium').exists(), reason='Chromium não instalado neste ambiente')
def test_forum_procura_resposta_em_posts_anteriores_quando_ultimo_nao_tem_botao():
    from playwright.async_api import async_playwright
    from moodle_adapter import open_moodle_forum_reply

    async def run():
        html = '''<!doctype html><html><body>
          <article class="forumpost"><h3>Post inicial</h3><a href="/mod/forum/post.php?reply=12&amp;sesskey=temporary">Responder</a></article>
          <article class="forumpost"><h3>Resposta mais recente</h3><p>Sem controle de resposta.</p></article>
        </body></html>'''
        editor = '<!doctype html><html><body><textarea name="message"></textarea></body></html>'
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox'])
            raw = await browser.new_page()
            await raw.set_content(html)
            page = MoodlePageProxy(raw, f'{SED}/mod/forum/discuss.php?d=12', {
                '/mod/forum/post.php': editor,
            })
            result = await open_moodle_forum_reply(page)
            assert result['ok'] is True
            assert 'reply=12' in page.url
            assert 'sesskey=temporary' in page.url
            await browser.close()
    asyncio.run(run())


@pytest.mark.skipif(not Path('/usr/bin/chromium').exists(), reason='Chromium não instalado neste ambiente')
def test_questao_com_campo_texto_e_iframe_nao_preenche_apenas_um_dos_dois():
    from playwright.async_api import async_playwright

    async def run():
        html = '''<!doctype html><html><body>
          <div class="que qtype_essay" id="question-504-1">
            <div class="qtext">Responda nos dois campos.</div>
            <textarea name="shortanswer"></textarea>
            <iframe title="Editor" srcdoc="<body contenteditable='true' class='mce-content-body'></body>"></iframe>
          </div>
        </body></html>'''
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox'])
            raw = await browser.new_page()
            await raw.set_content(html)
            page = MoodlePageProxy(raw, f'{SED}/mod/quiz/attempt.php?attempt=504')
            result = await apply_moodle_quiz_suggestions(page, [
                {'id': 'question-504-1', 'indice': 0, 'selecionadas': [], 'texto': 'Resposta única'},
            ])
            assert result['confirmadas'] == 0
            assert result['detalhes'][0]['estado'] == 'multiplos_campos_requerem_resposta_por_campo'
            assert await raw.locator('textarea[name="shortanswer"]').input_value() == ''
            frame_body = page.frame_locator('iframe').locator('body[contenteditable="true"]')
            assert (await frame_body.inner_text()).strip() == ''
            await browser.close()
    asyncio.run(run())


def test_fechar_pdf_so_confirma_quando_aba_foi_fechada_e_curso_restaurado(monkeypatch):
    class FakeContext:
        pass

    class FakePage:
        def __init__(self, url, fail_close=False):
            self.url = url
            self._closed = False
            self.fail_close = fail_close
            self.context = FakeContext()
            self.fronted = False

        def is_closed(self):
            return self._closed

        async def close(self):
            if self.fail_close:
                raise RuntimeError('falha simulada de fechamento')
            self._closed = True

        async def bring_to_front(self):
            self.fronted = True

    async def run():
        pdf = FakePage(f'{SED}/pluginfile.php/1/teste.pdf')
        course = FakePage(f'{SED}/course/view.php?id=90')
        monkeypatch.setattr(servidor, 'moodle_pdf_page', pdf)
        monkeypatch.setattr(servidor, 'moodle_pdf_return_page', course)
        monkeypatch.setattr(servidor, 'page', pdf)
        result = await servidor.moodle_close_pdf()
        assert result['fechado'] is True
        assert result['restaurado'] is True
        assert pdf.is_closed() is True
        assert servidor.page is course
        assert course.fronted is True

        failed_pdf = FakePage(f'{SED}/pluginfile.php/1/teste.pdf', fail_close=True)
        monkeypatch.setattr(servidor, 'moodle_pdf_page', failed_pdf)
        monkeypatch.setattr(servidor, 'moodle_pdf_return_page', course)
        failure = await servidor.moodle_close_pdf()
        assert failure['fechado'] is False
        assert failure['ok'] is False
        assert servidor.moodle_pdf_page is failed_pdf

    asyncio.run(run())


def test_extracao_pdf_com_texto_e_pdf_sem_texto_reporta_legibilidade():
    from io import BytesIO
    reportlab_canvas = pytest.importorskip('reportlab.pdfgen.canvas')
    canvas = reportlab_canvas.Canvas

    readable = BytesIO()
    pdf = canvas(readable)
    pdf.drawString(72, 720, 'Conteudo para auditoria do PDF')
    pdf.showPage()
    pdf.save()
    result = servidor._extract_moodle_pdf_bytes(readable.getvalue())
    assert result['ok'] is True and result['legivel'] is True
    assert 'Conteudo para auditoria do PDF' in result['texto']
    assert result['paginas'] == 1

    empty = BytesIO()
    blank = canvas(empty)
    blank.showPage()
    blank.save()
    result_blank = servidor._extract_moodle_pdf_bytes(empty.getvalue())
    assert result_blank['ok'] is True and result_blank['legivel'] is False
    assert 'OCR não está habilitado' in result_blank['aviso']


@pytest.mark.skipif(not Path('/usr/bin/chromium').exists(), reason='Chromium não instalado neste ambiente')
def test_forum_listagem_abre_discussao_antes_de_tentar_gerar_rascunho():
    from playwright.async_api import async_playwright
    from moodle_adapter import open_moodle_discussion_from_listing

    async def run():
        listing = '''<!doctype html><html><body>
          <a href="/mod/forum/discuss.php?d=77">Tema da discussão</a>
        </body></html>'''
        discussion = '''<!doctype html><html><body>
          <article class="forumpost"><h3>Enunciado do fórum</h3><p>Debata os efeitos da tecnologia na educação.</p>
          <a href="/mod/forum/post.php?reply=77">Responder</a></article>
        </body></html>'''
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox'])
            raw = await browser.new_page()
            await raw.set_content(listing)
            page = MoodlePageProxy(raw, f'{SED}/mod/forum/view.php?id=7', {
                '/mod/forum/discuss.php': discussion,
            })
            result = await open_moodle_discussion_from_listing(page)
            assert result['ok'] is True
            assert result['ja_estava_em_discussao'] is False
            assert page.url.endswith('/mod/forum/discuss.php?d=77')
            overview = await inspect_moodle_page(page)
            post = overview['forum']['posts'][0]
            assert post['podeResponder'] is True
            assert 'Debata os efeitos' in post['texto']
            await browser.close()
    asyncio.run(run())


def test_quiz_com_mais_de_25_questoes_e_dividido_em_lotes_sem_perder_ids(monkeypatch):
    calls = []

    def fake_suggest(batch, material):
        calls.append([item['id'] for item in batch])
        return [{'id': item['id'], 'indice': item['indice'], 'selecionadas': [0], 'texto': '',
                 'justificativa': 'Base de teste', 'confianca': 'alta'} for item in batch]

    monkeypatch.setattr(servidor, 'suggest_moodle_quiz', fake_suggest)
    questions = [{'id': f'q{i}', 'indice': i, 'texto': f'Pergunta {i}', 'estado': 'nao_respondida'} for i in range(28)]
    async def run():
        suggestions, used = await servidor._generate_moodle_quiz_suggestions_in_batches(questions, 'Material', 1)
        assert len(suggestions) == 28
        assert used == 2
        assert [len(call) for call in calls] == [25, 3]
        assert [row['id'] for row in suggestions] == [f'q{i}' for i in range(28)]
    asyncio.run(run())


def test_ia_quiz_reconhece_indice_de_opcao_nao_contiguo(monkeypatch):
    import auto_ia
    captured = {}

    def fake_request(prompt, cfg, **kwargs):
        captured['prompt'] = prompt
        return '{"respostas":[{"id":"q1","indice":0,"selecionadas":[1],"texto":"","justificativa":"Rótulo disponível","confianca":"alta"}]}'

    monkeypatch.setattr(auto_ia, 'settings', lambda: {'EC_IA_PROVEDOR': 'openai', 'EC_IA_CHAVE': 'test-key'})
    monkeypatch.setattr(auto_ia, '_request_text', fake_request)
    result = auto_ia.suggest_moodle_quiz([{
        'id': 'q1', 'indice': 0, 'texto': 'Selecione a resposta correta', 'tipo': 'multichoice',
        'opcoes': [{'indice': 1, 'tipo': 'radio', 'texto': 'Resposta B'}], 'campos': [], 'estado': 'nao_respondida'
    }])
    assert result[0]['selecionadas'] == [1]
    assert 'nunca os renumere' in captured['prompt']
