import asyncio
import json
from unittest.mock import AsyncMock

import pytest

import auto_ia


@pytest.fixture(autouse=True)
def isolated_inference_cache(monkeypatch):
    monkeypatch.setattr(auto_ia, 'settings', lambda: {
        'EC_IA_PROVEDOR': 'ollama', 'EC_IA_MODELO': 'test-model',
    })
    auto_ia._INFERENCE_CACHE.clear()
    yield
    auto_ia._INFERENCE_CACHE.clear()


def suggestion(*args):
    raise AssertionError('The test runner must provide the result without network access')


def test_invalid_quiz_suggestion_is_not_cached():
    async def scenario():
        runner = AsyncMock(return_value=['only'])
        validate = lambda values: len(values[0].replace(' ', '')) == 6
        for _ in range(3):
            assert await auto_ia.run_inference(suggestion, 'same question',
                runner=runner, validator=validate) == ['only']
        assert runner.await_count == 3
        assert not auto_ia._INFERENCE_CACHE
    asyncio.run(scenario())


def test_invalid_existing_cache_is_evicted_and_valid_response_reused():
    async def scenario():
        runner = AsyncMock(side_effect=[['only'], ['only if']])
        await auto_ia.run_inference(suggestion, 'same question', runner=runner)
        validate = lambda values: values == ['only if']
        result = await auto_ia.run_inference(suggestion, 'same question',
            runner=runner, validator=validate)
        assert result == ['only if']
        result[0] = 'changed by caller'
        assert await auto_ia.run_inference(suggestion, 'same question',
            runner=runner, validator=validate) == ['only if']
        assert runner.await_count == 2
        assert list(auto_ia._INFERENCE_CACHE.values()) == [['only if']]
    asyncio.run(scenario())


def test_unknown_answer_is_never_cached():
    async def scenario():
        runner = AsyncMock(return_value=['?'])
        await auto_ia.run_inference(suggestion, 'same question', runner=runner)
        await auto_ia.run_inference(suggestion, 'same question', runner=runner)
        assert runner.await_count == 2
        assert not auto_ia._INFERENCE_CACHE
    asyncio.run(scenario())


def test_prompt_preserves_rejections_and_letter_constraints(monkeypatch):
    requests = []
    def request(prompt, config, **kwargs):
        requests.append((prompt, kwargs))
        return '{"respostas":["only if"]}'
    monkeypatch.setattr(auto_ia, '_request_text', request)
    rejected = ['old answer', 'a'*80, 'b'*80, 'only', 'only when']
    hint = '6 letras; padrão: o_____; ' + 'x'*180
    result = auto_ia.suggest([{
        'label': 'Palavra que falta',
        'contexto': 'Adverb:somente She says, "___ you are having some yourself."',
        'placeholder': hint,
        'rejeitadas': rejected,
        'letras_disponiveis': 'iyfln',
        'tamanhos_palavras': [4, 2],
    }], 'duplicate context')
    assert result == ['only if']
    prompt, options = requests[0]
    payload = json.loads(prompt.split('\n\n', 1)[1])
    item = payload['campos'][0]
    assert item['rejeitadas'] == rejected[-4:]
    assert item['letras_disponiveis'] == 'iyfln'
    assert item['tamanhos_palavras'] == [4, 2]
    assert item['dica'] == hint
    assert payload['contexto_visivel'] == ''
    assert options['num_predict'] >= 32


def test_local_response_schema_matches_number_of_fields(monkeypatch):
    monkeypatch.setattr(auto_ia,'settings',lambda:{'EC_IA_PROVEDOR':'ollama','EC_IA_MODELO':'test-model'})
    requests=[]
    def post(url,payload,headers,**kwargs):
        requests.append(payload)
        return {'message':{'content':'{"respostas":["boot"]}'}}
    monkeypatch.setattr(auto_ia,'_post_json',post)
    assert auto_ia.suggest([{'contexto':'We call it a ___.','placeholder':'4 letras; padrão: b___'}],'')==['boot']
    array=requests[0]['format']['properties']['respostas']
    assert array['minItems']==array['maxItems']==1
