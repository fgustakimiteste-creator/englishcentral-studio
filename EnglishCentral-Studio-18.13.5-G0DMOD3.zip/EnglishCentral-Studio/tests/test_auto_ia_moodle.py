import json

import pytest

import auto_ia


def sample_draft(**updates):
    data = {
        'resposta': 'A resposta explica a ideia principal com base no material apresentado.',
        'explicacao': 'A pergunta pede uma explicação do conceito.',
        'fundamentacao': 'O material destaca a ideia principal.',
        'pontos_a_conferir': '',
        'confianca': 'media',
    }
    data.update(updates)
    return json.dumps(data, ensure_ascii=False)


def test_draft_moodle_uses_only_ollama_and_material_local(monkeypatch):
    prompts = []
    monkeypatch.setattr(auto_ia, 'settings', lambda: {
        'EC_IA_PROVEDOR': 'ollama', 'EC_IA_MODELO': 'qwen2.5:3b',
        'EC_IA_URL': 'http://127.0.0.1:11434',
    })

    def fake_request(prompt, cfg, **kwargs):
        prompts.append((prompt, cfg, kwargs))
        return sample_draft()

    monkeypatch.setattr(auto_ia, '_request_text', fake_request)
    result = auto_ia.draft_moodle_answer(
        'Explique a importância da preservação ambiental.',
        'A aula destaca a conservação da biodiversidade.',
        'desenvolvida',
    )

    assert result['resposta'].startswith('A resposta explica')
    prompt, cfg, kwargs = prompts[0]
    assert 'preservação ambiental' in prompt
    assert 'conservação da biodiversidade' in prompt
    assert cfg['EC_IA_PROVEDOR'] == 'ollama'
    assert kwargs['num_predict'] == 560
    assert kwargs['schema']['additionalProperties'] is False


def test_draft_moodle_aceita_provedor_openai_com_api_configurada(monkeypatch):
    prompts = []
    monkeypatch.setattr(auto_ia, 'settings', lambda: {
        'EC_IA_PROVEDOR': 'openai', 'EC_IA_CHAVE': 'sk-test-placeholder',
        'EC_IA_MODELO': 'gpt-5.4-mini',
    })

    def fake_request(prompt, cfg, **kwargs):
        prompts.append((prompt, cfg, kwargs))
        return sample_draft(
            resposta=('A fotossíntese transforma energia luminosa em energia química. '
                      'Nesse processo, plantas utilizam água e dióxido de carbono para produzir glicose e liberar oxigênio. '
                      'A glicose contribui para o crescimento e o metabolismo vegetal.')
        )

    monkeypatch.setattr(auto_ia, '_request_text', fake_request)
    result = auto_ia.draft_moodle_answer('Explique a importância da fotossíntese nas plantas.')
    assert 'fotossíntese' in result['resposta'].lower()
    assert prompts[0][1]['EC_IA_PROVEDOR'] == 'openai'
    assert prompts[0][2]['num_predict'] == 560


def test_draft_moodle_valida_enunciado_e_formato(monkeypatch):
    monkeypatch.setattr(auto_ia, 'settings', lambda: {'EC_IA_PROVEDOR': 'ollama'})
    with pytest.raises(RuntimeError, match='enunciado'):
        auto_ia.draft_moodle_answer('oi')
    with pytest.raises(RuntimeError, match='Formato'):
        auto_ia.draft_moodle_answer('Explique o ciclo da água.', formato='longa')


def test_parser_draft_invalido_nao_passar_em_silencio():
    with pytest.raises(RuntimeError, match='JSON válido'):
        auto_ia._parse_moodle_draft('isso não é json')
    with pytest.raises(RuntimeError, match='não conseguiu formular'):
        auto_ia._parse_moodle_draft(sample_draft(resposta=''))


def test_parser_draft_normaliza_confianca_desconhecida():
    parsed = auto_ia._parse_moodle_draft(sample_draft(confianca='certeza absoluta'))
    assert parsed['confianca'] == 'baixa'


def test_autotune_classifica_tipos_de_questao():
    assert auto_ia.classify_moodle_question('Compare as fontes renováveis e não renováveis de energia.')['tipo'] == 'comparacao'
    assert auto_ia.classify_moodle_question('Calcule a área do triângulo.')['tipo'] == 'calculo'
    assert auto_ia.classify_moodle_question('Na sua opinião, como combater o bullying?')['tipo'] == 'opiniao'


def test_material_longo_prioriza_trechos_relacionados():
    material = (
        'A história da arte apresenta vários movimentos culturais e estilos de pintura. ' * 12
        + 'A fotossíntese é o processo pelo qual as plantas usam luz, água e gás carbônico para produzir glicose e liberar oxigênio. '
        + 'A respiração celular libera energia a partir da glicose.'
    )
    selected = auto_ia._select_relevant_material('Explique como ocorre a fotossíntese nas plantas.', material, 1400)
    assert 'fotossíntese' in selected.lower()
    assert len(selected) <= 1400


def test_autotune_usa_uma_geracao_quando_qualidade_esta_boa(monkeypatch):
    prompts = []
    monkeypatch.setattr(auto_ia, 'settings', lambda: {
        'EC_IA_PROVEDOR': 'ollama', 'EC_IA_MODELO': 'qwen2.5:3b',
        'EC_IA_URL': 'http://127.0.0.1:11434',
    })
    answer = sample_draft(
        resposta=('As fontes renováveis, como a energia solar e eólica, se recompõem naturalmente. '
                  'Já as fontes não renováveis, como petróleo e carvão, existem em quantidade limitada '
                  'e levam muito tempo para se formar. Por isso, a principal diferença está na capacidade '
                  'de reposição e na disponibilidade desses recursos.'),
        explicacao='A comparação considera a reposição natural e a disponibilidade de cada fonte.',
        fundamentacao='O material distingue fontes renováveis e não renováveis e apresenta exemplos.',
        confianca='alta',
    )

    def fake_request(prompt, cfg, **kwargs):
        prompts.append((prompt, kwargs))
        return answer

    monkeypatch.setattr(auto_ia, '_request_text', fake_request)
    result = auto_ia.draft_moodle_answer(
        'Compare as fontes renováveis e não renováveis de energia.',
        'As fontes renováveis se recompõem naturalmente, como solar e eólica. As fontes não renováveis são limitadas, como petróleo e carvão.',
        'desenvolvida',
    )
    assert len(prompts) == 1
    assert result['tipo_pergunta'] == 'comparacao'
    assert result['qualidade'] >= 80
    assert result['avaliacao_heuristica'] is True
    assert 'verificada' not in result  # pontuação heurística não comprova correção factual
    assert result['revisada'] is False
    assert prompts[0][1]['ollama_options']['temperature'] <= 0.2


def test_autotune_revisa_uma_vez_quando_rascunho_e_generico(monkeypatch):
    prompts = []
    monkeypatch.setattr(auto_ia, 'settings', lambda: {
        'EC_IA_PROVEDOR': 'ollama', 'EC_IA_MODELO': 'qwen2.5:3b',
        'EC_IA_URL': 'http://127.0.0.1:11434',
    })
    weak = sample_draft(resposta='É muito importante.', confianca='alta')
    improved = sample_draft(
        resposta=('A fotossíntese permite que as plantas produzam glicose usando a energia da luz solar. '
                  'Nesse processo, água e gás carbônico são utilizados, e o oxigênio é liberado no ambiente. '
                  'Assim, a fotossíntese contribui para a nutrição das plantas e para a manutenção do oxigênio.'),
        explicacao='A resposta descreve os elementos e o resultado do processo.',
        fundamentacao='O material apresenta luz, água, gás carbônico, glicose e liberação de oxigênio.',
        confianca='alta',
    )

    def fake_request(prompt, cfg, **kwargs):
        prompts.append(prompt)
        return weak if len(prompts) == 1 else improved

    monkeypatch.setattr(auto_ia, '_request_text', fake_request)
    result = auto_ia.draft_moodle_answer(
        'Explique como ocorre a fotossíntese nas plantas.',
        'A fotossíntese usa luz, água e gás carbônico para produzir glicose e liberar oxigênio.',
        'desenvolvida',
    )
    assert len(prompts) == 2
    assert 'problemas_detectados' in prompts[1]
    assert result['revisada'] is True
    assert 'fotossíntese' in result['resposta'].lower()


def test_feedback_local_aprende_sem_armazenar_conteudo(tmp_path, monkeypatch):
    monkeypatch.setenv('EC_DATA_DIR', str(tmp_path))
    question = 'Explique o ciclo da água na natureza.'
    first = auto_ia.record_moodle_feedback(question, 'mais_detalhes')
    second = auto_ia.record_moodle_feedback(question, 'mais_detalhes')
    assert first['tipo_pergunta'] == 'explicacao'
    assert second['amostras'] == 2
    profile = auto_ia._read_response_profile('explicacao')
    assert profile['ajuste_detalhe'] > 0
    saved = (tmp_path / 'moodle_ai_feedback.json').read_text(encoding='utf-8')
    assert question not in saved
    assert 'ciclo da água' not in saved


def test_local_openai_compatible_only_loopback(monkeypatch):
    seen = []
    monkeypatch.setattr(auto_ia, '_post_json', lambda url, data, headers, timeout=12: (
        seen.append((url, data, headers)) or {'choices': [{'message': {'content': '{"ok":true}'}}]}
    ))
    cfg = {'EC_IA_PROVEDOR': 'local_openai', 'EC_IA_MODELO': 'qwen-local',
           'EC_IA_URL': 'http://127.0.0.1:1234/v1'}
    assert auto_ia._request_text('teste', cfg) == '{"ok":true}'
    assert seen[0][0] == 'http://127.0.0.1:1234/v1/chat/completions'
    assert seen[0][2] == {}

    cfg['EC_IA_URL'] = 'https://example.com/v1'
    with pytest.raises(RuntimeError, match='somente em loopback|localhost'):
        auto_ia._request_text('teste', cfg)


def test_ia_status_reconhece_servidor_local_compativel(monkeypatch):
    monkeypatch.setattr(auto_ia, 'settings', lambda: {
        'EC_IA_PROVEDOR': 'local_openai', 'EC_IA_MODELO': 'qwen-local',
        'EC_IA_URL': 'http://127.0.0.1:1234/v1',
    })
    status = auto_ia.ia_status()
    assert status['configurada'] is True
    assert status['provedor'] == 'local_openai'


def test_perfil_de_feedback_corrompido_nao_quebra_a_geracao(tmp_path, monkeypatch):
    monkeypatch.setenv('EC_DATA_DIR', str(tmp_path))
    (tmp_path / 'moodle_ai_feedback.json').write_text(
        '{"tarefas":{"explicacao":{"amostras":"inválido","ajuste_detalhe":"NaN"}}}',
        encoding='utf-8',
    )
    profile = auto_ia._read_response_profile('explicacao')
    assert profile['amostras'] == 0
    assert profile['ajuste_detalhe'] == 0
    # Mesmo que o arquivo local tenha sido editado/corrompido, o próximo feedback recupera.
    result = auto_ia.record_moodle_feedback('Explique a importância da água.', 'mais_curta')
    assert result['amostras'] == 1


def test_sugestao_englishcentral_aceita_modelo_local_openai(monkeypatch):
    requests = []
    monkeypatch.setattr(auto_ia, 'settings', lambda: {
        'EC_IA_PROVEDOR': 'local_openai', 'EC_IA_MODELO': 'qwen-local',
        'EC_IA_URL': 'http://127.0.0.1:1234/v1',
    })
    monkeypatch.setattr(auto_ia, '_request_text', lambda prompt, cfg, **kwargs: (
        requests.append(kwargs) or '{"respostas":["because"]}'
    ))
    result = auto_ia.suggest([{'contexto': 'I stayed home ___ it was raining.'}], '')
    assert result == ['because']
    assert requests[0]['ollama_options']['temperature'] == 0.0


def test_ai_config_path_isolated_per_additional_profile(monkeypatch, tmp_path):
    profile_dir = tmp_path / 'pessoa2'
    monkeypatch.setenv('EC_DATA_DIR', str(profile_dir))
    monkeypatch.setenv('EC_PROFILE_ID', 'pessoa2')
    assert auto_ia.config_path() == profile_dir / 'config_ia.local.txt'


def test_ai_config_path_preserves_legacy_main_profile(monkeypatch, tmp_path):
    legacy = auto_ia.ROOT / 'config_ia.local.txt'
    # The current test workspace has no live key file; verify the per-profile
    # path rule without creating or reading a real credential.
    monkeypatch.setenv('EC_DATA_DIR', str(tmp_path / 'principal'))
    monkeypatch.setenv('EC_PROFILE_ID', 'principal')
    assert auto_ia.config_path() == (legacy if legacy.exists() else tmp_path / 'principal' / 'config_ia.local.txt')


def test_suggest_moodle_quiz_aceita_questao_sem_palpite_baixa_confianca(monkeypatch):
    monkeypatch.setattr(auto_ia, 'settings', lambda: {'EC_IA_PROVEDOR': 'ollama', 'EC_IA_MODELO': 'qwen2.5:3b'})
    payload = {'respostas': [{
        'id': 'q1', 'indice': 0, 'selecionadas': [], 'texto': '',
        'justificativa': 'O material disponível não permite determinar a alternativa.',
        'confianca': 'baixa',
    }]}
    monkeypatch.setattr(auto_ia, '_request_text', lambda *a, **k: json.dumps(payload))
    result = auto_ia.suggest_moodle_quiz([{
        'id': 'q1', 'indice': 0, 'texto': 'Qual alternativa depende de um gráfico que não está visível?',
        'opcoes': [{'indice': 0, 'tipo': 'radio', 'texto': 'A'}, {'indice': 1, 'tipo': 'radio', 'texto': 'B'}],
        'campos': [], 'estado': 'nao_respondida',
    }], '')
    assert result[0]['confianca'] == 'baixa'
    assert result[0]['selecionadas'] == []


def test_suggest_moodle_quiz_rejeita_ids_duplicados_ou_questoes_omitidas(monkeypatch):
    monkeypatch.setattr(auto_ia, 'settings', lambda: {'EC_IA_PROVEDOR': 'ollama', 'EC_IA_MODELO': 'qwen2.5:3b'})
    question = {'id': 'q1', 'indice': 0, 'texto': 'Explique um conceito.', 'opcoes': [], 'campos': [{'indice': 0, 'tipo': 'input'}]}
    duplicate = {'respostas': [
        {'id': 'q1', 'indice': 0, 'selecionadas': [], 'texto': 'Resposta um', 'justificativa': '', 'confianca': 'alta'},
        {'id': 'q1', 'indice': 0, 'selecionadas': [], 'texto': 'Resposta dois', 'justificativa': '', 'confianca': 'alta'},
    ]}
    monkeypatch.setattr(auto_ia, '_request_text', lambda *a, **k: json.dumps(duplicate))
    with pytest.raises(RuntimeError, match='duplicado'):
        auto_ia.suggest_moodle_quiz([question, {**question, 'id': 'q2', 'indice': 1}], '')


def test_ultraplinian_moodle_avalia_formato_e_relacao_material_sem_promover_correcao():
    question = {
        'id': 'q1', 'indice': 0,
        'texto': 'Explique como a fotossíntese transforma energia luminosa em energia química.',
        'opcoes': [
            {'indice': 3, 'tipo': 'radio', 'texto': 'Produz glicose com energia luminosa, água e gás carbônico.'},
            {'indice': 7, 'tipo': 'radio', 'texto': 'Consome glicose e libera somente nitrogênio.'},
        ],
    }
    suggestion = {
        'id': 'q1', 'indice': 0, 'selecionadas': [3], 'texto': '',
        'justificativa': 'A alternativa relaciona luz, água, gás carbônico e glicose.',
        'confianca': 'alta',
    }
    quality = auto_ia.score_moodle_quiz_suggestions(
        [question], [suggestion],
        'A fotossíntese utiliza energia luminosa, água e gás carbônico para formar glicose e liberar oxigênio.',
    )
    assert quality['pontuacao'] >= 80
    assert quality['questoes_correspondentes'] == 1
    assert quality['indices_validos'] == 1
    assert quality['avaliacao_heuristica'] is True
    assert quality['nao_comprova_correcao'] is True


def test_autotune_quiz_usa_material_relevante_e_temperatura_por_tarefa(monkeypatch):
    requests = []
    monkeypatch.setattr(auto_ia, 'settings', lambda: {
        'EC_IA_PROVEDOR': 'ollama', 'EC_IA_MODELO': 'qwen2.5:3b',
        'EC_IA_URL': 'http://127.0.0.1:11434',
    })
    payload = {'respostas': [{
        'id': 'q-calculo', 'indice': 0, 'selecionadas': [5], 'texto': '',
        'justificativa': 'A operação corresponde aos dados fornecidos no enunciado.',
        'confianca': 'alta',
    }]}

    def fake_request(prompt, cfg, **kwargs):
        requests.append((prompt, kwargs))
        return json.dumps(payload, ensure_ascii=False)

    monkeypatch.setattr(auto_ia, '_request_text', fake_request)
    irrelevant = 'A pintura modernista teve diferentes movimentos e artistas no século XX. ' * 80
    relevant = 'A fórmula da velocidade média é a distância percorrida dividida pelo tempo gasto.'
    result = auto_ia.suggest_moodle_quiz([{
        'id': 'q-calculo', 'indice': 0,
        'texto': 'Calcule a velocidade média para a distância e o tempo apresentados.',
        'opcoes': [{'indice': 5, 'tipo': 'radio', 'texto': 'Distância dividida pelo tempo.'}],
    }], irrelevant + relevant)
    assert result[0]['selecionadas'] == [5]
    prompt, kwargs = requests[0]
    assert 'velocidade média' in prompt.lower()
    assert kwargs['ollama_options']['temperature'] == 0.03
    assert len(prompt) < 10000
