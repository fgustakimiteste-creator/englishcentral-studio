"""Fluxo do engine em DOM representativo do player, sem conta ou IA externa.

O fixture usa inputs readonly="false" com keydown por letra e validação
automática na última letra, como o componente Angular. Não usa gabarito
privado: a automação só recebe a seleção e a correção exibidas na página.
"""
import asyncio
from unittest.mock import patch

from playwright.async_api import async_playwright

from conftest import chromium_launch_options
from ec_engine import ECState, process_ec_page
from ec_player import inspect_ec_player
import memoria


PLAYER_HTML = r'''<!doctype html><html lang="pt"><head><title>Curso fixture</title>
<style>
ec-activity-app,ec-player-app,ec-video,ec-activity-list,ec-learn-interstitial,
ec-player-transcript,ec-player-word-input,ec-word-definition { display:block }
[hidden] { display:none!important }
input { width:28px;height:30px }
.footer-button,.continue-button,.cta-buttons .button { display:inline-block;padding:12px;cursor:pointer }
video { width:320px;height:150px }
</style></head><body>
<ec-activity-app>
 <ec-player-app>
  <div id="activity-app-container" class="learn-mode">
   <div class="dialog-title">Aula de teste 123</div>
   <ec-video><video src="/dialogs/123/video.mp4" preload="none" id="ns-dialog-123"></video></ec-video>
   <button data-testid="player-play-pause" onclick="window.plays++">Reproduzir</button>
   <div id="exercise"></div>
  </div>
 </ec-player-app>
 <ec-activity-list>
  <button data-testid="player-activity-button" class="activity-list-watch completed">Assista ao vídeo</button>
  <button data-testid="player-activity-button" class="activity-list-learn active">Aprenda as palavras</button>
  <button data-testid="player-activity-button" class="activity-list-speak" onclick="window.speech++">Fale as linhas</button>
  <button data-testid="player-activity-button" class="activity-list-chat" onclick="window.chat++">Converse sobre o vídeo</button>
 </ec-activity-list>
</ec-activity-app>
<button id="switch-lesson">Trocar aula</button>
<script>
 window.plays=0;window.speech=0;window.chat=0;window.enters=0;
 window.continues=0;window.retries=0;window.submissions=[];window.q=0;
 window.vocabulary=['walk','ride'];window.answers=['walk','ride'];
 const exercise=document.querySelector('#exercise');
 function selection(){
   exercise.replaceChildren();
   const el=document.createElement('ec-learn-interstitial');
   for(const word of window.vocabulary){
     const label=document.createElement('span');label.className='orthography-text';
     label.textContent=word;el.append(label,document.createTextNode(' '));
   }
   const start=document.createElement('div');start.className='footer-button';
   start.textContent='Aprenda '+window.vocabulary.length+' palavras';
   start.onclick=renderQuestion;el.append(start);exercise.append(el);
 }
 function renderQuestion(){
   const prefix=window.q===0?'I ':'We ';
   const suffix=window.q===0?' to school.':' our bikes.';
   exercise.innerHTML='<ec-player-transcript><div class="player-transcript-row">'+prefix+
    '<ec-player-word-input></ec-player-word-input>'+suffix+'</div></ec-player-transcript>'+
    '<div class="correct-answer-tooltip" hidden><div class="continue-button">Continuar</div></div>'+
    '<ec-word-definition hidden><div class="word" lang="en"><span class="me-1"></span><span>5</span></div>'+
    '<div class="cta-buttons"><div class="button">Tentar Novamente</div></div></ec-word-definition>';
   const root=exercise.querySelector('ec-player-word-input');
   let checked=false;
   function validate(){
     if(checked)return;
     const fields=[...root.querySelectorAll('input')];
     const word=fields.map(e=>e.value).join('');
     if(word.length!==window.answers[window.q].length)return;
     checked=true;window.submissions.push({q:window.q,word});
     if(word===window.answers[window.q]){
       for(const field of fields){field.classList.add('bg-strong');field.setAttribute('readonly','true')}
       exercise.querySelector('.correct-answer-tooltip').hidden=false;
     }else{
       for(const field of fields)field.classList.add('bg-weak');
       exercise.querySelector('ec-word-definition .me-1').textContent=window.answers[window.q];
       exercise.querySelector('ec-word-definition').hidden=false;
     }
   }
   for(let i=0;i<window.answers[window.q].length;i++){
     const input=document.createElement('input');input.className='char-input'+(i===0?' focused':'');
     input.maxLength=1;input.setAttribute('readonly','false');
     input.addEventListener('keydown',e=>{
       if(e.key.length===1&&/[a-z]/i.test(e.key)&&!checked){
         e.preventDefault();input.value=e.key.toLowerCase();
         for(const f of root.querySelectorAll('input'))f.classList.remove('focused');
         const next=root.querySelectorAll('input')[i+1];
         if(next){next.classList.add('focused');next.focus()}
         validate();
       }
     });
     input.addEventListener('keyup',e=>{if(e.key==='Enter'){window.enters++;validate()}});
     root.append(input);
   }
   exercise.querySelector('.continue-button').onclick=()=>{
     window.continues++;window.q++;
     if(window.q<window.answers.length)renderQuestion();
     else{
       document.querySelector('.activity-list-learn').classList.add('completed');
       exercise.innerHTML='<div class="learn-complete-msg">Aprender concluído</div>';
     }
   };
   exercise.querySelector('.cta-buttons .button').onclick=()=>{window.retries++;renderQuestion()};
 }
 document.querySelector('#switch-lesson').onclick=()=>{
   const video=document.querySelector('video');video.setAttribute('src','/dialogs/456/video.mp4');
   video.id='ns-dialog-456';document.querySelector('.dialog-title').textContent='Aula de teste 456';
   window.q=0;window.vocabulary=['jump'];window.answers=['jump'];
   document.querySelector('.activity-list-learn').classList.remove('completed');selection();
 };
 selection();
</script></body></html>'''


async def _page(browser):
    page = await browser.new_page(viewport={"width": 1100, "height": 850})
    # O src do vídeo serve só como identidade DOM; nenhuma mídia é carregada.
    await page.route("**/*", lambda route: route.abort())
    await page.set_content(PLAYER_HTML)
    return page


def test_fluxo_completo_sem_ia_corrige_avanca_e_verifica_etapas(tmp_path, monkeypatch):
    monkeypatch.setattr(memoria, "MEMORY_PATH", tmp_path / "memory.json")

    async def run():
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(**chromium_launch_options())
            try:
                page = await _page(browser)
                state = ECState()
                events = []
                with patch("ec_engine.ia_status", return_value={"configurada": False}), \
                     patch("ec_engine.suggest", side_effect=AssertionError("Não deve usar IA externa")):
                    for _ in range(14):
                        event = await process_ec_page(page, state, submit=True)
                        events.append(event)
                        if event and event["tipo"] == "escopo_concluido":
                            break
                assert events[-1]["tipo"] == "escopo_concluido", events
                assert state.cursor.seen == {"123"}
                assert await page.evaluate("window.submissions") == [
                    {"q": 0, "word": "walk"},
                    {"q": 1, "word": "walk"},
                    {"q": 1, "word": "ride"},
                ]
                assert await page.evaluate("window.continues") == 2
                assert await page.evaluate("window.retries") == 1
                assert await page.evaluate("[window.plays,window.speech,window.chat,window.enters]") == [0, 0, 0, 0]
                snapshot = await inspect_ec_player(page)
                assert snapshot["watch_complete"] and snapshot["learn_complete"]
                memory = memoria.read_memory()
                assert memory["frases"]["i ____ to school."] == "walk"
                assert memory["frases"]["we ____ our bikes."] == "ride"
                assert "ride" in memory["palavras"]
            finally:
                await browser.close()

    asyncio.run(run())


def test_sem_confirmacao_nao_avanca_nem_envia_enter_apos_autovalidacao(tmp_path, monkeypatch):
    monkeypatch.setattr(memoria, "MEMORY_PATH", tmp_path / "memory.json")

    async def run():
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(**chromium_launch_options())
            try:
                page = await _page(browser)
                state = ECState()
                with patch("ec_engine.ia_status", return_value={"configurada": False}):
                    await process_ec_page(page, state, submit=False)  # Identidade
                    await process_ec_page(page, state, submit=False)  # Seleção
                    typed = await process_ec_page(page, state, submit=False)
                    assert typed["tipo"] == "lacuna_video", typed
                    assert typed["enviadas"] is False
                    checked = await process_ec_page(page, state, submit=False)
                    assert checked["tipo"] == "conferencia", checked
                assert (await inspect_ec_player(page))["correct"] is True
                assert await page.evaluate("[window.continues,window.enters,window.plays]") == [0, 0, 0]
                assert state.cursor.seen == set()
            finally:
                await browser.close()

    asyncio.run(run())


def test_troca_de_aula_mesma_url_limpa_tentativa_e_usa_vocabulario_novo(tmp_path, monkeypatch):
    monkeypatch.setattr(memoria, "MEMORY_PATH", tmp_path / "memory.json")

    async def run():
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(**chromium_launch_options())
            try:
                page = await _page(browser)
                original_url = page.url
                state = ECState()
                with patch("ec_engine.ia_status", return_value={"configurada": False}):
                    await process_ec_page(page, state, submit=True)
                    await process_ec_page(page, state, submit=True)
                    first = await process_ec_page(page, state, submit=True)
                    assert first["resposta"] == "walk", first
                    old_question = state.question
                    await page.locator("#switch-lesson").click()
                    assert page.url == original_url
                    identity = await process_ec_page(page, state, submit=True)
                    assert identity["aula_id"] == "dialog:456"
                    assert state.answer == "" and state.question == ""
                    await process_ec_page(page, state, submit=True)  # Seleção nova
                    second = await process_ec_page(page, state, submit=True)
                assert second["tipo"] == "lacuna_video", second
                assert second["resposta"] == "jump"
                assert state.question != old_question
                assert state.lesson == "dialog:456"
                assert state.attempts == ["jump"]
                assert state.cursor.seen == set()
                assert await page.evaluate("[window.plays,window.speech,window.chat]") == [0, 0, 0]
            finally:
                await browser.close()

    asyncio.run(run())


def test_duas_lacunas_consecutivas_com_mesma_assinatura_sao_respondidas(tmp_path, monkeypatch):
    monkeypatch.setattr(memoria, "MEMORY_PATH", tmp_path / "memory.json")
    repeated = PLAYER_HTML.replace(
        "const prefix=window.q===0?'I ':'We ';", "const prefix='I ';"
    ).replace(
        "const suffix=window.q===0?' to school.':' our bikes.';", "const suffix=' to school.';"
    ).replace(
        "window.vocabulary=['walk','ride'];window.answers=['walk','ride'];",
        "window.vocabulary=['walk'];window.answers=['walk','walk'];"
    )

    async def run():
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(**chromium_launch_options())
            try:
                page = await browser.new_page(viewport={"width": 1100, "height": 850})
                await page.route("**/*", lambda route: route.abort())
                await page.set_content(repeated)
                state = ECState()
                events, signatures = [], []
                with patch("ec_engine.ia_status", return_value={"configurada": False}), \
                     patch("ec_engine.suggest", side_effect=AssertionError("Não deve usar IA externa")):
                    for _ in range(15):
                        snapshot = await inspect_ec_player(page)
                        if snapshot.get("question") and not snapshot.get("correct") and not any(snapshot.get("values", [])):
                            signatures.append(snapshot["question_id"])
                        event = await process_ec_page(page, state, submit=True)
                        events.append(event)
                        if event and event["tipo"] == "escopo_concluido":
                            break
                assert len(signatures) >= 2 and len(set(signatures)) == 1
                assert events[-1]["tipo"] == "escopo_concluido", events
                assert await page.evaluate("window.submissions") == [
                    {"q": 0, "word": "walk"}, {"q": 1, "word": "walk"}
                ]
                assert await page.evaluate("[window.continues,window.retries,window.plays,window.speech,window.chat]") == [2, 0, 0, 0, 0]
                assert state.cursor.seen == {"123"}
            finally:
                await browser.close()
    asyncio.run(run())


def test_inicio_no_meio_do_treino_reabre_lista_da_aula_e_resolve_sem_ia(tmp_path, monkeypatch):
    monkeypatch.setattr(memoria, "MEMORY_PATH", tmp_path / "memory.json")

    async def run():
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(**chromium_launch_options())
            try:
                page = await _page(browser)
                await page.locator('.activity-list-learn').evaluate("e=>{window.reopened=0;e.onclick=()=>{window.reopened++;selection()}}")
                await page.evaluate("renderQuestion()")
                state = ECState()
                assert (await inspect_ec_player(page))["question"]
                with patch("ec_engine.ia_status", return_value={"configurada": False}), \
                     patch("ec_engine.suggest", side_effect=AssertionError("Não deve usar IA externa")):
                    await process_ec_page(page, state, submit=True)  # Identidade da aula.
                    reopened = await process_ec_page(page, state, submit=True)
                    assert reopened["tipo"] == "navegacao" and reopened["acao"] == "learn", reopened
                    assert await page.evaluate("window.reopened") == 1
                    assert (await inspect_ec_player(page))["word_selection"]
                    started = await process_ec_page(page, state, submit=True)
                    assert started["acao"] == "iniciar_palavras", started
                    typed = await process_ec_page(page, state, submit=True)
                    assert typed["tipo"] == "lacuna_video" and typed["resposta"] == "walk", typed
                assert state.words["dialog:123"] == ["walk", "ride"]
                assert await page.evaluate("window.submissions") == [{"q": 0, "word": "walk"}]
                assert await page.evaluate("[window.reopened,window.plays,window.speech,window.chat]") == [1, 0, 0, 0]
            finally:
                await browser.close()
    asyncio.run(run())
