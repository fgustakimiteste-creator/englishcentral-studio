"""EnglishCentral Studio: painel local simples, sessão persistente e estudo assistido.

Não contorna login, CAPTCHA, nem fabrica progresso/vídeos/gravações.
"""
from __future__ import annotations

import asyncio
import hmac
import hashlib
import logging
import os
import re
import secrets
import shutil
import time
import urllib.request
from collections import deque
from contextlib import asynccontextmanager
from functools import wraps
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal
from urllib.parse import urlparse


def _android_host() -> bool:
    """Servidor no celular (Termux ou Linux sobre Android). EC_FORCE_DESKTOP=1 desliga, EC_TERMUX=1 força."""
    if os.getenv('EC_FORCE_DESKTOP', '0') == '1':
        return False
    if os.getenv('EC_TERMUX', '0') == '1':
        return True
    return (bool(os.getenv('TERMUX_VERSION')) or 'com.termux' in os.getenv('PREFIX', '') or
            bool(os.getenv('ANDROID_ROOT')) or bool(os.getenv('ANDROID_DATA')) or
            Path('/data/data/com.termux/files/usr').exists() or
            Path('/system/build.prop').exists() or Path('/system/bin/app_process').exists())


DATA_RELOCATED = ''
if (_android_host() and not os.getenv('EC_DATA_DIR') and
        str(Path(__file__).resolve().parent).startswith(('/storage/', '/sdcard', '/mnt/sdcard', '/mnt/media_rw', '/mnt/runtime'))):
    # O armazenamento compartilhado do Android não tem flock nem permissões: dados vão para a pasta interna.
    DATA_RELOCATED = os.getenv('EC_TERMUX_HOME') or str(Path.home() / '.englishcentral-studio')
    os.environ['EC_DATA_DIR'] = DATA_RELOCATED
    os.environ.setdefault('EC_PROFILES_ROOT', DATA_RELOCATED)

from fastapi import Depends, FastAPI, Header, HTTPException
from integracao import inspect_page, fill_selected, toggle_video
from auto_fluxo import process_page, EngineState
from modos import ModoEstudo
from progresso import ProgressoVerificado
from auto_ia import (ia_status, probe_provider, warm_local_model, draft_moodle_answer, record_moodle_feedback,
                     suggest_moodle_quiz, score_moodle_quiz_suggestions, mimi_video_chat)
from recuperacao import Recuperacao
from network_probe import network_available, restore_network_page, NetworkUnavailable
from assistant_preferences import read_preferences, set_warning_preference
from session_actions import issue_context, skip_issue
from fala_preferencias import SpeechPolicy, load_speech_policy, save_speech_policy
from perfis import ProfileManager
from arquivos_locais import file_lock, local_token, write_json_atomic
from browser_session import (choose_page, google_login_url, platform_url, seductec_url,
                             supported_platform_url, session_tab, tab_label, public_url, LOGIN_READY_JS)
from moodle_adapter import (SEDUCTEC_HOME, is_seductec_url, is_direct_moodle_pdf, normalize_seductec_url,
                            inspect_moodle_page, page_kind, platform_info as moodle_platform_info,
                            open_moodle_pdf, open_moodle_forum_reply, open_moodle_discussion_from_listing, fill_moodle_forum_editor,
                            apply_moodle_quiz_suggestions, retry_moodle_quiz,
                            expand_moodle_course_sections,
                            submit_moodle_quiz_attempt, publish_moodle_forum_post)
from moodle_automation import MoodleAutomation
from course_flow import CourseCursor, course_progress, inspect_course
from memoria import read_memory
from playwright.async_api import TimeoutError as BrowserTimeoutError
from fala_sintetica import SYNTHETIC_MIC_INIT
from mobile_app import RemoteConfig, install_mobile_routes
import json
from fastapi.responses import FileResponse, Response
from pydantic import BaseModel, Field, SecretStr

ROOT = Path(__file__).resolve().parent


def is_termux() -> bool:
    """Servidor rodando no próprio celular (Termux)."""
    return _android_host()


TERMUX = is_termux()


def load_remote_config():
    """No Termux o painel é local (127.0.0.1): não exige HTTPS nem endereço externo."""
    try:
        return RemoteConfig.from_env()
    except RuntimeError:
        if TERMUX:
            return RemoteConfig()
        raise


REMOTE_CONFIG = load_remote_config()


def personal_chrome_blocked() -> bool:
    # Só bloqueia o "meu Chrome" quando o servidor está em outra máquina.
    # No Termux o servidor e o Chrome estão no mesmo celular.
    return REMOTE_CONFIG.enabled and not TERMUX


TERMUX_CHROME_HELP = (
    'No Termux não achei um navegador para o assistente usar. '
    'Opção A (usa o Chrome do celular): no Termux rode "pkg install android-tools", ative Opções do '
    'desenvolvedor > Depuração sem fio, faça "adb pair" e "adb connect", depois rode '
    '"adb forward tcp:9222 localabstract:chrome_devtools_remote", deixe o Chrome aberto no curso e '
    'toque em Conectar de novo. '
    'Opção B (navegador próprio): "pkg install x11-repo" e "pkg install chromium", depois use '
    '"Usar sessão do assistente".')
CDP_PORTS_TERMUX = (9222, 9223, 9333)


def _cdp_alive(port: int) -> bool:
    try:
        with urllib.request.urlopen(f'http://127.0.0.1:{port}/json/version', timeout=1.5) as response:
            return response.status == 200
    except (OSError, ValueError):
        return False


async def phone_chrome_endpoint(port=None):
    """Procura o Chrome do celular aberto para conexão local; None se não houver."""
    if port:
        ports = [port]
    else:
        try:
            ports = [int(os.environ['EC_CDP_PORT'])] if os.getenv('EC_CDP_PORT') else list(CDP_PORTS_TERMUX)
        except ValueError:
            ports = list(CDP_PORTS_TERMUX)
    for candidate in ports:
        if await asyncio.to_thread(_cdp_alive, candidate):
            return f'http://127.0.0.1:{candidate}'
    return None


def configured_browser_executable() -> str | None:
    """Executável Chromium configurado explicitamente, com fallback legado."""
    configured = (os.getenv('EC_BROWSER_EXECUTABLE') or os.getenv('EC_CHROMIUM_PATH') or '').strip()
    if not configured:
        return None
    executable = Path(configured).expanduser()
    if not executable.is_file() or (os.name != 'nt' and not os.access(executable, os.X_OK)):
        raise FileNotFoundError(
            'O navegador configurado em EC_BROWSER_EXECUTABLE/EC_CHROMIUM_PATH não existe ou não é executável.'
        )
    return str(executable)


def termux_chromium_path() -> str:
    explicit = configured_browser_executable()
    if explicit:
        return explicit
    for name in ('chromium-browser', 'chromium', 'chrome'):
        found = shutil.which(name)
        if found:
            return found
    return ''

class OpenAIConfig(BaseModel):
    chave: SecretStr

class MoodleDraftRequest(BaseModel):
    pergunta: str = Field(min_length=5, max_length=2000)
    material: str = Field(default='', max_length=8000)
    formato: Literal['curta', 'desenvolvida', 'topicos'] = 'desenvolvida'

class MoodleFeedbackRequest(BaseModel):
    pergunta: str = Field(min_length=5, max_length=2000)
    avaliacao: Literal['boa', 'mais_detalhes', 'mais_curta', 'muito_generica', 'incorreta', 'faltou_material']

class MoodleSettingsRequest(BaseModel):
    # Campos omitidos em um PUT parcial preservam as preferências existentes.
    modo: Literal['tudo', 'pdf', 'forum', 'quiz'] | None = None
    preencher_quiz: bool | None = None
    preencher_forum: bool | None = None
    tentar_novamente: bool | None = None
    enviar_quiz: bool | None = None
    publicar_forum: bool | None = None
    max_tentativas: int | None = Field(default=None, ge=1, le=3)
    agentes: int | None = Field(default=None, ge=1, le=4)

class MoodleQuizAssistRequest(BaseModel):
    aplicar: bool = True
    somente_pendentes: bool = True

class MoodleOpenActivityRequest(BaseModel):
    url: str = Field(min_length=10, max_length=1200)

class MoodleForumFillRequest(BaseModel):
    resposta: str = Field(min_length=1, max_length=6000)

class MoodleOpenPDFRequest(BaseModel):
    url: str = Field(min_length=10, max_length=1200)

class MimiChatRequest(BaseModel):
    mensagem: str = Field(min_length=1, max_length=1200)
    historico: list[dict] = Field(default_factory=list, max_length=8)
    nivel: Literal['A1', 'A2', 'B1', 'B2', 'C1', 'C2'] = 'A2'
    estilo: Literal['curta', 'natural', 'detalhada'] = 'natural'
    idioma_apoio: Literal['pt', 'en', 'bilíngue'] = 'pt'

class MimiSettingsRequest(BaseModel):
    nivel: Literal['A1', 'A2', 'B1', 'B2', 'C1', 'C2'] | None = None
    estilo: Literal['curta', 'natural', 'detalhada'] | None = None
    idioma_apoio: Literal['pt', 'en', 'bilíngue'] | None = None

class MoodleAutomationStartRequest(BaseModel):
    agentes: int = Field(default=2, ge=1, le=4)
    incluir_materiais: bool = True

DATA = Path(os.getenv('EC_DATA_DIR', str(ROOT / '.dados_locais')))
PROFILES_ROOT = Path(os.getenv('EC_PROFILES_ROOT', str(ROOT / '.dados_locais')))
PROFILE_ID = os.getenv('EC_PROFILE_ID', 'pessoa2' if DATA == PROFILES_ROOT / 'pessoa2' else 'principal')
PROFILE = DATA / 'perfil_chromium'
TOKEN_FILE = DATA / 'token_painel.txt'
STUDY_FILE = DATA / 'estudo_local.json'
PROGRESS_FILE = DATA / 'progresso_verificado.json'
COURSE_URL = 'https://pt.englishcentral.com/course/8597'
ENGLISHCENTRAL_CLASS_URL = 'https://pt.englishcentral.com/myclass/232103/0/courses'
COURSE_FILE = DATA / 'ultimo_curso.txt'
LAST_TARGET_FILE = DATA / 'ultimo_destino.txt'

def course_url(url=''):
    parsed = urlparse(url)
    match = re.match(r'^/course/(\d+)(?:/|$)', parsed.path)
    if parsed.scheme == 'https' and parsed.hostname == 'pt.englishcentral.com' and match:
        result = 'https://pt.englishcentral.com/course/' + match.group(1)
        DATA.mkdir(exist_ok=True)
        if not COURSE_FILE.exists() or COURSE_FILE.read_text(encoding='utf-8') != result:
            COURSE_FILE.write_text(result, encoding='utf-8')
        return result
    if COURSE_FILE.exists():
        saved = COURSE_FILE.read_text(encoding='utf-8').strip()
        if re.fullmatch(r'https://pt\.englishcentral\.com/course/\d+', saved):
            return saved
    return COURSE_URL


def englishcentral_class_url_is_valid(url: str) -> bool:
    parsed = urlparse(str(url))
    return (parsed.scheme == 'https' and parsed.hostname == 'pt.englishcentral.com'
            and re.fullmatch(r'/myclass/[0-9]{1,12}/[0-9]{1,4}/courses/?', parsed.path) is not None)


def target_url(url=''):
    """Destino persistente da sessão: curso/área MyClass do EC ou página oficial SEDUCTEC."""
    candidate = str(url or '').strip()
    if candidate:
        if course_url_is_valid(candidate):
            result = course_url(candidate)
        elif englishcentral_class_url_is_valid(candidate):
            result = candidate
        elif is_seductec_url(candidate):
            result = normalize_seductec_url(candidate)
        else:
            raise ValueError('Use um link HTTPS do EnglishCentral ou do SEDUCTEC oficial.')
        DATA.mkdir(mode=0o700, parents=True, exist_ok=True)
        target_file = DATA / LAST_TARGET_FILE.name
        target_file.write_text(result, encoding='utf-8')
        return result
    target_file = DATA / LAST_TARGET_FILE.name
    if target_file.exists():
        saved = target_file.read_text(encoding='utf-8').strip()
        if course_url_is_valid(saved):
            return course_url(saved)
        if englishcentral_class_url_is_valid(saved):
            return saved
        if is_seductec_url(saved):
            return normalize_seductec_url(saved)
    return course_url()


def course_url_is_valid(url: str) -> bool:
    parsed = urlparse(str(url))
    return (parsed.scheme == 'https' and parsed.hostname == 'pt.englishcentral.com'
            and re.fullmatch(r'/course/\d+/?', parsed.path) is not None)


def selected_target(url='') -> str:
    """Aplica a validação estrita usada pelo seletor de destino."""
    if course_url_is_valid(url):
        return course_url(url)
    if englishcentral_class_url_is_valid(url):
        return str(url).split('#', 1)[0]
    if is_seductec_url(url):        return normalize_seductec_url(url)
    raise ValueError('O link deve ser um curso EnglishCentral, a área MyClass permitida ou o SEDUCTEC oficial.')


def page_platform(url: str) -> dict:
    if is_seductec_url(url):
        return moodle_platform_info(url)
    if platform_url(url):
        return {'id': 'englishcentral', 'nome': 'EnglishCentral',
                'automacao_especifica': True,
                'ferramentas': ['navegacao', 'pre_visualizacao', 'leitura', 'inspecao', 'video', 'automacao_englishcentral']}
    return {'id': 'desconhecida', 'nome': 'Página não reconhecida',
            'automacao_especifica': False, 'ferramentas': ['navegacao', 'pre_visualizacao', 'leitura', 'inspecao']}

VIEWPORT = {'width': 1280, 'height': 800}

@asynccontextmanager
async def lifespan(app):
    try:
        yield
    finally:
        global context, page, browser_driver, last_snapshot, auto_running, auto_task
        auto_running = False
        if auto_task is not None:
            auto_task.cancel()
            try:
                await auto_task
            except asyncio.CancelledError:
                pass
        last_snapshot = None
        await moodle_automation.shutdown()
        await dispose_browser_session()


app = FastAPI(title='EnglishCentral Studio — V18.13.1 Automação paralela SEDUCTEC', docs_url=None, redoc_url=None, lifespan=lifespan)
lock = asyncio.Lock()
auto_control_lock = asyncio.Lock()
context = None
page = None
browser_driver = None
moodle_pdf_page = None
moodle_pdf_return_page = None
preview_scroll_ratio = 0.0
moodle_automation = MoodleAutomation()
entries = deque(maxlen=120)
last_snapshot = None
auto_task = None
auto_running = False
auto_submit = False
auto_mode = ModoEstudo()
stop_confirmation = None
stop_confirmation_event = None
AUTO_RETRY_SECONDS = 10
AUTO_RETRY_LIMIT = 3
auto_retry_counts = {}
connection_health = {'estado':'desconhecida','latencia_ms':None}
activity_attempt = {'em_andamento':False,'inicio':None}
browser_owned = True
browser_channel = ''
connected_browser = None
browser_lease = None
browser_tabs = {}
browser_parents = {}
browser_events = set()
browser_fault = None
browser_serial = 0
auto_latest = {'tipo': 'parado', 'mensagem': 'Pronto para começar.'}
auto_counts = {'ciclos': 0, 'lacunas': 0}
# Ações repetidas sem progresso não podem consumir CPU/IA indefinidamente.
STALL_LIMIT_SECONDS = 45
BROWSER_READ_TIMEOUT = 45
BROWSER_ACTION_TIMEOUT = 30
BROWSER_START_TIMEOUT = 45
MODEL_WARMUP_TIMEOUT = 15
LOGIN_CHECK_SECONDS = 1
MIC_RELEASE_TIMEOUT_SECONDS = 3
HALT_RESULTS = {'escopo_pulado', 'video_atencao', 'escopo_concluido', 'ajuda', 'login', 'verificacao', 'fora',
                'sem_ia', 'erro_ia', 'incerto', 'campo', 'lacuna_sem_texto', 'lacuna_sem_campo'}
last_word_start = {'pagina': '', 'quando': 0.0}


def progress_scope(mode: ModoEstudo) -> tuple[str, ...]:
    # A unidade só pode ser reutilizada se também incluiu os quizzes selecionados.
    return mode.etapas + (('quizzes',) if mode.quiz else ()) + (('activities',) if mode.activities else ())


def get_token() -> str:
    env_token = os.getenv('EC_PANEL_TOKEN', '').strip()
    if env_token:
        if len(env_token) < 16:
            raise RuntimeError('EC_PANEL_TOKEN deve conter pelo menos 16 caracteres.')
        return env_token
    DATA.mkdir(mode=0o700, parents=True, exist_ok=True)
    try:
        os.chmod(DATA, 0o700)
    except OSError:
        pass
    return local_token(TOKEN_FILE)


def require_auth(x_ec_token: str | None = Header(default=None)):
    expected = get_token()
    if not x_ec_token or not hmac.compare_digest(x_ec_token, expected):
        raise HTTPException(401, 'Token inválido. Confira o token do servidor.')
    return True


def record(message: str):
    entries.append({'horario': datetime.now(timezone.utc).isoformat(), 'evento': message})


def browser_deadline(setting='BROWSER_READ_TIMEOUT', *, read_only=False):
    """Cancelar a requisição cancela também o trabalho e libera seu lock."""
    def decorate(function):
        @wraps(function)
        async def bounded(*args,**kwargs):
            global browser_fault
            try:
                # Leituras aguardam a operação corrente em vez de falhar com 409.
                # Isso evita o aviso repetido no painel móvel enquanto o agente navega,
                # lê um PDF ou aplica respostas. O timeout continua protegendo a sessão.
                return await asyncio.wait_for(function(*args,**kwargs),timeout=globals()[setting])
            except (asyncio.TimeoutError,BrowserTimeoutError) as exc:
                browser_fault={'operacao':function.__name__,'quando':time.time(),
                    'mensagem':'O navegador demorou a responder. A espera foi liberada para permitir a retomada.'}
                record(browser_fault['mensagem'])
                raise HTTPException(504,browser_fault['mensagem']) from exc
        return bounded
    return decorate


def available_pages(*,all_contexts=False):
    try:
        if all_contexts and not browser_owned and connected_browser is not None:
            return [p for c in connected_browser.contexts for p in c.pages]
        return list(context.pages) if context is not None else []
    except Exception:return []


def current_page():
    global context,page,last_snapshot
    if page is not None and not page.is_closed():return page
    preferred=getattr(page,'url',COURSE_URL) if page is not None else COURSE_URL
    candidate=choose_page(available_pages(),page,preferred)
    if candidate is None:
        raise HTTPException(409, 'Abra primeiro a sessão do navegador.')
    if candidate is not page:
        page=candidate;last_snapshot=None
        if not browser_owned:context=candidate.context
        record('Aba do curso recuperada na sessão já aberta.')
    return candidate


class FillField(BaseModel):
    frame: int = Field(ge=0, le=14)
    id: str = Field(pattern=r'^[1-9][0-9]?$')
    resposta: str = Field(min_length=1, max_length=250)


class VideoAction(BaseModel):
    frame: int = Field(ge=0, le=14)
    id: str = Field(pattern=r'^[1-9][0-9]?$')
    acao: Literal['play', 'pause']


class StudyNote(BaseModel):
    observacao: str = Field(default='', max_length=400)


def local_study() -> dict:
    if STUDY_FILE.exists():
        try:
            data = json.loads(STUDY_FILE.read_text('utf-8'))
            if isinstance(data, dict) and isinstance(data.get('paginas'), list):
                return data
        except (ValueError, OSError):
            pass
    return {'paginas': []}


def save_study(data: dict):
    DATA.mkdir(mode=0o700, exist_ok=True)
    temp = STUDY_FILE.with_suffix('.tmp')
    temp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    os.chmod(temp, 0o600)
    temp.replace(STUDY_FILE)


class Tap(BaseModel):
    x: float = Field(ge=0, le=10000)
    y: float = Field(ge=0, le=10000)


class InputText(BaseModel):
    text: str = Field(max_length=2000)


class KeyInput(BaseModel):
    key: Literal['Enter', 'Tab', 'Escape', 'Backspace', 'ArrowUp', 'ArrowDown', 'Space']


class ScrollInput(BaseModel):
    amount: int = Field(ge=-2500, le=2500)

class ScrollToInput(BaseModel):
    progress: float = Field(ge=0, le=100)


class CourseUnit(BaseModel):
    id: str = Field(pattern=r'^[A-Za-z0-9_-]{1,80}$')

class CourseSelection(BaseModel):
    ano: int = Field(ge=1, le=3)
    etapa: int = Field(ge=1, le=4)
    url: str = Field(default='', max_length=1200)

@app.post('/api/course/select', dependencies=[Depends(require_auth)])
@browser_deadline('BROWSER_ACTION_TIMEOUT')
async def select_course(action: CourseSelection):
    """Seleciona o ambiente sem substituir a aba do outro portal na mesma sessão."""
    global page, context, last_snapshot
    file = DATA / 'cursos_selecionados.json'
    mapping = json.loads(file.read_text('utf-8')) if file.exists() else {}
    slot = f'{action.ano}:{action.etapa}'
    url = action.url.strip() or mapping.get(slot, '')
    try:
        url = selected_target(url)
        url = target_url(url)
    except ValueError as exc:
        raise HTTPException(400, 'Cole um link HTTPS de curso do EnglishCentral ou uma página do domínio oficial seductec.seduc.pi.gov.br.') from exc
    await pause_for_manual_action()
    if page is None or page.is_closed():
        await open_browser()
    async with lock:
        try:
            active = current_page()
        except HTTPException:
            active = None
        # Não procurar em outros BrowserContexts: eles podem representar outra conta/sessão.
        # As duas plataformas são abas irmãs dentro do contexto do perfil atual.
        candidates = available_pages()
        if active is not None and active not in candidates:
            candidates.insert(0, active)
        else:
            candidates = ([active] if active is not None else []) + [candidate for candidate in candidates if candidate is not active]
        target_is_moodle = is_seductec_url(url)

        def is_environment_tab(candidate):
            try:
                if candidate.is_closed():
                    return False
                candidate_url = str(candidate.url or '')
                if target_is_moodle:
                    path = urlparse(candidate_url).path.casefold()
                    # Não confundir a aba temporária do PDF com a aba principal do curso.
                    if path.startswith('/pluginfile.php/') or path.endswith('.pdf'):
                        return False
                    return is_seductec_url(candidate_url)
                return platform_url(candidate_url)
            except Exception:
                return False

        target_page = next((candidate for candidate in candidates if is_environment_tab(candidate)), None)
        created = False
        if target_page is None:
            base = active or (candidates[0] if candidates else None)
            if base is None:
                raise HTTPException(409, 'Não há uma sessão de navegador ativa. Abra o navegador antes de escolher o curso.')
            try:
                target_page = await base.context.new_page()
                register_tab(target_page)
                created = True
            except Exception as exc:
                raise HTTPException(409, 'Não consegui abrir uma aba separada para este ambiente. Confira se o navegador permite novas abas.') from exc
        try:
            await target_page.goto(url, wait_until='domcontentloaded', timeout=35000)
            page = target_page
            context = target_page.context
            last_snapshot = None
            await target_page.bring_to_front()
        except Exception as exc:
            if created:
                try:
                    await target_page.close()
                except Exception:
                    pass
            raise HTTPException(502, 'Não consegui abrir este ambiente na aba separada. A outra plataforma foi mantida aberta. Confira a conexão e tente novamente.') from exc

        DATA.mkdir(parents=True, exist_ok=True)
        mapping[slot] = url  # compatibilidade com instalações anteriores
        mapping[('seductec' if target_is_moodle else 'englishcentral') + ':' + slot] = url
        file.write_text(json.dumps(mapping, ensure_ascii=False), encoding='utf-8')
        record(('Aba SEDUCTEC selecionada; a aba EnglishCentral foi preservada.' if target_is_moodle else
                'Aba EnglishCentral selecionada; a aba SEDUCTEC foi preservada.') + (' Uma aba nova foi criada.' if created else ' A aba existente foi reutilizada.'))
    message = ('SEDUCTEC aberto em sua própria aba. Faça login no próprio Moodle; a aba do EnglishCentral permanece aberta.'
               if target_is_moodle else
               f'EnglishCentral aberto em sua própria aba: {action.ano}º ano, etapa {action.etapa}. A aba do SEDUCTEC permanece aberta.')
    return {'ok':True, 'mensagem':message, 'aba_nova':created,
            'plataforma': 'seductec' if target_is_moodle else 'englishcentral'}


@app.api_route('/', methods=['GET', 'HEAD'])
async def home():
    return FileResponse(ROOT / 'web' / 'index.html', media_type='text/html', headers={'Cache-Control': 'no-store'})


class AutoStart(BaseModel):
    activities: bool = False
    enviar_automaticamente: bool = False
    assistir: bool = True
    aprender: bool = True
    falar: bool = False
    quiz: bool = True
    conversar: bool = False  # Converse sobre o vídeo (MiMi)


async def pause_for_manual_action() -> None:
    """Interrompe o worker antes de uma interação manual, evitando disputas de foco.

    Chamar sempre FORA de `async with lock` para não provocar deadlock.
    """
    if auto_running and stop_confirmation is not None and stop_confirmation.get('tipo')=='login':
        return  # o worker já aguarda o usuário; digitar o login não cancela a retomada
    if auto_running:
        await auto_stop()
        record('Controle manual ativado: assistente pausado para não disputar o navegador.')


async def request_stop_confirmation(result, context=None):
    """Espera uma escolha ou a tentativa automática sinalizada no painel."""
    global stop_confirmation, stop_confirmation_event, auto_latest
    event = asyncio.Event()
    context=context or {'categoria':'geral','pode_pular':False}
    preferences=read_preferences(DATA/'preferencias_assistente.json')
    request = {'id':secrets.token_hex(12), 'motivo':result.get('mensagem') or 'Esta etapa precisa de atenção.',
               'tipo':result.get('tipo','ajuda'), 'continuar':None, 'acao':None,
               'categoria':context['categoria'], 'pode_pular':context.get('pode_pular',False),
               'alvo':context.get('rotulo',''), 'curso':context.get('curso',''), 'mostrar_novamente':preferences.get(context['categoria'],True)}
    key = repr((result.get('tipo'), context.get('categoria'), context.get('curso'),
                context.get('tipo'), context.get('id'), context.get('linha_id'),
                context.get('pergunta') or request['motivo']))[:4096]
    eligible = result.get('tipo') in {'ajuda', 'erro', 'erro_ia', 'incerto', 'campo',
                                     'lacuna_sem_texto', 'lacuna_sem_campo', 'video_atencao'}
    if any(code in request['motivo'] for code in ('OPENAI_SEM_CREDITO', 'OPENAI_CHAVE_INVALIDA')):
        eligible = False
    count = auto_retry_counts.get(key, 0)
    active = eligible and auto_running and count < AUTO_RETRY_LIMIT
    request['_retry_key'] = key
    request['_retry_deadline'] = asyncio.get_running_loop().time() + AUTO_RETRY_SECONDS if active else None
    request['auto_retry'] = {'ativa': active, 'cancelada': False, 'esgotada': eligible and count >= AUTO_RETRY_LIMIT,
                             'duracao_ms': AUTO_RETRY_SECONDS * 1000,
                             'tentativa': count + 1 if active else count, 'limite': AUTO_RETRY_LIMIT}
    stop_confirmation, stop_confirmation_event = request, event
    auto_latest = {**result, 'tipo':'aguardando_confirmacao',
                   'mensagem':request['motivo'], 'motivo_original':request['tipo']}
    record('Aguardando decisão: '+request['motivo'])
    timer = asyncio.create_task(retry_after_countdown(request, event)) if active else None
    login_watch = asyncio.create_task(resume_after_login(request,event)) if request['tipo']=='login' and auto_running else None
    try:
        await event.wait()
        return 'skip' if request['acao']=='skip' else request['continuar'] is True
    finally:
        if timer is not None:
            if not timer.done():
                timer.cancel()
            await asyncio.gather(timer, return_exceptions=True)
        if login_watch is not None:
            if not login_watch.done():login_watch.cancel()
            await asyncio.gather(login_watch,return_exceptions=True)
        if stop_confirmation is request:
            stop_confirmation, stop_confirmation_event = None, None


async def resume_after_login(request,event):
    while auto_running and stop_confirmation is request and not event.is_set():
        await asyncio.sleep(LOGIN_CHECK_SECONDS)
        try:
            p=current_page()
            if not platform_url(p.url):continue
            if lock.locked():continue
            async with lock:
                ready=await asyncio.wait_for(p.evaluate(LOGIN_READY_JS),timeout=2)
            if ready is not True:continue
        except Exception:
            continue
        async with auto_control_lock:
            if auto_running and stop_confirmation is request and not event.is_set():
                request['acao']='retry';request['continuar']=True;request['origem']='login_concluido'
                record('Curso disponível após o login. Retomando a leitura da atividade.')
                event.set()
        return


def confirmation_status():
    request = stop_confirmation
    if request is None:
        return None
    result = {key: value for key, value in request.items() if not key.startswith('_')}
    plan = dict(request.get('auto_retry', {}))
    deadline = request.get('_retry_deadline')
    plan['restante_ms'] = max(0, (deadline-asyncio.get_running_loop().time()) * 1000) if plan.get('ativa') and deadline else 0
    result['auto_retry'] = plan
    return result


async def retry_after_countdown(request, event):
    try:
        if not request.get('_retry_deadline') or not request['auto_retry']['ativa']:
            return
        delay = max(0, request['_retry_deadline'] - asyncio.get_running_loop().time())
        await asyncio.wait_for(event.wait(), timeout=delay)
        return
    except asyncio.TimeoutError:
        pass
    async with auto_control_lock:
        if (stop_confirmation is not request or stop_confirmation_event is not event or
                not auto_running or request['continuar'] is not None or not request['auto_retry']['ativa']):
            return
        key = request['_retry_key']
        if len(auto_retry_counts) >= 1000 and key not in auto_retry_counts:
            auto_retry_counts.pop(next(iter(auto_retry_counts)))
        auto_retry_counts[key] = auto_retry_counts.get(key, 0) + 1
        request['acao'], request['continuar'], request['origem'] = 'retry', True, 'automatica'
        request['auto_retry']['ativa'] = False
        record(f'Tempo esgotado: tentativa automática {auto_retry_counts[key]}/{AUTO_RETRY_LIMIT}. Relendo a atividade.')
        event.set()


class PendingDecisionOptions(BaseModel):
    solicitacao: str
    tentativa_automatica: Literal[False] | None = None
    mostrar_novamente: bool | None = None


@app.post('/api/auto/decision/options', dependencies=[Depends(require_auth)])
async def pending_decision_options(options: PendingDecisionOptions):
    async with auto_control_lock:
        request = stop_confirmation
        if request is None or request['id'] != options.solicitacao or request['continuar'] is not None:
            raise HTTPException(409, 'Essa solicitação já foi resolvida. Atualize o painel.')
        if options.mostrar_novamente is not None:
            try:
                set_warning_preference(DATA/'preferencias_assistente.json', request['categoria'], options.mostrar_novamente)
            except OSError as exc:
                raise HTTPException(409, 'Não consegui salvar a preferência de aviso.') from exc
            request['mostrar_novamente'] = options.mostrar_novamente
        if options.tentativa_automatica is False:
            request['auto_retry']['ativa'] = False
            request['auto_retry']['cancelada'] = True
            request['_retry_deadline'] = None
        return {'ok': True, 'confirmacao_parada': confirmation_status()}


class StopDecision(BaseModel):
    solicitacao: str
    continuar: bool | None = None
    acao: Literal['retry','skip','stop'] | None = None
    mostrar_novamente: bool = True


@app.post('/api/auto/decision', dependencies=[Depends(require_auth)])
async def auto_decision(decision: StopDecision):
    async with auto_control_lock:
        request, event = stop_confirmation, stop_confirmation_event
        if request is None or event is None or request['id']!=decision.solicitacao or request['continuar'] is not None:
            raise HTTPException(409, 'Essa solicitação já foi resolvida. Atualize o painel.')
        action=decision.acao or ('retry' if decision.continuar is True else 'stop' if decision.continuar is False else None)
        if action is None:raise HTTPException(422,'Escolha tentar novamente, pular ou parar.')
        if action=='skip' and not request.get('pode_pular'):raise HTTPException(409,'Não há uma atividade identificável para pular nesta tela.')
        try:
            set_warning_preference(DATA/'preferencias_assistente.json',request['categoria'],decision.mostrar_novamente)
        except OSError:
            record('Não consegui salvar a preferência do aviso. A escolha da ação será respeitada.')
        request['acao']=action
        request['origem']='usuario'
        if action == 'retry':
            auto_retry_counts.pop(request.get('_retry_key'), None)
        request['continuar'] = action!='stop'
        if action=='stop':
            try:
                ProgressoVerificado(PROGRESS_FILE).registrar_evento(request.get('curso') or course_url().rsplit('/',1)[-1],'parar',request['alvo'],request['motivo'])
            except OSError:
                record('Não consegui salvar a ocorrência, mas o assistente será pausado.')
            await _auto_stop_locked()
        else:
            event.set()
        return {'ok':True,'executando':auto_running}


async def handle_issue(result, engine, progress, course):
    global auto_latest
    if result.get('tipo') not in {'escopo_concluido','escopo_pulado'} and not await network_available(page):
        raise NetworkUnavailable('Sem acesso ao EnglishCentral')
    auto_latest=dict(result)
    try:
        async with lock:
            context=await asyncio.wait_for(issue_context(page,engine,course,result),timeout=5)
    except Exception:
        context={'categoria':'geral','pode_pular':False}
    choice=await request_stop_confirmation(result,context)
    progress.registrar_evento(course,'pular' if choice=='skip' else 'tentar_novamente' if choice else 'parar',
                             context.get('rotulo',''),result.get('mensagem',''))
    if choice=='skip':
        try:
            async with lock:
                skipped=await asyncio.wait_for(skip_issue(page,engine,context),timeout=5)
        except Exception:
            skipped=False
        record('Atividade pulada nesta sessão; permanece pendente.' if skipped else 'A tela mudou; nada foi pulado. Relendo a atividade.')
        if skipped and context.get('tipo') == 'linha_fala':
            progress.registrar_fala(course, context['id'], {**result.get('fala_precisao', {}),
                'linha': context['linha_id'], 'estado': 'pulada_por_usuario', 'pulado': True})
    elif choice and result.get('tipo')=='escopo_pulado':
        cursor=engine.real.cursor
        cursor.visited_units.difference_update(cursor.skipped_units)
        cursor.skipped_units.clear();cursor.skipped_lessons.clear();cursor.skipped_quizzes.clear()
    if choice is True:
        engine.real.cursor.pending_attempts=0
        engine.real.action_attempts=0
        if context.get('categoria')=='video':
            engine.real.video_resumes=0
            engine.real.video_attention_attempted=False
            engine.real.video_position_at=time.monotonic()
        if context.get('tipo')=='unidade':
            cursor=engine.real.cursor;unit=context.get('id')
            cursor.blocked_units.discard(unit);cursor.visited_units.discard(unit)
            cursor.empty_since.pop(unit,None)
            cursor.card_loading_since={key:value for key,value in cursor.card_loading_since.items()
                                       if not key.startswith(str(unit)+':')}
        if context.get('categoria') == 'fala':
            speech = engine.speech_flow
            speech.force_retry = speech.observed
            speech.retry_capture = speech.observed
            speech.sent = speech.pending = speech.error = speech.error_for = speech.retried = ''
            speech.attempts.pop(speech.observed, None)
    return bool(choice)


def restore_saved_scope(cursor, progress, course, mode):
    lessons=progress.concluidas(course,mode.etapas) if mode.etapas else set()
    cursor.seen.update(lessons);cursor.saved_scope_lessons.update(lessons)
    cursor.seen_quizzes.update(progress.quizzes(course))
    units=progress.unidades(course,progress_scope(mode))
    cursor.verified_units.update(units);cursor.visited_units.update(units)


def progress_signature(result,engine,url):
    """Texto de espera/contadores de tentativas não são avanço da atividade."""
    real=engine.real;cursor=real.cursor
    return (url,real.lesson,real.question,engine.last_question,engine.choice_question,
            cursor.current,cursor.current_unit,cursor.pending,
            tuple(sorted((result.get('progresso_etapas') or {}).items())),
            result.get('aula_id'),tuple(sorted(cursor.seen)),tuple(sorted(cursor.seen_quizzes)))


async def auto_worker():
    """Inclui preparação e encerramento no tratamento de falhas do worker."""
    global auto_running, auto_latest
    try:
        while auto_running:
            try:
                await _auto_worker_run()
                break
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                result = {'tipo':'erro', 'mensagem':'Não consegui preparar a sessão ('
                          +type(exc).__name__+'). Confira a configuração antes de continuar.'}
                logging.getLogger('uvicorn.error').exception('Falha na preparação do assistente')
                if not await request_stop_confirmation(result):
                    break
    except asyncio.CancelledError:
        pass
    finally:
        auto_running = False
        if auto_mode.falar and page is not None and not page.is_closed():
            try:
                await asyncio.wait_for(asyncio.gather(*(
                    frame.evaluate('() => window.__ecStudioSyntheticMic?.release()')
                    for frame in page.frames[:15]), return_exceptions=True), timeout=MIC_RELEASE_TIMEOUT_SECONDS)
            except Exception:
                pass



async def _auto_worker_run():
    global auto_running, auto_latest, connection_health, activity_attempt
    previous_message = None
    course_report = {}
    recovery = Recuperacao()
    if auto_mode.aprender or auto_mode.quiz:
        auto_latest={'tipo':'aguardando','mensagem':'Carregando a IA local antes de iniciar os exercícios com tempo.'}
        try:
            await asyncio.wait_for(asyncio.to_thread(warm_local_model),timeout=MODEL_WARMUP_TIMEOUT)
        except Exception as exc:
            record('Não consegui preparar a IA local: '+type(exc).__name__+'. Vou conferir a atividade disponível.')
    if not auto_running:
        return
    engine = EngineState(speech_policy=load_speech_policy(DATA / 'preferencias_fala.json'))
    async def run_inference_without_browser_lock(function, *args):
        global auto_latest
        auto_latest = {**auto_latest, 'tipo': 'aguardando',
                       'mensagem': 'IA local analisando a atividade. A primeira resposta pode demorar mais.'}
        # A IA pode demorar segundos. Capturas e estado do painel continuam fluindo,
        # enquanto ações do navegador seguem serializadas com o lock global.
        lock.release()
        try:
            return await asyncio.to_thread(function, *args)
        finally:
            await lock.acquire()
    engine.inference = run_inference_without_browser_lock
    progresso = ProgressoVerificado(PROGRESS_FILE)
    curso_atual = course_url(page.url if page is not None else '').rsplit('/', 1)[-1]
    restore_saved_scope(engine.real.cursor,progresso,curso_atual,auto_mode)
    # Releia cada unidade nesta sessão; o cache não substitui a inspeção atual.
    last_pointer = None
    last_signature = None
    signature_since = time.monotonic()
    last_network_check = float('-inf')
    reconnecting = False
    async def handle_failure(result):
        nonlocal reconnecting, last_network_check
        try:
            return await handle_issue(result, engine, progresso, curso_atual)
        except NetworkUnavailable:
            reconnecting = True
            last_network_check = float('-inf')
            return True
    while auto_running:
        try:
            try:p=current_page()
            except HTTPException:p=None
            if p is None or p.is_closed():
                reconnecting = False
            elif is_seductec_url(p.url):
                auto_running = False
                auto_latest = {'tipo':'parado', 'mensagem':'A aba mudou para o SEDUCTEC. A automação exclusiva do EnglishCentral foi interrompida; navegação e estudo manual continuam disponíveis.'}
                record(auto_latest['mensagem'])
                break
            if p is not None and not p.is_closed() and time.monotonic()-last_network_check >= (5 if reconnecting else 10):
                last_network_check = time.monotonic()
                probe_start=time.monotonic()
                online = await network_available(p)
                latency=max(0,int((time.monotonic()-probe_start)*1000))
                connection_health={'estado':'offline' if not online else 'lenta' if latency>=2000 else 'online','latencia_ms':latency}
                if not online:
                    reconnecting = True
                elif reconnecting:
                    await restore_network_page(p, course_url(p.url))
                    reconnecting = False
                    signature_since = time.monotonic()
                    auto_latest = {'tipo':'aguardando','mensagem':'Conexão restabelecida. Relendo a atividade antes de continuar.'}
                    record(auto_latest['mensagem'])
                    progresso.registrar_evento(curso_atual,'reconectado','','Conexão restabelecida; sessão preservada.')
            if reconnecting:
                auto_latest = {'tipo':'reconectando','mensagem':'Reconectando… Aguardando acesso ao EnglishCentral. O trabalho será retomado automaticamente.'}
                await asyncio.sleep(2)
                continue
            if p is None or p.is_closed():
                auto_latest = {'tipo': 'aguardando', 'mensagem': 'Abra o Chrome e faça login.'}
            else:
                # Evita iniciar o mesmo exercício repetidamente enquanto o JS carrega.
                match_course = re.search(r'/course/(\d+)', p.url)
                current_course = match_course.group(1) if match_course else ''
                if current_course and current_course != curso_atual:
                    curso_atual = current_course
                    course_url(p.url)
                    course_report = {}
                    engine.real.cursor.reset()
                    restore_saved_scope(engine.real.cursor,progresso,curso_atual,auto_mode)
                    # Unidades serão verificadas novamente na sessão atual.
                lesson_key = p.url + '|' + engine.real.lesson
                allow_start = (last_word_start['pagina'] != lesson_key or
                               time.monotonic() - last_word_start['quando'] > 35)
                async with lock:
                    if is_seductec_url(p.url):
                        auto_running = False
                        auto_latest = {'tipo':'parado', 'mensagem':'A aba mudou para o SEDUCTEC. A automação exclusiva do EnglishCentral foi interrompida; navegação e estudo manual continuam disponíveis.'}
                        record(auto_latest['mensagem'])
                        break
                    if getattr(engine,'skip_return_url',''):
                        await p.goto(engine.skip_return_url,wait_until='domcontentloaded',timeout=20000)
                        engine.skip_return_url=''
                        continue
                    activity_attempt={'em_andamento':True,'inicio':time.time()}
                    try:
                        auto_latest = await asyncio.wait_for(process_page(p, submit=auto_submit,
                                                         allow_word_start=allow_start, engine=engine,
                                                         modo=auto_mode), timeout=90)
                    finally:
                        activity_attempt={'em_andamento':False,'inicio':None}
                auto_latest = recovery.aplicar(auto_latest, p.url)
                if auto_latest.get('progresso_curso'):
                    course_report = auto_latest['progresso_curso']
                elif course_report:
                    auto_latest['progresso_curso'] = course_report
                for unit in (auto_latest.get('progresso_curso') or {}).get('unidades',[]):
                    if unit.get('estado')=='pendente' and unit.get('atividades_lidas') and unit.get('id') not in engine.real.cursor.verified_units:
                        stages = (auto_mode.etapas if unit.get('videos_pendentes') else ())
                        if unit.get('quizzes_pendentes'): stages += ('quizzes',)
                        if unit.get('activities_pendentes'): stages += ('activities',)
                        # Relatórios antigos não detalhavam a etapa contradita.
                        if not any(key in unit for key in ('videos_pendentes', 'quizzes_pendentes', 'activities_pendentes')):
                            stages = progress_scope(auto_mode)
                        progresso.invalidar_unidade(curso_atual,unit['id'],stages)
                flags = auto_latest.get('progresso_etapas') or {}
                verified_id = auto_latest.get('aula_id') or ''
                speech_event = auto_latest.get('fala_evento')
                if speech_event and verified_id:
                    progresso.registrar_fala(curso_atual, verified_id, speech_event)
                if verified_id and curso_atual and flags:
                    pending_steps = tuple(step for step in auto_mode.etapas if flags.get(step) is False)
                    if pending_steps:
                        progresso.invalidar(curso_atual, verified_id, pending_steps, engine.real.cursor.current_unit)
                        if engine.real.cursor.current_unit:
                            engine.real.cursor.verified_units.discard(engine.real.cursor.current_unit)
                        else:
                            engine.real.cursor.verified_units.clear()
                        from course_flow import lesson_key
                        pending_lesson = lesson_key(verified_id)
                        engine.real.cursor.seen.discard(pending_lesson)
                        engine.real.cursor.saved_scope_lessons.discard(pending_lesson)
                        engine.real.cursor.session_verified_lessons.discard(pending_lesson)
                    if progresso.confirmar(curso_atual, verified_id, flags):
                        record('Progresso confirmado pelo site e salvo localmente para esta aula.')
                    engine.real.cursor.seen.update(progresso.concluidas(curso_atual, auto_mode.etapas))
                completed_quiz = auto_latest.get('quiz_concluido')
                if completed_quiz:
                    engine.real.cursor.mark_quiz_done(completed_quiz)
                    if progresso.confirmar_quiz(curso_atual, completed_quiz):
                        record('Quiz confirmado pela tela da plataforma e salvo localmente para não repetir.')
                if engine.real.cursor.verified_units:
                    progresso.confirmar_unidades(curso_atual, progress_scope(auto_mode), engine.real.cursor.verified_units,
                        {key:value.get('titulo','') for key,value in engine.real.cursor.unit_reports.items()})
                if auto_latest.get("ponteiro"):
                    last_pointer = auto_latest["ponteiro"]
                elif last_pointer is not None:
                    auto_latest["ultimo_ponteiro"] = last_pointer
                if auto_latest.get('acao') == 'iniciar_palavras':
                    last_word_start.update(pagina=p.url + '|' + engine.real.lesson,
                                           quando=time.monotonic())
                auto_counts['ciclos'] += 1
                auto_counts['lacunas'] += auto_latest.get('preenchidas', 0)
                msg = auto_latest.get('mensagem')
                if msg != previous_message and msg:
                    record(msg)
                    previous_message = msg
                kind = auto_latest.get('tipo')
                if kind in HALT_RESULTS:
                    # Enquanto a decisão está pendente, nenhuma ação é repetida.
                    if not await handle_issue(auto_latest,engine,progresso,curso_atual):
                        break
                    if kind=='video_atencao':
                        engine.real.video_tracking_replays = 0
                        engine.real.video_replays = 0
                        engine.real.video_white_since = None
                        engine.real.video_attention_attempted = False
                    last_network_check = float('-inf')
                    last_signature = None
                    signature_since = time.monotonic()
                    continue
                watch_stall = kind in {'aguardando','palavras','navegacao','quiz_resposta','lacunas','lacuna_video'} or (
                    auto_submit and kind in {'conferencia','correcao'})
                if watch_stall:
                    signature = progress_signature(auto_latest,engine,p.url)
                    now = time.monotonic()
                    if signature != last_signature:
                        last_signature, signature_since = signature, now
                    elif now - signature_since > STALL_LIMIT_SECONDS:
                        auto_latest = {'tipo': 'ajuda', 'mensagem':
                            f'Sem mudança detectável na atividade por {STALL_LIMIT_SECONDS} segundos. Vou reler a tela antes de tentar novamente.'}
                        record(auto_latest['mensagem'])
                        if not await handle_issue(auto_latest,engine,progresso,curso_atual):break
                        last_signature = None
                        signature_since = time.monotonic()
                        continue
                else:
                    last_signature, signature_since = None, time.monotonic()
        except asyncio.CancelledError:
            raise
        except NetworkUnavailable:
            reconnecting=True
            last_network_check=float('-inf')
            continue
        except (BrowserTimeoutError, TimeoutError):
            result = {'tipo':'ajuda','mensagem':'O navegador demorou a responder. Confira a tela antes de repetir uma ação.'}
            if not await handle_failure(result):break
            signature_since = time.monotonic()
            continue
        except Exception as exc:
            result = {'tipo':'erro','mensagem':'Não consegui continuar nesta página ('
                      +type(exc).__name__+'). Confira a atividade antes de retomar.'}
            logging.getLogger('uvicorn.error').exception('Falha no ciclo do assistente')
            if not await handle_failure(result):break
            signature_since = time.monotonic()
            continue
        # Reage mais depressa às telas de exercício e transição; durante vídeo/fala
        # consulta com menor frequência para não disputar recursos com o navegador.
        kind = auto_latest.get('tipo')
        delay = 0.45 if kind in {'lacuna_video', 'lacunas', 'correcao', 'quiz_resposta', 'navegacao'} else (
            5.0 if kind == 'video_atencao' else 2.0 if kind in {'video', 'fala', 'audio'} else 0.85)
        await asyncio.sleep(delay)



@app.get('/api/auto/status', dependencies=[Depends(require_auth)])
async def auto_status():
    return {'executando': auto_running, 'envio': auto_submit, 'modo': auto_mode.__dict__, 'ultimo': auto_latest,
            'contadores': auto_counts, 'ia': ia_status(), 'confirmacao_parada':confirmation_status(),
            'conexao':connection_health,'processamento':activity_attempt}


@app.post('/api/auto/start', dependencies=[Depends(require_auth)])
async def auto_start(action: AutoStart):
    async with auto_control_lock:
        return await _auto_start_locked(action)


async def _auto_start_locked(action: AutoStart):
    global auto_running, auto_task, auto_submit, auto_latest, auto_mode
    try:
        active_page = current_page()
    except HTTPException:
        active_page = None
    if active_page is not None and is_seductec_url(active_page.url):
        raise HTTPException(409, 'SEDUCTEC reconhecido. A automação de etapas do EnglishCentral não é compatível com este Moodle. Use a prévia, leitura, inspeção, controle de vídeo e anotações; respostas e envios permanecem sob seu controle.')
    if not auto_running:
        if auto_task is not None:
            # Um worker pode ter publicado "pausado" e ainda estar liberando áudio/lock.
            # Nunca deixe esse finally antigo alcançar uma execução nova.
            try:
                await auto_task
            except asyncio.CancelledError:
                pass
            except Exception:
                logging.getLogger('uvicorn.error').exception('Falha ao encerrar worker anterior')
            auto_task = None
        try:
            auto_mode = ModoEstudo(activities=action.activities, assistir=action.assistir, aprender=action.aprender,
                                   falar=action.falar, quiz=action.quiz, conversar=action.conversar)
        except ValueError as exc:
            raise HTTPException(422, str(exc)) from exc
        if auto_mode.falar:
            async with lock:
                p = current_page()
                from fala_automatica import prepare_synthetic_mic
                found = await prepare_synthetic_mic(p)
                if not found:
                    raise HTTPException(409, 'A entrada de voz sintética não foi preparada. Feche e abra o navegador pelo painel antes de iniciar.')
        auto_running = True
        auto_retry_counts.clear()
        auto_submit = action.enviar_automaticamente
        auto_latest = {'tipo': 'iniciado', 'mensagem': 'Analisando a página atual do curso.'}
        auto_task = asyncio.create_task(auto_worker())
        record('Assistente iniciado para: ' + ', '.join(progress_scope(auto_mode)) + '. Confirmação de respostas: ' + str(auto_submit) + '.')
    return {'ok': True, 'executando': auto_running}


@app.post('/api/auto/stop', dependencies=[Depends(require_auth)])
async def auto_stop():
    async with auto_control_lock:
        return await _auto_stop_locked()


async def _auto_stop_locked():
    global auto_running, auto_task, auto_latest
    auto_running = False
    if auto_task is not None:
        auto_task.cancel()
        try:
            await auto_task
        except asyncio.CancelledError:
            pass
        auto_task = None
    auto_latest = {'tipo': 'parado', 'pausa_motivo':'manual',
                   'mensagem': 'Assistente pausado por você. Clique em Iniciar assistente para retomar.'}
    record('Automação interrompida pelo usuário.')
    return {'ok': True}


@app.get('/api/health', dependencies=[Depends(require_auth)])
async def health():
    # A identificação de um perfil não depende da aba, do título ou da IA.
    return {'ok': True, 'perfil': {'id': PROFILE_ID}, 'versao': '18.13.1'}


@app.get('/api/status', dependencies=[Depends(require_auth)])
async def status():
    # Estado não disputa o lock da automação nem espera um DOM travado.
    try:
        current_page();active=True
    except HTTPException:active=False
    title = ''
    if active and not lock.locked():
        try:
            title = (await asyncio.wait_for(page.title(), timeout=1))[:160]
        except Exception:
            pass
    active_url = page.url if active else ''
    return {'aberto': active, 'url': active_url,
            'titulo': title, 'resolucao': VIEWPORT, 'eventos': list(entries)[-8:],
            'executando': auto_running, 'auto': auto_latest,
            'confirmacao_parada':confirmation_status(),'conexao':connection_health,'processamento':activity_attempt,
            'ia': ia_status(), 'contadores': auto_counts, 'modo': auto_mode.__dict__,
            'perfil': current_profile(), 'navegador':browser_session_status(), 'versao': '18.13.1',
            'aplicativo': REMOTE_CONFIG.describe(), 'plataforma': page_platform(active_url) if active else None,
            'motivo_pausa': auto_latest.get('mensagem', '') if not auto_running else ''}


@app.get('/api/history', dependencies=[Depends(require_auth)])
async def saved_history():
    if page is not None and not page.is_closed() and is_seductec_url(page.url):
        return {'curso':'SEDUCTEC · estudo manual','unidades':[],'eventos':[],'linhas_fala':[],
                'avisos':['O histórico de conclusão da V18.11 pertence ao EnglishCentral. As anotações locais do SEDUCTEC ficam separadas.']}
    course=course_url(page.url if page is not None and not page.is_closed() else '').rsplit('/',1)[-1]
    progress=ProgressoVerificado(PROGRESS_FILE)
    return {'curso':course,'unidades':progress.resumo_unidades(course),'eventos':progress.historico(course),
            'linhas_fala':progress.historico_fala(course),'avisos':progress.avisos}


class SpeechOptions(BaseModel):
    precisao_minima: int = Field(default=80, ge=0, le=100, strict=True)
    max_tentativas: int = Field(default=2, ge=1, le=5, strict=True)
    abaixo_meta: Literal['next', 'retry', 'ask'] = 'next'


@app.get('/api/speech/settings', dependencies=[Depends(require_auth)])
async def speech_settings():
    from dataclasses import asdict
    return asdict(load_speech_policy(DATA / 'preferencias_fala.json'))


@app.put('/api/speech/settings', dependencies=[Depends(require_auth)])
async def update_speech_settings(options: SpeechOptions):
    async with auto_control_lock:
        if auto_running:
            raise HTTPException(409, 'Pause o assistente antes de alterar as preferências de fala.')
        policy = SpeechPolicy(**options.model_dump())
        save_speech_policy(DATA / 'preferencias_fala.json', policy)
        return {'ok': True, **options.model_dump()}


def profile_manager():
    return ProfileManager(PROFILES_ROOT, ROOT)


def current_profile():
    try:
        return profile_manager().current(PROFILE_ID)
    except (OSError, ValueError, RuntimeError):
        return {'id': PROFILE_ID, 'nome': PROFILE_ID}


class ProfileName(BaseModel):
    nome: str = Field(default='', max_length=60)


@app.get('/api/profiles', dependencies=[Depends(require_auth)])
async def profiles():
    try:
        return {'pessoas': await asyncio.to_thread(profile_manager().list), 'atual': PROFILE_ID}
    except (OSError, RuntimeError) as exc:
        raise HTTPException(409, str(exc)) from exc


async def open_profile_response(profile_id):
    try:
        result = await asyncio.to_thread(profile_manager().open, profile_id)
        if REMOTE_CONFIG.enabled:
            # As sessões continuam separadas; o celular acessa todas pelo HTTPS
            # do painel, sem tentar abrir o próprio 127.0.0.1.
            fragment = urlparse(result['url']).fragment
            result['url'] = f'/p/{profile_id}/#{fragment}'
        return result
    except KeyError as exc:
        raise HTTPException(404, 'Pessoa não encontrada.') from exc
    except (OSError, ValueError, RuntimeError) as exc:
        raise HTTPException(409, str(exc)) from exc


@app.post('/api/profiles', dependencies=[Depends(require_auth)])
async def add_profile(name: ProfileName):
    try:
        person = await asyncio.to_thread(profile_manager().create, name.nome)
        # Criar não depende do tempo de início de outro servidor.
        return {'ok': True, 'perfil': person}
    except (OSError, ValueError, RuntimeError) as exc:
        raise HTTPException(409, str(exc)) from exc


@app.post('/api/profiles/{profile_id}/open', dependencies=[Depends(require_auth)])
async def open_person(profile_id: str):
    return await open_profile_response(profile_id)


@app.patch('/api/profiles/{profile_id}', dependencies=[Depends(require_auth)])
async def rename_profile(profile_id: str, name: ProfileName):
    try:
        return {'ok': True, 'perfil': await asyncio.to_thread(profile_manager().rename, profile_id, name.nome)}
    except KeyError as exc:
        raise HTTPException(404, 'Pessoa não encontrada.') from exc
    except (OSError, ValueError, RuntimeError) as exc:
        raise HTTPException(409, str(exc)) from exc


@app.get('/api/course', dependencies=[Depends(require_auth)])
@browser_deadline(read_only=True)
async def course_summary():
    async with lock:
        p = current_page()
        if is_seductec_url(getattr(p, 'url', '')):
            return {'supported': False, 'unidades': [], 'plataforma': 'seductec',
                    'mensagem': 'O SEDUCTEC usa Moodle; consulte as seções e atividades na inspeção da página.'}
        info = await inspect_course(p)
        if not info.get('supported') or not info.get('course_id'):
            return {'supported': False, 'unidades': []}
        course_id = str(info['course_id'])
        progress = ProgressoVerificado(PROGRESS_FILE)
        cursor = CourseCursor()
        cursor.seen.update(progress.concluidas(course_id, auto_mode.etapas) if auto_mode.etapas else set())
        cursor.saved_scope_lessons.update(cursor.seen)
        cursor.seen_quizzes.update(progress.quizzes(course_id))
        scope = progress_scope(auto_mode)
        cursor.verified_units.update(progress.unidades(course_id, scope))
        report = course_progress(
            info, cursor, include_videos=bool(auto_mode.etapas), include_quizzes=auto_mode.quiz, include_activities=auto_mode.activities)
        units = report['unidades']
        return {
            'supported': True,
            **report,
            'aulas_verificadas': len(cursor.seen),
            'unidades_concluidas': sum(unit['estado'] == 'concluida' for unit in units),
            'unidades_total': len(units),
            'atividades_confirmadas': sum(unit['confirmadas'] for unit in units),
            'atividades_total': sum(unit['atividades_lidas'] for unit in units),
            'modo': auto_mode.__dict__,
        }


@app.post('/api/course/unit', dependencies=[Depends(require_auth)])
@browser_deadline('BROWSER_ACTION_TIMEOUT')
async def open_course_unit(action: CourseUnit):
    global last_snapshot
    await pause_for_manual_action()
    async with lock:
        p = current_page()
        info = await inspect_course(p)
        matches = [unit for unit in info.get('units', []) if unit.get('id') == action.id]
        if not info.get('supported') or len(matches) != 1:
            raise HTTPException(409, 'A unidade não está disponível na lista atual do curso. Atualize as unidades.')
        unit = matches[0]
        if unit.get('locked'):
            raise HTTPException(409, 'Esta unidade está bloqueada na plataforma.')
        if unit.get('active'):
            return {'ok': True, 'mensagem': 'Esta unidade já está selecionada no curso.'}
        index = unit.get('index')
        if not isinstance(index, int) or index < 0:
            raise HTTPException(409, 'Não foi possível identificar a posição da unidade. Atualize o curso.')
        target = p.locator('ec-course-unit .unit[id]').nth(index).locator('.unit-header')
        if await target.count() != 1 or not await target.is_visible():
            raise HTTPException(409, 'O cabeçalho desta unidade não está visível. Atualize o curso.')
        await target.click(timeout=5000)
        last_snapshot = None
        title = unit.get('title') or 'unidade selecionada'
        record('Unidade aberta manualmente: ' + title + '.')
        return {'ok': True, 'mensagem': 'Unidade aberta: ' + title + '.'}

@app.get('/api/course/inspection', dependencies=[Depends(require_auth)])
@browser_deadline(read_only=True)
async def inspect_course_controls():
    async with lock:
        p = current_page()
        if is_seductec_url(p.url):
            return {'supported': True, 'plataforma': 'seductec',
                    'moodle': await inspect_moodle_page(p)}
        return await inspect_course(p)


@app.get('/api/memory', dependencies=[Depends(require_auth)])
async def study_memory():
    memory = read_memory()
    return {
        'palavras': memory.get('palavras', [])[-100:],
        'frases': list(memory.get('frases', {}).items())[-50:],
    }


def browser_preferences():
    try:
        value=json.loads((DATA/'preferencias_navegador.json').read_text('utf-8'))
        if (isinstance(value,dict) and value.get('modo')=='existente' and
                value.get('canal') in {'chrome','msedge'} and
                (value.get('porta') is None or type(value['porta']) is int and 1024<=value['porta']<=65535)):
            return value
    except (OSError,ValueError):pass
    return {'modo':'assistente'}


def browser_session_status():
    prefs={'modo':'assistente'} if personal_chrome_blocked() else browser_preferences()
    active=page is not None and not page.is_closed()
    mode=('assistente' if browser_owned else 'existente') if context is not None else prefs['modo']
    return {'modo':mode,'conectado':active,'canal':browser_channel or prefs.get('canal',''),
            'mensagem':('Sessão do servidor; o login permanece salvo por pessoa.' if REMOTE_CONFIG.enabled else 'Usando o login do seu Chrome/Edge.' if mode=='existente' else
                        'Sessão do assistente; o login permanece salvo por pessoa.'),
            'ultimo_erro':browser_fault}


async def halt_auto_on_seductec_navigation(p):
    """Cancela o worker se a aba ativa sair do EnglishCentral e entrar no Moodle."""
    global auto_running, auto_task, auto_latest
    if p is not page or not is_seductec_url(p.url) or not auto_running:
        return
    auto_running = False
    auto_latest = {'tipo':'parado', 'mensagem':'Você abriu o SEDUCTEC. A automação do EnglishCentral foi interrompida; o modo de estudo manual está disponível.'}
    record(auto_latest['mensagem'])
    task = auto_task
    if task is not None and task is not asyncio.current_task() and not task.done():
        task.cancel()


def observe_tab(p):
    global page,context,last_snapshot
    if not session_tab(p.url):return
    parent=browser_parents.get(id(p))
    if ((page is None or page.is_closed()) and (context is None or p.context is context) or
            parent is page and google_login_url(p.url) or
            parent is page and google_login_url(page.url) and platform_url(p.url)):
        page=p;context=p.context;last_snapshot=None
        record('Acompanhando a aba de login.' if google_login_url(p.url) else 'Aba do curso recuperada na sessão atual.')


def register_tab(p):
    if id(p) in browser_events:return
    browser_events.add(id(p));browser_tabs[secrets.token_hex(8)]=p
    serial=browser_serial
    def navigated(frame):
        if serial==browser_serial and frame is p.main_frame:
            observe_tab(p)
            if p is page and is_seductec_url(p.url) and auto_running:
                asyncio.create_task(halt_auto_on_seductec_navigation(p))
    def closed():
        if serial!=browser_serial:return
        browser_events.discard(id(p));browser_parents.pop(id(p),None)
        for key,value in list(browser_tabs.items()):
            if value is p:browser_tabs.pop(key,None)
        if page is p:
            try:current_page()
            except HTTPException:pass
    async def parent():
        try:opener=await asyncio.wait_for(p.opener(),timeout=1)
        except Exception:opener=None
        if serial==browser_serial:
            browser_parents[id(p)]=opener;observe_tab(p)
    p.on('framenavigated',navigated);p.on('close',closed)
    asyncio.create_task(parent())


def track_context(c):
    serial=browser_serial
    c.on('page',lambda p:register_tab(p) if serial==browser_serial else None)
    for p in c.pages:register_tab(p)


async def dispose_browser_session():
    """Desconectar um Chrome pessoal nunca fecha suas abas ou seu contexto."""
    global context,page,browser_driver,connected_browser,browser_lease,browser_owned,browser_channel,browser_serial,last_snapshot
    old_context,driver,owned,lease=context,browser_driver,browser_owned,browser_lease
    context=page=browser_driver=connected_browser=browser_lease=None
    last_snapshot=None
    browser_owned=True;browser_channel='';browser_serial+=1
    browser_tabs.clear();browser_parents.clear();browser_events.clear()
    try:
        if owned and old_context is not None:
            # Encerrar o perfil com abas de rede abertas pode restaurar uma aba
            # sem evento load antes de o Playwright conseguir assumir a sessão.
            # Feche as abas apenas do navegador criado pelo próprio assistente.
            try:
                pages=list(getattr(old_context,'pages',[]))
                await asyncio.wait_for(asyncio.gather(*(p.close(run_before_unload=False)
                    for p in pages if not p.is_closed()),return_exceptions=True),timeout=3)
            except Exception:pass
            try:await asyncio.wait_for(old_context.close(),timeout=3)
            except Exception:record('A janela demorou a encerrar; liberando a conexão local.')
        if driver is not None:
            try:await asyncio.wait_for(driver.stop(),timeout=3)
            except Exception:record('Não consegui confirmar o encerramento da conexão com o navegador.')
    finally:
        if lease is not None:lease.__exit__(None,None,None)


class BrowserConnect(BaseModel):
    canal: Literal['chrome','msedge'] = 'chrome'
    porta: int | None = Field(default=None,ge=1024,le=65535)


@app.post('/api/browser/connect',dependencies=[Depends(require_auth)])
@browser_deadline('BROWSER_START_TIMEOUT')
async def connect_browser(action:BrowserConnect):
    global browser_driver,context,page,browser_owned,browser_channel,connected_browser,browser_lease,last_snapshot
    if personal_chrome_blocked():
        raise HTTPException(409, 'No celular, use a sessão do servidor. O Chrome do telefone não compartilha seu login com o navegador remoto.')
    termux_endpoint=None
    if TERMUX:
        # Chrome do próprio celular: conexão local por porta, nunca pelo canal de PC.
        termux_endpoint=await phone_chrome_endpoint(action.porta)
        if termux_endpoint is None:
            if termux_chromium_path():
                # Sem ponte para o Chrome do celular: usa o Chromium do Termux automaticamente.
                async with auto_control_lock:
                    await _auto_stop_locked()
                    async with lock:
                        await dispose_browser_session()
                        write_json_atomic(DATA/'preferencias_navegador.json',{'modo':'assistente'})
                result=await open_browser()
                record('Chrome do celular não estava acessível; usando o Chromium do Termux.')
                return {**result,'mensagem':'Chrome do celular não acessível; abri o navegador do Termux. Faça login pela prévia.'}
            raise HTTPException(409,TERMUX_CHROME_HELP)
    async with auto_control_lock:
        await _auto_stop_locked()
        async with lock:
            await dispose_browser_session()
            lease=file_lock(PROFILES_ROOT/'navegador_pessoal.lock',timeout=0)
            try:lease.__enter__()
            except RuntimeError as exc:
                raise HTTPException(409,'O navegador pessoal já está conectado a outro painel. Desconecte esse painel ou use uma sessão separada do assistente.') from exc
            browser_lease=lease;browser_owned=False;browser_channel=action.canal
            from playwright.async_api import async_playwright
            try:
                write_json_atomic(DATA/'preferencias_navegador.json',{'modo':'existente','canal':action.canal,'porta':action.porta})
                browser_driver=await async_playwright().start()
                endpoint=termux_endpoint or ('http://127.0.0.1:'+str(action.porta) if action.porta else action.canal)
                connected_browser=await browser_driver.chromium.connect_over_cdp(endpoint,timeout=25000,no_defaults=True)
                contexts=connected_browser.contexts
                if not contexts:raise RuntimeError('Nenhuma sessão existente disponível')
                page=choose_page([p for c in contexts for p in c.pages],preferred=target_url())
                context=page.context if page is not None else contexts[0]
                for c in contexts:track_context(c)
                if page is None:
                    page=await context.new_page()
                    await page.goto(target_url(),wait_until='domcontentloaded',timeout=25000)
                last_snapshot=None
                await page.bring_to_front()
                write_json_atomic(DATA/'preferencias_navegador.json',{'modo':'existente','canal':action.canal,'porta':action.porta})
                record('Conectado ao navegador já aberto; usando a aba e o login existentes.')
                return {'ok':True,'mensagem':'Chrome/Edge conectado. A aba e o login existentes foram reutilizados.'}
            except BaseException as exc:
                await dispose_browser_session()
                if isinstance(exc,asyncio.CancelledError):raise
                raise HTTPException(409,TERMUX_CHROME_HELP if TERMUX else 'Não consegui conectar ao Chrome/Edge aberto. No Chrome 144 ou superior, abra chrome://inspect/#remote-debugging, habilite a conexão e aceite a solicitação no próprio Chrome. O assistente não abriu outro perfil.') from exc


@app.get('/api/browser/tabs',dependencies=[Depends(require_auth)])
async def session_tabs():
    for p in available_pages(all_contexts=True):
        if session_tab(p.url) and id(p) not in browser_events:register_tab(p)
    return {'abas':[{'id':key,'rotulo':tab_label(p.url),'url':public_url(p.url),'atual':p is page}
                    for key,p in list(browser_tabs.items()) if not p.is_closed() and session_tab(p.url)]}


class BrowserTab(BaseModel):
    id:str = Field(pattern=r'^[a-f0-9]{16}$')


@app.post('/api/browser/tab',dependencies=[Depends(require_auth)])
@browser_deadline('BROWSER_ACTION_TIMEOUT')
async def select_browser_tab(action:BrowserTab):
    global context,page,last_snapshot
    async with auto_control_lock:
        await _auto_stop_locked()
        async with lock:
            selected=browser_tabs.get(action.id)
            if selected is None or selected.is_closed() or not session_tab(selected.url):
                raise HTTPException(409,'A aba não está mais disponível. Atualize a lista.')
            page=selected;context=selected.context;last_snapshot=None
            await selected.bring_to_front()
            record('Aba escolhida por você. Inicie o assistente para trabalhar nessa aba.')
            return {'ok':True,'mensagem':'Aba selecionada; o assistente está pausado.'}


@app.post('/api/browser/managed',dependencies=[Depends(require_auth)])
@browser_deadline('BROWSER_START_TIMEOUT')
async def managed_browser():
    async with auto_control_lock:
        await _auto_stop_locked()
        async with lock:
            await dispose_browser_session()
            write_json_atomic(DATA/'preferencias_navegador.json',{'modo':'assistente'})
    return await open_browser()


@app.post('/api/open', dependencies=[Depends(require_auth)])
@browser_deadline('BROWSER_START_TIMEOUT')
async def open_browser():
    global browser_driver,context,page,last_snapshot
    try:
        current_page()
        return {'ok':True,'mensagem':'Sessão e aba existentes reutilizadas.'}
    except HTTPException:pass
    if (TERMUX and context is None and not (DATA/'preferencias_navegador.json').exists() and
            await phone_chrome_endpoint() is not None):
        # Primeira abertura no Termux: aproveita o Chrome do celular se ele já estiver acessível.
        return await connect_browser(BrowserConnect(canal='chrome',porta=None))
    if not personal_chrome_blocked() and context is None and browser_preferences()['modo']=='existente':
        prefs=browser_preferences()
        return await connect_browser(BrowserConnect(canal=prefs['canal'],porta=prefs.get('porta')))
    async with lock:
        last_snapshot=None
        try:
            current_page()
            return {'ok':True,'mensagem':'Sessão e aba existentes reutilizadas.'}
        except HTTPException:pass
        # Fechar uma aba não significa que o navegador/perfil foi encerrado.
        if context is not None:
            external=not browser_owned
            try:
                page=await context.new_page()
                await page.goto(target_url(),wait_until='domcontentloaded',timeout=25000)
                register_tab(page)
                return {'ok':True,'mensagem':'Curso aberto na sessão já existente.'}
            except Exception as exc:
                await dispose_browser_session()
                if external:
                    raise HTTPException(409,'A conexão com seu Chrome foi encerrada. Reconecte o mesmo Chrome pelo painel; nenhum perfil novo foi aberto.') from exc
        if browser_driver is not None:await dispose_browser_session()
        from playwright.async_api import async_playwright
        DATA.mkdir(mode=0o700,parents=True,exist_ok=True)
        PROFILE.mkdir(mode=0o700,parents=True,exist_ok=True)
        termux_exe=''
        if TERMUX:
            termux_exe=termux_chromium_path()
            if not termux_exe:raise HTTPException(409,TERMUX_CHROME_HELP)
        try:
            browser_driver=await async_playwright().start()
        except Exception as exc:
            browser_driver=None
            record('Falha ao iniciar o Playwright: '+type(exc).__name__+'.')
            raise HTTPException(502,'Não consegui iniciar o Playwright (nodejs instalado? "pkg install nodejs"). Detalhe: '+type(exc).__name__+': '+((str(exc).strip().splitlines() or [''])[0][:180])) from exc
        try:
            kwargs={'user_data_dir':str(PROFILE),'headless':os.getenv('EC_HEADLESS','0')=='1',
                    'viewport':VIEWPORT,'locale':'pt-BR','timeout':25000,
                    'args':['--no-first-run','--no-default-browser-check']}
            configured_chromium = configured_browser_executable()
            if os.name=='nt' and not configured_chromium:
                kwargs['channel']='chrome' if os.getenv('EC_BROWSER','chrome')=='chrome' else 'msedge'
            if configured_chromium:
                kwargs['executable_path']=configured_chromium
            if TERMUX:
                kwargs['executable_path']=termux_exe
                kwargs['headless']=os.getenv('EC_HEADLESS','1')=='1'
                kwargs['args']=kwargs['args']+['--no-sandbox','--disable-dev-shm-usage','--disable-gpu']
            try:context=await browser_driver.chromium.launch_persistent_context(**kwargs)
            except Exception:
                if 'channel' not in kwargs:raise
                kwargs.pop('channel')
                context=await browser_driver.chromium.launch_persistent_context(**kwargs)
            await context.add_init_script(script=SYNTHETIC_MIC_INIT)
            page=choose_page(context.pages,preferred=target_url())
            if page is None:
                page=context.pages[0] if context.pages else await context.new_page()
                await page.goto(target_url(),wait_until='domcontentloaded',timeout=25000)
            track_context(context)
            record('Sessão persistente do assistente iniciada; login salvo por pessoa.')
            return {'ok':True,'mensagem':('Sessão do servidor aberta. Faça login pela prévia; a sessão fica salva por pessoa.' if REMOTE_CONFIG.enabled else 'Sessão do assistente aberta. O login fica salvo; para usar seu Chrome já logado, escolha Navegador e login em Configurações.')}
        except BaseException as exc:
            await dispose_browser_session()
            if isinstance(exc,asyncio.CancelledError):raise
            record('Falha ao abrir o navegador: '+type(exc).__name__+'.')
            first=(str(exc).strip().splitlines() or [''])[0][:180]
            raise HTTPException(502,'Não foi possível abrir o navegador. Confira se a sessão anterior foi fechada e consulte o diagnóstico local. Detalhe: '+type(exc).__name__+(': '+first if first else '')+('. '+TERMUX_CHROME_HELP if TERMUX else '')) from exc


@app.post('/api/close', dependencies=[Depends(require_auth)])
async def close_browser():
    global context, page, browser_driver, last_snapshot
    await auto_stop()
    last_snapshot = None
    async with lock:
        await dispose_browser_session()
        record('Sessão do assistente encerrada ou Chrome pessoal desconectado por você.')
        return {'ok': True}


@app.get('/api/screenshot', dependencies=[Depends(require_auth)])
async def screenshot():
    # Captura REAL. Prioriza prévia de agente quando a automação está com o lock
    # (evita a mensagem "navegador ocupado" e mostra o que o worker está fazendo).
    # Timeout curto; se o navegador estiver ocupado, devolve a última imagem de
    # lane ou tenta novamente com espera breve em vez de bloquear 40s.
    if moodle_automation.running:
        try:
            snap = moodle_automation.snapshot()
            for agent in (snap.get('agentes') or []):
                blob = agent.get('last_preview_bytes')
                if blob:
                    return Response(blob, media_type='image/jpeg',
                                    headers={'Cache-Control': 'no-store, private',
                                             'X-Content-Type-Options': 'nosniff',
                                             'X-EC-Preview-Source': 'agent'})
                page = agent.get('preview_page')
                if page is not None and not getattr(page, 'is_closed', lambda: True)():
                    try:
                        raw = await page.screenshot(type='jpeg', quality=55, animations='disabled', timeout=4000)
                        return Response(raw, media_type='image/jpeg',
                                        headers={'Cache-Control': 'no-store, private',
                                                 'X-Content-Type-Options': 'nosniff',
                                                 'X-EC-Preview-Source': 'agent-live'})
                    except Exception:
                        pass
        except Exception:
            pass
    try:
        await asyncio.wait_for(lock.acquire(), timeout=4.5)
    except asyncio.TimeoutError:
        # Automação segura continua; a UI deve mostrar o grid de agentes.
        raise HTTPException(503, 'O navegador está ocupado com a automação. A consulta será repetida sem interromper o assistente. Use a grade de agentes para acompanhar ao vivo.')
    try:
        p = current_page()
        raw = await p.screenshot(type='jpeg', quality=64, animations='disabled', scale='css', timeout=9000)
        return Response(raw, media_type='image/jpeg',
                        headers={'Cache-Control': 'no-store, private', 'X-Content-Type-Options': 'nosniff'})
    finally:
        lock.release()


@app.post('/api/focus', dependencies=[Depends(require_auth)])
@browser_deadline('BROWSER_ACTION_TIMEOUT')
async def focus_browser():
    async with lock:
        p = current_page()
        await p.bring_to_front()
    return {'ok': True, 'mensagem': 'Janela da aula colocada em primeiro plano.'}

@app.post('/api/ia/openai', dependencies=[Depends(require_auth)])
async def configure_openai(action: OpenAIConfig):
    key = action.chave.get_secret_value().strip()
    if not key.startswith('sk-') or len(key) < 20 or any(c.isspace() for c in key):
        raise HTTPException(400, 'Chave inválida. Copie uma chave da sua conta da API OpenAI.')
    await pause_for_manual_action()
    from auto_ia import save_openai_key, _INFERENCE_CACHE, _CACHE_LOCK
    async with lock:
        save_openai_key(key)
        with _CACHE_LOCK:
            _INFERENCE_CACHE.clear()
    return {'ok':True, 'mensagem':'OpenAI configurada. Clique em Iniciar assistente. O uso da API pode gerar cobrança.'}


@app.post('/api/window/new', dependencies=[Depends(require_auth)])
@browser_deadline('BROWSER_ACTION_TIMEOUT')
async def new_browser_window():
    async with lock:
        p = current_page()
        session = await context.new_cdp_session(p)
        try:
            await session.send('Target.createTarget', {
                'url': target_url(p.url), 'newWindow': True,
            })
        finally:
            await session.detach()
    return {'ok': True, 'mensagem': 'Nova janela aberta com o mesmo login. O assistente continua na janela principal.'}



@app.post('/api/tap', dependencies=[Depends(require_auth)])
@browser_deadline('BROWSER_ACTION_TIMEOUT')
async def tap(action: Tap):
    await pause_for_manual_action()
    editable = password = False
    async with lock:
        tapped = current_page()
        await tapped.mouse.click(action.x, action.y)
        try:
            info = await tapped.evaluate("""() => {
                const e = document.activeElement; if (!e) return {};
                const tag = (e.tagName || '').toLowerCase(), kind = (e.type || '').toLowerCase();
                const skip = ['button','submit','checkbox','radio','file','image','reset','range','color'];
                return {editable: tag === 'textarea' || !!e.isContentEditable || (tag === 'input' && !skip.includes(kind)),
                        password: kind === 'password'};
            }""")
            if isinstance(info, dict):
                editable, password = bool(info.get('editable')), bool(info.get('password'))
        except Exception:
            pass  # a prévia continua funcionando mesmo sem essa dica
    return {'ok': True, 'editable': editable, 'password': password}


@app.post('/api/type', dependencies=[Depends(require_auth)])
@browser_deadline('BROWSER_ACTION_TIMEOUT')
async def type_text(action: InputText):
    await pause_for_manual_action()
    async with lock:
        await current_page().keyboard.insert_text(action.text)
    # Nunca registrar conteúdos digitados: podem incluir credenciais.
    return {'ok': True}


@app.post('/api/key', dependencies=[Depends(require_auth)])
@browser_deadline('BROWSER_ACTION_TIMEOUT')
async def key(action: KeyInput):
    await pause_for_manual_action()
    async with lock:
        await current_page().keyboard.press(action.key)
    return {'ok': True}


@app.post('/api/scroll', dependencies=[Depends(require_auth)])
@browser_deadline('BROWSER_ACTION_TIMEOUT')
async def scroll(action: ScrollInput):
    await pause_for_manual_action()
    async with lock:
        p = current_page()
        await p.mouse.wheel(0, action.amount)
        await asyncio.sleep(0.3)
    return {'ok': True}


@app.get('/api/scroll/state', dependencies=[Depends(require_auth)])
@browser_deadline(read_only=True)
async def scroll_state():
    async with lock:
        p = current_page()
        try:
            state = await p.evaluate(r'''() => {
              const nodes=[document.scrollingElement,...document.querySelectorAll('*')];
              let best=null,bestMax=0;
              for(const el of nodes){if(!el)continue;const max=el.scrollHeight-el.clientHeight;
                if(max>bestMax+40){const style=getComputedStyle(el);if(el===document.scrollingElement||/auto|scroll|overlay/.test(style.overflowY)){best=el;bestMax=max;}}}
              if(best){const top=best.scrollTop||0;return {progress:bestMax>0?Math.round(top/bestMax*100):0,scrollTop:top,maxScroll:bestMax,kind:best===document.scrollingElement?'document':'container'};}
              return {progress:null,scrollTop:0,maxScroll:0,kind:'browser-pdf-or-no-scroll'};
            }''')
        except Exception:
            state = {'progress': None, 'scrollTop': 0, 'maxScroll': 0, 'kind': 'indisponivel'}
    if state.get('progress') is not None:
        return {'ok': True, **state}
    return {'ok': True, **state, 'progress': preview_scroll_ratio}


@app.post('/api/scroll/to', dependencies=[Depends(require_auth)])
@browser_deadline('BROWSER_ACTION_TIMEOUT')
async def scroll_to(action: ScrollToInput):
    global preview_scroll_ratio
    await pause_for_manual_action()
    async with lock:
        p = current_page()
        try:
            state = await p.evaluate(r'''(percent) => {
              const nodes=[document.scrollingElement,...document.querySelectorAll('*')];
              let best=null,bestMax=0;
              for(const el of nodes){if(!el)continue;const max=el.scrollHeight-el.clientHeight;
                if(max>bestMax+40){const style=getComputedStyle(el);if(el===document.scrollingElement||/auto|scroll|overlay/.test(style.overflowY)){best=el;bestMax=max;}}}
              if(best){best.scrollTop=Math.round(bestMax*(percent/100));return {progress:percent,scrollTop:best.scrollTop,maxScroll:bestMax,kind:best===document.scrollingElement?'document':'container'};}
              return null;
            }''', action.progress)
        except Exception:
            state = None
        if state is None:
            # Visualizador PDF nativo: seu DOM é protegido; use a roda real do mouse.
            delta = int((action.progress - preview_scroll_ratio) * 18)
            if delta == 0:
                delta = 1 if action.progress >= 50 else -1
            await p.mouse.move(max(10, VIEWPORT['width'] - 30), VIEWPORT['height'] // 2)
            await p.mouse.wheel(0, max(-2400, min(2400, delta * 120)))
            state = {'progress': action.progress, 'kind': 'browser-pdf-wheel'}
        preview_scroll_ratio = action.progress
        await asyncio.sleep(0.15)
    return {'ok': True, **state}


@app.post('/api/{operation}', dependencies=[Depends(require_auth)])
@browser_deadline('BROWSER_ACTION_TIMEOUT')
async def navigation(operation: Literal['back', 'forward', 'reload', 'course']):
    global last_snapshot, moodle_pdf_page, moodle_pdf_return_page, context, page
    last_snapshot = None
    await pause_for_manual_action()
    async with lock:
        p = current_page()
        if operation == 'back' and moodle_pdf_page is not None and p is moodle_pdf_page:
            # A seta de voltar fecha exclusivamente a aba temporária criada para o PDF.
            pdf_page = moodle_pdf_page
            try:
                if not pdf_page.is_closed():
                    await pdf_page.close()
            except Exception as exc:
                raise HTTPException(502, f'Não consegui fechar a aba temporária do PDF: {type(exc).__name__}.') from exc
            restored = moodle_pdf_return_page
            moodle_pdf_page = None
            moodle_pdf_return_page = None
            if restored is not None and not restored.is_closed() and is_seductec_url(restored.url):
                page = restored
                context = restored.context
                try:
                    await restored.bring_to_front()
                except Exception:
                    pass
                record('PDF temporário fechado; curso SEDUCTEC restaurado pela seta Voltar.')
                return {'ok': True, 'pdf_fechado': True, 'restaurado': True}
            raise HTTPException(409, 'PDF fechado, mas a página do curso já não está disponível. Reabra o curso SEDUCTEC.')
        if operation == 'back':
            await p.go_back(wait_until='domcontentloaded', timeout=15000)
        elif operation == 'forward':
            await p.go_forward(wait_until='domcontentloaded', timeout=15000)
        elif operation == 'reload':
            await p.reload(wait_until='domcontentloaded', timeout=25000)
        else:
            await p.goto(target_url(p.url), wait_until='domcontentloaded', timeout=35000)
        record({'back': 'Voltou uma página.', 'forward': 'Avançou uma página.', 'reload': 'Atualizou a página.', 'course': 'Voltou para a página do curso.'}[operation])
    return {'ok': True}


@app.get('/api/text', dependencies=[Depends(require_auth)])
@browser_deadline(read_only=True)
async def read_text():
    async with lock:
        p = current_page()
        text = (await p.locator('body').inner_text(timeout=12000))[:9000]
    return {'texto': text, 'observacao': 'Texto visível para estudar e consultar; respostas devem ser confirmadas por você.'}


@app.get('/api/inspect', dependencies=[Depends(require_auth)])
@browser_deadline(read_only=True)
async def inspect():
    global last_snapshot
    async with lock:
        p = current_page()
        last_snapshot = await inspect_page(p)
        if is_seductec_url(p.url):
            last_snapshot['plataforma'] = moodle_platform_info(p.url)
            last_snapshot['moodle'] = await inspect_moodle_page(p)
        # Nunca salvar conteúdo de exercícios ou senhas no disco.
        return last_snapshot


@app.get('/api/quiz', dependencies=[Depends(require_auth)])
@browser_deadline(read_only=True)
async def inspect_current_quiz():
    from exercicio import inspect_quiz
    async with lock:
        p = current_page()
        if is_seductec_url(p.url):
            overview = await inspect_moodle_page(p)
            questions = overview.get('questoes', [])
            return {'ativa': page_platform(p.url).get('tipo_pagina') == 'questionario' or bool(questions),
                    'tipo': 'moodle', 'pergunta': questions[0]['texto'] if questions else '',
                    'questoes': questions, 'texto': overview.get('texto', '')[:3800],
                    'observacao': 'Leitura de enunciados do Moodle. Use Assistente SEDUCTEC para gerar e preencher rascunhos pendentes; o envio final continua manual.',
                    'plataforma': 'seductec'}
        result = await inspect_quiz(p)
        from auto_fluxo import _quiz_start_buttons
        result['botoes_inicio'] = [label for _,label in await _quiz_start_buttons(p)]
        # Somente estrutura de campos do exercício, sem valores ou credenciais.
        if result.get('ativa') and not result.get('campos'):
            result['diagnostico_campos'] = await p.locator('input,textarea,[contenteditable="true"]').evaluate_all("""els => els.filter(e=>!['password','email','hidden'].includes(e.type)).slice(0,30).map(e=>{
                const r=e.getBoundingClientRect();return {tag:e.tagName,type:e.type,cls:e.className,
                readonly:e.getAttribute('readonly'),disabled:e.disabled,maxLength:e.maxLength,width:r.width,height:r.height};})""")
        return result


# Preferências SEDUCTEC são isoladas por perfil/conta (DATA).
MOODLE_SETTINGS_FILE = DATA / 'preferencias_seductec.json'
MOODLE_DEFAULT_SETTINGS = {
    'schema_version': 3, 'modo': 'tudo', 'preencher_quiz': True, 'preencher_forum': True,
    'tentar_novamente': True, 'max_tentativas': 2, 'agentes': 2,
    # Opt-in explícito: padrão continua seguro (não envia/publica).
    'enviar_quiz': False, 'publicar_forum': False,
}


def read_moodle_settings() -> dict:
    result = dict(MOODLE_DEFAULT_SETTINGS)
    try:
        raw = json.loads(MOODLE_SETTINGS_FILE.read_text('utf-8')) if MOODLE_SETTINGS_FILE.exists() else {}
    except (OSError, ValueError, TypeError):
        raw = {}
    if isinstance(raw, dict):
        if raw.get('modo') in ('tudo', 'pdf', 'forum', 'quiz'):
            result['modo'] = raw['modo']
        for key in ('preencher_quiz', 'preencher_forum', 'tentar_novamente', 'enviar_quiz', 'publicar_forum'):
            if type(raw.get(key)) is bool:
                result[key] = raw[key]
        # V18.12 gravava preencher_forum=false como padrão, mesmo quando o usuário
        # nunca tinha alterado essa opção. Migra esse padrão antigo uma única vez;
        # depois o painel salva schema_version=2 e respeita a escolha do usuário.
        try:
            schema = int(raw.get('schema_version', 1))
        except (TypeError, ValueError, OverflowError):
            schema = 1
        if schema < 2 and raw.get('preencher_forum') is False:
            result['preencher_forum'] = True
        try:
            result['max_tentativas'] = max(1, min(3, int(raw.get('max_tentativas', result['max_tentativas']))))
        except (TypeError, ValueError, OverflowError):
            pass
        try:
            result['agentes'] = max(1, min(4, int(raw.get('agentes', result['agentes']))))
        except (TypeError, ValueError, OverflowError):
            pass
    result['schema_version'] = 3
    return result


def save_moodle_settings(action: MoodleSettingsRequest) -> dict:
    current = read_moodle_settings()
    result = {
        'schema_version': 3, 'modo': action.modo or current['modo'],
        'preencher_quiz': current['preencher_quiz'] if action.preencher_quiz is None else action.preencher_quiz,
        'preencher_forum': current['preencher_forum'] if action.preencher_forum is None else action.preencher_forum,
        'tentar_novamente': current['tentar_novamente'] if action.tentar_novamente is None else action.tentar_novamente,
        'enviar_quiz': current.get('enviar_quiz', False) if getattr(action, 'enviar_quiz', None) is None else bool(action.enviar_quiz),
        'publicar_forum': current.get('publicar_forum', False) if getattr(action, 'publicar_forum', None) is None else bool(action.publicar_forum),
        'max_tentativas': max(1, min(3, int(action.max_tentativas if action.max_tentativas is not None else current['max_tentativas']))),
        'agentes': max(1, min(4, int(action.agentes if action.agentes is not None else current['agentes']))),
    }
    write_json_atomic(MOODLE_SETTINGS_FILE, result)
    return result


@app.get('/api/moodle/settings', dependencies=[Depends(require_auth)])
async def get_moodle_settings():
    return {'ok': True, 'configuracao': read_moodle_settings(),
            'arquivo': 'preferencias_seductec.json', 'escopo': 'perfil atual'}


@app.put('/api/moodle/settings', dependencies=[Depends(require_auth)])
async def put_moodle_settings(action: MoodleSettingsRequest):
    saved = save_moodle_settings(action)
    return {'ok': True, 'configuracao': saved,
            'mensagem': 'Preferências do SEDUCTEC salvas somente no perfil atual.'}


MIMI_SETTINGS_FILE = DATA / 'preferencias_mimi.json'
MIMI_DEFAULT_SETTINGS = {'nivel': 'A2', 'estilo': 'natural', 'idioma_apoio': 'pt'}


def read_mimi_settings() -> tuple[dict, bool]:
    settings = dict(MIMI_DEFAULT_SETTINGS)
    try:
        raw = json.loads(MIMI_SETTINGS_FILE.read_text('utf-8')) if MIMI_SETTINGS_FILE.exists() else {}
    except (OSError, ValueError, TypeError):
        raw = {}
    if isinstance(raw, dict):
        if raw.get('nivel') in ('A1', 'A2', 'B1', 'B2', 'C1', 'C2'):
            settings['nivel'] = raw['nivel']
        if raw.get('estilo') in ('curta', 'natural', 'detalhada'):
            settings['estilo'] = raw['estilo']
        if raw.get('idioma_apoio') in ('pt', 'en', 'bilíngue'):
            settings['idioma_apoio'] = raw['idioma_apoio']
    return settings, MIMI_SETTINGS_FILE.exists()


def save_mimi_settings(action: MimiSettingsRequest) -> dict:
    current, _ = read_mimi_settings()
    result = {
        'nivel': action.nivel or current['nivel'],
        'estilo': action.estilo or current['estilo'],
        'idioma_apoio': action.idioma_apoio or current['idioma_apoio'],
    }
    write_json_atomic(MIMI_SETTINGS_FILE, result)
    return result


@app.get('/api/mimi/settings', dependencies=[Depends(require_auth)])
async def get_mimi_settings():
    settings, saved = read_mimi_settings()
    return {'ok': True, 'configuracao': settings, 'salva': saved,
            'escopo': 'perfil atual', 'arquivo': 'preferencias_mimi.json'}


@app.put('/api/mimi/settings', dependencies=[Depends(require_auth)])
async def put_mimi_settings(action: MimiSettingsRequest):
    settings = save_mimi_settings(action)
    return {'ok': True, 'configuracao': settings,
            'mensagem': 'Preferências da MiMi salvas no servidor deste perfil.'}


@app.get('/api/ia/status', dependencies=[Depends(require_auth)])
async def local_ia_status():
    status = ia_status()
    probe = await asyncio.to_thread(probe_provider) if status.get('configurada') else {
        'pronto': False, 'conectado': False, 'mensagem': status.get('mensagem', 'IA não configurada.')}
    ready = probe.get('pronto') is True
    status.update({'conectado': probe.get('conectado') is True, 'pronta': ready,
                   'mensagem_conexao': probe.get('mensagem', ''),
                   'respostas_seductec': ready, 'respostas_englishcentral': ready})
    status['moodle_settings'] = read_moodle_settings()
    status['aviso'] = (
        'API OpenAI conectada. Enunciados, trechos de materiais selecionados e mensagens enviados à IA são processados pela nuvem; não envie dados pessoais. A conexão não confirma créditos de geração.'
        if ready and status.get('nuvem') else
        'Modelo local conectado e encontrado no servidor.'
        if ready else probe.get('mensagem') or 'Configure e conecte um provedor de IA para gerar respostas.')
    return status


@app.get('/api/moodle/status', dependencies=[Depends(require_auth)])
@browser_deadline(read_only=True)
async def moodle_status():
    async with lock:
        p = current_page()
        if not is_seductec_url(p.url):
            raise HTTPException(409, 'A aba atual não pertence ao SEDUCTEC.')
        overview = await inspect_moodle_page(p)
    questions = overview.get('questoes', []) or []
    answered = sum(1 for q in questions if q.get('estado') in ('respondida_nao_enviada', 'correta', 'incorreta'))
    partial = sum(1 for q in questions if q.get('estado') == 'parcial')
    pending = sum(1 for q in questions if q.get('estado') in ('nao_respondida', 'invalida'))
    page_type = overview.get('tipo_pagina')
    page_state = (overview.get('conclusao') or {}).get('estado', 'nao_confirmado')
    if page_type == 'quiz_revisao':
        state = 'concluido'
    elif page_type == 'quiz_resumo' and page_state == 'concluido':
        state = 'concluido'
    elif page_type == 'quiz_resumo':
        state = 'em_andamento'
    elif page_type == 'questionario' and questions and pending == 0:
        state = 'preenchido_nao_enviado'
    elif page_type == 'questionario' and (answered or partial):
        state = 'parcial'
    elif page_type == 'questionario':
        state = 'pendente'
    elif page_state == 'concluido':
        state = 'concluido'
    elif page_state == 'pendente':
        state = 'pendente'
    else:
        state = 'nao_confirmado'
    retry_items = overview.get('tentarNovamente') or []
    retry_labels = [str(item.get('texto') or '') for item in retry_items if not item.get('desabilitado', False)]
    can_retry = any(re.search(r'tentar novamente|nova tentativa|re-attempt|\bretry\b|reopen attempt', label, re.I)
                    for label in retry_labels)
    can_start = any(re.search(r'tentar (?:responder|iniciar).*question[aá]rio|iniciar (?:uma )?tentativa|attempt quiz now|start (?:a )?new attempt', label, re.I)
                    for label in retry_labels)
    return {
        'ok': True, 'plataforma': 'seductec', 'url': overview.get('url'),
        'tipo_pagina': page_type, 'estado': state,
        'questoes': {'total': len(questions), 'respondidas': answered, 'parciais': partial, 'pendentes': pending},
        'pdfs': overview.get('pdfs', []), 'forum': overview.get('forum', {}),
        'atividades': overview.get('atividades', []),
        'pode_iniciar_tentativa': can_start,
        'pode_tentar_novamente': can_retry,
        'botoes_tentar_novamente': retry_items,
        'evidencias': (overview.get('conclusao') or {}).get('evidencias', []),
        'configuracao': read_moodle_settings(),
        'aviso': 'Preenchido não significa enviado. A conclusão só é confirmada quando há evidência visível de conclusão/revisão no Moodle.'
    }


@app.post('/api/moodle/open-activity', dependencies=[Depends(require_auth)])
@browser_deadline('BROWSER_ACTION_TIMEOUT')
async def moodle_open_activity(action: MoodleOpenActivityRequest):
    """Navega somente para uma atividade que foi listada na página Moodle atual."""
    global page, context, last_snapshot
    await pause_for_manual_action()
    async with lock:
        p = current_page()
        if not is_seductec_url(p.url):
            raise HTTPException(409, 'Abra a página do curso SEDUCTEC antes de selecionar uma atividade.')
        try:
            target = normalize_seductec_url(action.url)
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc
        overview = await inspect_moodle_page(p)
        allowed = set()
        for item in overview.get('atividades', []) or []:
            candidate = item.get('url') if isinstance(item, dict) else None
            if candidate:
                try:
                    allowed.add(normalize_seductec_url(candidate))
                except ValueError:
                    continue
        if target not in allowed:
            raise HTTPException(409, 'Esse link não está entre as atividades visíveis do curso atual. Atualize a leitura do curso e tente novamente.')
        path = urlparse(target).path.casefold()
        if not path.startswith(('/mod/quiz/', '/mod/forum/', '/mod/resource/', '/mod/page/',
                                '/mod/url/', '/mod/book/', '/pluginfile.php/')):
            raise HTTPException(409, 'O link encontrado não corresponde a uma atividade Moodle suportada.')
        source_url = p.url
        try:
            await p.goto(target, wait_until='domcontentloaded', timeout=30000)
            if not is_seductec_url(p.url):
                try:
                    await p.goto(source_url, wait_until='domcontentloaded', timeout=15000)
                except Exception:
                    pass
                raise RuntimeError('A navegação saiu do domínio oficial; a página original foi restaurada quando possível.')
            page = p
            context = p.context
            last_snapshot = None
            await p.wait_for_timeout(250)
            result = await inspect_moodle_page(p)
            return {'ok': True, 'url': result.get('url'), 'tipo_pagina': result.get('tipo_pagina'),
                    'titulo': result.get('titulo'), 'pdfs': result.get('pdfs', []),
                    'questoes': len(result.get('questoes', []) or []),
                    'mensagem': 'Atividade aberta na sessão autenticada. A página foi relida antes da próxima ação.'}
        except HTTPException:
            raise
        except Exception as exc:
            raise HTTPException(502, f'Não consegui abrir a atividade detectada: {type(exc).__name__}: {str(exc)[:180]}') from exc


async def _generate_moodle_quiz_suggestions_in_batches(questions: list[dict], material: str,
                                                         max_attempts: int) -> tuple[list[dict], int]:
    """Gera sugestões em lotes paralelos limitados; só devolve após todos validarem."""
    if not isinstance(questions, list) or not questions:
        raise RuntimeError('Não há questões pendentes para analisar.')
    batches = [questions[offset:offset + 25] for offset in range(0, len(questions), 25)]
    attempts_limit = max(1, min(3, int(max_attempts)))
    semaphore = asyncio.Semaphore(3)
    calls = 0
    calls_lock = asyncio.Lock()

    async def solve_batch(index: int, batch: list[dict]) -> list[dict]:
        nonlocal calls
        best_batch = None
        best_score = -1
        last_error = None
        for attempt in range(attempts_limit):
            async with semaphore:
                async with calls_lock:
                    calls += 1
                try:
                    suggestions = await asyncio.to_thread(suggest_moodle_quiz, batch, material)
                except RuntimeError as exc:
                    last_error = str(exc)
                    if attempt + 1 >= attempts_limit:
                        raise RuntimeError(last_error) from exc
                    continue
            if not isinstance(suggestions, list) or len(suggestions) != len(batch):
                last_error = f'A IA devolveu um lote incompleto ({index + 1}).'
                if attempt + 1 >= attempts_limit:
                    raise RuntimeError(last_error)
                continue
            quality = score_moodle_quiz_suggestions(batch, suggestions, material)
            score = int(quality.get('pontuacao', 0))
            if score > best_score:
                best_batch, best_score = suggestions, score
            # AutoTune/ULTRAPLINIAN-inspired stopping rule: stop only when
            # the batch is structurally complete, grounded and high confidence.
            # This is a quality heuristic, never proof that answers are correct.
            structurally_complete = (
                quality.get('questoes_correspondentes') == len(batch) and
                quality.get('questoes_com_conteudo') == len(batch) and
                quality.get('indices_validos') == len(batch)
            )
            if (score >= 88 and structurally_complete and suggestions and
                    all(row.get('confianca') == 'alta' for row in suggestions)):
                break
        if not best_batch:
            raise RuntimeError(last_error or f'A IA não gerou sugestões válidas para o lote {index + 1}.')
        return best_batch

    # O gather preserva a ordem dos lotes, mesmo quando a IA responde fora de ordem.
    solved = await asyncio.gather(*(solve_batch(i, batch) for i, batch in enumerate(batches)))
    return [row for batch in solved for row in batch], calls


def _moodle_quiz_fingerprint(questions: list[dict]) -> str:
    """Assinatura dos enunciados/opções/campos para bloquear aplicação em DOM alterado."""
    projection = []
    for question in questions if isinstance(questions, list) else []:
        if not isinstance(question, dict):
            continue
        projection.append({
            'id': question.get('id'), 'indice': question.get('indice'),
            'texto': question.get('texto'), 'tipo': question.get('tipo'),
            'estado': question.get('estado'),
            'opcoes': [{key: option.get(key) for key in ('indice', 'tipo', 'valor', 'texto', 'selecionada', 'desabilitada')}
                       for option in question.get('opcoes', []) if isinstance(option, dict)],
            'campos': [{key: field.get(key) for key in ('indice', 'tipo', 'inputType', 'placeholder', 'opcoes', 'preenchido')}
                       for field in question.get('campos', []) if isinstance(field, dict)],
        })
    raw = json.dumps(projection, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
    return hashlib.sha256(raw.encode('utf-8')).hexdigest()


MOODLE_AUTOMATION_STATE_FILE = DATA / 'progresso_automacao_seductec.json'


def _read_moodle_automation_state() -> dict:
    try:
        raw = json.loads(MOODLE_AUTOMATION_STATE_FILE.read_text('utf-8')) if MOODLE_AUTOMATION_STATE_FILE.exists() else {}
        return raw if isinstance(raw, dict) else {}
    except (OSError, ValueError, TypeError):
        return {}


def _save_moodle_automation_item(course_url_value: str, item: dict, result: dict) -> None:
    # Somente metadados de progresso. Enunciados, respostas e cookies nunca são persistidos.
    try:
        state = _read_moodle_automation_state()
        courses = state.setdefault('cursos', {})
        course_key = normalize_seductec_url(course_url_value)
        course = courses.setdefault(course_key, {})
        activity_url = normalize_seductec_url(str(item.get('url') or ''))
        course[activity_url] = {
            'nome': str(item.get('nome') or 'Atividade')[:180],
            'tipo': str(item.get('tipo') or 'atividade')[:40],
            'estado': str(result.get('estado') or 'nao_confirmado')[:50],
            'atualizado_em': datetime.now(timezone.utc).isoformat(),
        }
        state['versao'] = 1
        write_json_atomic(MOODLE_AUTOMATION_STATE_FILE, state)
    except Exception as exc:
        logging.warning('Não foi possível persistir metadados de automação SEDUCTEC: %s', type(exc).__name__)


async def _process_moodle_automation_activity(worker_page, item: dict, lane: dict) -> dict:
    """Executa uma atividade real em uma aba lane isolada, sem tocar na aba principal."""
    target = normalize_seductec_url(str(item.get('url') or ''))
    if not is_seductec_url(target):
        raise ValueError('Atividade fora da origem oficial do SEDUCTEC.')
    lane['progresso'] = 5
    lane['fase'] = 'Abrindo atividade autenticada'
    await worker_page.goto(target, wait_until='domcontentloaded', timeout=35000)
    if not is_seductec_url(worker_page.url):
        raise ValueError('A atividade redirecionou para fora do SEDUCTEC; o agente interrompeu a execução.')
    await worker_page.wait_for_timeout(250)
    lane['progresso'] = 18
    overview = await inspect_moodle_page(worker_page)
    kind = page_kind(worker_page.url)
    lane['progresso'] = 30
    lane['fase'] = 'Analisando conteúdo e controles'
    # Check verde / conclusão já registrada no Moodle: não refaz a atividade.
    page_state = str((overview.get('conclusao') or {}).get('estado') or '')
    if page_state == 'concluido' and kind not in ('questionario',):
        return {
            'estado': 'pulado',
            'tipo': str(item.get('tipo') or kind or 'atividade'),
            'mensagem': 'Atividade já concluída no SEDUCTEC (indicador verde/check). Pulada pela automação.',
        }

    # PDF: leitura pela requisição autenticada, sem roubar a aba principal/preview.
    pdf_candidates = []
    if item.get('pdf') and is_direct_moodle_pdf(target):
        pdf_candidates.append(target)
    pdf_candidates.extend(url for row in overview.get('pdfs', []) or []
                          if (url := row.get('url')) and is_direct_moodle_pdf(url))
    if not pdf_candidates and kind == 'material' and urlparse(worker_page.url).path.startswith('/mod/resource/'):
        await worker_page.wait_for_timeout(500)
        fresh_overview = await inspect_moodle_page(worker_page)
        pdf_candidates.extend(url for row in fresh_overview.get('pdfs', []) or []
                              if (url := row.get('url')) and is_direct_moodle_pdf(url))
        overview = fresh_overview
    if pdf_candidates:
        pdf_url = normalize_seductec_url(pdf_candidates[0])
        lane['progresso'] = 42
        lane['fase'] = 'Abrindo PDF em aba temporária autenticada'
        pdf_page = await open_moodle_pdf(worker_page, pdf_url)
        lane['preview_page'] = pdf_page
        try:
            lane['progresso'] = 48
            lane['fase'] = 'Lendo PDF autenticado (até 50 páginas)'
            response = await pdf_page.request.get(pdf_url, timeout=30000)
            if not response.ok:
                raise RuntimeError(f'O Moodle retornou HTTP {response.status} ao carregar o PDF.')
            if not is_seductec_url(response.url):
                raise RuntimeError('O PDF redirecionou para uma origem externa. Leitura bloqueada.')
            body = await response.body()
            content_type = str(response.headers.get('content-type', '')).lower()
            if len(body) > 20 * 1024 * 1024:
                raise RuntimeError('PDF acima do limite de 20 MB.')
            if b'%PDF-' not in body[:1024] and 'application/pdf' not in content_type:
                raise RuntimeError('O recurso não retornou um arquivo PDF válido.')
            lane['progresso'] = 72
            lane['fase'] = 'Extraindo texto e confirmando leitura'
            extracted = await asyncio.to_thread(_extract_moodle_pdf_bytes, body)
            # Guarda uma captura do documento para a próxima atualização do painel,
            # mesmo que o processamento do PDF termine entre dois polls da interface.
            try:
                lane['last_preview_bytes'] = await pdf_page.screenshot(type='jpeg', quality=55, animations='disabled', timeout=5000)
            except Exception:
                lane['last_preview_bytes'] = None
            await pdf_page.wait_for_timeout(1450)
            lane['progresso'] = 95
            if extracted.get('legivel'):
                return {'estado': 'pdf_lido', 'tipo': 'pdf', 'paginas': extracted.get('paginas'),
                        'paginas_lidas': extracted.get('paginas_lidas'),
                        'caracteres_extraidos': len(extracted.get('texto') or ''),
                        # Conteúdo transitório consumido pelo orquestrador na fase
                        # de quiz/fórum. Nunca vai para o JSON de progresso/status.
                        '_contexto_material': extracted.get('texto') or '',
                        'mensagem': 'PDF autenticado aberto na prévia do agente, texto extraído e enviado ao contexto temporário da seção; a aba temporária foi fechada.'}
            return {'estado': 'nao_extraivel', 'tipo': 'pdf', 'paginas': extracted.get('paginas'),
                    'mensagem': extracted.get('aviso', 'PDF sem texto selecionável; leitura automática não confirmada.')}
        finally:
            try:
                if not pdf_page.is_closed():
                    await pdf_page.close()
            finally:
                lane['preview_page'] = None

    if kind in ('quiz_inicio', 'quiz_resumo', 'quiz_revisao'):
        lane['progresso'] = 35
        lane['fase'] = 'Verificando tentativa disponível'
        if kind in ('quiz_inicio', 'quiz_resumo'):
            try:
                await retry_moodle_quiz(worker_page)
                lane['fase'] = 'Tentativa aberta pelo controle visível; relendo questões'
                await worker_page.wait_for_timeout(350)
                overview = await inspect_moodle_page(worker_page)
                kind = page_kind(worker_page.url)
            except ValueError as exc:
                return {'estado': 'precisa_acao_manual', 'tipo': 'quiz', 'mensagem': str(exc)}
        if kind != 'questionario':
            return {'estado': 'precisa_acao_manual', 'tipo': 'quiz',
                    'mensagem': 'O Moodle não abriu uma tentativa ativa. Confira a página e a disponibilidade do quiz.'}
        cfg = read_moodle_settings()
        if cfg['modo'] not in ('tudo', 'quiz') or not cfg['preencher_quiz']:
            return {'estado': 'precisa_acao_manual', 'tipo': 'quiz',
                    'mensagem': 'O preenchimento de quizzes está desativado nas configurações do perfil.'}
        questions_all = overview.get('questoes', []) or []
        pending = [q for q in questions_all if q.get('estado') == 'nao_respondida']
        if not pending:
            state = 'preenchido_nao_enviado' if any(q.get('estado') in ('respondida_nao_enviada', 'parcial') for q in questions_all) else 'precisa_acao_manual'
            return {'estado': state, 'tipo': 'quiz', 'questoes': len(questions_all),
                    'mensagem': 'Não há questões pendentes seguras para preencher. Respostas existentes foram preservadas.'}
        original_url = worker_page.url
        original_fingerprint = _moodle_quiz_fingerprint(questions_all)
        # Primeiro o material da mesma seção lido na fase anterior; em seguida,
        # o texto visível da atividade atual. O modelo seleciona trechos relevantes.
        material = '\n\n'.join(x for x in (
            str(lane.get('_material_context') or ''), overview.get('curso', ''),
            overview.get('enunciadoAtividade', ''), overview.get('texto', '')
        ) if x)[:8000]
        attempts = cfg['max_tentativas'] if cfg['tentar_novamente'] else 1
        lane['progresso'] = 48
        lane['fase'] = f'Analisando {len(pending)} questões com IA'
        suggestions, calls = await _generate_moodle_quiz_suggestions_in_batches(pending, material, attempts)
        usable = [row for row in suggestions if row.get('confianca') != 'baixa' and (row.get('selecionadas') or row.get('texto'))]
        if not usable:
            return {'estado': 'precisa_acao_manual', 'tipo': 'quiz', 'questoes': len(pending),
                    'mensagem': 'A IA não atingiu confiança mínima. Nada foi alterado.'}
        if worker_page.url != original_url:
            raise RuntimeError('A página do quiz mudou durante a geração. Nenhuma resposta foi aplicada.')
        fresh = await inspect_moodle_page(worker_page)
        if _moodle_quiz_fingerprint(fresh.get('questoes', [])) != original_fingerprint:
            raise RuntimeError('O enunciado ou os controles do quiz mudaram. Atualize e tente novamente.')
        lane['progresso'] = 82
        lane['fase'] = 'Preenchendo e relendo campos pendentes'
        applied = await apply_moodle_quiz_suggestions(worker_page, usable)
        confirmed = int(applied.get('confirmadas', 0) or 0)
        state = ('preenchido_nao_enviado' if confirmed == len(pending) and confirmed == len(usable)
                 else 'parcial_nao_enviado' if confirmed else 'precisa_acao_manual')
        enviado = False
        envio_msg = ''
        # Opt-in real: só clica no botão de enviar/finalizar se a configuração
        # estiver ligada e o preenchimento estiver completo.
        if state == 'preenchido_nao_enviado' and cfg.get('enviar_quiz'):
            lane['fase'] = 'Enviando tentativa (opt-in ativo)'
            lane['progresso'] = 92
            submit_result = await submit_moodle_quiz_attempt(worker_page)
            enviado = bool(submit_result.get('enviado'))
            envio_msg = str(submit_result.get('mensagem') or '')
            if enviado:
                state = 'enviado'
        base_msg = (
            'Todos os campos pendentes receberam rascunhos e foram relidos; revise e envie manualmente.'
            if state == 'preenchido_nao_enviado' else
            'Preenchimento parcial confirmado. Revise as questões pendentes antes de enviar.'
            if state == 'parcial_nao_enviado' else
            'Tentativa enviada pelo botão visível do Moodle (opt-in). Confira o status na plataforma.'
            if state == 'enviado' else
            'Nenhum campo foi confirmado pelo Moodle.'
        )
        if envio_msg and state != 'enviado':
            base_msg = f'{base_msg} {envio_msg}'
        elif envio_msg and state == 'enviado':
            base_msg = envio_msg
        return {'estado': state, 'tipo': 'quiz', 'questoes': len(pending),
                'preenchidas': applied.get('preenchidas', 0),
                'confirmadas': confirmed, 'sugestoes_com_base': len(usable),
                'questoes_sem_base': max(0, len(pending) - len(usable)),
                'questoes_nao_aplicadas': len(applied.get('puladas', []) or []),
                'chamadas_ia': calls, 'enviadas': enviado,
                'mensagem': base_msg}

    if kind == 'forum':
        cfg = read_moodle_settings()
        if cfg['modo'] not in ('tudo', 'forum'):
            return {'estado': 'precisa_acao_manual', 'tipo': 'forum', 'mensagem': 'Fóruns desativados nas configurações.'}
        lane['progresso'] = 35
        lane['fase'] = 'Lendo discussão do fórum'
        if urlparse(worker_page.url).path.casefold().endswith('/mod/forum/view.php'):
            await open_moodle_discussion_from_listing(worker_page)
        overview = await inspect_moodle_page(worker_page)
        posts = overview.get('forum', {}).get('posts', []) or []
        post = next((row for row in reversed(posts) if row.get('podeResponder')), posts[-1] if posts else {})
        question = '\n'.join(x for x in (post.get('titulo', ''), post.get('texto', ''), overview.get('enunciadoAtividade', '')) if x).strip()
        if len(question) < 5:
            return {'estado': 'precisa_acao_manual', 'tipo': 'forum', 'mensagem': 'Nenhuma discussão com texto suficiente foi identificada.'}
        material = '\n\n'.join(x for x in (
            str(lane.get('_material_context') or ''), str(overview.get('texto') or '')
        ) if x)[:8000]
        lane['progresso'] = 58
        lane['fase'] = 'Gerando rascunho contextualizado'
        draft = await asyncio.to_thread(draft_moodle_answer, question[:2000], material, 'desenvolvida')
        if not draft.get('resposta'):
            return {'estado': 'precisa_acao_manual', 'tipo': 'forum', 'mensagem': 'A IA não gerou um rascunho utilizável.'}
        if cfg['preencher_forum']:
            lane['progresso'] = 82
            lane['fase'] = 'Abrindo editor e verificando rascunho'
            await open_moodle_forum_reply(worker_page)
            filled = await fill_moodle_forum_editor(worker_page, draft['resposta'])
            publicado = False
            pub_msg = ''
            # Opt-in real: só clica em Publicar/Enviar se a configuração estiver ligada
            # e o rascunho foi confirmado no editor.
            if filled.get('preenchido') and cfg.get('publicar_forum'):
                lane['fase'] = 'Publicando resposta (opt-in ativo)'
                lane['progresso'] = 94
                pub = await publish_moodle_forum_post(worker_page)
                publicado = bool(pub.get('publicado'))
                pub_msg = str(pub.get('mensagem') or '')
            if publicado:
                return {'estado': 'publicado', 'tipo': 'forum', 'preenchido': True,
                        'confianca': draft.get('confianca'), 'enviado': True,
                        'mensagem': pub_msg or 'Resposta publicada pelo botão visível do Moodle (opt-in).'}
            return {'estado': 'rascunho_nao_publicado', 'tipo': 'forum', 'preenchido': bool(filled.get('preenchido')),
                    'confianca': draft.get('confianca'), 'enviado': False,
                    'mensagem': (pub_msg or 'Rascunho preenchido e relido no editor. Publicação continua manual.')}
        return {'estado': 'rascunho_nao_publicado', 'tipo': 'forum', 'preenchido': False,
                'confianca': draft.get('confianca'), 'enviado': False,
                'mensagem': 'Rascunho gerado para revisão; preenchimento automático desativado.'}

    lane['progresso'] = 45
    lane['fase'] = 'Extraindo conteúdo visível da atividade'
    body_text = str(overview.get('texto') or '')[:9000]
    if kind == 'material' and len(body_text.strip()) >= 40:
        return {'estado': 'material_lido', 'tipo': 'material', 'caracteres': len(body_text),
                '_contexto_material': body_text,
                'mensagem': 'Material textual da atividade lido na página autenticada e encaminhado ao contexto temporário da seção.'}
    if kind in ('tarefa', 'assign', 'assignment'):
        return {'estado': 'precisa_acao_manual', 'tipo': 'tarefa',
                'mensagem': 'Tarefa identificada. O Studio não envia arquivos nem submete entregas.'}
    return {'estado': 'pulado', 'tipo': kind, 'mensagem': 'Tipo de atividade não suportado com segurança neste fluxo.'}


async def _process_moodle_automation_and_persist(worker_page, item: dict, lane: dict, course_url_value: str) -> dict:
    result = await _process_moodle_automation_activity(worker_page, item, lane)
    _save_moodle_automation_item(course_url_value, item, result)
    return result


@app.post('/api/moodle/automation/start', dependencies=[Depends(require_auth)])
@browser_deadline('BROWSER_ACTION_TIMEOUT')
async def moodle_automation_start(action: MoodleAutomationStartRequest):
    await pause_for_manual_action()
    async with lock:
        source = current_page()
        if not is_seductec_url(source.url) or page_kind(source.url) != 'curso':
            raise HTTPException(409, 'Abra a página principal do curso SEDUCTEC antes de iniciar a automação completa.')
        course_url_value = normalize_seductec_url(source.url)
        try:
            expansion = await expand_moodle_course_sections(source)
            overview = await inspect_moodle_page(source)
        except Exception as exc:
            raise HTTPException(502, f'Falha ao expandir/ler as seções do curso: {type(exc).__name__}: {str(exc)[:180]}') from exc
        def _moodle_activity_order(row):
            try:
                section_index = int(row.get('secao_indice', 0) or 0)
            except (TypeError, ValueError):
                section_index = 0
            try:
                activity_index = int(row.get('atividade_indice', 0) or 0)
            except (TypeError, ValueError):
                activity_index = 0
            return section_index, activity_index

        # Links sem href ou fora da origem oficial não podem bloquear o curso inteiro.
        activities = [row for row in (overview.get('atividades', []) or [])
                      if isinstance(row, dict) and row.get('url')]
        valid_activities = []
        for row in activities:
            try:
                row = dict(row)
                row['url'] = normalize_seductec_url(str(row['url']))
                valid_activities.append(row)
            except (TypeError, ValueError):
                continue
        activities = sorted(valid_activities, key=_moodle_activity_order)
        cfg = read_moodle_settings()
        if not action.incluir_materiais:
            activities = [row for row in activities if row.get('tipo') in ('quiz', 'forum', 'assign', 'assignment', 'tarefa')]
        if cfg['modo'] == 'pdf':
            activities = [row for row in activities if row.get('pdf') or row.get('tipo') == 'resource']
        elif cfg['modo'] == 'forum':
            activities = [row for row in activities if row.get('tipo') == 'forum']
        elif cfg['modo'] == 'quiz':
            activities = [row for row in activities if row.get('tipo') == 'quiz']
        saved_course = _read_moodle_automation_state().get('cursos', {}).get(course_url_value, {})
        already_done = [row for row in activities if row.get('conclusao') == 'concluido'
                        or saved_course.get(row['url'], {}).get('estado') in (
                            'pdf_lido', 'material_lido', 'enviado', 'publicado', 'concluido')]
        activities = [row for row in activities if row.get('conclusao') != 'concluido'
                      and saved_course.get(row['url'], {}).get('estado') not in (
                          'pdf_lido', 'material_lido', 'enviado', 'publicado', 'concluido')]
        course_context = source.context
        done_count = len(already_done)
        pending_count = len(activities)
    try:
        result = await moodle_automation.start(
            course_context, course_url_value, activities,
            lambda worker_page, item, lane: _process_moodle_automation_and_persist(worker_page, item, lane, course_url_value),
            action.agentes)
    except (RuntimeError, ValueError) as exc:
        raise HTTPException(409, str(exc)) from exc
    result['varredura'] = expansion
    result['secoes'] = len(overview.get('secoes', []) or [])
    result['atividades_encontradas'] = len(overview.get('atividades', []) or [])
    result['ja_concluidas'] = done_count
    result['pendentes'] = pending_count
    record(f"Automação SEDUCTEC iniciada: {pending_count} pendente(s), {done_count} já concluída(s), {action.agentes} agente(s).")
    msg = (f'Fila iniciada com {pending_count} atividade(s) pendente(s). '
           f'{done_count} já marcada(s) como concluída(s) pelo check verde do SEDUCTEC e foram puladas. '
           f'Cada agente usa aba independente.')
    return {'ok': True, 'automacao': result, 'mensagem': msg}


@app.get('/api/moodle/automation/status', dependencies=[Depends(require_auth)])
async def moodle_automation_status():
    return {'ok': True, 'automacao': moodle_automation.snapshot()}


@app.post('/api/moodle/automation/stop', dependencies=[Depends(require_auth)])
async def moodle_automation_stop():
    result = await moodle_automation.stop()
    return {'ok': result.get('ok', True), 'automacao': moodle_automation.snapshot(),
            'mensagem': 'Parada solicitada. A ação atual de cada agente termina antes de parar.'}


@app.get('/api/moodle/automation/lanes/{lane_id}/screenshot', dependencies=[Depends(require_auth)])
async def moodle_automation_lane_screenshot(lane_id: str):
    if not re.fullmatch(r'agente-[1-4]', lane_id):
        raise HTTPException(404, 'Agente não encontrado.')
    raw = await moodle_automation.screenshot(lane_id)
    if raw is None:
        raise HTTPException(404, 'Prévia do agente ainda não está disponível.')
    return Response(raw, media_type='image/jpeg', headers={'Cache-Control': 'no-store, private', 'X-Content-Type-Options': 'nosniff'})


@app.post('/api/moodle/automation/close', dependencies=[Depends(require_auth)])
async def moodle_automation_close():
    if moodle_automation.running:
        raise HTTPException(409, 'Pare a automação antes de fechar as prévias dos agentes.')
    closed = await moodle_automation.close_pages()
    return {'ok': True, 'abas_fechadas': closed}


@app.post('/api/moodle/quiz/assist', dependencies=[Depends(require_auth)])
@browser_deadline('BROWSER_ACTION_TIMEOUT')
async def moodle_quiz_assist(action: MoodleQuizAssistRequest):
    cfg = read_moodle_settings()
    if cfg['modo'] not in ('tudo', 'quiz') or not cfg['preencher_quiz']:
        raise HTTPException(409, 'A configuração atual não permite assistência de quiz. Altere o modo para Quiz ou Tudo.')
    await pause_for_manual_action()
    async with lock:
        p = current_page()
        if not is_seductec_url(p.url) or page_platform(p.url).get('id') != 'seductec':
            raise HTTPException(409, 'Abra um questionário do SEDUCTEC primeiro.')
        original_url = p.url
        overview = await inspect_moodle_page(p)
        if overview.get('tipo_pagina') != 'questionario':
            raise HTTPException(409, 'Abra uma tentativa ativa do questionário. Resumo e revisão não aceitam preenchimento.')
    questions = overview.get('questoes', []) or []
    if action.somente_pendentes:
        questions = [q for q in questions if q.get('estado') == 'nao_respondida']
    if not questions:
        question_rows = overview.get('questoes', []) or []
        has_partial = any(q.get('estado') == 'parcial' for q in question_rows)
        return {'ok': True, 'estado': 'questoes_parciais' if has_partial else 'sem_questoes_pendentes',
                'total': len(question_rows), 'preenchidas': 0, 'confirmadas': 0, 'enviadas': False,
                'mensagem': ('Há questões com vários campos parcialmente preenchidos. Este fluxo não replica uma única resposta em vários campos; revise e complete manualmente.'
                             if has_partial else 'Não há questões pendentes visíveis. Isso não confirma envio nem nota.')}
    material = '\n\n'.join(x for x in (overview.get('curso', ''), overview.get('enunciadoAtividade', ''), overview.get('texto', '')) if x)[:5000]
    attempts = 1 if not cfg['tentar_novamente'] else cfg['max_tentativas']
    try:
        best, used = await _generate_moodle_quiz_suggestions_in_batches(questions, material, attempts)
    except RuntimeError as exc:
        # Nenhum campo é alterado se um dos lotes falhar na geração/validação.
        raise HTTPException(503, str(exc)) from exc
    low = [row for row in best if row['confianca'] == 'baixa' or not (row['selecionadas'] or row['texto'])]
    usable = [row for row in best if row not in low]
    if not usable:
        return {'ok': True, 'estado': 'precisa_revisao', 'sugestoes': best, 'preenchidas': 0,
                'baixa_confianca': len(low), 'tentativas_ia': used, 'enviadas': False,
                'mensagem': 'A IA não atingiu confiança mínima. Nada foi preenchido; confira o enunciado/material e tente novamente.'}
    async with lock:
        p = current_page()
        if p.url != original_url:
            raise HTTPException(409, 'A aba mudou durante a geração. Nada foi preenchido; inspecione a atividade novamente.')
        fresh = await inspect_moodle_page(p)
        if _moodle_quiz_fingerprint(fresh.get('questoes', [])) != _moodle_quiz_fingerprint(overview.get('questoes', [])):
            raise HTTPException(409, 'Os enunciados, opções ou campos mudaram durante a geração. Nada foi preenchido; atualize a inspeção e tente novamente.')
        if action.aplicar:
            try:
                applied = await apply_moodle_quiz_suggestions(p, usable)
            except ValueError as exc:
                raise HTTPException(409, str(exc)) from exc
        else:
            applied = {'preenchidas': 0, 'confirmadas': 0, 'detalhes': [], 'enviadas': False, 'estado': 'somente_sugestoes'}
    return {'ok': True, **applied, 'sugestoes': best, 'total_analisadas': len(questions),
            'baixa_confianca': len(low), 'tentativas_ia': used, 'pagina': original_url,
            'enviadas': False,
            'mensagem': f"{applied.get('confirmadas', 0)} de {len(usable)} preenchimento(s) confirmado(s) no formulário. Nada foi enviado/submetido."
            if action.aplicar else 'Sugestões geradas, sem alterar os campos.'}


@app.post('/api/moodle/quiz/retry', dependencies=[Depends(require_auth)])
@browser_deadline('BROWSER_ACTION_TIMEOUT')
async def moodle_quiz_retry():
    await pause_for_manual_action()
    async with lock:
        p = current_page()
        if not is_seductec_url(p.url):
            raise HTTPException(409, 'Abra primeiro o SEDUCTEC.')
        try:
            result = await retry_moodle_quiz(p)
        except ValueError as exc:
            raise HTTPException(409, str(exc)) from exc
        return result


@app.post('/api/moodle/forum/open-reply', dependencies=[Depends(require_auth)])
@browser_deadline('BROWSER_ACTION_TIMEOUT')
async def moodle_forum_open_reply():
    await pause_for_manual_action()
    async with lock:
        p = current_page()
        if not is_seductec_url(p.url):
            raise HTTPException(409, 'Abra primeiro uma discussão do SEDUCTEC.')
        try:
            return await open_moodle_forum_reply(p)
        except ValueError as exc:
            raise HTTPException(409, str(exc)) from exc


@app.post('/api/moodle/forum/draft', dependencies=[Depends(require_auth)])
async def moodle_forum_draft():
    cfg = read_moodle_settings()
    if cfg['modo'] not in ('tudo', 'forum'):
        raise HTTPException(409, 'Selecione Forum ou Tudo nas configurações do SEDUCTEC.')
    async with lock:
        p = current_page()
        if not is_seductec_url(p.url) or page_platform(p.url).get('tipo_pagina') != 'forum':
            raise HTTPException(409, 'Abra um fórum do SEDUCTEC.')
        try:
            await open_moodle_discussion_from_listing(p)
        except ValueError as exc:
            raise HTTPException(409, str(exc)) from exc
        overview = await inspect_moodle_page(p)
    posts = (overview.get('forum') or {}).get('posts') or []
    # O mesmo post com botão Responder visível é usado pelo abridor do editor.
    # Assim, o rascunho não responde a uma mensagem diferente daquela selecionada.
    post = next((item for item in reversed(posts) if item.get('podeResponder')), posts[-1] if posts else {})
    question = '\n'.join(x for x in (post.get('titulo', ''), post.get('texto', ''), overview.get('enunciadoAtividade', '')) if x).strip()
    if len(question) < 5:
        raise HTTPException(409, 'Não encontrei uma postagem/enunciado legível. Selecione o texto do fórum e use o assistente de rascunho.')
    material = (overview.get('texto') or '')[:5000]
    try:
        result = await asyncio.to_thread(draft_moodle_answer, question[:2000], material, 'desenvolvida')
    except RuntimeError as exc:
        raise HTTPException(503, str(exc)) from exc
    return {**result, 'pergunta': question[:2000], 'pagina': overview.get('url'),
            'aviso': 'Rascunho para discussão. Revise, respeite as regras do fórum e publique manualmente.'}


@app.post('/api/moodle/forum/fill', dependencies=[Depends(require_auth)])
@browser_deadline('BROWSER_ACTION_TIMEOUT')
async def moodle_forum_fill(action: MoodleForumFillRequest):
    cfg = read_moodle_settings()
    if cfg['modo'] not in ('tudo', 'forum') or not cfg['preencher_forum']:
        raise HTTPException(409, 'Ative Preencher rascunho de fórum e selecione Forum ou Tudo nas configurações.')
    await pause_for_manual_action()
    async with lock:
        p = current_page()
        if not is_seductec_url(p.url):
            raise HTTPException(409, 'Abra um fórum do SEDUCTEC.')
        try:
            return await fill_moodle_forum_editor(p, action.resposta)
        except ValueError as exc:
            raise HTTPException(409, str(exc)) from exc


@app.post('/api/moodle/open-pdf', dependencies=[Depends(require_auth)])
@browser_deadline('BROWSER_ACTION_TIMEOUT')
async def moodle_open_pdf(action: MoodleOpenPDFRequest):
    global page, context, moodle_pdf_page, moodle_pdf_return_page
    cfg = read_moodle_settings()
    if cfg['modo'] not in ('tudo', 'pdf'):
        raise HTTPException(409, 'Selecione PDF ou Tudo nas configurações do SEDUCTEC.')
    await pause_for_manual_action()
    async with lock:
        source = current_page()
        if not is_seductec_url(source.url):
            raise HTTPException(409, 'Abra o SEDUCTEC antes de abrir um PDF.')
        if moodle_pdf_page is not None:
            try:
                if not moodle_pdf_page.is_closed():
                    raise HTTPException(409, 'Já existe uma aba PDF aberta. Feche-a antes de abrir outro documento.')
            except AttributeError:
                moodle_pdf_page = None
        try:
            opened_page = await open_moodle_pdf(source, action.url)
        except Exception as exc:
            raise HTTPException(409, f'Não foi possível abrir o PDF: {str(exc)[:240]}') from exc
        moodle_pdf_return_page = source
        moodle_pdf_page = opened_page
        page = opened_page
        context = opened_page.context
        return {'ok': True, 'url': opened_page.url, 'titulo': await opened_page.title(),
                'mensagem': 'PDF aberto em uma nova aba autenticada. Use Fechar PDF para retornar ao curso.'}


@app.post('/api/moodle/close-pdf', dependencies=[Depends(require_auth)])
@browser_deadline('BROWSER_ACTION_TIMEOUT')
async def moodle_close_pdf():
    global page, context, moodle_pdf_page, moodle_pdf_return_page
    async with lock:
        pdf_page = moodle_pdf_page
        if pdf_page is None:
            return {'ok': True, 'fechado': False, 'restaurado': False,
                    'mensagem': 'Não há PDF temporário aberto pelo assistente.'}

        # Não declarar sucesso enquanto a aba temporária continuar aberta.
        try:
            if not pdf_page.is_closed():
                await pdf_page.close()
        except Exception as exc:
            try:
                still_open = not pdf_page.is_closed()
            except Exception:
                still_open = True
            if still_open:
                return {'ok': False, 'fechado': False, 'restaurado': False,
                        'mensagem': f'Não consegui fechar a aba PDF ({type(exc).__name__}). Tente novamente.'}

        try:
            closed = pdf_page.is_closed()
        except Exception:
            closed = False
        if not closed:
            return {'ok': False, 'fechado': False, 'restaurado': False,
                    'mensagem': 'A aba PDF continua aberta. O Studio não marcou o fechamento como concluído.'}

        restored = moodle_pdf_return_page
        if restored is None:
            # Recupera a aba do curso se o usuário a tiver fechado/recriado enquanto lia.
            try:
                candidates = [candidate for candidate in available_pages()
                              if not candidate.is_closed() and is_seductec_url(candidate.url)]
                restored = candidates[-1] if candidates else None
            except Exception:
                restored = None

        moodle_pdf_page = None
        moodle_pdf_return_page = None
        restored_ok = False
        if restored is not None:
            try:
                if not restored.is_closed() and is_seductec_url(restored.url):
                    page = restored
                    context = restored.context
                    await restored.bring_to_front()
                    restored_ok = True
            except Exception:
                # A referência pode continuar utilizável mesmo quando bring_to_front
                # não é permitido pelo backend; confirme apenas a restauração do contexto.
                try:
                    if not restored.is_closed() and is_seductec_url(restored.url):
                        page = restored
                        context = restored.context
                        restored_ok = True
                except Exception:
                    restored_ok = False
        if not restored_ok:
            try:
                candidates = [candidate for candidate in available_pages() if not candidate.is_closed()]
                if candidates:
                    page = candidates[-1]
                    context = page.context
            except Exception:
                pass
        return {'ok': True, 'fechado': True, 'restaurado': restored_ok,
                'url': getattr(page, 'url', ''),
                'mensagem': ('PDF fechado e curso restaurado.' if restored_ok else
                             'PDF fechado, mas não consegui restaurar a aba anterior. Selecione novamente a aba do SEDUCTEC.')}


def _extract_moodle_pdf_bytes(body: bytes) -> dict:
    """Extrai texto em thread de trabalho e limita páginas/caracteres apresentados."""
    from io import BytesIO
    from pypdf import PdfReader

    reader = PdfReader(BytesIO(body))
    page_count = len(reader.pages)
    pages = reader.pages[:50]
    chunks = []
    remaining = 24000
    pages_examined = 0
    for pdf_page in pages:
        if remaining <= 0:
            break
        pages_examined += 1
        text = (pdf_page.extract_text() or '').strip()
        if text:
            piece = text[:remaining]
            chunks.append(piece)
            remaining -= len(piece)
    extracted = '\n\n'.join(chunks).strip()[:24000]
    if not extracted:
        return {'ok': True, 'texto': '', 'paginas': page_count, 'paginas_lidas': pages_examined,
                'legivel': False,
                'aviso': 'O PDF parece ser digitalizado ou não contém texto selecionável. OCR não está habilitado neste fluxo.'}
    return {'ok': True, 'texto': extracted, 'paginas': page_count, 'paginas_lidas': pages_examined,
            'legivel': True,
            'aviso': 'Texto extraído do PDF autenticado. Confira gráficos, tabelas e páginas que possam não ter texto selecionável.'}


@app.post('/api/moodle/pdf/read', dependencies=[Depends(require_auth)])
@browser_deadline('BROWSER_ACTION_TIMEOUT')
async def moodle_read_pdf(action: MoodleOpenPDFRequest):
    async with lock:
        p = current_page()
        if not is_seductec_url(p.url):
            raise HTTPException(409, 'Abra uma página do SEDUCTEC antes de ler o PDF.')
        overview = await inspect_moodle_page(p)
        allowed = {item.get('url') for item in overview.get('pdfs', []) if item.get('url')}
        target = normalize_seductec_url(action.url)
        if target not in allowed:
            raise HTTPException(409, 'O PDF não foi identificado na página atual. Atualize a leitura da atividade e selecione um recurso visível.')
        try:
            response = await p.request.get(target, timeout=30000)
            if not response.ok:
                raise RuntimeError(f'O Moodle retornou HTTP {response.status}.')
            if not is_seductec_url(response.url):
                raise RuntimeError('O PDF redirecionou para outra origem; a leitura foi bloqueada.')
            content_type = response.headers.get('content-type', '').lower()
            body = await response.body()
            if len(body) > 20 * 1024 * 1024:
                raise RuntimeError('O PDF ultrapassa o limite de leitura de 20 MB.')
            if b'%PDF-' not in body[:1024] and 'application/pdf' not in content_type:
                raise RuntimeError('O recurso não retornou um PDF. Talvez seja preciso abrir o material no Moodle primeiro.')
        except HTTPException:
            raise
        except Exception as exc:
            raise HTTPException(422, f'Falha ao obter o PDF: {type(exc).__name__}: {str(exc)[:180]}') from exc

    # A extração é CPU-bound; não bloquear o event loop nem manter o lock do
    # navegador enquanto o pypdf analisa até 50 páginas.
    try:
        return await asyncio.to_thread(_extract_moodle_pdf_bytes, body)
    except Exception as exc:
        raise HTTPException(422, f'Falha ao ler o PDF: {type(exc).__name__}: {str(exc)[:180]}') from exc


@app.post('/api/mimi/chat', dependencies=[Depends(require_auth)])
async def mimi_chat(action: MimiChatRequest):
    async with lock:
        p = current_page()
        if not platform_url(p.url):
            raise HTTPException(409, 'Abra primeiro um vídeo do EnglishCentral para conversar com a MiMi.')
        try:
            has_video = await p.locator('video').count() > 0
            if not has_video and not re.search(r'/video|/lesson|/watch', urlparse(p.url).path, re.I):
                raise HTTPException(409, 'Abra um vídeo do EnglishCentral antes de conversar com a MiMi.')
            context_data = await p.evaluate(r'''() => {
              const clean=(s,n)=>String(s||'').replace(/\\s+/g,' ').trim().slice(0,n);
              const visible=e=>{if(!e)return false;const r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'};
              const captions=[...document.querySelectorAll('[class*="subtitle"],[class*="caption"],[aria-live="polite"],.transcript,.transcript-line')].filter(visible).map(e=>clean(e.innerText,240)).filter(Boolean).slice(-20);
              return {title:clean(document.querySelector('h1,h2,[data-testid*="title"]')?.innerText||document.title,180),captions:captions.join('\\n'),text:clean(document.body?.innerText,2200)};
            }''')
        except Exception:
            context_data = {'title': await p.title(), 'captions': '', 'text': ''}
    video_context = '\n'.join(str(context_data.get(k) or '') for k in ('title', 'captions', 'text'))[:3500]
    try:
        result = await asyncio.to_thread(mimi_video_chat, action.mensagem, video_context, action.historico, action.nivel, action.estilo, action.idioma_apoio)
    except RuntimeError as exc:
        raise HTTPException(503, str(exc)) from exc
    return {**result, 'oficial': False, 'aviso': 'Companheira de prática do Studio. Esta conversa não é a MiMi oficial e não gera XP ou registro no EnglishCentral.'}


@app.post('/api/mimi/open-official', dependencies=[Depends(require_auth)])
@browser_deadline('BROWSER_ACTION_TIMEOUT')
async def mimi_open_official():
    await pause_for_manual_action()
    async with lock:
        p = current_page()
        if not platform_url(p.url):
            raise HTTPException(409, 'Abra um vídeo do EnglishCentral primeiro.')
        candidates = p.locator('button,a,[role="button"]')
        for index in range(min(await candidates.count(), 120)):
            item = candidates.nth(index)
            try:
                if not await item.is_visible() or not await item.is_enabled():
                    continue
                label = await item.evaluate('(e)=>e.innerText||e.getAttribute("aria-label")||e.getAttribute("title")||""')
                if not re.search(r'\bmimi\b|chat with|conversation practice|conversar', str(label), re.I):
                    continue
                await item.click(timeout=5000)
                await p.wait_for_timeout(350)
                return {'ok': True, 'oficial': True, 'mensagem': 'Controle visível da MiMi no EnglishCentral acionado. Confira a interface oficial no navegador.'}
            except Exception:
                continue
    raise HTTPException(404, 'Não encontrei o controle oficial da MiMi nesta tela. Abra o vídeo e confira se o recurso está disponível para sua conta/região; a conversa alternativa do Studio continua disponível.')


@app.post('/api/moodle/draft', dependencies=[Depends(require_auth)])
async def draft_seductec_answer(action: MoodleDraftRequest):
    async with lock:
        p = current_page()
        if not is_seductec_url(p.url):
            raise HTTPException(409, 'Abra primeiro uma página do SEDUCTEC no navegador do Studio.')
        overview = await inspect_moodle_page(p)

    page_material = '\n\n'.join(part for part in (
        overview.get('curso', ''),
        overview.get('enunciadoAtividade', ''),
        overview.get('texto', ''),
    ) if isinstance(part, str) and part.strip())
    supplied_material = action.material.strip()
    combined = '\n\n'.join(part for part in (supplied_material, page_material) if part)
    combined = combined[:8000]
    try:
        result = await asyncio.to_thread(draft_moodle_answer, action.pergunta, combined, action.formato)
    except RuntimeError as exc:
        message = str(exc)
        code = 400 if any(token in message.lower() for token in ('informe', 'formato', 'exige um modelo local', 'configure')) else 503
        raise HTTPException(code, message) from exc
    record('Rascunho de resposta preparado pela IA local no SEDUCTEC; não preenchido nem enviado.')
    return {
        **result,
        'modelo': ia_status().get('modelo', ''),
        'pagina': overview.get('url', ''),
        'origem_material': 'material informado e texto visível da página atual',
        'preenchida': False,
        'enviada': False,
        'aviso': 'Revise o conteúdo antes de usar. A confiança é uma estimativa do modelo, não uma garantia de correção.',
    }


@app.post('/api/moodle/feedback', dependencies=[Depends(require_auth)])
async def moodle_answer_feedback(action: MoodleFeedbackRequest):
    async with lock:
        p = current_page()
        if not is_seductec_url(p.url):
            raise HTTPException(409, 'Abra primeiro uma página do SEDUCTEC para avaliar a resposta.')
    try:
        result = await asyncio.to_thread(record_moodle_feedback, action.pergunta, action.avaliacao)
    except RuntimeError as exc:
        raise HTTPException(400, str(exc)) from exc
    record('Preferência de qualidade da IA local atualizada para uma tarefa Moodle; sem guardar enunciado ou resposta.')
    return {**result, 'aviso': 'A avaliação foi salva localmente como preferência agregada. O enunciado, o material e a resposta não foram armazenados.'}


@app.post('/api/fill', dependencies=[Depends(require_auth)])
@browser_deadline('BROWSER_ACTION_TIMEOUT')
async def fill(action: FillField):
    global last_snapshot
    await pause_for_manual_action()
    async with lock:
        p = current_page()
        if not last_snapshot or last_snapshot['url'] != p.url:
            raise HTTPException(409, 'Analise a atividade primeiro.')
        matches = [f for f in last_snapshot['campos'] if f['frame']==action.frame and f['id']==action.id]
        if len(matches)!=1:
            raise HTTPException(409, 'Campo não identificado. Analise novamente.')
        if last_snapshot.get('loginDetectado'):
            raise HTTPException(409, 'Página de login detectada. Digite suas credenciais manualmente.')
        try:
            await fill_selected(p, action.frame, action.id, action.resposta)
        except Exception as exc:
            raise HTTPException(409, f'Falha ao preencher o campo: {type(exc).__name__}. Atualize a inspeção.')
        # O sistema preenche o campo, mas não envia a resposta.
        record('Uma lacuna foi preenchida sob comando do usuário (não enviada).')
        return {'ok': True, 'enviado': False}


@app.post('/api/video', dependencies=[Depends(require_auth)])
@browser_deadline('BROWSER_ACTION_TIMEOUT')
async def video(action: VideoAction):
    await pause_for_manual_action()
    async with lock:
        p = current_page()
        try:
            state = await toggle_video(p, action.frame, action.id, action.acao)
        except Exception as exc:
            raise HTTPException(409, f'Player indisponível: {type(exc).__name__}. Use a tela remota.')
        record('Controle do vídeo acionado pelo usuário: '+action.acao)
        return {'ok': True, **state}


@app.get('/api/study', dependencies=[Depends(require_auth)])
async def study():
    return local_study()


@app.post('/api/study', dependencies=[Depends(require_auth)])
@browser_deadline('BROWSER_ACTION_TIMEOUT')
async def study_note(note: StudyNote):
    async with lock:
        p = current_page()
        if not (platform_url(p.url) or is_seductec_url(p.url)):
            raise HTTPException(409, 'Abra uma página do EnglishCentral ou do SEDUCTEC para registrar visita.')
        data = local_study()
        pages = data['paginas']
        item = {'url': p.url[:450], 'titulo': (await p.title())[:150],
                'registrado_em': datetime.now(timezone.utc).isoformat(),
                'observacao': note.observacao.strip()}
        pages[:] = [x for x in pages if x.get('url') != item['url']][-199:]
        pages.append(item)
        save_study(data)
        record('Visita à página registrada localmente, sem concluir a aula na plataforma.')
        return {'ok': True, 'numeroPaginas': len(pages)}


@app.get('/api/log', dependencies=[Depends(require_auth)])
async def log():
    return {'eventos': list(entries)}




@app.post('/api/profile/second', dependencies=[Depends(require_auth)])
async def second_profile():
    # Compatibilidade com painéis antigos; os novos usam /api/profiles.
    manager = profile_manager()
    people = await asyncio.to_thread(manager.list)
    if not any(person['id'] == 'pessoa2' for person in people):
        await asyncio.to_thread(manager.create)
    return await open_profile_response('pessoa2')


install_mobile_routes(app, ROOT, profile_manager, REMOTE_CONFIG)


if __name__ == '__main__':
    import uvicorn
    import argparse
    parser = argparse.ArgumentParser(description='Painel de acompanhamento remoto')
    parser.add_argument('--host', default='127.0.0.1', help='Use 127.0.0.1 com túnel privado (padrão)')
    parser.add_argument('--port', type=int, default=8765)
    args = parser.parse_args()
    if REMOTE_CONFIG.enabled:
        get_token()
        print('Servidor remoto preparado. Consulte o acesso privado com acesso_servidor.py.', flush=True)
        print('Painel: ' + REMOTE_CONFIG.origin, flush=True)
    else:
        print('Modo celular (Termux):', 'ATIVADO' if TERMUX else 'desativado (use EC_TERMUX=1 para forçar)', flush=True)
        print('TOKEN DO PAINEL (guarde em local seguro):', get_token(), flush=True)
        print(f'Abra no servidor: http://{args.host}:{args.port} (ou configure acesso privado HTTPS)', flush=True)
        if TERMUX:
            print(f'No Chrome do celular abra: http://127.0.0.1:{args.port}/#token=' + get_token(), flush=True)
            print('Dados e login salvos em:', DATA, flush=True)
            if DATA_RELOCATED:
                print('(Pasta do projeto está no armazenamento compartilhado; dados movidos para a pasta interna do Termux.)', flush=True)
            exe = termux_chromium_path()
            print('Navegador do assistente:', exe or 'NÃO ENCONTRADO -> rode: pkg install x11-repo && pkg install chromium', flush=True)
            print('Dica: rode "termux-wake-lock" para o Android não pausar o servidor com a tela apagada.', flush=True)
    if TERMUX:
        import socket
        with socket.socket() as probe:
            probe.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                probe.bind((args.host, args.port))
            except OSError:
                print(f'\nA porta {args.port} já está em uso: há um servidor antigo aberto (o painel que você vê no Chrome é o dele).', flush=True)
                print('Encerre com:  pkill -f servidor.py   e rode de novo (ou use --port 8766).', flush=True)
                raise SystemExit(1)
    uvicorn.run(app, host=args.host, port=args.port, proxy_headers=True,
                forwarded_allow_ips=os.getenv('EC_TRUSTED_PROXY_IPS', '127.0.0.1'))
