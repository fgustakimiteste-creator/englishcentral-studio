"""Fluxo representativo de fala com gravador real, sem acessar conta ou site.

Os seletores desta fixture são um contrato de teste, não documentação do DOM
atual do EnglishCentral. Há atraso real entre capturar a pista e iniciar o
MediaRecorder para impedir que uma pista viva seja confundida com gravação.
"""
import asyncio
from unittest.mock import AsyncMock, patch

from playwright.async_api import async_playwright

from auto_fluxo import EngineState, process_page
from conftest import chromium_launch_options
from ec_player import inspect_ec_player
from fala_sintetica import SYNTHETIC_MIC_INIT
from modos import ModoEstudo
from test_synthetic_audio import _tone_wav


SPEECH_PAGE = '''<!doctype html><title>Aula local de fala</title><style>
ec-activity-app,ec-player-app,ec-activity-interstitial,ec-activity-list,ec-speak-interstitial,ec-speak-mode,
ec-speak-microphone,ec-speech-meter,ec-speech-feedback{display:block}
[hidden]{display:none!important}video{width:160px;height:90px}button{padding:12px}
.player-transcript-row{padding:12px}.recording-indicator{padding:8px}
</style><ec-activity-app><div class="player-app-wrapper"><ec-player-app>
<div id="activity-app-container" class="speak-mode">
 <video id="ns-dialog-123" width="160" height="90"></video>
 <p data-testid="player-speech-listening" hidden>Ouvindo a frase</p>
 <section id="speech-area" hidden>
 <ec-speak-mode>
  <div class="player-transcript-row current" data-line-id="101" dialog-line-id="101">
   <span lang="en" class="player-transcript-line">This is the same line.</span>
   <span class="player-transcript-translation">Esta é a mesma linha.</span>
  </div>
  <ec-speak-microphone><button data-testid="player-record" aria-label="Gravar">Gravar</button></ec-speak-microphone>
  <p data-testid="player-recording-pending" hidden>Preparando gravação</p>
  <ec-speech-meter><p class="recording-indicator" data-testid="player-recording-indicator" hidden>Gravando</p></ec-speech-meter>
  <button data-testid="player-stop-recording" aria-label="Parar gravação" hidden>Stop recording</button>
  <p class="speech-processing" data-testid="player-recording-processing" hidden>Processando gravação</p>
  <ec-speech-feedback><div class="speak-result" data-testid="player-recording-result" hidden></div></ec-speech-feedback>
  <button data-testid="player-next-line" hidden>Próxima linha</button>
 </ec-speak-mode></section>
</div></ec-player-app><ec-activity-interstitial><ec-speak-interstitial>
  <p id="selected-lines">Linhas selecionadas: 0</p>
  <div class="footer-button disabled" aria-disabled="true" data-testid="player-start-speaking">Comece a Falar</div>
</ec-speak-interstitial></ec-activity-interstitial></div><ec-activity-list>
 <button data-testid="player-activity-button" class="activity-list-watch completed">Assista ao vídeo</button>
 <button data-testid="player-activity-button" class="activity-list-learn completed">Aprenda as palavras</button>
 <button data-testid="player-activity-button" class="activity-list-speak active">Fale as linhas</button>
</ec-activity-list></ec-activity-app><script>
window.speechEvents=[];window.startClicks=0;window.recordClicks=0;window.stopClicks=0;
window.nextClicks=0;window.recordings=[];window.lineIndex=0;window.failCapture=false;
window.keepSelection=false;
window.persistZero=false;
const find=testid=>document.querySelector('[data-testid="'+testid+'"]');
const show=(testid,value)=>find(testid).hidden=!value;
const line=()=>document.querySelector('.player-transcript-row');
const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
setTimeout(()=>{
 if(window.persistZero)return;
 document.querySelector('#selected-lines').textContent='Linhas selecionadas: 2';
 find('player-start-speaking').textContent='Falar 2 linhas';
 find('player-start-speaking').classList.remove('disabled');
 find('player-start-speaking').removeAttribute('aria-disabled');
},180);
find('player-start-speaking').onclick=()=>{
 if(find('player-start-speaking').classList.contains('disabled')){
  speechEvents.push('invalid-selection-click');return;
 }
 window.startClicks++;
 if(window.keepSelection){speechEvents.push('selection-waiting');return;}
 document.querySelector('ec-speak-interstitial').hidden=true;
 show('player-speech-listening',true);speechEvents.push('selection-started');
 // A primeira frase é reproduzida antes de a área de gravação aparecer.
 setTimeout(()=>{
  show('player-speech-listening',false);document.querySelector('#speech-area').hidden=false;
  speechEvents.push('record-window-ready');
 },250);
};
find('player-record').onclick=async()=>{
 window.recordClicks++;speechEvents.push('record-click:'+line().getAttribute('data-line-id'));
 show('player-record',false);show('player-recording-pending',true);
 if(window.failCapture){show('player-recording-pending',false);show('player-record',true);return;}
 const stream=await navigator.mediaDevices.getUserMedia({audio:true});
 const recorder=new MediaRecorder(stream),parts=[];window.currentRecorder=recorder;
 recorder.ondataavailable=event=>{if(event.data.size)parts.push(event.data)};
 recorder.onstop=async()=>{
  show('player-recording-indicator',false);show('player-stop-recording',false);
  show('player-recording-processing',true);speechEvents.push('processing');
  await wait(120);
  window.recordings.push({line:line().getAttribute('data-line-id'),bytes:new Blob(parts).size});
  stream.getTracks().forEach(track=>track.stop());
  show('player-recording-processing',false);show('player-recording-result',true);
  find('player-recording-result').textContent='Pronúncia registrada';
  find('player-recording-result').setAttribute('data-status','accepted');
  line().classList.add('completed');speechEvents.push('accepted:'+line().getAttribute('data-line-id'));
  if(window.lineIndex===0)show('player-next-line',true);
  else{
   document.querySelector('.activity-list-speak').classList.add('completed');
   const done=document.createElement('p');done.className='speak-complete-msg';
   done.textContent='Fala concluída';document.querySelector('#speech-area').append(done);
  }
 };
 // Uma pista já existe, mas o gravador ainda não está pronto durante esse atraso.
 await wait(350);recorder.start();show('player-recording-pending',false);
 show('player-recording-indicator',true);show('player-stop-recording',true);
 speechEvents.push('recording:'+line().getAttribute('data-line-id'));
};
find('player-stop-recording').onclick=()=>{
 window.stopClicks++;speechEvents.push('stop:'+window.currentRecorder?.state);
 if(window.currentRecorder?.state==='recording')window.currentRecorder.stop();
};
find('player-next-line').onclick=()=>{
 window.nextClicks++;window.lineIndex++;
 line().setAttribute('data-line-id','102');line().setAttribute('dialog-line-id','102');
 line().classList.remove('completed');
 show('player-next-line',false);show('player-recording-result',false);
 find('player-recording-result').removeAttribute('data-status');
 show('player-record',true);speechEvents.push('next:102');
};
const mic=window.__ecStudioSyntheticMic;
if(mic){
 const feed=mic.feed.bind(mic);
 mic.feed=async payload=>{
  const status=window.currentRecorder?.state;
  speechEvents.push('feed:'+status+':'+line().getAttribute('data-line-id'));
  if(status!=='recording')throw Error('O gravador local ainda não iniciou');
  return feed(payload);
 };
}
</script>'''


def _with_speech_page(scenario):
    async def run():
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(**chromium_launch_options())
            try:
                context = await browser.new_context()
                await context.add_init_script(script=SYNTHETIC_MIC_INIT)
                page = await context.new_page()
                await page.route('https://ec-speech-auto.test/**', lambda route: route.fulfill(body=SPEECH_PAGE))
                await page.goto('https://ec-speech-auto.test/')
                await scenario(page)
            finally:
                await browser.close()
    asyncio.run(run())


SPEECH_ONLY = ModoEstudo(assistir=False, aprender=False, falar=True, quiz=False)


async def _cycle(page, state, *, submit=True):
    # O domínio de fixture é local; nenhuma chamada vai para EnglishCentral.
    with patch('auto_fluxo.is_englishcentral', return_value=True), \
         patch('auto_fluxo.synthesize_wav', return_value=(_tone_wav(), 0.75)):
        return await process_page(page, engine=state, modo=SPEECH_ONLY, submit=submit)


def test_leitor_distingue_selecao_escuta_gravacao_resultado_e_id_da_linha():
    async def scenario(page):
        assert await page.locator('ec-player-app ec-speak-interstitial').count() == 0
        assert await page.locator('ec-activity-interstitial ec-speak-interstitial').count() == 1
        before = await inspect_ec_player(page)
        assert before['speak_phase'] == 'selection'
        assert before['speak_selection_ready'] is False
        await page.wait_for_function("document.querySelector('[data-testid=player-start-speaking]').textContent==='Falar 2 linhas'")
        selection = await inspect_ec_player(page)
        assert selection['speak_selection_count'] == 2
        assert selection['speak_selection_ready'] is True
        await page.get_by_test_id('player-start-speaking').click()
        listening = await inspect_ec_player(page)
        assert listening['speak_phase'] == 'unknown'
        assert listening['speak_can_record'] is False
        await page.get_by_test_id('player-record').wait_for(state='visible')
        ready = await inspect_ec_player(page)
        assert ready['speak_phase'] == 'ready'
        assert ready['speak_line_id'] == '101'
        assert ready['speak_prompt'] == 'This is the same line.'
        await page.evaluate('window.__ecStudioSyntheticMic.setEnabled(true)')
        await page.get_by_test_id('player-record').click()
        await page.wait_for_function("window.currentRecorder?.state==='recording'")
        recording = await inspect_ec_player(page)
        assert recording['speak_phase'] == 'recording'
        assert recording['speak_recording'] is True
        assert recording['speak_can_stop'] is True
        import base64
        payload = base64.b64encode(_tone_wav()).decode('ascii')
        await page.evaluate('payload=>window.__ecStudioSyntheticMic.feed(payload)', payload)
        await page.get_by_test_id('player-stop-recording').click()
        await page.get_by_test_id('player-recording-result').wait_for(state='visible')
        result = await inspect_ec_player(page)
        assert result['speak_phase'] == 'result'
        assert result['speak_line_complete'] is True
        assert result['speak_next_ready'] is True
        await page.get_by_test_id('player-next-line').click()
        next_line = await inspect_ec_player(page)
        assert next_line['speak_line_id'] == '102'
        assert next_line['speak_prompt'] == ready['speak_prompt']
    _with_speech_page(scenario)


def test_sem_confirmacao_apenas_observa_sem_abrir_linhas_ou_gravar():
    async def scenario(page):
        state = EngineState()
        for _ in range(3):
            await _cycle(page, state, submit=False)
        observed = await page.evaluate('''() => ({start:startClicks,record:recordClicks,
          stop:stopClicks,next:nextClicks,events:speechEvents,recordings})''')
        assert observed == {'start':0,'record':0,'stop':0,'next':0,'events':[],'recordings':[]}
        # Prepare a área de gravação pela UI da fixture; o controlador continua
        # somente observando quando o envio automático está desabilitado.
        await page.wait_for_function("document.querySelector('[data-testid=player-start-speaking]').textContent==='Falar 2 linhas'")
        await page.get_by_test_id('player-start-speaking').click()
        await page.get_by_test_id('player-record').wait_for(state='visible')
        for _ in range(3):
            await _cycle(page, state, submit=False)
        assert await page.evaluate('window.recordClicks') == 0
        assert await page.evaluate('window.stopClicks') == 0
        assert await page.evaluate('window.recordings.length') == 0
    _with_speech_page(scenario)


def test_linha_inactive_nao_e_confundida_com_linha_atual():
    async def scenario(page):
        await page.wait_for_function("document.querySelector('[data-testid=player-start-speaking]').textContent==='Falar 2 linhas'")
        await page.get_by_test_id('player-start-speaking').click()
        await page.get_by_test_id('player-record').wait_for(state='visible')
        await page.locator('ec-speak-mode').evaluate('''mode=>{
          const old=document.createElement('div');old.className='player-transcript-row inactive';
          old.setAttribute('data-line-id','old');old.textContent='Do not record this old line.';
          mode.append(old);
        }''')
        current = await inspect_ec_player(page)
        assert current['speak_line_id'] == '101'
        assert current['speak_prompt'] == 'This is the same line.'
    _with_speech_page(scenario)


def test_frase_longa_nao_e_cortada_no_limite_da_sintese_pelo_leitor():
    async def scenario(page):
        await page.wait_for_function("document.querySelector('[data-testid=player-start-speaking]').textContent==='Falar 2 linhas'")
        await page.get_by_test_id('player-start-speaking').click()
        await page.get_by_test_id('player-record').wait_for(state='visible')
        phrase = 'a' * 301
        await page.locator('.player-transcript-line').evaluate('(line,text)=>line.textContent=text', phrase)
        current = await inspect_ec_player(page)
        assert current['speak_prompt'] == phrase
        assert current['speak_prompt_length'] == 301
        assert current['speak_prompt_truncated'] is False
        await page.locator('.player-transcript-line').evaluate("line=>line.textContent='a'.repeat(2001)")
        overflow = await inspect_ec_player(page)
        assert overflow['speak_prompt_length'] == 2001
        assert overflow['speak_prompt_truncated'] is True
    _with_speech_page(scenario)


def test_feedback_antigo_sob_ancestral_transparente_nao_muda_fase_pronta():
    async def scenario(page):
        await page.wait_for_function("document.querySelector('[data-testid=player-start-speaking]').textContent==='Falar 2 linhas'")
        await page.get_by_test_id('player-start-speaking').click()
        await page.get_by_test_id('player-record').wait_for(state='visible')
        await page.locator('ec-speak-mode').evaluate('''mode=>{
          const stale=document.createElement('div');stale.style.opacity='0';
          stale.innerHTML='<ec-speech-feedback><div class="speak-result">Verifique seus erros</div></ec-speech-feedback>';
          mode.append(stale);
        }''')
        current = await inspect_ec_player(page)
        assert current['speak_phase'] == 'ready'
        assert current['speak_result'] == ''
        assert not current['speak_line_complete']
    _with_speech_page(scenario)


def test_check_do_trecho_selecionado_confirma_so_fala_sem_sinal_negativo():
    async def scenario(page):
        await page.wait_for_function("document.querySelector('[data-testid=player-start-speaking]').textContent==='Falar 2 linhas'")
        await page.get_by_test_id('player-start-speaking').click()
        await page.get_by_test_id('player-record').wait_for(state='visible')
        await page.locator('ec-player-app').evaluate('''player=>{
          const bar=document.createElement('div');bar.className='seek-bar';
          bar.setAttribute('dialog-line-id','101');
          bar.innerHTML='<span class="seek-bar-selected-circle" style="display:inline-block;width:8px;height:8px"></span><i class="fa-check" style="display:inline-block;width:10px;height:10px"></i>';
          player.append(bar);
        }''')
        assert (await inspect_ec_player(page))['speak_line_complete']
        await page.locator('.seek-bar').evaluate("bar=>bar.setAttribute('aria-label','Não concluída')")
        assert not (await inspect_ec_player(page))['speak_line_complete']
        await page.locator('.seek-bar').evaluate('''bar=>{
          bar.removeAttribute('aria-label');const failed=document.createElement('i');
          failed.className='fa-times';failed.style='display:inline-block;width:10px;height:10px';bar.append(failed);
        }''')
        assert not (await inspect_ec_player(page))['speak_line_complete']
        await page.locator('.seek-bar .fa-times').evaluate('icon=>icon.remove()')
        await page.locator('.activity-list-speak').evaluate("button=>button.classList.remove('active')")
        await page.locator('.activity-list-watch').evaluate("button=>button.classList.add('active')")
        assert not (await inspect_ec_player(page))['speak_line_complete']
    _with_speech_page(scenario)


def test_fluxo_automatico_duas_linhas_iguais_grava_espera_resultado_e_avanca():
    async def scenario(page):
        state = EngineState()
        advance = AsyncMock(return_value={'tipo':'fora_curso'})
        results = []
        with patch('ec_engine.advance_course', advance):
            for _ in range(40):
                result = await _cycle(page, state)
                results.append(result)
                assert result.get('tipo') != 'ajuda', result
                if await page.locator('.activity-list-speak').evaluate("e=>e.classList.contains('completed')"):
                    break
                await page.wait_for_timeout(60)
            final = await _cycle(page, state)
        observed = await page.evaluate('''() => ({start:startClicks,record:recordClicks,
          stop:stopClicks,next:nextClicks,events:speechEvents,recordings})''')
        assert len(observed['recordings']) == 2, {'observed':observed,'results':results}
        assert [item['line'] for item in observed['recordings']] == ['101','102']
        assert all(item['bytes'] > 100 for item in observed['recordings'])
        assert observed['start'] == 1
        assert observed['record'] == observed['stop'] == 2
        assert observed['next'] == 1
        assert [item for item in observed['events'] if item.startswith('feed:')] == [
            'feed:recording:101','feed:recording:102']
        assert observed['events'].index('accepted:101') < observed['events'].index('next:102')
        assert observed['events'].index('record-window-ready') < observed['events'].index('record-click:101')
        assert 'invalid-selection-click' not in observed['events']
        assert '123' in state.real.cursor.seen
        assert final.get('progresso_etapas',{}).get('falar') is True
        assert final['tipo'] == 'escopo_concluido'
    _with_speech_page(scenario)


def test_botao_de_linhas_persistente_nao_recebe_cliques_duplicados():
    async def scenario(page):
        await page.evaluate('window.keepSelection=true')
        await page.wait_for_function("document.querySelector('[data-testid=player-start-speaking]').textContent==='Falar 2 linhas'")
        state = EngineState()
        for _ in range(5):
            await _cycle(page, state)
        assert await page.evaluate('window.startClicks') == 1
        assert await page.evaluate('window.recordClicks') == 0
    _with_speech_page(scenario)


def test_falha_ao_obter_microfone_nao_anuncia_audio_enviado():
    async def scenario(page):
        await page.evaluate('window.failCapture=true')
        state = EngineState()
        results = []
        for _ in range(8):
            result = await _cycle(page, state)
            results.append(result)
            if await page.evaluate('window.recordClicks>0'):
                break
            await page.wait_for_timeout(60)
        assert await page.evaluate('window.recordClicks') > 0, results
        # O worker real pausa em ajuda. As releituras adicionais verificam que
        # um estado antigo não se transforma em uma declaração falsa de envio.
        for _ in range(2):
            results.append(await _cycle(page, state))
        assert not await page.evaluate("speechEvents.some(event=>event.startsWith('feed:'))")
        assert await page.evaluate('window.recordings.length') == 0
        for result in results:
            assert not result.get('duracao'), result
            assert 'áudio sintético enviado' not in result.get('mensagem','').casefold(), result
            assert result.get('enviadas') is not True, result
    _with_speech_page(scenario)


def test_captura_encerra_entre_prontidao_e_envio_sem_entregar_audio_antigo():
    async def scenario(page):
        await page.wait_for_function("document.querySelector('[data-testid=player-start-speaking]').textContent==='Falar 2 linhas'")
        await page.get_by_test_id('player-start-speaking').click()
        await page.get_by_test_id('player-record').wait_for(state='visible')
        state = EngineState()
        recording_reads = 0
        stopped_snapshot = None

        async def inspect_with_late_stop(target):
            nonlocal recording_reads, stopped_snapshot
            current = await inspect_ec_player(target)
            if current.get('speak_recording'):
                recording_reads += 1
                if recording_reads == 2:
                    # A primeira leitura confirmou prontidão. O gravador real
                    # encerra antes da releitura final e do envio da voz.
                    await target.evaluate('window.currentRecorder.stop()')
                    await target.wait_for_function("speechEvents.includes('processing')")
                    current = await inspect_ec_player(target)
                    stopped_snapshot = current
            return current

        with patch('auto_fluxo.inspect_ec_player', inspect_with_late_stop):
            result = await _cycle(page, state)
        assert recording_reads >= 2
        assert stopped_snapshot and stopped_snapshot['speak_phase'] in {'processing','result'}
        assert not await page.evaluate("speechEvents.some(event=>event.startsWith('feed:'))")
        assert not result.get('enviadas'), result
        assert not result.get('duracao'), result
        assert not state.speech_flow.sent
        assert not state.speak_started
    _with_speech_page(scenario)


def test_microfone_sob_ancestral_transparente_nao_e_acionado_durante_escuta():
    async def scenario(page):
        await page.wait_for_function("document.querySelector('[data-testid=player-start-speaking]').textContent==='Falar 2 linhas'")
        await page.get_by_test_id('player-start-speaking').click()
        await page.get_by_test_id('player-record').wait_for(state='visible')
        await page.locator('ec-speak-mode').evaluate('''mode=>{
          // O texto continua visível enquanto a área do microfone desvanece.
          mode.before(mode.querySelector('.player-transcript-row'));
          mode.style.opacity='0';
        }''')
        current = await inspect_ec_player(page)
        assert current['speak_prompt'] == 'This is the same line.'
        assert current['speak_can_record'] is False
        state = EngineState()
        for _ in range(3):
            result = await _cycle(page, state)
            assert not result.get('enviadas'), result
        assert await page.evaluate('window.recordClicks') == 0
        assert await page.evaluate('window.stopClicks') == 0
        assert not await page.evaluate("speechEvents.some(event=>event.startsWith('feed:'))")
    _with_speech_page(scenario)


def test_selecao_padrao_zero_abre_todas_as_linhas_seleciona_e_inicia_sozinha():
    async def scenario(page):
        await page.evaluate('''() => {
          window.persistZero=true;window.keepSelection=true;
          window.showAllClicks=0;window.selectAllClicks=0;
          const selection=document.querySelector('ec-speak-interstitial');
          const footer=document.querySelector('[data-testid="player-start-speaking"]');
          footer.textContent='Comece a Falar';footer.classList.add('disabled');
          footer.setAttribute('aria-disabled','true');
          document.querySelector('#selected-lines').textContent='Linhas selecionadas: 0';
          const all=document.createElement('button');all.className='btn-filter-all';
          all.textContent='Todas as linhas: 2';
          const panel=document.createElement('div');panel.hidden=true;
          panel.innerHTML='<button class="select-all" data-testid="speak-select-all">Selecionar todas as linhas</button>';
          all.onclick=()=>{
            window.showAllClicks++;speechEvents.push('show-all');
            // A aba continua visível enquanto sua lista carrega.
            setTimeout(()=>panel.hidden=false,180);
          };
          panel.querySelector('button').onclick=()=>{
            window.selectAllClicks++;speechEvents.push('select-all');
            document.querySelector('#selected-lines').textContent='Linhas selecionadas: 2';
            footer.textContent='Falar 2 linhas';footer.classList.remove('disabled');
            footer.removeAttribute('aria-disabled');
          };
          selection.prepend(all,panel);
        }''')
        state = EngineState()
        first = await _cycle(page, state)
        assert first['tipo'] == 'aguardando', first
        assert await page.evaluate('window.startClicks') == 0
        # A seleção padrão já teve sua janela de carregamento. Avance apenas
        # esse relógio do controlador, sem trocar o relógio do navegador.
        state.speech_flow.phase_since -= 2.5
        opened = await _cycle(page, state)
        assert opened['tipo'] == 'navegacao', opened
        for _ in range(2):
            await _cycle(page, state)
        assert await page.evaluate('window.showAllClicks') == 1
        await page.get_by_test_id('speak-select-all').wait_for(state='visible')
        for _ in range(4):
            await _cycle(page, state)
        observed = await page.evaluate('''() => ({showAll:showAllClicks,selectAll:selectAllClicks,
          started:startClicks,recorded:recordClicks,events:speechEvents})''')
        assert observed['showAll'] == observed['selectAll'] == observed['started'] == 1, observed
        assert observed['recorded'] == 0
        assert 'invalid-selection-click' not in observed['events']
        assert observed['events'].index('show-all') < observed['events'].index('select-all')
        assert observed['events'].index('select-all') < observed['events'].index('selection-waiting')
    _with_speech_page(scenario)


def test_seekbar_responsiva_d_none_d_sm_block_visivel_preserva_id_e_check():
    async def scenario(page):
        await page.wait_for_function("document.querySelector('[data-testid=player-start-speaking]').textContent==='Falar 2 linhas'")
        await page.get_by_test_id('player-start-speaking').click()
        await page.get_by_test_id('player-record').wait_for(state='visible')
        await page.locator('ec-player-app').evaluate('''player=>{
          // Bootstrap oculta a barra no celular, mas a mesma árvore fica
          // visível no desktop por uma regra responsiva mais específica.
          const style=document.createElement('style');
          style.textContent='.d-none{display:none!important}@media(min-width:576px){.d-sm-block{display:block!important}}';
          document.head.append(style);
          const row=player.querySelector('.player-transcript-row');
          row.removeAttribute('data-line-id');row.removeAttribute('dialog-line-id');
          const responsive=document.createElement('div');
          responsive.className='player-seek-bar d-none d-sm-block';
          responsive.innerHTML='<div class="seek-bar" dialog-line-id="483128"><span class="seek-bar-selected-circle" style="display:inline-block;width:8px;height:8px"></span><i class="fa-check" style="display:inline-block;width:10px;height:10px"></i></div>';
          player.append(responsive);
        }''')
        assert await page.locator('.player-seek-bar').evaluate("e=>getComputedStyle(e).display") == 'block'
        current = await inspect_ec_player(page)
        assert current['speak_line_id'] == '483128', current
        assert current['speak_line_complete'] is True
    _with_speech_page(scenario)
