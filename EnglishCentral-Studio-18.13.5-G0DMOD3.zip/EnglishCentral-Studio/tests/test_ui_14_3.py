import asyncio, json
from pathlib import Path
from playwright.async_api import async_playwright
from conftest import chromium_launch_options


def test_clean_interface_layout_and_start_controls(tmp_path):
    async def run():
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(**chromium_launch_options())
            try:
                page=await browser.new_page(viewport={'width':1280,'height':900})
                errors=[]
                page.on('pageerror',lambda error:errors.append(str(error)))
                payload={'aberto':False,'executando':False,'modo':{'assistir':True,'aprender':True,'quiz':True,'falar':False},
                         'auto':{'tipo':'parado','mensagem':'Escolha as atividades e inicie o assistente.'}}
                stub='''<script>location.hash='#token=local-test-token-123';window.requests=[];
                window.fetch=async function(url,options){requests.push({url,body:options?.body});
                return new Response(String(url).includes('/api/status')?__PAYLOAD__:'{}', {status:200,headers:{'Content-Type':'application/json'}})};</script>'''.replace('__PAYLOAD__',json.dumps(json.dumps(payload)))
                html=(Path(__file__).resolve().parents[1]/'web/index.html').read_text(encoding='utf-8')
                await page.set_content(html.replace('<script>',stub+'<script>',1))
                await page.locator('#activityMsg').wait_for()
                assert await page.locator('#toggle').is_visible()
                assert await page.locator('.rail').is_visible()
                assert not await page.locator('[data-panel=content]').is_visible()
                assert not await page.locator('#settingsDrawer .drawerBody').is_visible()
                assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth')
                output=tmp_path
                await page.screenshot(path=str(output/'interface-atual-desktop.png'),full_page=True)
                await page.get_by_role('button',name='Conteúdo',exact=True).click()
                assert await page.locator('[data-panel=content]').is_visible()
                await page.get_by_role('button',name='Estudar',exact=True).click()
                await page.set_viewport_size({'width':390,'height':844})
                assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth')
                await page.screenshot(path=str(output/'interface-atual-celular.png'),full_page=True)
                await page.locator('#toggle').click()
                await page.wait_for_function("requests.some(r=>r.url==='/api/auto/start')")
                body=await page.evaluate("JSON.parse(requests.find(r=>r.url==='/api/auto/start').body)")
                assert body['quiz'] and body['aprender'] and not body['falar']
                assert not errors, errors
            finally:
                await browser.close()
    asyncio.run(run())
