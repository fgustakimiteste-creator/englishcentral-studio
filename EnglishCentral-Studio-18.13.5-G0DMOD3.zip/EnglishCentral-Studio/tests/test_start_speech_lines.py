from unittest.mock import patch,AsyncMock
from test_ec_player import run_with_page
from auto_fluxo import EngineState,process_page
from modos import ModoEstudo

def test_start_selected_lines_before_reading_active_prompt():
    async def scenario(page):
        await page.set_content('<p>Linhas selecionadas: 5</p><button onclick="window.started=true">Falar 5 linhas</button>')
        state=EngineState()
        with patch('auto_fluxo.is_englishcentral',return_value=True),patch('auto_fluxo._page_gate',AsyncMock(return_value={})),patch('auto_fluxo.inspect_ec_player',AsyncMock(return_value={'supported':True,'mode':'speak','speak_prompt':''})):
            result=await process_page(page,engine=state,modo=ModoEstudo(assistir=False,aprender=False,falar=True,quiz=False),submit=True)
        assert result['tipo']=='navegacao'
        assert await page.evaluate('window.started') is True
    run_with_page(scenario)
