"""Valida o domínio antes de construir/iniciar o servidor; não publica nada."""
from pathlib import Path
import re
import sys


def read_domain(path: Path) -> str:
    values = []
    for line in path.read_text('utf-8').splitlines():
        line = line.strip()
        if line and not line.startswith('#'):
            if not line.startswith('EC_DOMAIN='):
                raise ValueError('Use somente EC_DOMAIN no arquivo de configuração.')
            values.append(line.split('=', 1)[1].strip())
    if len(values) != 1:
        raise ValueError('Informe EC_DOMAIN uma única vez.')
    domain = values[0].lower()
    if (len(domain) > 253 or not re.fullmatch(r'(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}', domain)
            or domain.endswith('.seu-dominio.com')):
        raise ValueError('Troque o domínio de exemplo por um domínio real, sem protocolo, porta ou caminho.')
    return domain


if __name__ == '__main__':
    try:
        domain = read_domain(Path(__file__).with_name('.env'))
        print(f'Configuração válida para https://{domain}. Aponte o DNS antes de iniciar.')
    except (OSError, ValueError) as error:
        print(f'Configuração incompleta: {error}', file=sys.stderr)
        sys.exit(1)
