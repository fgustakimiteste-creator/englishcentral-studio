import asyncio
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch
from course_flow import CourseCursor, _advance_course
from auto_fluxo import EngineState, _finish_quiz


def test_empty_unit_is_not_visited_and_later_opens_lesson():
    async def run():
        state=CourseCursor()
        unit={'id':'1','index':0,'active':True,'visible':True,'ready':True,'cards':[]}
        snapshot={'supported':True,'course_id':'8571','units':[unit]}
        result=await _advance_course(None,state,snapshot=snapshot)
        assert result['tipo']=='aguardando'
        assert '1' not in state.visited_units and '1' not in state.verified_units
        unit['cards']=[{'video':True,'lesson_id':'101','visible':True,'index':0,'title':'Lesson'}]
        from unittest.mock import MagicMock
        page=MagicMock()
        with patch('course_flow._click',AsyncMock(return_value={'tipo':'navegacao'})):
            result=await _advance_course(page,state,snapshot=snapshot)
        assert result['tipo']=='navegacao' and state.pending=='lesson:101'
    asyncio.run(run())


def test_empty_unit_recovery_bounded_and_other_units_continue():
    async def run():
        state=CourseCursor()
        unit={'id':'1','index':0,'active':True,'visible':True,'ready':True,'cards':[]}
        snapshot={'supported':True,'course_id':'8571','units':[unit]}
        with patch('course_flow.time.monotonic',return_value=1):
            await _advance_course(None,state,snapshot=snapshot)
        with patch('course_flow.time.monotonic',return_value=25):
            result=await _advance_course(None,state,snapshot=snapshot)
        assert result['tipo']=='aguardando' and '1' in state.blocked_units
        result=await _advance_course(None,state,snapshot=snapshot)
        assert result['tipo']=='aguardando' and '1' not in state.visited_units
        assert '1' in state.reread_units
        with patch('course_flow.time.monotonic',return_value=30):
            await _advance_course(None,state,snapshot=snapshot)
        with patch('course_flow.time.monotonic',return_value=55):
            await _advance_course(None,state,snapshot=snapshot)
        result=await _advance_course(None,state,snapshot=snapshot)
        assert result['tipo']=='ajuda' and '1' not in state.verified_units
    asyncio.run(run())


def test_finished_quiz_returns_to_same_course_and_reports_completion():
    page=SimpleNamespace(url='https://pt.englishcentral.com/course/8571',goto=AsyncMock())
    state=EngineState(last_question='old',last_answer='old')
    result=asyncio.run(_finish_quiz(page,'unit:q1',state,{},submit=True))
    assert result['quiz_concluido']=='unit:q1' and result['tipo']=='navegacao'
    assert page.goto.await_args.args[0]=='https://pt.englishcentral.com/course/8571'
    assert state.last_answer==''


def test_quiz_does_not_navigate_without_auto_confirmation():
    page=SimpleNamespace(url='https://pt.englishcentral.com/course/8571',goto=AsyncMock())
    result=asyncio.run(_finish_quiz(page,'unit:q1',EngineState(),{},submit=False))
    assert result['tipo']=='conferencia'
    page.goto.assert_not_awaited()


def test_quiz_only_unit_does_not_block_video_only_mode():
    from course_flow import course_progress
    state=CourseCursor()
    unit={'id':'1','index':0,'active':True,'visible':True,'ready':True,
          'cards':[{'quiz':True,'quiz_key':'1:q1'}]}
    snapshot={'supported':True,'course_id':'8571','units':[unit]}
    result=asyncio.run(_advance_course(None,state,snapshot=snapshot,include_quizzes=False))
    assert result['tipo']=='escopo_concluido'
    assert '1' not in state.verified_units
    report=course_progress(snapshot,state)
    assert report['unidades'][0]['estado']=='fora_escopo'


def test_quiz_intro_starts_once_and_waits_for_questions():
    from auto_fluxo import process_page
    from test_ec_player import run_with_page
    async def scenario(page):
        await page.set_content('<button onclick="window.starts=(window.starts||0)+1">Iniciar o teste</button>')
        state=EngineState()
        state.real.cursor.pending='quiz:1:q1'
        quiz={'ativa':False,'texto':'Quiz Iniciar o teste'}
        with patch('auto_fluxo.is_englishcentral',return_value=True), patch('auto_fluxo._page_gate',AsyncMock(return_value={})), patch('auto_fluxo.inspect_ec_player',AsyncMock(return_value={'supported':False})), patch('auto_fluxo.inspect_quiz',AsyncMock(return_value=quiz)):
            result=await process_page(page,submit=True,engine=state)
            assert result['tipo']=='navegacao'
            result=await process_page(page,submit=True,engine=state)
            assert result['tipo']=='aguardando'
        assert await page.evaluate('window.starts')==1
    run_with_page(scenario)


def test_angular_quiz_keeps_hint_and_types_remaining_letters():
    from test_ec_player import run_with_page
    from exercicio import inspect_quiz, type_quiz_answer
    async def scenario(page):
        await page.locator('ec-player-transcript').evaluate("e=>e.insertAdjacentHTML('beforeend','<div class=caption>She likes to ____ through the forest.</div><div>Digite a resposta correta</div>')")
        await page.locator('ec-player-word-input').evaluate("e=>e.style.width='200px'")
        await page.locator('input.char-input').first.evaluate("e=>{e.value='r';e.setAttribute('readonly','true')}")
        quiz=await inspect_quiz(page)
        assert quiz['campos'] and quiz['campos'][0]['group']
        assert quiz['campos'][0]['limit']==4
        await type_quiz_answer(page,quiz,'ride',enter=True)
        assert await page.evaluate('window.keyCount')==3
        assert await page.evaluate('window.enterCount')==1
    run_with_page(scenario)


def test_quiz_feedback_without_input_advances_to_next_question():
    from test_ec_player import run_with_page
    from exercicio import inspect_quiz
    from auto_fluxo import process_page
    async def scenario(page):
        await page.set_content('<div class="quiz">Resposta certa: get down <div class="button" onclick="window.nextQuestion=true">Continuar</div>REPORT 1/8</div>')
        quiz=await inspect_quiz(page)
        assert quiz['questao_encerrada'] and not quiz['quiz_concluido']
        with patch('auto_fluxo.is_englishcentral',return_value=True):
            result=await process_page(page,submit=True,engine=EngineState())
        assert result['tipo']=='navegacao'
        assert await page.evaluate('window.nextQuestion')
    run_with_page(scenario)
