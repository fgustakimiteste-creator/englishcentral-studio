"""Disponibilidade pública do site; não envia cookies, chaves nem progresso."""
import asyncio
from urllib.request import Request, urlopen
from urllib.error import HTTPError
NETWORK_CHECK_TIMEOUT_SECONDS = 6


class NetworkUnavailable(RuntimeError):
    pass


def _public_site_available():
    try:
        with urlopen(Request('https://pt.englishcentral.com/', method='HEAD'), timeout=4) as response:
            return response.status < 500
    except HTTPError as error:
        # 401/403/429 ainda provam conectividade. Autenticação/verificação é
        # tratada na página; nunca se tenta contornar esses bloqueios.
        return error.code < 500
    except (OSError, ValueError):
        return False


async def network_available(page=None):
    if page is not None and not page.is_closed():
        try:
            state=await asyncio.wait_for(page.evaluate(r'''() => {
              const error=location.protocol==='chrome-error:' || !!document.querySelector('#main-frame-error');
              const host=location.hostname;
              return {online:navigator.onLine,error,
                usable:!error&&document.readyState!=='loading'&&!!document.body&&
                  (host==='accounts.google.com'||host==='englishcentral.com'||host.endsWith('.englishcentral.com'))};
            }'''),timeout=2)
            if isinstance(state,dict):
                if state.get('online') is False:return False
                if state.get('online') is True and state.get('usable') is True and not state.get('error'):
                    return True
        except Exception:
            pass  # uma navegação pode destruir o contexto durante a leitura
    try:
        return await asyncio.wait_for(asyncio.to_thread(_public_site_available), timeout=NETWORK_CHECK_TIMEOUT_SECONDS)
    except asyncio.TimeoutError:
        return False


async def restore_network_page(page, url):
    """Reabre apenas uma página de erro do navegador, nunca a aula intacta."""
    try:
        broken = await asyncio.wait_for(page.evaluate('''() => location.protocol==='chrome-error:' ||
      !!document.querySelector('#main-frame-error') &&
      /ERR_(?:INTERNET_DISCONNECTED|NETWORK_CHANGED|NAME_NOT_RESOLVED|CONNECTION_(?:RESET|CLOSED|REFUSED)|TIMED_OUT)/.test(document.body?.innerText||'')'''),timeout=2)
    except Exception:
        return  # contexto em navegação; a próxima leitura irá conferir a página
    if broken:
        await page.goto(url, wait_until='domcontentloaded', timeout=20000)
