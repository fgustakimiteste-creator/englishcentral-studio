"""Preferências de fala por pessoa; a meta local não altera a nota do site."""
from dataclasses import asdict, dataclass
import json
from pathlib import Path
from arquivos_locais import write_json_atomic


@dataclass(frozen=True)
class SpeechPolicy:
    precisao_minima: int = 80
    max_tentativas: int = 2
    abaixo_meta: str = 'next'

    def __post_init__(self):
        if type(self.precisao_minima) is not int or not 0 <= self.precisao_minima <= 100:
            raise ValueError('A precisão deve estar entre 0 e 100%.')
        if type(self.max_tentativas) is not int or not 1 <= self.max_tentativas <= 5:
            raise ValueError('Escolha de uma a cinco tentativas por linha.')
        if self.abaixo_meta not in {'next', 'retry', 'ask'}:
            raise ValueError('Escolha avançar, tentar novamente ou perguntar.')


def load_speech_policy(path: Path) -> SpeechPolicy:
    try:
        data = json.loads(Path(path).read_text('utf-8'))
        if isinstance(data, dict):
            return SpeechPolicy(**{key: data[key] for key in asdict(SpeechPolicy()) if key in data})
    except (OSError, ValueError, TypeError):
        pass
    return SpeechPolicy()


def save_speech_policy(path: Path, policy: SpeechPolicy):
    write_json_atomic(path, asdict(policy))
