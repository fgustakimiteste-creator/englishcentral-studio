from exercicio import inspect_quiz, inspect_words
from test_ec_player import run_with_page


def test_quiz_reconstructs_gap_without_player_custom_element():
    async def scenario(page):
        await page.set_content('''<style>
          .word-boxes{display:inline-block;width:180px;height:34px}
          input{width:20px;height:28px} button{padding:8px}
          </style><section class="quiz-panel"><div>Adverb: sómente</div>
          <div class="quiz-sentence">She says, "<span class="word-boxes">
          <input class="char-input" maxlength="1" readonly="true" value="o">
          <input class="char-input" maxlength="1" readonly="false">
          <input class="char-input" maxlength="1" readonly="false">
          <input class="char-input" maxlength="1" readonly="false">
          <input class="char-input" maxlength="1" readonly="false">
          <input class="char-input" maxlength="1" readonly="false">
          </span> you're having some yourself."</div>
          <p>Digite a resposta correta</p>
          <div class="letter-bank"><button>i</button><button>y</button><button>f</button><button>l</button><button>n</button><button>n</button></div>
          <button>Verificar</button><small>REPORT 4/8 Pular</small></section>''')
        quiz=await inspect_quiz(page)
        assert quiz['ativa']
        assert '___' in quiz['frase']
        assert 'She says' in quiz['frase'] and "you're having some yourself" in quiz['frase']
        field=quiz['campos'][0]
        assert field['pattern']=='o_____' and field['limit']==6
        assert quiz['banco_letras']==['i','y','f','l','n','n']
        assert field['letter_bank']==quiz['banco_letras']
        # Partial input values cannot move the apparent gap or change its phrase.
        await page.locator('.char-input').nth(1).evaluate("e=>e.value='n'")
        reread=await inspect_quiz(page)
        assert reread['frase']==quiz['frase']
    run_with_page(scenario)


def test_group_pattern_uses_every_character_of_maxlength_two_fields():
    async def scenario(page):
        await page.set_content('''<style>.answer-word{display:flex;width:150px;gap:3px}.answer-word input{width:42px;height:28px}</style>
          <div class="quiz">Type the missing word</div><div class="caption">They saw a ____ in the forest.</div>
          <div class="answer-word"><input class="answer" maxlength="2"><input class="answer" maxlength="2"><input class="answer" maxlength="2"></div>''')
        quiz=await inspect_quiz(page)
        field=quiz['campos'][0]
        assert field['group'] and field['limit']==6
        assert field['pattern']=='______'
    run_with_page(scenario)


def test_word_list_reader_preserves_normal_title_case():
    async def scenario(page):
        await page.set_content('<div class="word">Figure Out<br>Verb: descobrir; entender</div><div class="word">Countless<br>Adjective: inúmero</div>')
        words=await inspect_words(page)
        assert 'Figure Out' in words and 'Countless' in words
    run_with_page(scenario)
