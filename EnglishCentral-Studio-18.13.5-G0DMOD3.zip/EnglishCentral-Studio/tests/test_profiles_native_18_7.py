"""Integração local com dois servidores reais; nenhuma conta é conectada."""
import json
from urllib.error import HTTPError
from urllib.parse import urlparse
from urllib.request import Request, urlopen

import pytest
import perfis
from perfis import ProfileManager


def test_dois_servidores_locais_isolam_tokens_e_preferencias(tmp_path, monkeypatch):
    manager=ProfileManager(tmp_path/'dados',perfis.Path(perfis.__file__).parent)
    people=[manager.create(f'Teste {n}') for n in range(7)]
    spawned=[]; original=perfis.subprocess.Popen
    def track(*args,**kwargs):
        process=original(*args,**kwargs);spawned.append(process);return process
    monkeypatch.setattr(perfis.subprocess,'Popen',track)
    def request(url, token, method='GET', data=None):
        req=Request(url,data=json.dumps(data).encode() if data is not None else None,
                    headers={'X-EC-Token':token,'Content-Type':'application/json'},method=method)
        with urlopen(req,timeout=4) as response:return json.load(response)
    try:
        one,two=manager.open(people[0]['id']),manager.open(people[6]['id'])
        base1=one['url'].split('/#',1)[0];token1=one['url'].split('#token=',1)[1]
        base2=two['url'].split('/#',1)[0];token2=two['url'].split('#token=',1)[1]
        assert token1!=token2 and base1!=base2 and len(spawned)==2
        request(base1+'/api/speech/settings',token1,'PUT',{'precisao_minima':65,'max_tentativas':3,'abaixo_meta':'retry'})
        assert request(base1+'/api/speech/settings',token1)['precisao_minima']==65
        assert request(base2+'/api/speech/settings',token2)['precisao_minima']==80
        with pytest.raises(HTTPError) as error:request(base2+'/api/status',token1)
        assert error.value.code==401
        assert request(base2+'/api/status',token2)['perfil']['id']==people[6]['id']
        assert manager.open(people[0]['id'])['url']==one['url'] and len(spawned)==2
    finally:
        for process in spawned:process.terminate()
        for process in spawned:
            try:process.wait(timeout=5)
            except perfis.subprocess.TimeoutExpired:process.kill();process.wait(timeout=5)
