"""Um clique no Windows: prepara dependências, inicia servidor e abre painel com acesso local."""
from __future__ import annotations

import os
import hashlib
import subprocess
import sys
import time
import urllib.error
import urllib.request
import webbrowser
from pathlib import Path
from urllib.parse import quote

ROOT = Path(__file__).resolve().parent
VENV = ROOT / '.venv'
PY = VENV / 'Scripts' / 'python.exe' if os.name == 'nt' else VENV / 'bin' / 'python'
FLAG = ROOT / '.dados_locais' / 'instalacao_pronta.txt'


def command(*args):
    subprocess.run(list(map(str,args)), cwd=ROOT, check=True)


def _requirements_signature() -> str:
    """Invalida instalações antigas ao mudar dependências ou versão de Python."""
    requirement_bytes = (ROOT / 'requirements.txt').read_bytes()
    payload = requirement_bytes + f'|{sys.version_info.major}.{sys.version_info.minor}|v14'.encode()
    return hashlib.sha256(payload).hexdigest()


def _installed_browser() -> bool:
    """Confere o Chromium do Playwright sem abrir navegador ou acessar a rede."""
    try:
        code = 'from pathlib import Path; from playwright.sync_api import sync_playwright; p=sync_playwright().start(); print(int(Path(p.chromium.executable_path).is_file())); p.stop()'
        proc = subprocess.run([str(PY), '-c', code], cwd=ROOT, capture_output=True,
                              text=True, timeout=20, check=True)
        return proc.stdout.strip().splitlines()[-1] == '1'
    except (OSError, subprocess.SubprocessError, IndexError):
        return False


def bootstrap():
    if not PY.exists():
        print('[1/3] Preparando ambiente Python (somente na primeira vez)...', flush=True)
        command(sys.executable, '-m', 'venv', VENV)
    fingerprint = _requirements_signature()
    current_marker = FLAG.read_text('utf-8').strip() if FLAG.exists() else ''
    installed = subprocess.run([str(PY), '-c', 'import fastapi, uvicorn, playwright'],
                               cwd=ROOT, capture_output=True, timeout=25).returncode == 0
    if current_marker != fingerprint or not installed:
        print('[2/3] Instalando ou atualizando dependências...', flush=True)
        command(PY, '-m', 'pip', 'install', '-r', ROOT / 'requirements.txt')
    if not _installed_browser():
        print('[2/3] Preparando Chromium para o Playwright...', flush=True)
        command(PY, '-m', 'playwright', 'install', 'chromium')
    FLAG.parent.mkdir(parents=True, exist_ok=True)
    FLAG.write_text(fingerprint + '\n', encoding='utf-8')
    print('[2/3] Ambiente verificado.', flush=True)


PORT = int(os.getenv('EC_PORT', '8765'))

def main():
    if sys.version_info < (3, 10):
        raise RuntimeError('Python 3.10 ou mais recente é necessário.')
    bootstrap()
    print('[3/3] Iniciando painel local...', flush=True)
    token = subprocess.check_output([str(PY), '-c', 'from servidor import get_token; print(get_token())'], cwd=ROOT, text=True).strip()
    url = f'http://127.0.0.1:{PORT}/#token=' + quote(token, safe='')
    # Sem desativar autenticação: token passa somente no fragmento local, não na requisição HTTP.
    # Não confundir um servidor de versão anterior com esta instalação.
    try:
        with urllib.request.urlopen(f'http://127.0.0.1:{PORT}/', timeout=0.5):
            raise RuntimeError(f'Já existe um painel aberto na porta {PORT}. Feche a janela anterior e tente novamente.')
    except urllib.error.HTTPError:
        raise RuntimeError(f'A porta {PORT} está ocupada. Feche o servidor anterior antes de iniciar esta versão.')
    except urllib.error.URLError:
        pass
    proc = subprocess.Popen([str(PY), '-u', 'servidor.py', '--port', str(PORT)], cwd=ROOT)
    try:
        for _ in range(80):
            if proc.poll() is not None:
                raise RuntimeError('Servidor fechou antes de iniciar. Veja o erro no terminal.')
            try:
                with urllib.request.urlopen(f'http://127.0.0.1:{PORT}/', timeout=0.5) as resp:
                    if resp.status == 200:
                        break
            except (OSError, urllib.error.URLError):
                time.sleep(0.4)
        else:
            raise RuntimeError(f'O painel não iniciou na porta {PORT}. Confira se já está aberto.')
        print(f'Painel aberto em http://127.0.0.1:{PORT}', flush=True)
        print('Para encerrar, feche esta janela ou pressione Ctrl+C.', flush=True)
        webbrowser.open(url)
        proc.wait()
    except KeyboardInterrupt:
        print('\nEncerrando...', flush=True)
    finally:
        if proc.poll() is None:
            proc.terminate()
            try: proc.wait(timeout=5)
            except subprocess.TimeoutExpired: proc.kill()


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print('\nERRO:', exc, file=sys.stderr, flush=True)
        sys.exit(1)
