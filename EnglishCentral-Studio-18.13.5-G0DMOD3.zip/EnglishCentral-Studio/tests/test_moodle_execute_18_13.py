"""Regressões da execução Moodle: status, navegação e ações reais no DOM.

Usa Chromium local com fixtures HTML e uma fachada de URL SEDUCTEC, pois o
ambiente de CI bloqueia navegação para domínios externos. Os cliques/preenchimentos
são feitos pelo Playwright no DOM real do Chromium, não por mocks de locators.
"""
import asyncio
from pathlib import Path
from types import SimpleNamespace
from urllib.parse import urlparse
from unittest.mock import AsyncMock

import pytest

import servidor
from moodle_adapter import (
    page_kind, platform_info, inspect_moodle_page, apply_moodle_quiz_suggestions,
    open_moodle_forum_reply, fill_moodle_forum_editor, retry_moodle_quiz,
)

SED = 'https://seductec.seduc.pi.gov.br'


class MoodlePageProxy:
    """Mantém URL Moodle realista e delega interações a uma página Chromium local."""
    def __init__(self, page, url, route_pages=None):
        self._page = page
        self._url = url
        self._route_pages = route_pages or {}

    @property
    def url(self):
        return self._url

    async def goto(self, url, **kwargs):
        self._url = url
        path = urlparse(url).path
        body = self._route_pages.get(path)
        if body is None:
            # Também permite fixtures indexadas por prefixo para endpoints com query.
            body = next((value for prefix, value in self._route_pages.items()
                         if path.startswith(prefix)), '<html><body>Fixture vazia</body></html>')
        await self._page.set_content(body)
        return None

    def __getattr__(self, name):
        return getattr(self._page, name)


def test_quiz_view_e_inicio_nao_tentativa_ativa():
    url = f'{SED}/mod/quiz/view.php?id=12'
    assert page_kind(url) == 'quiz_inicio'
    assert platform_info(url)['tipo_pagina'] == 'quiz_inicio'
    assert page_kind(f'{SED}/mod/quiz/attempt.php?attempt=18') == 'questionario'


def test_moodle_open_activity_so_abre_link_listado_na_pagina(monkeypatch):
    async def run():
        class FakePage:
            def __init__(self):
                self.url = f'{SED}/course/view.php?id=20'
                self.context = SimpleNamespace()
                self.wait_for_timeout = AsyncMock()
            async def goto(self, url, **kwargs):
                self.url = url
        fake = FakePage()
        monkeypatch.setattr(servidor, 'current_page', lambda: fake)
        monkeypatch.setattr(servidor, 'pause_for_manual_action', AsyncMock())
        monkeypatch.setattr(servidor, 'inspect_moodle_page', AsyncMock(side_effect=[
            {'atividades': [{'url': f'{SED}/mod/quiz/view.php?id=44'}]},
            {'url': fake.url, 'tipo_pagina': 'quiz_inicio', 'titulo': 'Quiz de teste', 'pdfs': [], 'questoes': []},
        ]))
        monkeypatch.setattr(servidor, 'lock', asyncio.Lock())
        result = await servidor.moodle_open_activity(servidor.MoodleOpenActivityRequest(
            url=f'{SED}/mod/quiz/view.php?id=44'))
        assert result['ok'] is True and result['tipo_pagina'] == 'quiz_inicio'
        assert fake.url.endswith('/mod/quiz/view.php?id=44')
    asyncio.run(run())


def test_moodle_open_activity_restores_course_after_external_redirect(monkeypatch):
    async def run():
        source_url = f'{SED}/course/view.php?id=20'
        target_url = f'{SED}/mod/quiz/view.php?id=44'
        class FakePage:
            def __init__(self):
                self.url = source_url
                self.context = SimpleNamespace()
                self.wait_for_timeout = AsyncMock()
            async def goto(self, url, **kwargs):
                self.url = 'https://example.org/redirected' if url == target_url else url
        fake = FakePage()
        monkeypatch.setattr(servidor, 'current_page', lambda: fake)
        monkeypatch.setattr(servidor, 'pause_for_manual_action', AsyncMock())
        monkeypatch.setattr(servidor, 'inspect_moodle_page', AsyncMock(return_value={
            'atividades': [{'url': target_url}],
        }))
        monkeypatch.setattr(servidor, 'lock', asyncio.Lock())
        with pytest.raises(servidor.HTTPException) as error:
            await servidor.moodle_open_activity(servidor.MoodleOpenActivityRequest(url=target_url))
        assert error.value.status_code == 502
        assert fake.url == source_url
    asyncio.run(run())


@pytest.mark.asyncio
async def test_pdf_leitura_bloqueia_url_nao_listada_na_pagina_atual(monkeypatch):
    source = SimpleNamespace(url=f'{SED}/course/view.php?id=20', request=SimpleNamespace(get=AsyncMock()))
    monkeypatch.setattr(servidor, 'current_page', lambda: source)
    monkeypatch.setattr(servidor, 'inspect_moodle_page', AsyncMock(return_value={'pdfs': []}))
    monkeypatch.setattr(servidor, 'lock', asyncio.Lock())
    with pytest.raises(servidor.HTTPException) as error:
        await servidor.moodle_read_pdf(servidor.MoodleOpenPDFRequest(url=f'{SED}/files/nao-listado.pdf'))
    assert error.value.status_code == 409
    source.request.get.assert_not_awaited()


@pytest.mark.asyncio
async def test_open_moodle_pdf_bloqueia_pdf_mesmo_host_nao_listado():
    from moodle_adapter import open_moodle_pdf
    frame = SimpleNamespace(evaluate=AsyncMock(return_value={'pdfs': []}))
    context = SimpleNamespace(new_page=AsyncMock())
    source = SimpleNamespace(url=f'{SED}/course/view.php?id=20', main_frame=frame, context=context)
    with pytest.raises(ValueError, match='não foi identificado'):
        await open_moodle_pdf(source, f'{SED}/files/nao-listado.pdf')
    context.new_page.assert_not_awaited()


def test_forum_default_permite_preencher_rascunho_sem_publicar():
    assert servidor.MOODLE_DEFAULT_SETTINGS['preencher_forum'] is True


@pytest.mark.skipif(not Path('/usr/bin/chromium').exists(), reason='Chromium não instalado neste ambiente')
def test_chromium_real_inspeciona_e_preenche_radio_essay_e_select():
    from playwright.async_api import async_playwright

    async def run():
        html = '''<!doctype html><html><body>
          <form>
           <div class="que qtype_multichoice" id="question-101-1"><div class="qtext">Quanto é 2 + 2?</div>
             <input style="display:none" type="radio" id="opt-a" name="q101" value="a"><label for="opt-a">3</label>
             <input style="display:none" type="radio" id="opt-b" name="q101" value="b"><label for="opt-b">4</label>
           </div>
           <div class="que qtype_essay" id="question-102-1"><div class="qtext">Explique a ideia.</div><textarea name="q102"></textarea></div>
           <div class="que qtype_match" id="question-103-1"><div class="qtext">Escolha a categoria.</div>
             <select name="q103"><option value="">Escolha</option><option value="a">Alpha</option><option value="b">Beta</option></select>
           </div>
          </form></body></html>'''
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox'])
            raw = await browser.new_page()
            await raw.set_content(html)
            page = MoodlePageProxy(raw, f'{SED}/mod/quiz/attempt.php?attempt=1')
            overview = await inspect_moodle_page(page)
            assert len(overview['questoes']) == 3
            assert overview['questoes'][0]['opcoes'][1]['texto'] == '4'
            select_fields = overview['questoes'][2]['campos']
            assert select_fields and select_fields[0]['opcoes'] == ['Alpha', 'Beta']
            result = await apply_moodle_quiz_suggestions(page, [
                {'id': 'question-101-1', 'indice': 0, 'selecionadas': [1], 'texto': ''},
                {'id': 'question-102-1', 'indice': 1, 'selecionadas': [], 'texto': 'Uma explicação objetiva.'},
                {'id': 'question-103-1', 'indice': 2, 'selecionadas': [], 'texto': 'Beta'},
            ])
            assert result['confirmadas'] == 3, result
            assert await raw.locator('#opt-b').is_checked()
            assert await raw.locator('textarea[name="q102"]').input_value() == 'Uma explicação objetiva.'
            assert await raw.locator('select[name="q103"]').input_value() == 'b'
            assert result['enviadas'] is False
            await browser.close()
    asyncio.run(run())


@pytest.mark.skipif(not Path('/usr/bin/chromium').exists(), reason='Chromium não instalado neste ambiente')
def test_chromium_real_abre_discussao_e_preenche_editor_sem_publicar():
    from playwright.async_api import async_playwright

    async def run():
        discussion = '''<!doctype html><html><body><div class="discussion"><a href="/mod/forum/discuss.php?d=77">Discussão da turma</a></div></body></html>'''
        thread = '''<!doctype html><html><body><article class="forumpost"><h3>Debate sobre o tema</h3><p>Como a escola pode melhorar a convivência?</p><a href="/mod/forum/post.php?reply=77&amp;sesskey=temp-forum-csrf">Responder</a></article></body></html>'''
        editor = '''<!doctype html><html><body><form><label for="id_message">Mensagem</label><textarea id="id_message" name="message"></textarea><button type="submit">Enviar</button></form></body></html>'''
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox'])
            raw = await browser.new_page()
            await raw.set_content(discussion)
            page = MoodlePageProxy(raw, f'{SED}/mod/forum/view.php?id=4', {
                '/mod/forum/discuss.php': thread,
                '/mod/forum/post.php': editor,
            })
            opened = await open_moodle_forum_reply(page)
            assert '/mod/forum/post.php' in page.url and 'sesskey=temp-forum-csrf' in page.url
            assert opened['editor'] is True
            filled = await fill_moodle_forum_editor(page, 'Minha contribuição para a discussão.')
            assert filled['preenchido'] is True and filled['enviado'] is False
            assert await raw.locator('#id_message').input_value() == 'Minha contribuição para a discussão.'
            assert await raw.get_by_role('button', name='Enviar').count() == 1
            await browser.close()
    asyncio.run(run())


@pytest.mark.skipif(not Path('/usr/bin/chromium').exists(), reason='Chromium não instalado neste ambiente')
def test_chromium_real_inicia_quiz_a_partir_da_pagina_view():
    from playwright.async_api import async_playwright

    async def run():
        intro = '''<!doctype html><html><body><a href="/mod/quiz/attempt.php?attempt=81&amp;sesskey=temp-quiz-csrf">Tentar responder ao questionário agora</a></body></html>'''
        attempt = '''<!doctype html><html><body><div class="que qtype_multichoice" id="question-1-1"><div class="qtext">Teste?</div><input type="radio" name="q" id="a"><label for="a">Sim</label></div></body></html>'''
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox'])
            raw = await browser.new_page()
            await raw.set_content(intro)
            page = MoodlePageProxy(raw, f'{SED}/mod/quiz/view.php?id=3', {
                '/mod/quiz/attempt.php': attempt,
            })
            result = await retry_moodle_quiz(page)
            assert result['ok'] and '/mod/quiz/attempt.php' in page.url
            assert 'sesskey=temp-quiz-csrf' in page.url
            assert page_kind(page.url) == 'questionario'
            await browser.close()
    asyncio.run(run())


def test_platform_info_nao_quebra_em_nenhuma_rota_moodle():
    routes = [
        '/login/index.php', '/course/view.php?id=7', '/my/',
        '/mod/quiz/view.php?id=2', '/mod/quiz/attempt.php?attempt=3',
        '/mod/quiz/summary.php?attempt=3', '/mod/quiz/review.php?attempt=3',
        '/mod/forum/view.php?id=4', '/mod/resource/view.php?id=5', '/mod/assign/view.php?id=6',
    ]
    for route in routes:
        info = platform_info(SED + route)
        assert info['id'] == 'seductec'
        assert info['nome']


def test_pdf_distingue_arquivo_real_de_pagina_intermediaria():
    from moodle_adapter import is_direct_moodle_pdf
    assert is_direct_moodle_pdf(f'{SED}/pluginfile.php/123/mod_resource/content/1/aula.pdf?forcedownload=1')
    assert is_direct_moodle_pdf(f'{SED}/arquivos/material.pdf')
    assert not is_direct_moodle_pdf(f'{SED}/mod/resource/view.php?id=55')


@pytest.mark.asyncio
async def test_abrir_pdf_resolve_link_resource_para_pluginfile():
    from moodle_adapter import open_moodle_pdf
    resource_url = f'{SED}/mod/resource/view.php?id=55'
    pdf_url = f'{SED}/pluginfile.php/123/mod_resource/content/1/material.pdf?forcedownload=1'

    class Frame:
        def __init__(self, owner):
            self.owner = owner
        async def evaluate(self, _script):
            return {'pdfs': self.owner.pdfs}

    class PdfTab:
        def __init__(self):
            self.url = 'about:blank'
            self.pdfs = [{'url': pdf_url, 'nome': 'material.pdf'}]
            self.main_frame = Frame(self)
            self.visited = []
        async def goto(self, url, **kwargs):
            self.url = url
            self.visited.append(url)
        async def wait_for_timeout(self, _ms):
            return None
        async def close(self):
            return None

    class Context:
        def __init__(self):
            self.created = None
        async def new_page(self):
            self.created = PdfTab()
            return self.created

    class Source:
        def __init__(self):
            self.url = f'{SED}/course/view.php?id=7'
            self.pdfs = [{'url': resource_url, 'nome': 'Apostila PDF', 'pdf': True}]
            self.main_frame = Frame(self)
            self.context = Context()

    source = Source()
    result = await open_moodle_pdf(source, resource_url)
    assert result.url == pdf_url
    assert result.visited == [resource_url, pdf_url]


def test_moodle_config_legada_migra_padrao_de_forum_uma_vez(monkeypatch, tmp_path):
    import json
    settings_file = tmp_path / 'preferencias_seductec.json'
    settings_file.write_text(json.dumps({
        'modo': 'tudo', 'preencher_quiz': True, 'preencher_forum': False,
        'tentar_novamente': True, 'max_tentativas': 2,
    }), encoding='utf-8')
    monkeypatch.setattr(servidor, 'MOODLE_SETTINGS_FILE', settings_file)
    migrated = servidor.read_moodle_settings()
    assert migrated['preencher_forum'] is True
    assert migrated['schema_version'] == 3
    assert migrated.get('enviar_quiz') is False
    assert migrated.get('publicar_forum') is False


def test_moodle_save_settings_persists_user_opt_out_after_migration(monkeypatch, tmp_path):
    settings_file = tmp_path / 'preferencias_seductec.json'
    monkeypatch.setattr(servidor, 'MOODLE_SETTINGS_FILE', settings_file)
    action = servidor.MoodleSettingsRequest(modo='tudo', preencher_forum=False)
    saved = servidor.save_moodle_settings(action)
    assert saved['schema_version'] == 3
    assert servidor.read_moodle_settings()['preencher_forum'] is False
    assert servidor.read_moodle_settings().get('enviar_quiz') is False


def test_status_separa_inicio_de_primeira_tentativa_de_repeticao(monkeypatch):
    async def run():
        class Page:
            url = f'{SED}/mod/quiz/view.php?id=88'
        monkeypatch.setattr(servidor, 'current_page', lambda: Page())
        monkeypatch.setattr(servidor, 'inspect_moodle_page', AsyncMock(return_value={
            'url': Page.url, 'tipo_pagina': 'quiz_inicio', 'questoes': [], 'pdfs': [],
            'forum': {}, 'atividades': [], 'conclusao': {'estado': 'pendente', 'evidencias': []},
            'tentarNovamente': [{'texto': 'Tentar responder ao questionário agora', 'desabilitado': False}],
        }))
        monkeypatch.setattr(servidor, 'lock', asyncio.Lock())
        result = await servidor.moodle_status()
        assert result['pode_iniciar_tentativa'] is True
        assert result['pode_tentar_novamente'] is False
    asyncio.run(run())


@pytest.mark.skipif(not Path('/usr/bin/chromium').exists(), reason='Chromium não instalado neste ambiente')
def test_botao_executar_orquestra_curso_quiz_iniciar_e_preencher():
    from playwright.async_api import async_playwright
    from pathlib import Path
    source = (Path(__file__).resolve().parents[1] / 'web' / 'index.html').read_text(encoding='utf-8')
    start = source.index('function moodleActivityKind(item){')
    end = source.index("$('saveMoodleSettings').onclick", start)
    logic = source[start:end]

    async def run():
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox'])
            page = await browser.new_page()
            await page.set_content('<button id="toggle"><span id="toggleLabel"></span></button><select id="moodlePDFSelect"></select><div id="moodleStatusText"></div>')
            setup = f'''(() => {{
              window.$ = id => document.getElementById(id);
              window.text = (id, value) => {{ const e=$(id); if(e)e.textContent=value; }};
              window.platformType='seductec'; window.perform=async fn=>await fn(); window.grab=async()=>{{}};
              window.__log = [];
              window.__state = {{tipo_pagina:'curso', url:'{SED}/course/view.php?id=9', pdfs:[], atividades:[
                {{nome:'Quiz da unidade', url:'{SED}/mod/quiz/view.php?id=3', tipo:'quiz', conclusao:'pendente'}}]}};
              window.checkMoodleStatus = async () => window.__state;
              window.loadMoodleSettings = async () => ({{modo:'tudo', preencher_quiz:true, preencher_forum:true, tentar_novamente:true}});
              window.api = async (path, method, body) => {{
                window.__log.push([path, body]);
                if(path==='moodle/open-activity') window.__state={{tipo_pagina:'quiz_inicio',url:body.url,pdfs:[],atividades:[],botoes_tentar_novamente:[]}};
                return {{ok:true}};
              }};
              window.retryMoodleQuiz = async () => {{window.__log.push(['quiz/start']);window.__state={{tipo_pagina:'questionario',url:'{SED}/mod/quiz/attempt.php?attempt=11',pdfs:[],atividades:[]}};return {{ok:true,mensagem:'iniciou'}}}};
              window.runMoodleQuizAssist = async () => {{window.__log.push(['quiz/assist']);return {{ok:true,confirmadas:2}}}};
            }})();'''
            handler_start = source.index("$('toggle').onclick=()=>perform")
            handler = source[handler_start:source.index('\n', handler_start)]
            await page.add_script_tag(content=setup + '\n' + logic + '\n' + handler)
            await page.locator('#toggle').click()
            log = await page.evaluate('window.__log')
            assert any(x[0]=='moodle/open-activity' for x in log), log
            assert any(x[0]=='quiz/start' for x in log), log
            assert any(x[0]=='quiz/assist' for x in log), log
            await browser.close()
    asyncio.run(run())


@pytest.mark.skipif(not Path('/usr/bin/chromium').exists(), reason='Chromium não instalado neste ambiente')
def test_botao_executar_abre_resource_view_e_depois_pdf_direto():
    from playwright.async_api import async_playwright
    from pathlib import Path
    source = (Path(__file__).resolve().parents[1] / 'web' / 'index.html').read_text(encoding='utf-8')
    start = source.index('function moodleActivityKind(item){')
    end = source.index("$('saveMoodleSettings').onclick", start)
    logic = source[start:end]

    async def run():
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox'])
            page = await browser.new_page()
            await page.set_content('<button id="toggle"><span id="toggleLabel"></span></button><select id="moodlePDFSelect"></select><div id="moodleStatusText"></div>')
            resource = f'{SED}/mod/resource/view.php?id=44'
            direct = f'{SED}/pluginfile.php/2/mod_resource/content/1/apostila.pdf'
            setup = f'''(() => {{
              window.$ = id => document.getElementById(id);
              window.text = (id, value) => {{ const e=$(id); if(e)e.textContent=value; }};
              window.platformType='seductec'; window.perform=async fn=>await fn(); window.grab=async()=>{{}};
              window.__log = [];
              window.__state = {{tipo_pagina:'curso',url:'{SED}/course/view.php?id=9',pdfs:[{{nome:'Apostila PDF',url:'{resource}',pdf:true}}],atividades:[
                {{nome:'Apostila PDF',url:'{resource}',tipo:'resource',pdf:true,conclusao:'pendente'}}]}};
              window.checkMoodleStatus = async () => {{
                const current=window.__state, select=$('moodlePDFSelect'); select.replaceChildren();
                for(const item of current.pdfs||[]){{const option=document.createElement('option');option.value=item.url;option.textContent=item.nome;select.append(option)}}
                return current;
              }};
              window.loadMoodleSettings = async () => ({{modo:'tudo', preencher_quiz:true, preencher_forum:true, tentar_novamente:true}});
              window.api = async (path, method, body) => {{
                window.__log.push([path, body]);
                if(path==='moodle/open-activity') window.__state={{tipo_pagina:'material',url:'{resource}',pdfs:[{{nome:'apostila.pdf',url:'{direct}',pdf:true}}],atividades:[]}};
                return {{ok:true}};
              }};
              window.openMoodlePDF = async () => {{window.__log.push(['pdf/open', $('moodlePDFSelect').value]);return {{ok:true}}}};
              window.readMoodlePDF = async () => {{window.__log.push(['pdf/read', $('moodlePDFSelect').value]);return {{ok:true,legivel:true}}}};
            }})();'''
            handler_start = source.index("$('toggle').onclick=()=>perform")
            handler = source[handler_start:source.index('\n', handler_start)]
            await page.add_script_tag(content=setup + '\n' + logic + '\n' + handler)
            await page.locator('#toggle').click()
            log = await page.evaluate('window.__log')
            assert any(x[0]=='moodle/open-activity' and x[1]['url']==resource for x in log), log
            assert ['pdf/open', direct] in log, log
            assert ['pdf/read', direct] in log, log
            await browser.close()
    asyncio.run(run())


@pytest.mark.skipif(not Path('/usr/bin/chromium').exists(), reason='Chromium não instalado neste ambiente')
def test_botao_executar_prepara_rascunho_de_forum_e_preenche_editor():
    from playwright.async_api import async_playwright
    from pathlib import Path
    source = (Path(__file__).resolve().parents[1] / 'web' / 'index.html').read_text(encoding='utf-8')
    start = source.index('function moodleActivityKind(item){')
    end = source.index("$('saveMoodleSettings').onclick", start)
    logic = source[start:end]
    handler_start = source.index("$('toggle').onclick=()=>perform")
    handler = source[handler_start:source.index('\n', handler_start)]

    async def run():
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox'])
            page = await browser.new_page()
            await page.set_content('<button id="toggle"><span id="toggleLabel"></span></button><div id="moodleStatusText"></div><div id="moodleForumStatus"></div>')
            setup = f'''(() => {{
              window.$ = id => document.getElementById(id);
              window.text = (id, value) => {{ const e=$(id); if(e)e.textContent=value; }};
              window.platformType='seductec'; window.perform=async fn=>await fn(); window.grab=async()=>{{}};
              window.__log=[];
              window.checkMoodleStatus=async()=>({{tipo_pagina:'forum',estado:'pendente',forum:{{editorDetectado:false}}}});
              window.loadMoodleSettings=async()=>({{modo:'tudo',preencher_quiz:true,preencher_forum:true,tentar_novamente:true}});
              window.draftMoodleForum=async()=>{{window.__log.push('forum/draft');return {{resposta:'Rascunho para a discussão.'}}}};
              window.openMoodleForumReply=async()=>{{window.__log.push('forum/open-reply');return {{editor:true}}}};
              window.fillMoodleForum=async()=>{{window.__log.push('forum/fill');return {{preenchido:true,enviado:false}}}};
            }})();'''
            await page.add_script_tag(content=setup+'\n'+logic+'\n'+handler)
            await page.locator('#toggle').click()
            log=await page.evaluate('window.__log')
            assert log==['forum/draft','forum/open-reply','forum/fill'], log
            await browser.close()
    asyncio.run(run())


def test_fechar_pdf_fecha_aba_temporaria_e_restaura_curso(monkeypatch):
    async def run():
        class Tab:
            def __init__(self, url):
                self.closed = False
                self.context = object()
                self.url = url
                self.brought_front = False
            def is_closed(self):
                return self.closed
            async def close(self):
                self.closed = True
            async def bring_to_front(self):
                self.brought_front = True
        pdf_tab = Tab('https://seductec.seduc.pi.gov.br/pluginfile.php/1/teste.pdf')
        course_tab = Tab('https://seductec.seduc.pi.gov.br/course/view.php?id=90')
        monkeypatch.setattr(servidor, 'moodle_pdf_page', pdf_tab)
        monkeypatch.setattr(servidor, 'moodle_pdf_return_page', course_tab)
        monkeypatch.setattr(servidor, 'page', pdf_tab)
        monkeypatch.setattr(servidor, 'context', pdf_tab.context)
        monkeypatch.setattr(servidor, 'lock', asyncio.Lock())
        result = await servidor.moodle_close_pdf()
        assert result['fechado'] is True
        assert pdf_tab.closed is True
        assert course_tab.brought_front is True
        assert servidor.page is course_tab
    asyncio.run(run())


@pytest.mark.asyncio
async def test_retry_moodle_quiz_restores_after_external_redirect():
    origin = f'{SED}/mod/quiz/summary.php?attempt=18'

    class FakeAction:
        def __init__(self):
            self.labels = iter(['BUTTON', 'Tentar novamente'])
        async def is_visible(self): return True
        async def is_enabled(self): return True
        async def evaluate(self, _script): return next(self.labels)
        async def get_attribute(self, _name): return None
        async def click(self, timeout=0): page.url = 'https://example.org/redirected'

    class FakeCandidates:
        async def count(self): return 1
        def nth(self, _index): return action

    class FakePage:
        def __init__(self): self.url = origin
        def locator(self, _selector): return FakeCandidates()
        async def wait_for_load_state(self, *_args, **_kwargs): return None
        async def goto(self, target, **_kwargs): self.url = target

    page = FakePage()
    action = FakeAction()
    with pytest.raises(ValueError, match='não permaneceu no questionário'):
        await retry_moodle_quiz(page)
    assert page.url == origin

@pytest.mark.asyncio
async def test_start_ignora_atividades_sem_url_ou_origem_invalida(monkeypatch):
    class Source:
        url = f'{SED}/course/view.php?id=35'
        context = object()

    class CaptureManager:
        def __init__(self): self.activities = None
        async def start(self, context, course, activities, processor, workers):
            self.activities = activities
            return {'estado': 'executando', 'total': len(activities)}

    capture = CaptureManager()
    monkeypatch.setattr(servidor, 'pause_for_manual_action', AsyncMock())
    monkeypatch.setattr(servidor, 'current_page', lambda: Source())
    monkeypatch.setattr(servidor, 'expand_moodle_course_sections', AsyncMock(return_value={'controles_acionados': 0}))
    monkeypatch.setattr(servidor, 'inspect_moodle_page', AsyncMock(return_value={
        'secoes': [{'titulo': 'Aula 01'}],
        'atividades': [
            {'nome': 'Cartão sem link', 'url': None, 'tipo': 'resource'},
            {'nome': 'Link externo', 'url': 'https://example.org/fora', 'tipo': 'resource'},
            {'nome': 'Quiz válido', 'url': f'{SED}/mod/quiz/view.php?id=52', 'tipo': 'quiz'},
        ],
    }))
    monkeypatch.setattr(servidor, 'read_moodle_settings', lambda: dict(servidor.MOODLE_DEFAULT_SETTINGS))
    monkeypatch.setattr(servidor, '_read_moodle_automation_state', lambda: {'cursos': {}})
    monkeypatch.setattr(servidor, 'moodle_automation', capture)
    monkeypatch.setattr(servidor, 'record', lambda *_: None)
    monkeypatch.setattr(servidor, 'lock', asyncio.Lock())
    result = await servidor.moodle_automation_start(servidor.MoodleAutomationStartRequest(agentes=2))
    assert result['ok'] is True
    assert [item['nome'] for item in capture.activities] == ['Quiz válido']

@pytest.mark.asyncio
async def test_automacao_pdf_abre_previa_temporaria_fecha_e_restabelece_aba_do_agente(monkeypatch):
    pdf_url = f'{SED}/pluginfile.php/123/mod_resource/content/1/aula.pdf'

    class Response:
        ok = True
        status = 200
        url = pdf_url
        headers = {'content-type': 'application/pdf'}
        async def body(self): return b'%PDF-' + b'fixture'

    class Request:
        async def get(self, url, **kwargs):
            assert url == pdf_url
            return Response()

    class Page:
        def __init__(self, url):
            self.url = url
            self.request = Request()
            self.context = SimpleNamespace()
            self.closed = False
        async def goto(self, url, **kwargs): self.url = url
        async def wait_for_timeout(self, _ms): return None
        async def screenshot(self, **kwargs): return b'preview-bytes'
        def is_closed(self): return self.closed
        async def close(self): self.closed = True

    worker = Page(f'{SED}/course/view.php?id=44')
    pdf_tab = Page(pdf_url)
    async def open_pdf(_page, url):
        assert url == pdf_url
        return pdf_tab

    monkeypatch.setattr(servidor, 'inspect_moodle_page', AsyncMock(return_value={
        'pdfs': [{'url': pdf_url, 'nome': 'Aula PDF'}], 'texto': '',
        'tipo_pagina': 'material', 'titulo': 'Leitura Aula 01',
    }))
    monkeypatch.setattr(servidor, 'open_moodle_pdf', open_pdf)
    monkeypatch.setattr(servidor, '_extract_moodle_pdf_bytes', lambda _body: {
        'legivel': True, 'texto': 'Texto de aula extraído.', 'paginas': 1, 'paginas_lidas': 1,
    })
    lane = {}
    result = await servidor._process_moodle_automation_activity(worker, {
        'url': f'{SED}/mod/resource/view.php?id=77', 'nome': 'Leitura Aula 01',
        'tipo': 'resource', 'pdf': True,
    }, lane)
    assert result['estado'] == 'pdf_lido'
    assert result['paginas_lidas'] == 1
    assert pdf_tab.closed is True
    assert lane['preview_page'] is None
    assert lane['last_preview_bytes'] == b'preview-bytes'
    manager = __import__('moodle_automation').MoodleAutomation()
    manager._lanes = {'agente-1': {'page': worker, 'preview_page': None, 'last_preview_bytes': b'preview-bytes'}}
    assert await manager.screenshot('agente-1') == b'preview-bytes'
    assert 'aba temporária foi fechada' in result['mensagem']


def test_extracao_pdf_real_respeita_limite_de_50_paginas():
    from io import BytesIO
    from reportlab.pdfgen import canvas

    buffer = BytesIO()
    document = canvas.Canvas(buffer)
    for number in range(1, 52):
        document.drawString(72, 720, f'Conteúdo de teste da página {number}.')
        document.showPage()
    document.save()
    result = servidor._extract_moodle_pdf_bytes(buffer.getvalue())
    assert result['legivel'] is True
    assert result['paginas'] == 51
    assert result['paginas_lidas'] == 50
    assert 'Conteúdo de teste da página 1.' in result['texto']
    assert 'Conteúdo de teste da página 50.' in result['texto']
    assert 'Conteúdo de teste da página 51.' not in result['texto']


def test_pdf_paginas_lidas_reflete_limite_de_caracteres(monkeypatch):
    import pypdf

    class LargeTextPage:
        def extract_text(self):
            return 'A' * 25050

    class Reader:
        def __init__(self, _stream):
            self.pages = [LargeTextPage(), LargeTextPage(), LargeTextPage()]

    monkeypatch.setattr(pypdf, 'PdfReader', Reader)
    result = servidor._extract_moodle_pdf_bytes(b'%PDF-fake-test-bytes')
    assert result['paginas'] == 3
    assert result['paginas_lidas'] == 1
    assert len(result['texto']) == 24000
