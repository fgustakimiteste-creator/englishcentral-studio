# Auditoria técnica — EnglishCentral Studio V18.12.4

## Base e método

- Base de trabalho: distribuição `EnglishCentral-Studio-18.12.3-AUTOMACAO-FILA-PREVIEW.zip`, mantida como referência funcional e atualizada incrementalmente.
- Skill aplicada: `SKILL.md` da distribuição 18.12.3, seguindo Analyze → Plan → Execute → Test → Fix → Optimize. O projeto `G0DM0D3-main` foi usado como referência arquitetural para manter orquestração modular, avaliação/feedback e adaptação, sem colocar agentes concorrentes para clicar no mesmo DOM Moodle.
- Princípios mantidos: EnglishCentral e SEDUCTEC permanecem isolados; texto de página é conteúdo não confiável; dados de login não vão para provedores de IA; respostas existentes são preservadas; quiz/fórum não são enviados/publicados em segundo plano; progresso só é informado quando há evidência da plataforma.

## Correções entregues

1. **Origem segura:** `moodle_adapter.platform_info()` agora reconhece explicitamente SEDUCTEC e os domínios oficiais EnglishCentral em HTTPS. Uma origem desconhecida não é rotulada incorretamente como EnglishCentral e não recebe automação específica.
2. **PDF limitado à página atual:** tanto a rota do servidor quanto `open_moodle_pdf()` exigem que a URL exata esteja entre os PDFs visíveis identificados na página atual. Ser um `.pdf` ou pertencer ao mesmo host não libera acesso por si só.
3. **Retorno após redirecionamento:** ao abrir uma atividade SEDUCTEC, se a navegação resultar fora do domínio oficial, o Studio tenta restaurar a URL de origem e devolve erro explícito em vez de continuar na origem externa.
4. **Repetição de quiz protegida:** a ação de nova tentativa valida novamente a origem e o caminho Moodle de quiz após navegar; caso o fluxo saia desse contexto, tenta voltar à página inicial da atividade e interrompe a operação.
5. **Nova tentativa segura:** quando um controle visível de repetição redireciona para uma origem ou rota fora do questionário SEDUCTEC, o Studio restaura a página original quando possível e interrompe a ação.
6. **Chromium no desktop e Termux:** `EC_BROWSER_EXECUTABLE` é a configuração prioritária, `EC_CHROMIUM_PATH` permanece como alternativa compatível. O helper valida que o caminho existe; o inicializador Android lê e exporta as duas variáveis, evitando divergência entre shell e servidor.
7. **Testes obsoletos ajustados:** os testes da captura e leitura agora refletem a fila do navegador (aguardar em vez de falhar imediatamente com 409); a fixture de PDF importa `reportlab.pdfgen.canvas` corretamente. Três testes novos verificam precedência, fallback e rejeição de caminho inexistente do Chromium.

## Resultados executados

Chromium do sistema utilizado nos testes: `/usr/bin/chromium` (144.0.7559.96). Os grupos abaixo foram executados separadamente para isolar falhas e evitar que um teste bloqueado esconda os resultados dos demais:

| Grupo | Resultado |
|---|---:|
| Origem, Moodle/SEDUCTEC, AutoTune IA, API, fila, perfis e regressões centrais | 86 aprovados |
| Fluxo, motor e player EnglishCentral | 23 aprovados |
| Seleção/revisão de quiz, restrições, navegação e progresso | 39 aprovados |
| Conexão do navegador, recuperação de sessão, perfis e configurações | 48 aprovados |
| Mobile/PWA/UI | 36 aprovados; 2 bloqueados pelo ambiente |

Os grupos são independentes e há sobreposição intencional de cobertura entre as baterias de conexão/perfis; os números não devem ser somados como contagem de testes únicos. A coleta atual identificou **480 testes Python** na suíte total. A suíte integral não foi declarada aprovada.

Os dois testes não concluídos da bateria mobile/PWA falharam antes de carregar suas páginas por `net::ERR_BLOCKED_BY_ADMINISTRATOR` ao navegar para `127.0.0.1` e para um domínio de fixture. O bloqueio é imposto pelo ambiente de execução do Chromium; não há evidência suficiente para atribuir essas duas falhas ao código do Studio. As demais 36 verificações daquele grupo passaram.

Verificações técnicas concluídas:

- `python -m compileall -q .` — aprovado.
- `bash -n TERMUX_INICIAR.sh` — aprovado.
- `node --check` em todos os arquivos JS do diretório web e no script inline da página — aprovado.
- 282 IDs HTML sem duplicidade e sem referências literais não resolvidas do helper `$()`.
- O pacote foi extraído em uma pasta limpa; compilação e sintaxe Termux passaram; uma bateria independente executada diretamente da cópia extraída teve **44 testes aprovados**.
- `ZipFile.testzip()` — sem erros. A distribuição contém 146 arquivos e não contém dados locais, segredos, tokens, cookies, bancos SQLite, arquivos `.env`, ambientes virtuais ou `node_modules`.

## Limites não mascarados

- Não foram fornecidos login autenticado real do SEDUCTEC/EnglishCentral, uma disciplina de teste, chave válida de API nem modelo local carregado. Portanto, não houve teste de submissão/XP, sessão real da conta ou integração com IA faturada.
- Não foi possível validar em produção os seletores/estados reais do curso. As interações Moodle automatizadas são verificadas com Chromium e páginas de fixture que executam DOM real local.
- O executor percorre atividades visíveis e compatíveis, mas não pode atravessar login, permissão, CAPTCHA, atividade oculta ou aprovação do professor. Quiz e fórum continuam exigindo revisão e ação final explícita.
- A suíte total tem 479 itens coletados; como alguns casos de navegador encontram bloqueio de rede neste ambiente e a execução integral tem duração longa, o resultado acima é por baterias independentes, não uma certificação total da suíte.
- A suíte JS baseada em jsdom não foi executada: este ambiente tem Node 22.16.0, enquanto `package.json` exige Node >=24.15.0, e não tem `jsdom` instalado. Os arquivos JS e scripts inline serão validados por `node --check` separadamente.

## Conclusão

A V18.12.4 entrega correções reproduzíveis de confiança da origem, acesso a PDF, retorno de navegação e inicialização do Chromium para desktop/Termux. Os testes aprovados são reais e reproduzíveis nas baterias listadas; os bloqueios ambientais e os passos que exigem sessão oficial permanecem explicitamente pendentes.
