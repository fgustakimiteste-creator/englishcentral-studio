import asyncio
from navegacao import safe_target, choose_navigation
from playwright.async_api import async_playwright
from conftest import chromium_launch_options


def test_itens_perigosos_ou_externos_sao_ignorados():
    assert safe_target({'label':'Iniciar', 'href':'https://pt.englishcentral.com/video/123'})
    assert not safe_target({'label':'Comprar Premium', 'href':'https://pt.englishcentral.com/premium'})
    assert not safe_target({'label':'Iniciar', 'href':'https://evil.example.com/video/123'})
    assert not safe_target({'label':'Speak', 'href':'https://pt.englishcentral.com/video/123'})
    assert not safe_target({'label':'Entrar', 'href':None})


def test_botao_unico_de_inicio_e_next():
    async def run():
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(**chromium_launch_options())
            p = await browser.new_page()
            await p.set_content('<button onclick="window.started = true">Começar</button><button>Ajuda</button>')
            result = await choose_navigation(p)
            assert result['tipo'] == 'navegacao'
            assert await p.evaluate('window.started') is True
            await p.set_content('<button onclick="window.next = true">Próximo</button><button>Speak</button>')
            result = await choose_navigation(p, next_only=True)
            assert result['tipo'] == 'navegacao'
            assert await p.evaluate('window.next') is True
            await browser.close()
    asyncio.run(run())


def test_navegacao_ambigua_nao_clica():
    async def run():
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(**chromium_launch_options())
            p = await browser.new_page()
            await p.set_content('<button onclick="window.pressed = true">Começar</button><button onclick="window.pressed = true">Começar</button>')
            result = await choose_navigation(p)
            assert result['tipo'] == 'indefinido'
            assert await p.evaluate('!!window.pressed') is False
            await browser.close()
    asyncio.run(run())
