import asyncio
from unittest.mock import patch, AsyncMock
import auto_ia
import servidor

def test_openai_response_is_extracted_without_returning_secrets():
    cfg={'EC_IA_PROVEDOR':'openai','EC_IA_MODELO':'gpt-5.4-mini','EC_IA_CHAVE':'test-only-secret'}
    response={'status':'completed','output':[{'type':'message','content':[{'type':'output_text','text':'{"respostas":["empire"]}'}]}]}
    with patch('auto_ia._post_json',return_value=response) as request:
        result=auto_ia._request_text('Return JSON',cfg)
    assert result=='{"respostas":["empire"]}'
    url,payload,headers=request.call_args.args
    assert url=='https://api.openai.com/v1/responses'
    assert payload['store'] is False
    assert 'test-only-secret' not in str(payload)

def test_config_saves_only_locally(tmp_path,monkeypatch):
    target=tmp_path/'config.txt'
    monkeypatch.setattr(auto_ia,'CONFIG',target)
    monkeypatch.setattr(servidor,'pause_for_manual_action',AsyncMock())
    key='sk-'+'x'*30
    result=asyncio.run(servidor.configure_openai(servidor.OpenAIConfig(chave=key)))
    assert key in target.read_text()
    assert key not in str(result)
    assert result['ok']
