/* Instalação e atualização sem iniciar, pausar ou repetir atividades. */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  let installPrompt = null, registration = null, reloading = false;
  const standalone = () => window.matchMedia?.('(display-mode: standalone)').matches || navigator.standalone === true;
  const ios = /iPad|iPhone|iPod/.test(navigator.userAgent) ||
    (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  const set = (id, value) => { if ($(id)) $(id).textContent = value; };
  function paintInstall() {
    const installed = standalone();
    set('appInstallTitle', installed ? 'Seu aplicativo está pronto' : 'Seu painel, como aplicativo');
    set('appInstallHelp', installed ? 'Acesse suas sessões pelo ícone na tela inicial.' : ios ?
      'No Safari, toque em Compartilhar e em Adicionar à Tela de Início.' : installPrompt ?
      'Instale para abrir pelo ícone, em uma janela própria.' :
      'Abra o menu do navegador e procure Instalar aplicativo ou Adicionar à tela inicial.');
    if ($('installApp')) $('installApp').hidden = installed;
    if ($('installApp')) $('installApp').textContent = installPrompt ? 'Instalar aplicativo' : 'Como instalar';
  }
  window.addEventListener('beforeinstallprompt', event => {
    event.preventDefault(); installPrompt = event; paintInstall();
  });
  window.addEventListener('appinstalled', () => { installPrompt = null; paintInstall(); set('appInstallHelp', 'Instalação concluída. Abra o Studio pelo ícone na tela inicial.'); });
  $('installApp')?.addEventListener('click', async () => {
    if (!window.isSecureContext) {
      set('appInstallHelp', 'A instalação no celular precisa do endereço HTTPS do painel. Um endereço HTTP da rede não oferece essa instalação.');
      return;
    }
    if (!installPrompt) { paintInstall(); return; }
    const prompt = installPrompt; installPrompt = null;
    $('installApp').disabled = true;
    try { await prompt.prompt(); await prompt.userChoice; }
    catch { set('appInstallHelp', 'O navegador não concluiu a instalação. Você pode tentar pelo menu.'); }
    finally { $('installApp').disabled = false; paintInstall(); }
  });
  function updateReady(worker) {
    if (!worker || !$('appUpdate')) return;
    $('appUpdate').hidden = false;
    set('appUpdateMessage', 'Há uma atualização pronta. O assistente continua no servidor durante a troca.');
    $('applyAppUpdate').onclick = () => {
      $('applyAppUpdate').disabled = true;
      worker.postMessage({type: 'ACTIVATE_UPDATE'});
    };
  }
  if ('serviceWorker' in navigator && window.isSecureContext) {
    navigator.serviceWorker.register('/sw.js', {scope: '/', updateViaCache: 'none'}).then(reg => {
      registration = reg; updateReady(reg.waiting);
      reg.addEventListener('updatefound', () => {
        const worker = reg.installing;
        worker?.addEventListener('statechange', () => {
          if (worker.state === 'installed' && navigator.serviceWorker.controller) updateReady(reg.waiting || worker);
        });
      });
    }).catch(() => set('appInstallHelp', 'O suporte à instalação está temporariamente indisponível. O painel continua acessível pelo navegador.'));
    navigator.serviceWorker.addEventListener('controllerchange', () => {
      if (!$('applyAppUpdate')?.disabled || reloading) return;
      reloading = true; location.reload();
    });
  }
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) registration?.update().catch(() => {});
  });
  paintInstall();
})();
