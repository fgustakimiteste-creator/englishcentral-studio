@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "PYTHONIOENCODING=utf-8"
set "PYTHONUTF8=1"
title EnglishCentral - Painel local
py -3 --version >nul 2>&1
if errorlevel 1 (
 python iniciar.py
) else (
 py -3 iniciar.py
)
if errorlevel 1 (
 echo.
 echo Houve um erro. Leia a mensagem acima e pressione uma tecla para sair.
 pause >nul
)
