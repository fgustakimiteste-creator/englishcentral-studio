"""Memória conservadora de conclusões verificadas no player oficial.

Não registra tempo de vídeo nem altera o status no EnglishCentral.
A lista agregada de cartões NÃO basta para comprovar progresso.
"""
from __future__ import annotations
import json
import math
import re
import time
from pathlib import Path
from arquivos_locais import write_json_atomic

VALID = ('assistir', 'aprender', 'falar')
MAX_LESSONS = 400
MAX_QUIZZES = 600
UNIT_STEPS = (*VALID, 'quizzes', 'activities')


def _safe_course(value: str) -> str:
    value = str(value or '')
    return value if value.isdecimal() and 1 <= len(value) <= 10 else ''


class ProgressoVerificado:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.data: dict = {'versao': 1, 'cursos': {}, 'unidades_verificadas': {}}
        self.avisos: list[str] = []
        self._needs_backup = False
        try:
            loaded = json.loads(self.path.read_text(encoding='utf-8'))
            if isinstance(loaded, dict):
                self.data = loaded
            else:
                self._needs_backup = True
        except FileNotFoundError:
            pass
        except (ValueError, UnicodeError):
            self._needs_backup = True
        self._normalize()
        if self._needs_backup:
            self.avisos.append('Registros inválidos foram ignorados; os dados válidos foram preservados. O original será copiado antes do próximo salvamento.')

    def _normalize(self):
        """Corrige apenas estruturas inválidas; preserva campos extras e confirmações válidas."""
        def mapping(parent, key):
            if key not in parent:
                parent[key] = {}
            elif not isinstance(parent[key], dict):
                parent[key] = {}; self._needs_backup = True
            return parent[key]
        courses = mapping(self.data, 'cursos')
        for course in list(courses):
            lessons = mapping(courses, course)
            for lesson in list(lessons):
                flags = mapping(lessons, lesson)
                for step in VALID:
                    if step in flags and type(flags[step]) is not bool:
                        del flags[step]; self._needs_backup = True
        for field in ('unidades_verificadas', 'titulos_unidades'):
            groups = mapping(self.data, field)
            for course in list(groups):
                values = mapping(groups, course)
                if field == 'unidades_verificadas':
                    for scope in list(values):
                        units = mapping(values, scope)
                        for unit, stamp in list(units.items()):
                            if type(stamp) not in (int, float) or not math.isfinite(stamp) or stamp <= 0:
                                del units[unit]; self._needs_backup = True
                    # Uma confirmação antiga de um foco combinado comprova cada
                    # etapa dele. Separe-a antes de invalidar apenas uma etapa.
                    for scope, units in list(values.items()):
                        if '|' not in scope:
                            continue
                        for step in set(scope.split('|')).intersection(UNIT_STEPS):
                            separate = mapping(values, step)
                            for unit, stamp in units.items():
                                if stamp <= time.time()+60 and stamp > separate.get(unit, 0):
                                    separate[unit] = stamp
        for field in ('quizzes_verificados', 'linhas_fala'):
            groups = mapping(self.data, field)
            for course, values in list(groups.items()):
                if not isinstance(values, list):
                    groups[course] = []; self._needs_backup = True
                elif field == 'quizzes_verificados':
                    valid = [key for key in values if isinstance(key, str) and re.fullmatch(r'[A-Za-z0-9:_-]{1,100}', key)]
                    if valid != values: self._needs_backup = True
                    groups[course] = valid
                elif field == 'linhas_fala':
                    valid = [row for row in values if isinstance(row, dict)]
                    if len(valid) != len(values): self._needs_backup = True
                    groups[course] = valid
                    for row in valid:
                        for key in ('precisao', 'meta'):
                            value = row.get(key)
                            if value is not None and (type(value) not in (int, float) or not math.isfinite(value) or not 0 <= value <= 100):
                                row[key] = None; self._needs_backup = True
        history = self.data.get('historico', [])
        valid = [row for row in history if isinstance(row, dict)] if isinstance(history, list) else []
        if valid != history: self._needs_backup = True
        self.data['historico'] = valid

    def confirmar(self, curso: str, aula: str, flags: dict) -> bool:
        from course_flow import lesson_key
        curso, aula = _safe_course(curso), lesson_key(aula)
        if not curso or not aula:
            return False
        if not any(flags.get(k) is True for k in VALID):
            return False
        cursos = self.data.setdefault('cursos', {})
        aulas = cursos.setdefault(curso, {})
        if aula not in aulas and len(aulas) >= MAX_LESSONS:
            return False
        atual = aulas.setdefault(aula, {})
        changed = False
        for etapa in VALID:
            if flags.get(etapa) is True and not atual.get(etapa):
                atual[etapa] = True
                changed = True
        if changed:
            self._save()
        return changed

    def concluidas(self, curso: str, etapas: tuple[str, ...]) -> set[str]:
        aulas = self.data.get('cursos', {}).get(_safe_course(curso), {})
        if not isinstance(aulas, dict):
            return set()
        return {aula for aula, flags in aulas.items() if isinstance(flags, dict) and
                all(flags.get(etapa) is True for etapa in etapas)}

    def invalidar(self, curso: str, aula: str, etapas: tuple[str, ...], unidade: str = '') -> bool:
        """Remove confirmações locais que uma leitura atual contradisse.

        Não altera o site. Sem mapa aula/unidade no cache, invalida também os
        grupos de unidades deste curso que dependem das etapas contraditas.
        """
        from course_flow import lesson_key
        curso, aula = _safe_course(curso), lesson_key(aula)
        if isinstance(etapas, str):
            etapas = (etapas,)
        selected = {etapa for etapa in etapas if etapa in VALID}
        if not curso or not aula or not selected:
            return False
        changed = False
        aulas = self.data.get('cursos', {}).get(curso, {})
        atual = aulas.get(aula) if isinstance(aulas, dict) else None
        if isinstance(atual, dict):
            for etapa in selected:
                if etapa in atual:
                    del atual[etapa]
                    changed = True
            if not atual:
                aulas.pop(aula, None)
        units = self.data.get('unidades_verificadas', {})
        groups = units.get(curso) if isinstance(units, dict) else None
        if isinstance(groups, dict):
            for scope in list(groups):
                if selected.intersection(scope.split('|')):
                    if unidade:
                        values=groups[scope]
                        if isinstance(values,dict) and unidade in values:
                            del values[unidade];changed=True
                    else:
                        del groups[scope]
                        changed = True
        if changed:
            self._save()
        return changed

    def confirmar_quiz(self, curso: str, quiz_id: str) -> bool:
        curso = _safe_course(curso)
        quiz_id = str(quiz_id or "")
        if not curso or not re.fullmatch(r"[A-Za-z0-9:_-]{1,100}", quiz_id):
            return False
        quizzes = self.data.setdefault("quizzes_verificados", {}).setdefault(curso, [])
        if quiz_id in quizzes or len(quizzes) >= MAX_QUIZZES:
            return False
        quizzes.append(quiz_id)
        self._save()
        return True

    def quizzes(self, curso: str) -> set[str]:
        values = self.data.get("quizzes_verificados", {}).get(_safe_course(curso), [])
        if not isinstance(values, list):
            return set()
        return {str(value) for value in values
                if re.fullmatch(r"[A-Za-z0-9:_-]{1,100}", str(value))}

    def _save(self) -> None:
        write_json_atomic(self.path, self.data, backup=self._needs_backup)
        self._needs_backup = False

    def confirmar_unidades(self, curso: str, etapas: tuple[str, ...], units: set[str], titulos: dict | None = None) -> bool:
        curso = _safe_course(curso)
        selected = tuple(step for step in UNIT_STEPS if step in etapas)
        if not curso or not selected:return False
        groups=self.data.setdefault('unidades_verificadas',{}).setdefault(curso,{})
        now=time.time();changed=False
        # Salve o foco completo e as etapas separadas. Fala nunca é inferida
        # a partir de uma unidade concluída apenas em vídeo/palavras/quiz.
        for scope in [selected,*[(step,) for step in selected]]:
            values=groups.setdefault('|'.join(scope),{})
            for unit in units:
                unit=str(unit)
                if re.fullmatch(r'[A-Za-z0-9_-]{1,80}',unit) and unit not in values and len(values)<100:
                    values[unit]=now;changed=True
        if titulos:
            titles=self.data.setdefault('titulos_unidades',{}).setdefault(curso,{})
            for unit,title in titulos.items():
                if str(unit) in units and isinstance(title,str) and titles.get(str(unit))!=title[:180]:
                    titles[str(unit)]=title[:180];changed=True
        if changed:self._save()
        return changed

    def resumo_unidades(self, curso: str) -> list[dict]:
        curso=_safe_course(curso);states={}
        all_groups=self.data.get('unidades_verificadas',{})
        groups=all_groups.get(curso,{}) if isinstance(all_groups,dict) else {}
        if not isinstance(groups,dict):return []
        for scope,values in groups.items():
            steps=set(scope.split('|')).intersection(UNIT_STEPS)
            if not isinstance(values,dict):continue
            for unit,timestamp in values.items():
                if type(timestamp) not in (int,float) or not math.isfinite(timestamp) or timestamp<=0 or timestamp>time.time()+60:continue
                states.setdefault(unit,set()).update(steps)
        all_titles=self.data.get('titulos_unidades',{})
        titles=all_titles.get(curso,{}) if isinstance(all_titles,dict) else {}
        if not isinstance(titles,dict):titles={}
        return [{'id':unit,'titulo':titles.get(unit,unit),'etapas':{s:s in steps for s in UNIT_STEPS}}
                for unit,steps in sorted(states.items())]

    def unidades(self, curso: str, etapas: tuple[str, ...]) -> set[str]:
        selected=set(etapas)
        if not selected or not selected.issubset(UNIT_STEPS):return set()
        return {u['id'] for u in self.resumo_unidades(curso) if all(u['etapas'].get(s) for s in selected)}

    def registrar_evento(self, curso: str, acao: str, alvo: str, motivo: str) -> None:
        curso=_safe_course(curso)
        if not curso:return
        events=self.data.setdefault('historico',[])
        events.append({'curso':curso,'acao':str(acao)[:40],'alvo':str(alvo)[:180],
                       'motivo':str(motivo)[:500],'quando':time.time()})
        self.data['historico']=events[-150:];self._save()

    def historico(self, curso: str) -> list[dict]:
        return [e for e in self.data.get('historico',[]) if e.get('curso')==_safe_course(curso)][-50:]

    def registrar_fala(self, curso: str, aula: str, evento: dict) -> None:
        from course_flow import lesson_key
        curso, aula = _safe_course(curso), lesson_key(aula)
        linha = str(evento.get('linha') or '')[:300]
        if not curso or not aula or not linha:
            return
        saved = {'aula': aula, 'linha': linha, 'precisao': evento.get('precisao'),
                 'meta': evento.get('meta'), 'tentativas': evento.get('tentativas'),
                 'estado': evento.get('estado'), 'pulado': evento.get('pulado') is True,
                 'quando': time.time()}
        rows = self.data.setdefault('linhas_fala', {}).setdefault(curso, [])
        rows[:] = [row for row in rows if (row.get('aula'), row.get('linha')) != (aula, linha)]
        rows.append(saved)
        self.data['linhas_fala'][curso] = rows[-1200:]
        self._save()

    def historico_fala(self, curso: str) -> list[dict]:
        return self.data.get('linhas_fala', {}).get(_safe_course(curso), [])[-200:]

    def invalidar_unidade(self, curso: str, unidade: str, etapas: tuple[str, ...]) -> bool:
        groups=self.data.get('unidades_verificadas',{}).get(_safe_course(curso),{})
        changed=False
        if not isinstance(groups,dict):return False
        for scope,values in groups.items():
            if set(etapas).intersection(scope.split('|')) and isinstance(values,dict) and unidade in values:
                del values[unidade];changed=True
        if changed:self._save()
        return changed
