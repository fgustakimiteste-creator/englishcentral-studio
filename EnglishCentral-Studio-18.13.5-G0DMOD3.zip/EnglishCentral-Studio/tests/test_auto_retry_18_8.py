import asyncio
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest
from fastapi import HTTPException

import servidor
from assistant_preferences import read_preferences

SLEEP = asyncio.sleep


@pytest.fixture
def env(monkeypatch, tmp_path):
    for key, value in {'DATA': tmp_path, 'PROGRESS_FILE': tmp_path/'progress.json',
        'COURSE_FILE': tmp_path/'course.txt', 'PROFILES_ROOT': tmp_path,
        'auto_running': True, 'auto_task': None, 'auto_control_lock': asyncio.Lock(),
        'lock': asyncio.Lock(), 'stop_confirmation': None, 'stop_confirmation_event': None,
        'auto_retry_counts': {}, 'AUTO_RETRY_SECONDS': .05, 'auto_latest': {}, 'page': None}.items():
        monkeypatch.setattr(servidor, key, value)


async def question(previous=None):
    for _ in range(1000):
        request = servidor.stop_confirmation
        if request and request['id'] != previous:
            return request
        await SLEEP(.001)
    raise AssertionError('O aviso não apareceu.')


def ask(kind='ajuda', message='Erro transitório'):
    return asyncio.create_task(servidor.request_stop_confirmation(
        {'tipo': kind, 'mensagem': message},
        {'categoria': 'quiz', 'curso': '8597', 'id': 'u1:q1', 'tipo': 'quiz', 'pode_pular': True}))


def test_padrao_e_dez_segundos():
    assert servidor.AUTO_RETRY_SECONDS == 10


def test_tempo_acaba_sem_pedido_do_navegador_e_repete_uma_vez(env):
    async def run():
        task = ask(); request = await question()
        status = servidor.confirmation_status()
        assert status['auto_retry']['ativa'] and status['auto_retry']['restante_ms'] > 0
        assert not any(key.startswith('_') for key in status)
        await SLEEP(.015); assert not task.done()
        assert await asyncio.wait_for(task, 1) is True
        assert request['origem'] == 'automatica' and request['acao'] == 'retry'
        assert list(servidor.auto_retry_counts.values()) == [1]
        assert servidor.stop_confirmation is None and servidor.auto_running
    asyncio.run(run())


def test_cancelar_contagem_preserva_aviso_e_opcoes(env):
    async def run():
        task = ask(); request = await question()
        await servidor.pending_decision_options(servidor.PendingDecisionOptions(
            solicitacao=request['id'], tentativa_automatica=False))
        await SLEEP(.08)
        assert not task.done() and servidor.confirmation_status()['auto_retry']['cancelada']
        await servidor.auto_decision(servidor.StopDecision(solicitacao=request['id'], acao='skip'))
        assert await task == 'skip' and not servidor.auto_retry_counts
    asyncio.run(run())


@pytest.mark.parametrize('action,expected', [('retry', True), ('skip', 'skip')])
def test_escolha_manual_cancela_temporizador(env, action, expected):
    async def run():
        task = ask(); request = await question()
        await servidor.auto_decision(servidor.StopDecision(solicitacao=request['id'], acao=action))
        assert await task == expected
        await SLEEP(.075)
        assert not servidor.auto_retry_counts and servidor.stop_confirmation is None
    asyncio.run(run())


def test_parar_cancela_worker_e_temporizador(env):
    async def run():
        task = ask(); servidor.auto_task = task; request = await question()
        await servidor.auto_decision(servidor.StopDecision(solicitacao=request['id'], acao='stop'))
        await SLEEP(.075)
        assert task.done() and not servidor.auto_running and servidor.stop_confirmation is None
        assert not servidor.auto_retry_counts
    asyncio.run(run())


def test_limite_de_tres_e_retentativa_manual_reabre_orcamento(env):
    async def run():
        for n in range(3):
            task = ask(); await question()
            assert await asyncio.wait_for(task, 1) is True
            assert list(servidor.auto_retry_counts.values()) == [n+1]
        task = ask(); request = await question()
        assert servidor.confirmation_status()['auto_retry']['esgotada']
        await SLEEP(.075); assert not task.done()
        await servidor.auto_decision(servidor.StopDecision(solicitacao=request['id'], acao='retry'))
        await task
        task = ask(); request = await question()
        assert servidor.confirmation_status()['auto_retry']['ativa']
        assert servidor.confirmation_status()['auto_retry']['tentativa'] == 1
        task.cancel(); await asyncio.gather(task, return_exceptions=True)
    asyncio.run(run())


@pytest.mark.parametrize('kind', ['login', 'verificacao', 'fora', 'sem_ia', 'escopo_concluido', 'escopo_pulado'])
def test_etapas_que_exigem_usuario_nao_disparam_sozinhas(env, kind):
    async def run():
        task = ask(kind); await question()
        assert not servidor.confirmation_status()['auto_retry']['ativa']
        await SLEEP(.065); assert not task.done()
        task.cancel(); await asyncio.gather(task, return_exceptions=True)
    asyncio.run(run())


@pytest.mark.parametrize('code', ['OPENAI_SEM_CREDITO', 'OPENAI_CHAVE_INVALIDA'])
def test_configuracao_que_nao_muda_sozinha_nao_consume_tentativas(env, code):
    async def run():
        task = ask('erro_ia', code); await question()
        assert not servidor.confirmation_status()['auto_retry']['ativa']
        task.cancel(); await asyncio.gather(task, return_exceptions=True)
    asyncio.run(run())


def test_opcao_antiga_nao_cancela_contagem_atual(env):
    async def run():
        task = ask(); request = await question()
        with pytest.raises(HTTPException) as error:
            await servidor.pending_decision_options(servidor.PendingDecisionOptions(
                solicitacao='solicitacao-antiga', tentativa_automatica=False))
        assert error.value.status_code == 409 and servidor.confirmation_status()['auto_retry']['ativa']
        task.cancel(); await asyncio.gather(task, return_exceptions=True)
    asyncio.run(run())


def test_preferencia_e_salva_antes_de_tentativa_automatica(env):
    async def run():
        task = ask(); request = await question()
        await servidor.pending_decision_options(servidor.PendingDecisionOptions(
            solicitacao=request['id'], mostrar_novamente=False))
        assert await task is True
        assert read_preferences(servidor.DATA/'preferencias_assistente.json')['quiz'] is False
        next_task = ask(); next_request = await question()
        assert next_request['mostrar_novamente'] is False
        assert servidor.confirmation_status()['auto_retry']['ativa']
        next_task.cancel(); await asyncio.gather(next_task, return_exceptions=True)
    asyncio.run(run())


def test_manual_e_automatico_nao_resolvem_a_mesma_solicitacao_duas_vezes(env):
    async def run():
        task = ask(); request = await question()
        async with servidor.auto_control_lock:
            manual = asyncio.create_task(servidor.auto_decision(servidor.StopDecision(
                solicitacao=request['id'], acao='skip')))
            await SLEEP(.075)
        await manual
        assert await task == 'skip'
        assert not servidor.auto_retry_counts
    asyncio.run(run())


def test_worker_retoma_mesmo_motor_e_conclusao_aguarda_usuario(env, monkeypatch):
    async def run():
        seen = []
        async def process(*args, engine, **kwargs):
            seen.append(engine)
            return {'tipo': 'ajuda' if len(seen) == 1 else 'escopo_concluido', 'mensagem': 'Teste local'}
        monkeypatch.setattr(servidor, 'page', SimpleNamespace(url='https://pt.englishcentral.com/course/8597', is_closed=lambda:False, frames=[]))
        monkeypatch.setattr(servidor, 'network_available', AsyncMock(return_value=True))
        monkeypatch.setattr(servidor, 'issue_context', AsyncMock(return_value={'categoria':'quiz','pode_pular':True,'curso':'8597','id':'u1:q1'}))
        monkeypatch.setattr(servidor, 'process_page', process)
        task = asyncio.create_task(servidor.auto_worker()); servidor.auto_task = task
        try:
            first = await question(); second = await question(first['id'])
            assert second['tipo'] == 'escopo_concluido' and len(seen) == 2
            assert seen[0] is seen[1] and servidor.auto_running
            assert not servidor.confirmation_status()['auto_retry']['ativa']
        finally: await servidor.auto_stop()
    asyncio.run(run())
