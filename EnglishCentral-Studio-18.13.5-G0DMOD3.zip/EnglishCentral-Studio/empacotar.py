"""Cria a distribuição local sem perfil, tokens, memória ou dependências."""
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT.parent / 'EnglishCentral-Studio-18.13.1-G0DMOD3-FIXED.zip'
EXCLUDED = {'.venv', 'venv', 'node_modules', '.dados_locais', '.test-deps', '.pytest_cache', '__pycache__', '.git', '.vscode'}
EXCLUDED_FILES = {'config_ia.local.txt', 'diagnostico_local.txt',
                  'auto_fluxo (# Edit conflict 2026-10-28 j4830aC #).py'}
ROOT_FILES = {
    'INICIAR.bat', 'TERMUX_INICIAR.sh', 'DIAGNOSTICO.bat', 'CONFIGURAR_IA_LOCAL.bat',
    'CONFIGURAR_LEITURA_VISUAL.bat', 'config_ia.exemplo.txt', 'requirements.txt',
    'requirements-dev.txt', 'pytest.ini', 'package.json', '.gitignore',
    'README.md', 'GUIA.md', 'LEIA_PRIMEIRO.txt', 'TESTES.md', 'CHANGELOG.md', 'SKILL.md', 'AUDITORIA_MINUCIOSA_V18_12_2.md',
    'AUDITORIA_V18_11.md', 'AUDITORIA_V18_12_3.md', 'AUDITORIA_V18_12_4.md', 'AUDITORIA_EnglishCentral_Studio_V18.13.0.md', 'TESTES_EnglishCentral_Studio_V18.13.0.md', 'AUDITORIA_G0DM0D3_EnglishCentral_Studio_V18.13.1.md', 'TESTES_G0DM0D3_EnglishCentral_Studio_V18.13.1.md', 'GUIA_CELULAR.md', 'Dockerfile', '.dockerignore',
}
ROOT_MODULES = set('''acesso_servidor arquivos_locais assistant_preferences auto_fluxo auto_ia browser_session moodle_adapter
course_flow diagnostico ec_engine ec_player empacotar etapas exercicio
fala_automatica fala_preferencias fala_sintetica iniciar integracao memoria
mobile_app modos navegacao network_probe perfis progresso quiz_constraints recuperacao
revisao_quiz servidor session_actions moodle_automation'''.split())
DIRECTORY_EXTENSIONS = {
    'web': {'.html', '.css', '.js', '.svg', '.png', '.webmanifest'},
    'tests': {'.py', '.cjs', '.html', '.json', '.webm'},
}
DIRECTORY_FILES = {'deploy': {'compose.yaml', 'Caddyfile', 'servidor.exemplo.env', 'verificar_configuracao.py'}}


def distribution_files():
    for path in sorted(ROOT.rglob('*')):
        rel = path.relative_to(ROOT)
        if not path.is_file() or path.is_symlink() or any(part in EXCLUDED for part in rel.parts):
            continue
        allowed = (len(rel.parts) == 1 and (path.name in ROOT_FILES or path.suffix == '.py' and path.stem in ROOT_MODULES) or
                   len(rel.parts) > 1 and path.suffix.lower() in DIRECTORY_EXTENSIONS.get(rel.parts[0], set()) or
                   len(rel.parts) == 2 and path.name in DIRECTORY_FILES.get(rel.parts[0], set()))
        if not allowed:
            continue
        lower_name = path.name.lower()
        sensitive_file = (any(word in lower_name for word in ('token', 'cookie', 'session')) and
                          path.suffix.lower() not in {'.py', '.js', '.cjs'})
        if (path.name in EXCLUDED_FILES | {'render_preview.py', 'render_preview_v11.py'} or
                lower_name.startswith('.env') or sensitive_file or
                path.suffix.lower() in {'.pyc', '.log', '.tmp', '.bak', '.sqlite', '.sqlite3'}):
            continue
        yield path, rel.as_posix()


def main():
    with ZipFile(OUTPUT, 'w', ZIP_DEFLATED) as archive:
        for path, name in distribution_files():
            archive.write(path, name)
    with ZipFile(OUTPUT) as archive:
        names = archive.namelist()
        assert 'INICIAR.bat' in names and 'TERMUX_INICIAR.sh' in names and 'ec_engine.py' in names and 'fala_sintetica.py' in names
        assert all(path.name in names for path in ROOT.glob('*.py')
                   if path.name not in EXCLUDED_FILES and (path.stem in ROOT_MODULES or path.name == 'empacotar.py'))
        assert archive.testzip() is None
        assert not any(any(part in EXCLUDED for part in Path(name).parts) for name in names)
        assert not any(Path(name).name in EXCLUDED_FILES or Path(name).name.lower().startswith('.env') for name in names)
    print(f'{OUTPUT} ({OUTPUT.stat().st_size} bytes; {len(names)} arquivos)')


if __name__ == '__main__':
    main()
