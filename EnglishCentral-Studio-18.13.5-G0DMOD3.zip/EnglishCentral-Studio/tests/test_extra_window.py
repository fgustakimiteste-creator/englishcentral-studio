import asyncio
from types import SimpleNamespace
from unittest.mock import AsyncMock
import servidor

def test_extra_window_preserves_bot_page(monkeypatch):
    p = SimpleNamespace(url='https://pt.englishcentral.com/course/8598')
    session = SimpleNamespace(send=AsyncMock(), detach=AsyncMock())
    context = SimpleNamespace(new_cdp_session=AsyncMock(return_value=session))
    monkeypatch.setattr(servidor, 'context', context)
    monkeypatch.setattr(servidor, 'page', p)
    monkeypatch.setattr(servidor, 'current_page', lambda:p)
    monkeypatch.setattr(servidor, 'course_url', lambda url:url)
    result = asyncio.run(servidor.new_browser_window())
    session.send.assert_awaited_once_with('Target.createTarget', {'url':p.url,'newWindow':True})
    session.detach.assert_awaited_once()
    assert servidor.page is p and result['ok']
