"""Testes de integração em páginas simuladas; não usam uma conta EnglishCentral."""
import asyncio
from unittest.mock import patch
from playwright.async_api import async_playwright
from conftest import chromium_launch_options
from auto_fluxo import EngineState, process_page
from exercicio import inspect_quiz, read_correction
from memoria import store_words, read_memory
import memoria


def test_lacuna_no_player_com_enter_e_sem_replay(tmp_path, monkeypatch):
    monkeypatch.setattr(memoria, 'MEMORY_PATH', tmp_path/'vocab.json')
    async def run():
        async with async_playwright() as pw:
            b=await pw.chromium.launch(**chromium_launch_options())
            p=await b.new_page(viewport={'width':1280,'height':800})
            await p.set_content('''<!doctype html><title>United by Passion</title>
             <div style="width:700px;height:430px;background:#fafafa">
              <video width="650" height="330"></video>
              <div class="quiz">Digite a palavra que falta</div>
              <div class="caption">I'm Emily Batty, a Canadian Olympic mountain bike ____</div>
              <input id="answer" type="text" class="typing-blank" maxlength="5" />
              <span role="alert" id="hint"></span>
              <script>
                document.getElementById('answer').addEventListener('keydown',ev=>{
                  if(ev.key==='Enter'){
                    document.body.dataset.entered=document.getElementById('answer').value;
                    if(document.body.dataset.entered==='racer') document.getElementById('hint').innerText='Resposta correta: racer';
                    else document.getElementById('hint').innerText='Resposta correta: racer';
                  }
                });
              </script>
             </div>''')
            q=await inspect_quiz(p)
            assert q['ativa'] and q['campos']
            state=EngineState()
            with patch('auto_fluxo.is_englishcentral',return_value=True), patch('auto_fluxo.suggest',return_value=['racer']), patch('auto_fluxo.ia_status',return_value={'configurada': True}):
                a=await process_page(p, submit=True,engine=state)
                assert a['tipo']=='lacuna_video',a
                assert await p.locator('#answer').input_value()=='racer'
                assert await p.locator('body').get_attribute('data-entered')=='racer'
                a2=await process_page(p, submit=True,engine=state)
                assert a2['tipo'] in ('conferencia','aguardando'),a2
                assert await p.locator('#answer').input_value()=='racer'
                assert await p.locator('video').evaluate('v=>v.paused')
            await b.close()
    asyncio.run(run())


def test_erro_feedback_corrige_uma_vez(tmp_path, monkeypatch):
    monkeypatch.setattr(memoria, 'MEMORY_PATH', tmp_path/'vocab.json')
    async def run():
        async with async_playwright() as pw:
            b=await pw.chromium.launch(**chromium_launch_options())
            p=await b.new_page(viewport={'width':1280,'height':800})
            await p.set_content('''<video width=600 height=300></video>
              <div class=quiz>Digite a palavra que falta</div>
              <div class=caption>She likes to ____ through the forest.</div>
              <input class=typing-input id=answer maxlength=4>
              <div role=alert id=feedback></div>
              <script>document.querySelector('#answer').addEventListener('keydown',e=>{if(e.key==='Enter'){
              window.enterCount=(window.enterCount||0)+1;
              document.querySelector('#feedback').innerText='Resposta correta: ride';
              }})</script>''')
            state=EngineState()
            with patch('auto_fluxo.is_englishcentral',return_value=True),patch('auto_fluxo.suggest',return_value=['walk']),patch('auto_fluxo.ia_status',return_value={'configurada':True}):
                a=await process_page(p,submit=True,engine=state)
                assert a['tipo']=='lacuna_video',a
                a=await process_page(p,submit=True,engine=state)
                assert a['tipo']=='correcao',a
                assert await p.locator('#answer').input_value()=='ride'
                a=await process_page(p,submit=True,engine=state)
                assert a['tipo']=='conferencia',a
                assert await p.evaluate('window.enterCount')==2
                assert len(read_memory()['frases'])==1
            await b.close()
    asyncio.run(run())


def test_video_nao_repete_reproducao():
    async def run():
        async with async_playwright() as pw:
            b=await pw.chromium.launch(**chromium_launch_options())
            p=await b.new_page()
            await p.set_content('<video width="300" height="200"></video>')
            state=EngineState()
            with patch('auto_fluxo.is_englishcentral',return_value=True),patch('auto_fluxo.toggle_video',return_value={'reproduzindo':True}) as toggle:
                await process_page(p,engine=state)
                await process_page(p,engine=state)
                assert toggle.await_count==1
            await b.close()
    asyncio.run(run())


def test_extrai_correcao_e_guarda_palavras(tmp_path, monkeypatch):
    monkeypatch.setattr(memoria, 'MEMORY_PATH', tmp_path/'vocab.json')
    assert read_correction('Resposta correta: racer')=='racer'
    assert read_correction('Correct answer: ride')=='ride'
    assert read_correction('foo') is None
    store_words(['PREPARATION', 'CONTRIBUTE', 'SOCIALIZING'])
    assert 'PREPARATION' in read_memory()['palavras']
