import asyncio
from unittest.mock import AsyncMock, patch

from ec_engine import ECState, _learn_question
from ec_player import ActivityChangedError, inspect_ec_player, type_ec_answer
from test_ec_player import run_with_page
import servidor


def test_transition_after_final_letter_never_confirms_next_question():
    async def scenario(page):
        snapshot = await inspect_ec_player(page)
        await page.locator('input.char-input').last.evaluate('''e => e.addEventListener('keyup', event => {
            if(event.key === 'e') document.querySelector('.player-transcript-row span').textContent = 'Another question';
        })''')
        try:
            await type_ec_answer(page, snapshot, 'ride')
        except ActivityChangedError:
            pass
        else:
            raise AssertionError('Transition was not detected')
        assert await page.evaluate('window.enterCount') == 0
    run_with_page(scenario)


def test_engine_recovers_transition_without_claiming_success():
    state = ECState(lesson='lesson', question='q', phrase='She ___', words={'lesson':['ride']})
    snapshot = {'question': True, 'question_id':'q', 'answer_length':4, 'letter_slots':[]}
    with patch('ec_engine.known_answer', return_value=None), patch('ec_engine.type_ec_answer', new=AsyncMock(side_effect=ActivityChangedError())):
        result = asyncio.run(_learn_question(None, snapshot, state, submit=True))
    assert result['tipo'] == 'aguardando'
    assert not state.answer and not state.attempts
    assert not result.get('preenchidas')


def test_model_failure_is_explained():
    state = ECState(lesson='lesson', question='q', phrase='She ___')
    snapshot = {'question': True, 'question_id':'q', 'answer_length':4, 'letter_slots':[]}
    with patch('ec_engine.known_answer', return_value=None), patch('ec_engine.ia_status', return_value={'configurada':True}), patch('ec_engine.run_inference', new=AsyncMock(side_effect=TimeoutError())):
        result = asyncio.run(_learn_question(None, snapshot, state, submit=True))
    assert result['tipo'] == 'erro_ia'
    assert 'TimeoutError' in result['mensagem']


def test_course_remembered_and_untrusted_url_not_saved(tmp_path, monkeypatch):
    monkeypatch.setattr(servidor, 'DATA', tmp_path)
    monkeypatch.setattr(servidor, 'COURSE_FILE', tmp_path / 'course.txt')
    assert servidor.course_url('https://pt.englishcentral.com/course/8571') .endswith('/8571')
    assert servidor.course_url('https://evil.example/course/123').endswith('/8571')
    assert servidor.course_url().endswith('/8571')


def test_paused_video_recovery_is_bounded():
    from ec_engine import _watch_only
    from unittest.mock import MagicMock
    state = ECState(video_started=True, video_position_at=1, video_last_position=4)
    snapshot = {'supported':True,'lesson_id':'dialog:123','mode':'watch', 'frame':0, 'player_index':0, 'video':{'paused':True, 'position':4}}
    control = MagicMock()
    control.count = AsyncMock(return_value=1)
    control.is_visible = AsyncMock(return_value=True)
    control.is_enabled = AsyncMock(return_value=True)
    control.click = AsyncMock()
    page = MagicMock()
    page.frames[0].locator.return_value.nth.return_value.locator.return_value = control
    for now in (30, 60):
        with patch('ec_engine.time.monotonic', return_value=now), patch('ec_engine.inspect_ec_player', AsyncMock(return_value=snapshot)):
            result = asyncio.run(_watch_only(page, snapshot, state))
        assert result['tipo'] == 'video'
    with patch('ec_engine.time.monotonic', return_value=90), patch('ec_engine.inspect_ec_player', AsyncMock(return_value=snapshot)):
        result = asyncio.run(_watch_only(page, snapshot, state))
    assert result['tipo'] == 'video_atencao'
    assert control.click.await_count == 2
