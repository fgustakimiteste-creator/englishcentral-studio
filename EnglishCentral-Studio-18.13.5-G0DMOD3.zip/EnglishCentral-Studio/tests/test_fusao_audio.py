"""Regressões da fusão: microfone reutilizável e validação antes de gravar."""
import asyncio
import base64
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from playwright.async_api import async_playwright

from auto_fluxo import EngineState, _handle_synthetic_speech
from conftest import chromium_launch_options
from fala_sintetica import SYNTHETIC_MIC_INIT, synthesize_wav
from test_synthetic_audio import _tone_wav


def test_microfone_enumera_reutiliza_encerra_e_reabilita():
    async def run():
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(**chromium_launch_options())
            try:
                context = await browser.new_context()
                await context.add_init_script(script=SYNTHETIC_MIC_INIT)
                page = await context.new_page()
                await page.route('https://ec-fusao.test/**', lambda route: route.fulfill(
                    body='<button id="activate" onclick="window.__ecStudioSyntheticMic.setEnabled(true)">Ativar</button>'))
                await page.goto('https://ec-fusao.test/')
                assert not await page.evaluate('window.__ecStudioSyntheticMic.enabled')
                await page.locator('#activate').click()
                payload = base64.b64encode(_tone_wav()).decode('ascii')
                result = await page.evaluate('''async payload => {
                  const mic = window.__ecStudioSyntheticMic;
                  const devices = await navigator.mediaDevices.enumerateDevices();
                  const synthetic = devices.filter(d=>d.deviceId==='ec-studio-synthetic');
                  if(await mic.waitForStream(10)) throw Error('Esperou um microfone inexistente');
                  const pending = mic.waitForStream(1000);
                  const first = await navigator.mediaDevices.getUserMedia({audio:true});
                  if(!await pending) throw Error('A captura não liberou a espera');
                  const second = await navigator.mediaDevices.getUserMedia({audio:true});
                  first.getTracks().forEach(t=>t.stop());
                  const secondLive = second.getAudioTracks()[0].readyState==='live';
                  const seconds = await mic.feed(payload);
                  second.getTracks().forEach(t=>t.stop());
                  let rejected = false;
                  try { await mic.feed(payload); } catch { rejected = true; }
                  const stoppedWait = mic.waitForStream(5000);
                  await mic.release();
                  const releasedWait = await stoppedWait;
                  const disabledDevices = await navigator.mediaDevices.enumerateDevices();
                  mic.setEnabled(true);
                  const third = await navigator.mediaDevices.getUserMedia({audio:true});
                  const thirdLive = third.getAudioTracks()[0].readyState==='live';
                  const repeatedSeconds = await mic.feed(payload);
                  await mic.release();
                  return {synthetic:synthetic.length,kind:synthetic[0]?.kind,
                    secondLive,seconds,rejected,releasedWait,thirdLive,repeatedSeconds,
                    hidden:!disabledDevices.some(d=>d.deviceId==='ec-studio-synthetic'),
                    ended:third.getTracks().every(t=>t.readyState==='ended')};
                }''', payload)
                assert result == {'synthetic':1,'kind':'audioinput','secondLive':True,
                                  'seconds':0.75,'rejected':True,'releasedWait':False,
                                  'thirdLive':True,'repeatedSeconds':0.75,'hidden':True,'ended':True}
                # A próxima navegação deve poder habilitar a entrada de novo.
                await page.goto('https://ec-fusao.test/next')
                assert not await page.evaluate('window.__ecStudioSyntheticMic.enabled')
                with patch('auto_fluxo.synthesize_wav', side_effect=RuntimeError('fim da verificação')):
                    await _handle_synthetic_speech(page, {'speak_prompt':'A new sentence.'}, EngineState(), submit=True)
                assert await page.evaluate('window.__ecStudioSyntheticMic.enabled')
            finally:
                await browser.close()
    asyncio.run(run())


@pytest.mark.parametrize('changed', [
    {},
    {'supported':True,'mode':'watch'},
    {'supported':True,'mode':'speak','frame':1},
    {'supported':True,'mode':'speak','lesson_id':'dialog:2'},
    {'supported':True,'mode':'speak','speak_prompt':'Another sentence.'},
])
def test_nao_grava_se_atividade_muda_durante_sintese(changed):
    async def run():
        frame = MagicMock()
        frame.evaluate = AsyncMock(return_value=True)
        frame.locator.return_value.all = AsyncMock(return_value=[])
        frame.locator.return_value.count = AsyncMock(return_value=0)
        frame.locator.return_value.locator.return_value = frame.locator.return_value
        page = MagicMock()
        page.frames = [frame]
        original = {'supported':True,'mode':'speak','frame':0,'speak_phase':'ready','speak_can_record':True,
                    'lesson_id':'dialog:1','speak_prompt':'This is a test sentence.'}
        fresh = {**original, **changed} if changed else {}
        with patch('auto_fluxo.synthesize_wav', return_value=(_tone_wav(),0.75)), \
             patch('auto_fluxo.inspect_ec_player', AsyncMock(return_value=fresh)), \
             patch('fala_automatica.click_control', AsyncMock()) as record:
            result = await _handle_synthetic_speech(page, original, EngineState(), submit=True)
        assert result['tipo'] == 'aguardando', result
        record.assert_not_awaited()
    asyncio.run(run())


def test_frase_longa_e_rejeitada_sem_truncar():
    with pytest.raises(RuntimeError):
        synthesize_wav('a' * 301)
    async def run():
        frame = MagicMock()
        frame.evaluate = AsyncMock(return_value=True)
        frame.locator.return_value.all = AsyncMock(return_value=[])
        frame.locator.return_value.count = AsyncMock(return_value=0)
        frame.locator.return_value.locator.return_value = frame.locator.return_value
        page = MagicMock()
        page.frames = [frame]
        with patch('auto_fluxo.synthesize_wav', side_effect=RuntimeError('frase longa')) as synth, \
             patch('fala_automatica.click_control', AsyncMock()) as record:
            result = await _handle_synthetic_speech(page, {'speak_phase':'ready','speak_can_record':True,'speak_prompt':'a' * 301}, EngineState(), submit=True)
        synth.assert_not_called()
        assert result['tipo'] == 'ajuda'
        record.assert_not_awaited()
    asyncio.run(run())
