"""Cobertura do fluxo de múltipla escolha com páginas locais e opções visíveis."""
import asyncio
import json
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

import pytest
from playwright.async_api import async_playwright

import auto_ia
from auto_fluxo import EngineState, process_page
from conftest import chromium_launch_options
from exercicio import inspect_quiz, select_quiz_choice, type_quiz_answer
from modos import ModoEstudo
from progresso import ProgressoVerificado


QUIZ_HTML = """<!doctype html><html><body>
<section class="quiz-panel">
  <h2 class="question-title">Where is the book?</h2>
  <fieldset>
    <legend>Choose the correct answer</legend>
    <label><input type="radio" name="answer" value="table">It is on the table.</label>
    <label><input type="radio" name="answer" value="car">It is in the car.</label>
    <label><input type="radio" name="answer" value="box">It is in the box.</label>
  </fieldset>
  <button type="submit">Check answer</button>
</section></body></html>"""


def test_detecta_e_seleciona_somente_a_opcao_exata():
    async def run():
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(**chromium_launch_options())
            try:
                page = await browser.new_page()
                await page.set_content(QUIZ_HTML)
                quiz = await inspect_quiz(page)
                assert quiz['ativa'] and quiz['tipo'] == 'multipla_escolha'
                assert quiz['pergunta'] == 'Where is the book?'
                assert [item['text'] for item in quiz['opcoes']] == [
                    'It is on the table.', 'It is in the car.', 'It is in the box.'
                ]
                pointer = await select_quiz_choice(page, quiz, 'It is in the box.')
                assert pointer['acao'] == 'quiz_opcao'
                assert await page.locator('input[value=box]').is_checked()
            finally:
                await browser.close()
    asyncio.run(run())


def test_lacuna_com_caixas_curta_usa_todas_as_letras():
    async def run():
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(**chromium_launch_options())
            try:
                page = await browser.new_page(viewport={'width': 900, 'height': 700})
                await page.set_content('''<style>.answer-word{display:flex;width:150px;gap:3px}.answer-word input{width:42px;height:28px}</style>
                  <div class="quiz">Type the missing word</div>
                  <div class="caption">They saw a ____ in the forest.</div>
                  <div class="answer-word"><input class="answer" maxlength="2"><input class="answer" maxlength="2"><input class="answer" maxlength="2"></div>''')
                quiz = await inspect_quiz(page)
                assert quiz['ativa'] and len(quiz['campos']) == 1
                assert quiz['campos'][0]['group'] and quiz['campos'][0]['limit'] == 6
                for i, item in enumerate(await page.locator('.answer-word input').all()):
                    await item.evaluate('''(e,i)=>e.addEventListener('keydown',ev=>{
                      if(ev.key.length===1){ev.preventDefault();e.value=(e.value+ev.key).slice(0,e.maxLength)};
                    })''', i)
                await type_quiz_answer(page, quiz, 'racer', enter=False)
                assert [await item.input_value() for item in await page.locator('.answer-word input').all()] == ['ra','ce','r']
            finally:
                await browser.close()
    asyncio.run(run())


def test_campo_maxlength_curto_nao_envia_so_as_duas_primeiras_letras():
    async def run():
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(**chromium_launch_options())
            try:
                page = await browser.new_page(viewport={'width': 900, 'height': 700})
                await page.set_content('''<div class="quiz">Type the missing word</div>
                  <div class="caption">They saw a ____ in the forest.</div>
                  <input id="answer" class="answer" maxlength="2">''')
                quiz = await inspect_quiz(page)
                with pytest.raises(RuntimeError, match='evitei enviar só o começo'):
                    await type_quiz_answer(page, quiz, 'racer', enter=True)
                assert await page.locator('#answer').input_value() == ''
            finally:
                await browser.close()
    asyncio.run(run())


def test_ia_restringe_a_resposta_a_uma_opcao_visivel(monkeypatch):
    monkeypatch.setattr(auto_ia, 'settings', lambda: {'EC_IA_PROVEDOR': 'ollama'})
    monkeypatch.setattr(auto_ia, '_request_text', lambda prompt, cfg, **kwargs: json.dumps({'resposta': 'It is in the box.'}))
    assert auto_ia.suggest_quiz_choice('Where is the book?', ['It is in the car.', 'It is in the box.']) == 'It is in the box.'
    monkeypatch.setattr(auto_ia, '_request_text', lambda prompt, cfg, **kwargs: json.dumps({'resposta': 'A made-up choice'}))
    assert auto_ia.suggest_quiz_choice('Where is the book?', ['It is in the car.', 'It is in the box.']) == '?'


def test_quiz_confirmado_fica_salvo_por_curso(tmp_path):
    path = tmp_path / 'progress.json'
    progress = ProgressoVerificado(path)
    assert progress.confirmar_quiz('8597', 'unit-1:q2')
    assert not progress.confirmar_quiz('8597', 'unit-1:q2')
    assert ProgressoVerificado(path).quizzes('8597') == {'unit-1:q2'}
    assert ProgressoVerificado(path).quizzes('9999') == set()


def test_responde_quiz_e_so_marca_conclusao_com_sinal_da_plataforma():
    async def run():
        state = EngineState()
        page = SimpleNamespace(url='https://pt.englishcentral.com/course/8597', goto=AsyncMock())
        info = {'loginDetectado': False, 'textoVisivel': '', 'campos': [], 'videos': [], 'audioIgnorado': False}
        quiz = {'ativa': True, 'tipo': 'multipla_escolha', 'pergunta': 'Where is the book?',
                'opcoes': [{'id': '1', 'text': 'In the car.'}, {'id': '2', 'text': 'On the table.'}],
                'frame': 0, 'texto': 'Where is the book? In the car. On the table.'}
        with patch('auto_fluxo.inspect_ec_player', AsyncMock(return_value={'supported':False})), \
             patch('auto_fluxo._page_gate', AsyncMock(return_value={'login': False, 'captcha': False})), \
             patch('auto_fluxo.inspect_page', AsyncMock(return_value=info)), \
             patch('auto_fluxo.inspect_quiz', AsyncMock(return_value=quiz)), \
             patch('auto_fluxo.process_ec_page', AsyncMock(return_value={'tipo': 'aguardando'})), \
             patch('auto_fluxo.ia_status', return_value={'configurada': True}), \
             patch('auto_fluxo.suggest_quiz_choice', return_value='On the table.'), \
             patch('auto_fluxo.select_quiz_choice', AsyncMock(return_value={'x': 10, 'y': 20, 'acao': 'quiz_opcao'})), \
             patch('auto_fluxo._click_unique', AsyncMock(return_value=True)):
            result = await process_page(page, submit=True, engine=state,
                                        modo=ModoEstudo(False, False, False, True))
        assert result['tipo'] == 'quiz_resposta' and result['enviadas']
        assert state.choice_answer == 'On the table.'

        state.real.cursor.pending = 'quiz:1:q0'
        completed = {**quiz, 'tipo': 'resultado', 'opcoes': [], 'quiz_concluido': True}
        with patch('auto_fluxo.inspect_ec_player', AsyncMock(return_value={'supported':False})), \
             patch('auto_fluxo._page_gate', AsyncMock(return_value={'login': False, 'captcha': False})), \
             patch('auto_fluxo.inspect_page', AsyncMock(return_value=info)), \
             patch('auto_fluxo.inspect_quiz', AsyncMock(return_value=completed)):
            result = await process_page(page, submit=True, engine=state)
        assert result['tipo'] == 'navegacao' and result['quiz_concluido'] == '1:q0'
        page.goto.assert_awaited_once()
    asyncio.run(run())

def test_quiz_expirado_avanca_antes_do_player():
    async def run():
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(**chromium_launch_options())
            try:
                page = await browser.new_page()
                await page.set_content('''<div>The doctor suggested a pet scan for diagnosis.</div>
                    <div>Acabou o tempo!</div><div>Resposta certa: pet</div>
                    <button onclick="this.textContent='Avançou'">Continuar</button><div>1/8</div>''')
                quiz = await inspect_quiz(page)
                assert quiz['ativa'] and quiz['expirou']
                with patch('auto_fluxo.is_englishcentral', return_value=True), \
                     patch('auto_fluxo.process_ec_page', AsyncMock()) as player:
                    result = await process_page(page, submit=True, engine=EngineState())
                assert result['tipo'] == 'navegacao'
                assert await page.locator('button').inner_text() == 'Avançou'
                player.assert_not_called()
            finally:
                await browser.close()
    asyncio.run(run())


def test_prompt_correta_preserva_frase_e_input_de_teclado_oculto():
    async def run():
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(**chromium_launch_options())
            try:
                page = await browser.new_page()
                await page.set_content('''<div class="quiz">Noun:boca The mask should cover your ___ and nose.
                  <div>Digite a resposta correta</div>
                  <input class="answer" style="position:absolute;width:0;height:0;opacity:0"></div>''')
                quiz = await inspect_quiz(page)
                assert quiz['ativa']
                assert 'The mask' in quiz['frase']
                assert len(quiz['campos']) == 1
            finally:
                await browser.close()
    asyncio.run(run())

def test_lacuna_no_video_usa_leitor_especifico_antes_do_generico():
    async def run():
        page = SimpleNamespace(url='https://pt.englishcentral.com/course/8571')
        quiz = {'ativa':True,'tipo':'lacuna','video':True,'frase':'','campos':[]}
        with patch('auto_fluxo.inspect_ec_player', AsyncMock(return_value={'supported':False})), \
             patch('auto_fluxo._page_gate', AsyncMock(return_value={})), \
             patch('auto_fluxo.inspect_quiz', AsyncMock(return_value=quiz)), \
             patch('auto_fluxo.process_ec_page', AsyncMock(return_value={'tipo':'lacunas','preenchidas':1})) as reader, \
             patch('auto_fluxo._handle_video_quiz', AsyncMock()) as generic:
            result=await process_page(page,submit=True,engine=EngineState(),modo=ModoEstudo(False,True,False,False))
        assert result['preenchidas']==1
        reader.assert_awaited_once()
        generic.assert_not_awaited()
    asyncio.run(run())

def test_aula_concluida_navega_sem_responder_exercicio_antigo():
    async def run():
        page=SimpleNamespace(url='https://pt.englishcentral.com/course/1')
        completed={'supported':True,'lesson_id':'dialog:123','watch_complete':True,'learn_complete':True,'speak_complete':True}
        with patch('auto_fluxo._page_gate',AsyncMock(return_value={})), \
             patch('auto_fluxo.inspect_ec_player',AsyncMock(return_value=completed)), \
             patch('auto_fluxo.inspect_quiz',AsyncMock()) as quiz, \
             patch('auto_fluxo.process_ec_page',AsyncMock(return_value={'tipo':'navegacao','acao':'voltar_lista'})) as engine:
            result=await process_page(page,submit=True,engine=EngineState(),modo=ModoEstudo(True,True,True,True))
        assert result['acao']=='voltar_lista'
        quiz.assert_not_awaited()
        engine.assert_awaited_once()
    asyncio.run(run())
