import memoria
from revisao_quiz import learn_review,review_answer
from test_ec_player import run_with_page

def test_missed_words_are_learned_and_match_definition_and_letters(tmp_path,monkeypatch):
    monkeypatch.setattr(memoria,'MEMORY_PATH',tmp_path/'memory.json')
    async def scenario(page):
        await page.set_content('''<div><div>Countless</div><div>Adjective: inúmero (a)</div><div>PROGRESSO</div><div>Aulas perdidas</div></div>
        <div><div>Commercial</div><div>Adjective: comercial</div><div>Correto!</div></div>''')
        assert await learn_review(page)==1
        assert review_answer('Adjective:inúmero (a) There are ___ stars.',{'limit':9,'pattern':'c________'})=='countless'
        assert review_answer('Adjective:inúmero (a) There are ___ stars.',{'limit':5}) is None
        assert review_answer('Adjective:comercial',{'limit':10}) is None
    run_with_page(scenario)
