"""Player representativo: input char-input reage a keydown e keyup.enter."""
import asyncio
import pytest
from playwright.async_api import async_playwright
from conftest import chromium_launch_options

from ec_player import inspect_ec_player, type_ec_answer, click_ec_control


HTML = '''<!doctype html><title>Curso de teste</title><style>
ec-player-app,ec-player-transcript,ec-player-word-input,ec-activity-list{display:block}
input.char-input{width:24px;height:28px} .hidden{display:none}
</style><ec-activity-app><ec-player-app><div id="activity-app-container" class="learn-mode">
<ec-video><video id="ns-dialog-123_html5_api" src="https://cdna.englishcentral.com/dialogs/123/sample.mp4" width="320" height="180"></video></ec-video>
<ec-player-transcript><div class="player-transcript-row"><span>She likes to</span>
<ec-player-word-input><input class="char-input focused" maxlength="1" readonly="false"><input class="char-input" maxlength="1" readonly="false"><input class="char-input" maxlength="1" readonly="false"><input class="char-input" maxlength="1" readonly="false"></ec-player-word-input><span>through the forest.</span>
</div></ec-player-transcript><ec-learn-interstitial class="hidden"><div class="footer-button">Aprenda 4 palavras</div></ec-learn-interstitial>
</div></ec-player-app><ec-activity-list>
<button data-testid="player-activity-button" class="activity-list-watch completed">Assista ao vídeo</button>
<button data-testid="player-activity-button" class="activity-list-learn active">Aprenda as palavras</button>
<button data-testid="player-activity-button" class="activity-list-speak">Fale as linhas</button>
</ec-activity-list></ec-activity-app><div id="feedback"></div>
<script>
window.enterCount=0;window.continueCount=0;window.keyCount=0;window.inputClicks=0;
const inputs=[...document.querySelectorAll('input.char-input')];
document.querySelector('ec-player-word-input').addEventListener('click',()=>window.inputClicks++);
function check(){const answer=inputs.map(e=>e.value).join('');
 if(answer==='ride'){inputs.forEach(e=>{e.readOnly=true;e.classList.add('bg-strong')});
 document.getElementById('feedback').innerHTML='<div class="correct-answer-tooltip"><div class="continue-button">Continuar</div></div>';
 document.querySelector('.continue-button').onclick=()=>{window.continueCount++;};
 }else{document.getElementById('feedback').innerHTML='<ec-word-definition><div class="word" lang="en"><span class="me-1">ride</span><span>5</span></div><div class="cta-buttons"><div class="button">Tentar Novamente</div></div></ec-word-definition>';
 document.querySelector('.cta-buttons .button').onclick=()=>{document.getElementById('feedback').innerHTML='';inputs.forEach(e=>e.value='');};}}
inputs.forEach((el,i)=>{el.addEventListener('keydown',e=>{e.preventDefault();if(e.key.length===1 && /^[a-z]$/i.test(e.key)){el.value=e.key;window.keyCount++;if(i+1<inputs.length){inputs[i+1].focus();inputs.forEach(x=>x.classList.remove('focused'));inputs[i+1].classList.add('focused');}
 if(window.autoCheck && inputs.map(e=>e.value).join('')==='ride')check();}});
 el.addEventListener('keyup',e=>{if(e.key==='Enter'){window.enterCount++;if(document.querySelector('.correct-answer-tooltip'))window.continueCount++;else check();}});
});
</script>'''


def run_with_page(fn):
    async def run():
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(**chromium_launch_options())
            page=await browser.new_page(viewport={'width':1280,'height':800})
            try:
                # A URL identifica a aula; a mídia pública não é necessária ao teste.
                await page.route('https://cdna.englishcentral.com/**',lambda route: route.abort())
                await page.set_content(HTML)
                await fn(page)
            finally:
                await browser.close()
    asyncio.run(run())


def test_char_inputs_use_keyboard_and_confirm_once():
    async def scenario(page):
        snapshot=await inspect_ec_player(page)
        assert snapshot['supported'] and snapshot['question']
        assert snapshot['mode']=='learn' and snapshot['watch_complete']
        assert not snapshot['learn_complete']
        assert snapshot['lesson_id']=='dialog:123'
        assert snapshot['phrase']=='She likes to ____ through the forest.'
        assert snapshot['speak_prompt']=='She likes to ____ through the forest.'
        # A propriedade nativa é true, mas o teclado customizado deve funcionar.
        assert await page.locator('input.char-input').first.evaluate('e=>e.readOnly')
        assert not snapshot['letter_slots'][0]['readonly']
        pointer=await type_ec_answer(page,snapshot,'ride')
        assert pointer['enter_enviado']
        assert await page.evaluate('window.keyCount')==4
        assert await page.evaluate('window.inputClicks')==0
        assert await page.evaluate('window.enterCount')==1
        assert (await inspect_ec_player(page))['correct']
        await click_ec_control(page,'continue')
        assert await page.evaluate('window.continueCount')==1
    run_with_page(scenario)


def test_auto_check_does_not_send_enter_or_skip_a_word():
    async def scenario(page):
        await page.evaluate('window.autoCheck=true')
        snapshot=await inspect_ec_player(page)
        pointer=await type_ec_answer(page,snapshot,'ride')
        assert not pointer['enter_enviado']
        assert await page.evaluate('window.enterCount')==0
        assert await page.evaluate('window.continueCount')==0
        assert (await inspect_ec_player(page))['correct']
    run_with_page(scenario)


def test_error_reads_visible_word_and_retries():
    async def scenario(page):
        first=await inspect_ec_player(page)
        await type_ec_answer(page,first,'walk')
        correction=await inspect_ec_player(page)
        assert correction['incorrect'] and correction['retry_ready']
        assert correction['correction']=='ride'  # não inclui o indicador de nível 5
        with pytest.raises(RuntimeError,match='correção'):
            await type_ec_answer(page,correction,'ride')
        assert await click_ec_control(page,'retry')
        retry=await inspect_ec_player(page)
        assert retry['question_id']==first['question_id']
        await type_ec_answer(page,retry,'ride')
        assert (await inspect_ec_player(page))['correct']
        assert await page.evaluate('window.enterCount')==2
    run_with_page(scenario)


def test_stale_question_cannot_type_in_another_lesson():
    async def scenario(page):
        first=await inspect_ec_player(page)
        await page.locator('video').evaluate("e=>e.setAttribute('src','https://cdna.englishcentral.com/dialogs/456/other.mp4')")
        with pytest.raises(RuntimeError,match='mudou'):
            await type_ec_answer(page,first,'ride')
        assert await page.evaluate('window.keyCount')==0
    run_with_page(scenario)


def test_div_starts_learning_and_hidden_controls_are_ignored():
    async def scenario(page):
        await page.locator('ec-player-transcript').evaluate("e=>e.classList.add('hidden')")
        await page.locator('ec-learn-interstitial').evaluate("e=>{e.classList.remove('hidden');e.querySelector('.footer-button').onclick=()=>document.body.dataset.started='yes'}")
        snapshot=await inspect_ec_player(page)
        assert snapshot['word_selection'] and snapshot['start_words'] and not snapshot['question']
        assert await click_ec_control(page,'start_words')
        assert await page.locator('body').get_attribute('data-started')=='yes'
    run_with_page(scenario)


def test_readonly_hint_is_preserved_and_matching_answer_uses_three_keys():
    async def scenario(page):
        await page.locator('input.char-input').first.evaluate("e=>{e.value='r';e.readOnly=true;e.classList.add('bg-strong')}")
        snapshot=await inspect_ec_player(page)
        assert snapshot['answer_length']==4
        await type_ec_answer(page,snapshot,'ride')
        assert (await inspect_ec_player(page))['correct']
        assert await page.evaluate('window.keyCount')==3
    run_with_page(scenario)


def test_correct_answer_is_never_typed_or_confirmed_twice():
    async def scenario(page):
        snapshot=await inspect_ec_player(page)
        await type_ec_answer(page,snapshot,'ride')
        again=await type_ec_answer(page,await inspect_ec_player(page),'ride')
        assert again['acao']=='conferencia'
        assert await page.evaluate('window.keyCount')==4
        assert await page.evaluate('window.enterCount')==1
        assert await page.evaluate('window.continueCount')==0
    run_with_page(scenario)


def test_hidden_old_player_cannot_receive_the_answer():
    async def scenario(page):
        await page.locator('ec-activity-app').evaluate("e=>{const old=e.cloneNode(true);old.className='hidden';old.querySelector('video').src='https://cdna.englishcentral.com/dialogs/999/old.mp4';e.before(old)}")
        snapshot=await inspect_ec_player(page)
        assert snapshot['lesson_id']=='dialog:123'
        assert snapshot['player_index']==1
        await type_ec_answer(page,snapshot,'ride')
        assert await page.locator('ec-player-app').first.locator('input').first.input_value()==''
        assert (await inspect_ec_player(page))['correct']
    run_with_page(scenario)


def test_correct_tooltip_then_definition_continue_without_inputs():
    """O fluxo real mostra o dicionário depois de aceitar a palavra."""
    async def scenario(page):
        await type_ec_answer(page,await inspect_ec_player(page),'ride')
        await page.locator('.correct-answer-tooltip .continue-button').evaluate('''button=>{
            button.onclick=()=>{
                document.querySelector('ec-player-word-input').outerHTML='<span>ride</span>';
                document.getElementById('feedback').innerHTML='<ec-word-definition><div class="word" lang="en"><span class="me-1">ride</span><span>5</span></div><div class="cta-buttons"><div class="button">Continuar</div></div></ec-word-definition>';
                document.querySelector('.cta-buttons .button').onclick=()=>{
                    window.nextCount=(window.nextCount||0)+1;
                    document.getElementById('feedback').innerHTML='';
                };
            };
        }''')
        assert await click_ec_control(page,'continue')
        definition=await inspect_ec_player(page)
        assert definition['supported'] and definition['mode']=='learn'
        assert definition['definition_open'] and definition['continue_ready']
        assert not definition['question'] and not definition['incorrect']
        assert definition['correction']=='ride'
        assert await click_ec_control(page,'retry') is None
        assert await click_ec_control(page,'continue')
        assert await page.evaluate('window.nextCount')==1
    run_with_page(scenario)
