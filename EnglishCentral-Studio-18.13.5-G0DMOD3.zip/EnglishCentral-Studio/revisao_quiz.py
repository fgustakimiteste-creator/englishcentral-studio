import re
from memoria import read_memory, _save, clean, normalized, MAX_ITEMS

async def learn_review(page, *, include_all=False):
    entries=[]
    for frame in page.frames[:15]:
        try:
            found = await frame.evaluate(r'''includeAll => {
          const result=[];
          for(const e of document.querySelectorAll('tr,li,div')){
            const r=e.getBoundingClientRect();if(!r.width||!r.height)continue;
            const t=(e.innerText||'').trim();
            if(t.length>700||!(includeAll?/aulas perdidas|missed|incorrect|correto|correct|progresso|progress/i:/aulas perdidas|missed|incorrect/i).test(t))continue;
            const definitions=[...t.matchAll(/(?:^|\n)\s*((?:Noun|Verb|Adjective|Adverb|Phrase):[^\n]+)/gi)];
            if(definitions.length!==1)continue;
            const before=t.slice(0,definitions[0].index).trim().split('\n').filter(x=>x.trim());
            const word=before[before.length-1]?.trim();
            if(word&&/^[A-Za-z][A-Za-z' -]{0,79}$/.test(word))result.push({word,definition:definitions[0][1].trim()});
          }
          return result;
        }''',include_all)
            entries += found
        except Exception:
            continue
    data=read_memory(); saved=data.setdefault('definicoes',{})
    for entry in entries:
        saved[normalized(entry['definition'])]=clean(entry['word'],80)
    data['definicoes']=dict(list(saved.items())[-MAX_ITEMS:])
    if entries:_save(data)
    return len({normalized(e['definition']) for e in entries})

def review_answer(phrase, field):
    canon=lambda text:re.sub(r'\s*:\s*',':',normalized(text))
    text=canon(phrase);matches=[]
    for definition,word in read_memory().get('definicoes',{}).items():
        if not re.search(re.escape(canon(definition))+r'(?=$|\s|[.;|])',text):continue
        letters=re.sub('[^a-z]','',word.casefold());pattern=field.get('pattern','').casefold()
        if field.get('limit') and len(letters)!=field['limit']:continue
        if pattern and (len(pattern)!=len(letters) or any(p!='_' and p!=a for p,a in zip(pattern,letters))):continue
        matches.append(word.casefold())
    matches=list(dict.fromkeys(matches))
    return matches[0] if len(matches)==1 else None
