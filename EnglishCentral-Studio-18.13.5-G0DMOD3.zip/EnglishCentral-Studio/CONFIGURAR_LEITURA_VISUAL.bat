@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Leitura visual local de frases - EnglishCentral
set "OLLAMA=ollama"
where ollama >nul 2>nul
if errorlevel 1 (
  if exist "%LOCALAPPDATA%\Programs\Ollama\ollama.exe" (
    set "OLLAMA=%LOCALAPPDATA%\Programs\Ollama\ollama.exe"
  ) else (
    echo Instale primeiro o Ollama: https://ollama.com/download/windows
    pause
    exit /b 1
  )
)
echo Este recurso e OPCIONAL. Um modelo visual exige mais memoria e downloads grandes.
echo A captura da aula sera analisada somente pelo Ollama neste computador.
choice /M "Deseja instalar o modelo visual qwen2.5vl:3b"
if errorlevel 2 exit /b 0
"%OLLAMA%" pull qwen2.5vl:3b
if errorlevel 1 (
 echo Falha no download. Confira o Ollama e o espaco em disco.
 pause
 exit /b 1
)
if exist "config_ia.local.txt" (
 copy /Y "config_ia.local.txt" "config_ia.local.txt.antes-leitura-visual.bak" >nul
 if errorlevel 1 (
  echo Nao foi possivel guardar a configuracao anterior. Nenhuma alteracao foi feita.
  pause
  exit /b 1
 )
)
if not exist config_ia.local.txt (
 echo EC_IA_PROVEDOR=ollama> config_ia.local.txt
 echo EC_IA_MODELO=llama3.2>> config_ia.local.txt
)
powershell -NoProfile -Command "$p='config_ia.local.txt';$t=[IO.File]::ReadAllText($p);$t=[regex]::Replace($t,'(?m)^EC_IA_VISAO_MODELO=.*(\r?\n)?','');[IO.File]::WriteAllText($p,$t.TrimEnd()+[Environment]::NewLine+'EC_IA_VISAO_MODELO=qwen2.5vl:3b'+[Environment]::NewLine)"
if errorlevel 1 (
 echo Falha ao gravar a configuracao. Confira as permissoes da pasta.
 pause
 exit /b 1
)
echo Modelo visual configurado. Reinicie com INICIAR.bat para testar.
pause
