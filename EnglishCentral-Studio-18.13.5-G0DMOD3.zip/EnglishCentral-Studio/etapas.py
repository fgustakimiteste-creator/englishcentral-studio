"""Reconhecimento de etapa usando indícios visíveis na página (não certifica conclusão)."""
from __future__ import annotations

import re

WORDS_SELECTED = re.compile(r'palavras\s+selecionadas\s*:\s*(\d+)', re.I)
WORDS_START = re.compile(r'\baprenda\s+(\d+)\s+palavras?\b', re.I)
WORDS_PANEL = re.compile(r'aprenda estas palavras|todas as palavras\s*:', re.I)
VIDEO_STAGE = re.compile(r'assista ao v[ií]deo|watch the video', re.I)
SPEECH_STAGE = re.compile(r'fale as linhas|speak the lines', re.I)


def classify_stage(info: dict) -> dict:
    """Classifica a etapa em primeiro lugar pela UI ativa, não por um player presente no DOM.

    Os estados são pistas do conteúdo mostrado, NÃO progresso oficial da plataforma.
    """
    text = info.get('textoVisivel') or ''
    fields = info.get('campos') or []
    videos = info.get('videos') or []
    quiz = info.get('quiz') or {}
    if quiz.get('ativa') and quiz.get('tipo') == 'multipla_escolha':
        return {'codigo':'quiz_escolha','rotulo':'Quiz de alternativas',
                'detalhe':'Lendo pergunta e alternativas visíveis.', 'confianca':'alta','proximo':'responder'}
    if quiz.get('quiz_concluido'):
        return {'codigo':'quiz_resultado','rotulo':'Resultado do quiz',
                'detalhe':'Conferindo a conclusão exibida pelo site.', 'confianca':'alta','proximo':'avancar'}
    if quiz.get('ativa'):
        return {'codigo':'lacuna_video', 'rotulo':'Palavra que falta no vídeo',
                'detalhe': 'Exercício ativo sobre o vídeo. O player não será reiniciado.',
                'confianca':'alta', 'proximo':'responder'}
    word_select = WORDS_SELECTED.search(text)
    word_button = WORDS_START.search(text)
    word_panel = bool(WORDS_PANEL.search(text))

    # Em alguns exercícios, o painel de seleção continua atrás de uma atividade
    # sobreposta. Lacunas VISÍVEIS têm prioridade sobre a seleção no fundo.
    if fields and any(f.get('dica') for f in fields):
        return {'codigo': 'lacunas', 'rotulo': 'Exercício de lacunas',
                'detalhe': '{} campo(s) detectado(s).'.format(len(fields)),
                'confianca': 'alta', 'proximo': 'responder'}
    if word_select or (word_panel and word_button):
        selected = int(word_select.group(1)) if word_select else None
        return {'codigo': 'palavras_selecao', 'rotulo': 'Aprenda as palavras',
                'detalhe': ('{} palavras selecionadas. Pronto para começar o exercício.'.format(selected)
                            if selected is not None else 'Tela de seleção de palavras aberta.'),
                'confianca': 'alta', 'selecionadas': selected,
                'proximo': 'iniciar_palavras' if word_button else 'observar'}
    if word_panel:
        return {'codigo': 'palavras', 'rotulo': 'Aprenda as palavras',
                'detalhe': 'Tela de vocabulário aberta. Aguardando exercício reconhecível.',
                'confianca': 'media', 'proximo': 'observar'}
    if videos:
        ended = all(v.get('concluidoNoPlayer') for v in videos)
        return {'codigo': 'video', 'rotulo': 'Assista ao vídeo',
                'detalhe': ('O player informou que o vídeo terminou.' if ended else
                            'Player de vídeo presente na página.'),
                'confianca': 'media', 'proximo': 'avancar' if ended else 'acompanhar'}
    # A etapa aparece no menu lateral, mas não dá para afirmar que ela é a ativa.
    if SPEECH_STAGE.search(text) and not VIDEO_STAGE.search(text) and not word_panel:
        return {'codigo': 'fala', 'rotulo': 'Fale as linhas',
                'detalhe': 'Atividade de fala detectada; aguardando uma área de gravação reconhecível.',
                'confianca': 'baixa', 'proximo': 'ignorar'}
    return {'codigo': 'indefinida', 'rotulo': 'Identificando atividade',
            'detalhe': 'Não foi possível reconhecer a etapa atual com segurança.',
            'confianca': 'baixa', 'proximo': 'observar'}
