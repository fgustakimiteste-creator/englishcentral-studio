import pytest
"""Fim da mídia não é confirmação e o worker reconcilia pendências atuais."""
import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

from auto_fluxo import EngineState, process_page
from modos import ModoEstudo
from progresso import ProgressoVerificado
import servidor


def _generic_info(*, completed=False):
    return {'url':'https://pt.englishcentral.com/video/101','titulo':'Aula',
            'textoVisivel':'Assista ao vídeo','loginDetectado':False,'campos':[],
            'audioIgnorado':False,'paginaVisivel':True,'videoEtapaConcluida':completed,
            'videos':[{'id':'1','frame':0,'origem':'https://media.test/dialogs/101/video.mp4',
                       'duracao':30,'posicao':30,'concluidoNoPlayer':True,'reproduzindo':False,
                       'pronto':4,'rede':1,'erro':None}]}


def test_fallback_midia_terminada_sem_confirmacao_nunca_avanca():
    async def run():
        page = MagicMock(url='https://pt.englishcentral.com/video/101')
        state = EngineState()
        with patch('auto_fluxo._page_gate', AsyncMock(return_value={})), \
             patch('auto_fluxo.inspect_ec_player', AsyncMock(return_value={'supported':False})), \
             patch('auto_fluxo.inspect_quiz', AsyncMock(return_value={'ativa':False,'texto':''})), \
             patch('auto_fluxo.process_ec_page', AsyncMock(return_value=None)), \
             patch('auto_fluxo.inspect_page', AsyncMock(return_value=_generic_info())), \
             patch('auto_fluxo.choose_navigation', AsyncMock()) as navigate, \
             patch('auto_fluxo.toggle_video', AsyncMock(return_value={'reproduzindo':True})) as play:
            results = []
            # Fim -> uma recuperação permitida -> novo fim -> limite esgotado.
            for now in (10, 23, 25, 80):
                with patch('auto_fluxo.time.monotonic', return_value=now):
                    results.append(await process_page(page, engine=state, submit=True,
                                                      modo=ModoEstudo(True,False,False,False)))
        assert [result['tipo'] for result in results] == ['aguardando','video','aguardando','ajuda']
        assert not any(result.get('progresso_etapas', {}).get('assistir') for result in results)
        navigate.assert_not_awaited()
        play.assert_awaited_once_with(page, 0, '1', 'play')
    asyncio.run(run())


def test_fallback_confirmacao_explicita_do_site_avanca_sem_reproduzir():
    async def run():
        page = MagicMock(url='https://pt.englishcentral.com/video/101')
        with patch('auto_fluxo._page_gate', AsyncMock(return_value={})), \
             patch('auto_fluxo.inspect_ec_player', AsyncMock(return_value={'supported':False})), \
             patch('auto_fluxo.inspect_quiz', AsyncMock(return_value={'ativa':False,'texto':''})), \
             patch('auto_fluxo.process_ec_page', AsyncMock(return_value=None)), \
             patch('auto_fluxo.inspect_page', AsyncMock(return_value=_generic_info(completed=True))), \
             patch('auto_fluxo.choose_navigation', AsyncMock(return_value={'tipo':'navegacao','acao':'proximo'})) as navigate, \
             patch('auto_fluxo.toggle_video', AsyncMock()) as play:
            result = await process_page(page, submit=True, modo=ModoEstudo(True,False,False,False))
        assert result['tipo'] == 'navegacao' and result['acao'] == 'proximo'
        navigate.assert_awaited_once_with(page, next_only=True)
        play.assert_not_awaited()
    asyncio.run(run())


def test_worker_pendencia_atual_remove_assistir_salvo_antes_de_reutilizar_cache(monkeypatch, tmp_path):
    async def run():
        progress_path = tmp_path / 'progress.json'
        progress = ProgressoVerificado(progress_path)
        progress.confirmar('8597', 'dialog:101', {'assistir':True,'aprender':True,'falar':True})
        progress.confirmar_unidades('8597', ('assistir',), {'unit-1'})
        page = type('Page', (), {'url':'https://pt.englishcentral.com/course/8597',
                                 'is_closed':lambda self:False})()
        calls = []
        async def process(_page, *, engine, **kwargs):
            calls.append(engine)
            if len(calls) == 1:
                assert '101' in engine.real.cursor.seen
                # Mesmo uma conferência anterior na sessão deve ceder à leitura atual.
                engine.real.cursor.mark_done('101')
                engine.real.cursor.verified_units.add('unit-1')
                return {'tipo':'video','mensagem':'Assistir ainda pendente.', 'aula_id':'dialog:101',
                        'progresso_etapas':{'assistir':False,'aprender':True,'falar':True}}
            assert '101' not in engine.real.cursor.seen
            assert '101' not in engine.real.cursor.session_verified_lessons
            assert not engine.real.cursor.verified_units
            reread = ProgressoVerificado(progress_path)
            assert not reread.concluidas('8597', ('assistir',))
            assert not reread.unidades('8597', ('assistir',))
            assert reread.concluidas('8597', ('aprender','falar')) == {'101'}
            return {'tipo':'escopo_concluido','mensagem':'Fim do teste.'}
        monkeypatch.setattr(servidor, 'page', page)
        monkeypatch.setattr(servidor, 'auto_mode', ModoEstudo(True,False,False,False))
        monkeypatch.setattr(servidor, 'auto_running', True)
        monkeypatch.setattr(servidor, 'auto_latest', {})
        monkeypatch.setattr(servidor, 'auto_counts', {'ciclos':0,'lacunas':0})
        monkeypatch.setattr(servidor, 'lock', asyncio.Lock())
        monkeypatch.setattr(servidor, 'PROGRESS_FILE', progress_path)
        monkeypatch.setattr(servidor, 'DATA', tmp_path)
        monkeypatch.setattr(servidor, 'COURSE_FILE', tmp_path / 'course.txt')
        monkeypatch.setattr(servidor, 'record', lambda _message: None)
        monkeypatch.setattr(servidor, 'process_page', process)
        with patch.object(servidor.asyncio, 'sleep', AsyncMock()):
            await servidor.auto_worker()
        assert len(calls) == 2
        assert servidor.auto_latest['tipo'] == 'escopo_concluido'
        assert not servidor.auto_running
        reread = ProgressoVerificado(progress_path)
        assert not reread.concluidas('8597', ('assistir',))
        assert not reread.unidades('8597', ('assistir',))
        assert reread.concluidas('8597', ('aprender','falar')) == {'101'}
    asyncio.run(run())


@pytest.fixture(autouse=True)
def _explicit_decisions_for_legacy_scenarios(monkeypatch):
    monkeypatch.setattr(servidor, 'network_available', AsyncMock(return_value=True))
    monkeypatch.setattr(servidor, 'request_stop_confirmation', AsyncMock(return_value=False))
