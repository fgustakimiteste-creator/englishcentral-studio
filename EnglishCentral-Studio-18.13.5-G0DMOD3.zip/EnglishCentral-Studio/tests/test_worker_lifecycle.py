import pytest
"""Parar aguarda o worker antigo antes de permitir a próxima execução."""
import asyncio
import time
from unittest.mock import AsyncMock

import servidor


def test_parar_aguarda_cancelamento_antes_de_reiniciar(monkeypatch):
    async def run():
        started = asyncio.Event()
        finalized = asyncio.Event()
        async def worker():
            started.set()
            try:
                await asyncio.Event().wait()
            finally:
                await asyncio.sleep(.01)
                servidor.auto_running = False
                finalized.set()
        monkeypatch.setattr(servidor, 'auto_worker', worker)
        monkeypatch.setattr(servidor, 'auto_task', None)
        monkeypatch.setattr(servidor, 'auto_running', False)
        try:
            await servidor.auto_start(servidor.AutoStart(enviar_automaticamente=True))
            await started.wait()
            old = servidor.auto_task
            await servidor.auto_stop()
            assert old.done() and finalized.is_set()
            started.clear()
            await servidor.auto_start(servidor.AutoStart(enviar_automaticamente=True))
            await started.wait()
            await asyncio.sleep(.03)
            assert servidor.auto_running is True
        finally:
            await servidor.auto_stop()
    asyncio.run(run())


def test_worker_para_quando_as_etapas_do_escopo_terminam(monkeypatch):
    async def run():
        page = type('Page', (), {'url': 'https://pt.englishcentral.com/course/8597',
                                 'is_closed': lambda self: False})()
        process = AsyncMock(return_value={'tipo': 'escopo_concluido', 'mensagem': 'Etapas verificadas.'})
        monkeypatch.setattr(servidor, 'page', page)
        monkeypatch.setattr(servidor, 'process_page', process)
        monkeypatch.setattr(servidor, 'auto_running', True)
        await servidor.auto_worker()
        assert servidor.auto_running is False
        assert servidor.auto_latest['tipo'] == 'escopo_concluido'
        process.assert_awaited_once()
    asyncio.run(run())


def test_worker_recupera_timeouts_transitorios(monkeypatch):
    async def run():
        page = type('Page', (), {'url': 'https://pt.englishcentral.com/course/8597',
                                 'is_closed': lambda self: False})()
        process = AsyncMock(side_effect=[
            servidor.BrowserTimeoutError('timeout temporário'),
            servidor.BrowserTimeoutError('timeout temporário'),
            servidor.BrowserTimeoutError('timeout temporário'),
            {'tipo': 'escopo_concluido', 'mensagem': 'Etapas verificadas.'},
        ])
        monkeypatch.setattr(servidor, 'page', page)
        monkeypatch.setattr(servidor, 'process_page', process)
        monkeypatch.setattr(servidor, 'request_stop_confirmation', AsyncMock(side_effect=[True,True,True,False]))
        monkeypatch.setattr(servidor, 'auto_running', True)

        await servidor.auto_worker()

        assert process.await_count == 4
        assert servidor.auto_running is False
        assert servidor.auto_latest['tipo'] == 'escopo_concluido'
    asyncio.run(run())


def test_worker_pausa_em_erro_inesperado_para_evitar_repetir_acao(monkeypatch):
    async def run():
        page = type('Page', (), {'url': 'https://pt.englishcentral.com/course/8597',
                                 'is_closed': lambda self: False})()
        process = AsyncMock(side_effect=RuntimeError('falha inesperada'))
        monkeypatch.setattr(servidor, 'page', page)
        monkeypatch.setattr(servidor, 'process_page', process)
        monkeypatch.setattr(servidor, 'auto_running', True)

        await servidor.auto_worker()

        assert process.await_count == 1
        assert servidor.auto_running is False
        assert servidor.request_stop_confirmation.await_args.args[0]['tipo']=='erro'
        assert servidor.request_stop_confirmation.await_count==1
    asyncio.run(run())


def test_previa_pode_ler_enquanto_a_ia_esta_processando(monkeypatch):
    async def run():
        started = asyncio.Event()
        page = type('Page', (), {'url': 'https://pt.englishcentral.com/course/8597',
                                 'is_closed': lambda self: False})()
        async def process(page, *, engine, **kwargs):
            started.set()
            await engine.inference(time.sleep, .08)
            return {'tipo': 'escopo_concluido', 'mensagem': 'Etapas verificadas.'}
        monkeypatch.setattr(servidor, 'page', page)
        monkeypatch.setattr(servidor, 'process_page', process)
        monkeypatch.setattr(servidor, 'auto_running', True)
        worker = asyncio.create_task(servidor.auto_worker())
        try:
            await started.wait()
            acquired = await asyncio.wait_for(servidor.lock.acquire(), timeout=.04)
            assert acquired
            servidor.lock.release()
            await worker
        finally:
            if not worker.done():
                worker.cancel()
                try:
                    await worker
                except asyncio.CancelledError:
                    pass
    asyncio.run(run())


def test_status_responde_mesmo_com_navegador_ocupado(monkeypatch):
    async def run():
        page=type('Page',(),{'url':'https://pt.englishcentral.com/course/8571',
                           'is_closed':lambda self:False})()
        page.title=AsyncMock(side_effect=AssertionError('Não ler DOM sob lock'))
        monkeypatch.setattr(servidor,'page',page)
        monkeypatch.setattr(servidor,'lock',asyncio.Lock())
        async with servidor.lock:
            result=await asyncio.wait_for(servidor.status(),timeout=.2)
        assert result['aberto'] and result['url'].endswith('/8571')
        page.title.assert_not_awaited()
    asyncio.run(run())


@pytest.fixture(autouse=True)
def _explicit_decisions_for_legacy_scenarios(monkeypatch):
    monkeypatch.setattr(servidor, 'network_available', AsyncMock(return_value=True))
    monkeypatch.setattr(servidor, 'request_stop_confirmation', AsyncMock(return_value=False))
