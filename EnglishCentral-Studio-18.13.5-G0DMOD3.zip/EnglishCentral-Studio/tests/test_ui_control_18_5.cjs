const fs=require('fs'),path=require('path'),assert=require('node:assert/strict');
const {JSDOM,VirtualConsole}=require(process.env.EC_JSDOM||'jsdom');
const html=fs.readFileSync(path.join(__dirname,'../web/index.html'),'utf8');
const wait=()=>new Promise(r=>setTimeout(r,30));
async function fixture({deferStatus=false,auto={}}={}){
 const callbacks=[],calls=[],errors=[];let resolveStatus,reads=0;
 const data={aberto:false,executando:false,auto,modo:{assistir:true,aprender:false,quiz:false,falar:false,activities:false},eventos:[]};
 const vc=new VirtualConsole();vc.on('jsdomError',e=>errors.push(e.message));
 const dom=new JSDOM(html,{url:'http://localhost/#token=fixture-only',runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:vc,beforeParse(w){
  w.scrollTo=()=>{};w.setInterval=(fn,delay)=>{callbacks.push({fn,delay});return callbacks.length};
  w.fetch=async(url,options={})=>{
   calls.push(url);
   if(url==='/api/status'){
    reads++;const snapshot=JSON.parse(JSON.stringify(data));
    if(deferStatus&&reads===2)return new Promise(resolve=>{resolveStatus=()=>resolve({ok:true,json:async()=>snapshot})});
    return {ok:true,json:async()=>snapshot};
   }
   if(url==='/api/auto/start'){data.executando=true;return {ok:true,json:async()=>({executando:true})}}
   if(url==='/api/auto/stop'){data.executando=false;return {ok:true,json:async()=>({ok:true})}}
   return {ok:true,json:async()=>({})};
  };
 }});await wait();return {dom,d:dom.window.document,data,calls,errors,poll:()=>callbacks.find(c=>c.delay===1500).fn(),release:()=>resolveStatus()};
}
(async()=>{
 let t=await fixture({deferStatus:true});t.poll();await wait();t.d.getElementById('toggle').click();await wait();t.release();await wait();
 assert.equal(t.d.getElementById('toggleLabel').textContent,'Pausar assistente');assert.equal(t.d.getElementById('toggle').disabled,false);assert.deepEqual(t.errors,[]);t.dom.window.close();console.log('PASS status antigo não desfaz o início');
 t=await fixture();t.d.getElementById('toggle').click();t.d.getElementById('toggle').click();await wait();
 assert.equal(t.calls.filter(u=>u==='/api/auto/start').length,1);assert.equal(t.d.querySelector('#toggle use').getAttribute('href'),'#ic-pause');t.d.getElementById('toggle').click();await wait();assert.equal(t.d.getElementById('toggleLabel').textContent,'Iniciar assistente');assert.equal(t.d.querySelector('#toggle use').getAttribute('href'),'#ic-play');t.dom.window.close();console.log('PASS início único e pausa com ícones coerentes');
 t=await fixture({auto:{tipo:'video_atencao',mensagem:'Aguardando ajuste',verificacao_video:{visual_state:'white'}}});t.data.executando=true;t.poll();await wait();
 assert.equal(t.d.getElementById('assistantState').textContent,'Aguardando ajuste');assert.equal(t.d.getElementById('toggleLabel').textContent,'Pausar assistente');assert(t.d.getElementById('trackingLabel').textContent.includes('branca'));t.dom.window.close();console.log('PASS atenção no vídeo continua permitindo pausar');
 t=await fixture();for(const color of ['yellow','green']){t.data.auto={verificacao_video:{visual_state:color}};t.poll();await wait();assert.equal(t.d.getElementById('videoTracking').classList.contains('hide'),false);assert(!t.d.getElementById('trackingLabel').textContent.includes('confirmada'))}t.dom.window.close();console.log('PASS cor exibe registro sem declarar conclusão');
 console.log('4 cenários do controle aprovados (DOM e API simulados).');
})().catch(e=>{console.error(e);process.exitCode=1});
