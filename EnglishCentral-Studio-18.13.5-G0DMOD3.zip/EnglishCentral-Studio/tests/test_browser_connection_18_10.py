"""Conexão ao navegador existente: sem leitura/cópia de cookies ou senhas."""
import asyncio
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import pytest
from fastapi import HTTPException
import servidor
from arquivos_locais import file_lock


@pytest.fixture
def connection_env(monkeypatch,tmp_path):
    p=MagicMock();p.url='https://pt.englishcentral.com/course/8597';p.is_closed.return_value=False
    p.bring_to_front=AsyncMock();p.goto=AsyncMock();p.opener=AsyncMock(return_value=None)
    c=MagicMock();c.pages=[p];c.close=AsyncMock();c.new_page=AsyncMock();p.context=c
    b=MagicMock();b.contexts=[c]
    chromium=SimpleNamespace(connect_over_cdp=AsyncMock(return_value=b),launch_persistent_context=AsyncMock())
    driver=SimpleNamespace(chromium=chromium,stop=AsyncMock())
    monkeypatch.setattr('playwright.async_api.async_playwright',lambda:SimpleNamespace(start=AsyncMock(return_value=driver)))
    for key,value in {'DATA':tmp_path,'PROFILES_ROOT':tmp_path,'COURSE_FILE':tmp_path/'course.txt',
        'context':None,'page':None,'browser_driver':None,'connected_browser':None,'browser_owned':True,
        'browser_lease':None,'browser_tabs':{},'browser_parents':{},'browser_events':set(),
        'auto_task':None,'auto_running':False,'lock':asyncio.Lock(),'auto_control_lock':asyncio.Lock()}.items():
        monkeypatch.setattr(servidor,key,value)
    return p,c,chromium,driver


def test_conexao_reutiliza_aba_sem_novo_perfil_ou_leitura_de_cookies(connection_env):
    async def run():
        p,c,chromium,driver=connection_env
        try:
            assert (await servidor.connect_browser(servidor.BrowserConnect()))['ok']
            assert servidor.page is p and servidor.context is c and not servidor.browser_owned
            chromium.connect_over_cdp.assert_awaited_once_with('chrome',timeout=25000,no_defaults=True)
            chromium.launch_persistent_context.assert_not_awaited();c.new_page.assert_not_awaited();p.goto.assert_not_awaited()
            c.cookies.assert_not_called();c.storage_state.assert_not_called();c.add_init_script.assert_not_called()
            assert servidor.browser_preferences()['modo']=='existente'
            assert len((await servidor.session_tabs())['abas'])==1
        finally:await servidor.dispose_browser_session()
        c.close.assert_not_awaited();driver.stop.assert_awaited_once()
    asyncio.run(run())


def test_conexao_recusada_nao_abre_chrome_vazio(connection_env):
    async def run():
        _,c,chromium,driver=connection_env
        chromium.connect_over_cdp.side_effect=RuntimeError('Permissão não concedida')
        with pytest.raises(HTTPException) as error:await servidor.connect_browser(servidor.BrowserConnect())
        assert error.value.status_code==409 and servidor.context is None
        assert servidor.browser_preferences()['modo']=='existente'
        chromium.launch_persistent_context.assert_not_awaited();c.close.assert_not_awaited()
        driver.stop.assert_awaited_once();assert servidor.browser_lease is None
    asyncio.run(run())


def test_cancelar_conexao_libera_driver_travas_e_lease(connection_env):
    async def run():
        _,c,chromium,driver=connection_env;entered=asyncio.Event()
        async def block(*_,**__):entered.set();await asyncio.Event().wait()
        chromium.connect_over_cdp.side_effect=block
        task=asyncio.create_task(servidor.connect_browser(servidor.BrowserConnect()))
        await entered.wait();task.cancel()
        with pytest.raises(asyncio.CancelledError):await task
        assert servidor.browser_lease is None and servidor.browser_driver is None
        assert not servidor.lock.locked() and not servidor.auto_control_lock.locked()
        driver.stop.assert_awaited_once();c.close.assert_not_awaited()
    asyncio.run(run())


def test_outro_painel_nao_controla_mesmo_navegador_pessoal(connection_env):
    async def run():
        _,_,chromium,_=connection_env
        with file_lock(servidor.PROFILES_ROOT/'navegador_pessoal.lock',timeout=0):
            with pytest.raises(HTTPException) as error:await servidor.connect_browser(servidor.BrowserConnect())
        assert error.value.status_code==409
        chromium.connect_over_cdp.assert_not_awaited()
    asyncio.run(run())


@pytest.mark.parametrize('port',[0,80,65536,-1])
def test_conexao_nao_aceita_porta_invalida(port):
    with pytest.raises(ValueError):servidor.BrowserConnect(porta=port)


def test_selecionar_aba_antiga_nao_navega_ou_cria_outra(connection_env):
    async def run():
        p,_,_,_=connection_env
        try:
            await servidor.connect_browser(servidor.BrowserConnect())
            item=(await servidor.session_tabs())['abas'][0]
            assert (await servidor.select_browser_tab(servidor.BrowserTab(id=item['id'])))['ok']
            assert servidor.page is p and not servidor.auto_running
            p.goto.assert_not_awaited()
        finally:await servidor.dispose_browser_session()
    asyncio.run(run())


def test_perda_do_chrome_existente_nao_cai_em_perfil_novo(connection_env,monkeypatch):
    async def run():
        _,c,chromium,driver=connection_env
        c.pages=[];c.new_page.side_effect=RuntimeError('Chrome desconectado')
        monkeypatch.setattr(servidor,'context',c);monkeypatch.setattr(servidor,'page',None)
        monkeypatch.setattr(servidor,'browser_owned',False);monkeypatch.setattr(servidor,'browser_driver',driver)
        with pytest.raises(HTTPException) as error:await servidor.open_browser()
        assert error.value.status_code==409 and 'nenhum perfil novo' in error.value.detail
        chromium.launch_persistent_context.assert_not_awaited()
        c.close.assert_not_awaited();driver.stop.assert_awaited_once()
    asyncio.run(run())


def test_aba_fechada_nao_muda_para_outro_contexto_sem_escolha(connection_env,monkeypatch):
    async def run():
        p,c,_,_=connection_env;p.is_closed.return_value=True
        other=MagicMock();other.url=p.url;other.is_closed.return_value=False;other.bring_to_front=AsyncMock()
        other_context=SimpleNamespace(pages=[other]);other.context=other_context
        for key,value in {'page':p,'context':c,'browser_owned':False,
            'connected_browser':SimpleNamespace(contexts=[c,other_context]),
            'browser_tabs':{'3333333333333333':other}}.items():monkeypatch.setattr(servidor,key,value)
        with pytest.raises(HTTPException):servidor.current_page()
        servidor.observe_tab(other)
        assert servidor.page is p
        await servidor.select_browser_tab(servidor.BrowserTab(id='3333333333333333'))
        assert servidor.page is other and servidor.context is other_context
    asyncio.run(run())


def test_configured_browser_executable_prefers_ec_browser_executable(monkeypatch, tmp_path):
    preferred = tmp_path / 'chromium-new'
    legacy = tmp_path / 'chromium-old'
    preferred.write_text('#!/bin/sh\n', encoding='utf-8')
    preferred.chmod(0o755)
    legacy.write_text('#!/bin/sh\n', encoding='utf-8')
    legacy.chmod(0o755)
    monkeypatch.setenv('EC_BROWSER_EXECUTABLE', str(preferred))
    monkeypatch.setenv('EC_CHROMIUM_PATH', str(legacy))
    assert servidor.configured_browser_executable() == str(preferred)


def test_configured_browser_executable_accepts_legacy_fallback(monkeypatch, tmp_path):
    legacy = tmp_path / 'chromium-old'
    legacy.write_text('#!/bin/sh\n', encoding='utf-8')
    legacy.chmod(0o755)
    monkeypatch.delenv('EC_BROWSER_EXECUTABLE', raising=False)
    monkeypatch.setenv('EC_CHROMIUM_PATH', str(legacy))
    assert servidor.configured_browser_executable() == str(legacy)


def test_configured_browser_executable_rejects_missing_path(monkeypatch, tmp_path):
    monkeypatch.setenv('EC_BROWSER_EXECUTABLE', str(tmp_path / 'missing-chromium'))
    monkeypatch.delenv('EC_CHROMIUM_PATH', raising=False)
    with pytest.raises(FileNotFoundError, match='não existe ou não é executável'):
        servidor.configured_browser_executable()
