from unittest.mock import AsyncMock, patch

import pytest
from auto_fluxo import EngineState
from ec_player import inspect_ec_player
from fala_preferencias import SpeechPolicy
import test_speech_automatic_flow as fixture


@pytest.fixture
def scored_page(monkeypatch):
    html = fixture.SPEECH_PAGE.replace('window.keepSelection=false;',
        'window.keepSelection=false;window.speechScores=[70,90];window.lastSpeechScore=0;')
    html = html.replace("find('player-recording-result').textContent='Pronúncia registrada';",
        "window.lastSpeechScore=window.speechScores.shift()??90;find('player-recording-result').textContent=window.lastSpeechScore+'%';")
    html = html.replace("find('player-recording-result').setAttribute('data-status','accepted');",
        "find('player-recording-result').setAttribute('data-status',window.lastSpeechScore>=80?'accepted':'retry');")
    html = html.replace("line().classList.add('completed');speechEvents.push('accepted:'",
        "line().classList.toggle('completed',window.lastSpeechScore>=80);speechEvents.push('scored:'")
    monkeypatch.setattr(fixture, 'SPEECH_PAGE', html)


@pytest.mark.parametrize('policy,expected_records,scores', [
    (SpeechPolicy(80, 2, 'next'), 2, [70, 90]),
    (SpeechPolicy(80, 2, 'retry'), 3, [70, 70, 90]),
    (SpeechPolicy(60, 2, 'retry'), 2, [70, 90]),
])
def test_fluxo_com_nota_baixa_avanca_e_repeticao_tem_limite(scored_page, policy, expected_records, scores):
    async def scenario(page):
        await page.evaluate('scores=>window.speechScores=scores', scores)
        await page.evaluate('''() => {
          const button=document.createElement('button');button.dataset.testid='player-retry-recording';
          button.textContent='Tentar novamente';button.onclick=()=>{
            document.querySelector('[data-testid="player-recording-result"]').hidden=true;
            document.querySelector('[data-testid="player-next-line"]').hidden=true;
            document.querySelector('[data-testid="player-record"]').hidden=false;
            document.querySelector('.player-transcript-row').classList.remove('completed');
          };
          document.querySelector('ec-speak-mode').append(button);
        }''')
        state = EngineState(speech_policy=policy); events=[]
        with patch('ec_engine.advance_course', AsyncMock(return_value={'tipo': 'fora_curso'})):
            for _ in range(50):
                out=await fixture._cycle(page,state)
                assert out.get('tipo')!='ajuda', out
                if out.get('fala_evento'):events.append(out['fala_evento'])
                if await page.locator('.activity-list-speak').evaluate("e=>e.classList.contains('completed')"):
                    break
                await page.wait_for_timeout(60)
        observed=await page.evaluate('({records:recordings.length,next:nextClicks})')
        assert observed=={'records':expected_records,'next':1}
        assert events[0]['precisao']==70
        assert events[0]['pulado']==(policy.precisao_minima>70)
    fixture._with_speech_page(scenario)


def test_leitor_nota_baixa_e_seta_sem_texto(scored_page):
    async def scenario(page):
        await page.get_by_test_id('player-start-speaking').wait_for(state='visible')
        await page.wait_for_function("document.querySelector('[data-testid=player-start-speaking]').textContent==='Falar 2 linhas'")
        await page.get_by_test_id('player-start-speaking').click()
        await page.get_by_test_id('player-record').wait_for(state='visible')
        await page.evaluate('''()=>{
          const result=document.querySelector('[data-testid="player-recording-result"]');
          result.hidden=false;result.textContent='Precisão: 70% · Tente novamente';
          result.dataset.status='retry';
          const next=document.querySelector('[data-testid="player-next-line"]');next.remove();
          const arrow=document.createElement('button');arrow.className='mic-next-line-button';
          arrow.setAttribute('aria-label','Próxima linha');arrow.innerHTML='→';
          document.querySelector('ec-speak-microphone').append(arrow);
          document.querySelector('.player-transcript-line').textContent='100% of the time.';
        }''')
        current=await inspect_ec_player(page)
        assert current['speak_phase']=='result' and current['speak_score']==70
        assert current['speak_next_ready'] and not current['speak_result_accepted']
    fixture._with_speech_page(scenario)


def test_notas_ambiguas_nao_viram_meta_atingida(scored_page):
    async def scenario(page):
        await page.wait_for_function("document.querySelector('[data-testid=player-start-speaking]').textContent==='Falar 2 linhas'")
        await page.get_by_test_id('player-start-speaking').click()
        await page.get_by_test_id('player-record').wait_for(state='visible')
        await page.get_by_test_id('player-recording-result').evaluate("e=>{e.hidden=false;e.textContent='Palavra 70%, outra palavra 90%'}")
        assert (await inspect_ec_player(page))['speak_score'] is None
    fixture._with_speech_page(scenario)
