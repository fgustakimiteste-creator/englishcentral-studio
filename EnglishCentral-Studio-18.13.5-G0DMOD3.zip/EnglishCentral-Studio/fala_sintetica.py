"""Síntese local para a etapa de fala e entrada direta no microfone do navegador."""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import tempfile
import wave
from functools import lru_cache
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA = Path(os.getenv('EC_DATA_DIR', str(ROOT / '.dados_locais')))


SYNTHETIC_MIC_INIT = r'''(() => {
  if (!navigator.mediaDevices?.getUserMedia || window.__ecStudioSyntheticMic) return;
  const nativeGetUserMedia = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
  const nativeEnumerate = navigator.mediaDevices.enumerateDevices?.bind(navigator.mediaDevices);
  const device = {deviceId:'ec-studio-synthetic', groupId:'ec-studio', kind:'audioinput',
    label:'EnglishCentral Studio — voz sintética', toJSON(){return {deviceId:this.deviceId,
      groupId:this.groupId, kind:this.kind, label:this.label};}};
  const state = {enabled:false, context:null, destination:null, requestCount:0, waiters:[],
    recordingWaiters:[], tracks:[], sources:new Set(), feeds:new Set(), recorders:new Set(),
    generation:0, recordingGeneration:0, recordingSupported:false,silence:null};
  const syntheticTracks = new WeakSet();
  const active = () => state.tracks.some(t=>t.readyState==='live');
  const recorderActive = item => item.started && item.recorder.state==='recording' &&
    item.stream.getAudioTracks().some(t=>syntheticTracks.has(t) && t.readyState==='live');
  const recording = after => state.enabled && [...state.recorders].some(item=>
    recorderActive(item) && item.generation>after);
  const recordingAt = generation => state.enabled && [...state.recorders].some(item=>
    recorderActive(item) && item.generation===generation);
  const wakeRecorders = () => {
    for(const waiter of [...state.recordingWaiters]){
      if(recording(waiter.after)) waiter.finish(true);
    }
  };
  const decorate = track => {
    if(syntheticTracks.has(track)) return track;
    syntheticTracks.add(track); state.tracks.push(track);
    const settings=track.getSettings?.bind(track), clone=track.clone.bind(track);
    try {
      if(settings) Object.defineProperty(track,'getSettings',{configurable:true,value:()=>
        ({...settings(),deviceId:device.deviceId,groupId:device.groupId})});
      const capabilities=track.getCapabilities?.bind(track);
      if(capabilities) Object.defineProperty(track,'getCapabilities',{configurable:true,value:()=>
        ({...capabilities(),deviceId:device.deviceId,groupId:device.groupId})});
      Object.defineProperty(track,'clone',{configurable:true,value:()=>decorate(clone())});
    } catch {}
    return track;
  };
  const NativeRecorder=window.MediaRecorder;
  if(typeof NativeRecorder==='function'){
    try {
      window.MediaRecorder=new Proxy(NativeRecorder,{construct(target,args,newTarget){
        const recorder=Reflect.construct(target,args,newTarget), stream=args[0];
        if(stream?.getAudioTracks().some(t=>syntheticTracks.has(t))){
          // Observe apenas gravações dessa entrada; streams nativos ficam intactos.
          for(const old of [...state.recorders]){
            if(state.recorders.size<64) break;
            if(!recorderActive(old)){old.cleanup();state.recorders.delete(old);}
          }
          const item={recorder,stream,started:false,generation:0};
          const started=()=>{
            item.started=true; item.generation=++state.recordingGeneration; wakeRecorders();
          };
          const stopped=()=>{item.started=false;};
          recorder.addEventListener('start',started); recorder.addEventListener('resume',started);
          recorder.addEventListener('stop',stopped); recorder.addEventListener('pause',stopped);
          recorder.addEventListener('error',stopped);
          item.cleanup=()=>{
            recorder.removeEventListener('start',started);recorder.removeEventListener('resume',started);
            recorder.removeEventListener('stop',stopped);recorder.removeEventListener('pause',stopped);
            recorder.removeEventListener('error',stopped);
          };
          state.recorders.add(item);
        }
        return recorder;
      }});
      state.recordingSupported=true;
    } catch {}
  }
  navigator.mediaDevices.enumerateDevices = async () => {
    if (!state.enabled) return nativeEnumerate();
    let devices=[];
    try { devices=await nativeEnumerate(); }
    catch(error){if(!state.enabled)throw error;}
    if(!state.enabled)return devices;
    return [device, ...devices.filter(d=>d.deviceId!==device.deviceId)];
  };
  const ensure = () => {
    if (!state.context) state.context = new AudioContext();
    if (!state.destination || state.destination.stream.getAudioTracks().some(t=>t.readyState==='ended')) {
      try{state.silence?.stop();state.silence?.disconnect();}catch{}
      state.destination = state.context.createMediaStreamDestination();
      // Uma entrada de microfone emite quadros mesmo em silêncio. Sem essa
      // fonte, MediaRecorder pode adiar start até o primeiro áudio de fala.
      state.silence=state.context.createConstantSource();state.silence.offset.value=0;
      state.silence.connect(state.destination);state.silence.start();
    }
    return state.context;
  };
  window.__ecStudioSyntheticMic = {
    setEnabled(value) {
      const changed = state.enabled !== !!value;
      state.enabled = !!value;
      if(!state.enabled){
        for(const waiter of [...state.recordingWaiters])waiter.finish(false);
        for(const cancel of [...state.feeds])cancel();
      }
      if(changed) navigator.mediaDevices.dispatchEvent(new Event('devicechange'));
      return state.enabled;
    },
    get enabled() { return state.enabled; },
    status() {
      return {enabled:state.enabled,liveTracks:state.tracks.filter(t=>t.readyState==='live').length,
        recording:recording(-1),recordingGeneration:state.recordingGeneration,
        requestCount:state.requestCount,recorderCount:[...state.recorders].filter(recorderActive).length,
        recordingSupported:state.recordingSupported,feeding:state.feeds.size>0,activeSources:state.sources.size};
    },
    async waitForStream(timeout=2500) {
      if (state.enabled && active()) return true;
      return await new Promise(resolve=>{
        const finish=value=>{
          clearTimeout(timer);
          state.waiters=state.waiters.filter(w=>w!==finish);
          resolve(value);
        };
        const timer=setTimeout(()=>finish(false),timeout);
        state.waiters.push(finish);
      });
    },
    async waitForRecording(timeout=2500, afterGeneration=-1) {
      if(recording(afterGeneration))return true;
      if(!state.enabled)return false;
      return await new Promise(resolve=>{
        const waiter={after:afterGeneration,finish:null};
        waiter.finish=value=>{
          clearTimeout(timer);
          state.recordingWaiters=state.recordingWaiters.filter(w=>w!==waiter);
          resolve(value);
        };
        const timer=setTimeout(()=>waiter.finish(false),timeout);
        state.recordingWaiters.push(waiter);
      });
    },
    async release() {
      this.setEnabled(false);
      state.generation++;
      for (const wake of [...state.waiters]) wake(false);
      for (const source of state.sources) { try {source.stop();} catch {} }
      state.sources.clear();
      try{state.silence?.stop();state.silence?.disconnect();}catch{}state.silence=null;
      state.tracks.forEach(track=>track.stop()); state.tracks=[];
      for(const item of state.recorders)item.cleanup();state.recorders.clear();
      state.destination?.stream.getTracks().forEach(track=>track.stop());
      await state.context?.close().catch(()=>{});
      state.context=null; state.destination=null; state.requestCount=0;
    },
    async feed(base64, options={}) {
      if (!state.enabled || !active()) throw new Error('Não há entrada sintética ativa para receber o áudio.');
      if(state.feeds.size)throw new Error('Uma frase sintética já está sendo reproduzida.');
      const required=options?.requireRecordingGeneration;
      if(required!==undefined && (!Number.isInteger(required)||required<1))throw new TypeError('Geração de gravação inválida.');
      const captureReady=()=>required===undefined||recordingAt(required);
      if(!captureReady())throw new Error('A gravação esperada não está ativa para receber a frase.');
      const context = ensure();
      const generation=state.generation;
      let cancel,source,timer,guardTimer;
      const cancelled=new Promise((_,reject)=>{cancel=reason=>reject(new Error(reason||'A reprodução sintética foi cancelada.'));});
      state.feeds.add(cancel);
      if(required!==undefined)guardTimer=setInterval(()=>{
        if(!captureReady())cancel('O gravador encerrou ou mudou a captura antes do fim da frase.');
      },30);
      try {
        if (context.state === 'suspended') await Promise.race([context.resume(),cancelled]);
        const binary = atob(base64), bytes = new Uint8Array(binary.length);
        for (let i=0; i<binary.length; i++) bytes[i] = binary.charCodeAt(i);
        const buffer = await Promise.race([context.decodeAudioData(bytes.buffer),cancelled]);
        if(generation!==state.generation||!state.enabled||!active())throw new Error('A entrada foi encerrada antes da reprodução.');
        if(!captureReady())throw new Error('A gravação terminou antes da reprodução da frase.');
        source=context.createBufferSource();source.buffer=buffer;source.connect(state.destination);
        state.sources.add(source);
        await Promise.race([new Promise((resolve, reject) => {
          timer=setTimeout(()=>{try{source.stop();}catch{} reject(new Error('Tempo de reprodução excedido.'));}, (buffer.duration+3)*1000);
          source.onended=()=>{clearTimeout(timer);resolve();};
          source.start();
        }),cancelled]);
        if(generation!==state.generation||!state.enabled||!active())throw new Error('A entrada foi encerrada durante a reprodução.');
        if(!captureReady())throw new Error('A gravação terminou antes do fim da frase.');
        return buffer.duration;
      } finally {
        clearTimeout(timer);clearInterval(guardTimer);state.feeds.delete(cancel);
        if(source){try{source.stop();}catch{}source.disconnect();state.sources.delete(source);}
      }
    }
  };
  navigator.mediaDevices.getUserMedia = async constraints => {
    if (!state.enabled || !constraints?.audio) return nativeGetUserMedia(constraints);
    const generation=state.generation;
    const context = ensure();
    if (context.state === 'suspended') await context.resume();
    state.tracks=state.tracks.filter(t=>t.readyState==='live');
    let camera=null,tracks=[];
    try {
      if (constraints.video) camera=await nativeGetUserMedia({audio:false, video:constraints.video});
      if(!state.enabled||generation!==state.generation)throw new DOMException('Entrada sintética encerrada.','AbortError');
      tracks=state.destination.stream.getAudioTracks().map(t=>decorate(t.clone()));
      if(camera)tracks.push(...camera.getVideoTracks());
      state.requestCount++;
      for (const wake of [...state.waiters]) wake(true);
      return new MediaStream(tracks);
    } catch(error){
      tracks.forEach(track=>track.stop());camera?.getTracks().forEach(track=>track.stop());
      throw error;
    }
  };
})();'''


@lru_cache(maxsize=24)
def synthesize_wav(text: str) -> tuple[bytes, float]:
    """SAPI no Windows; eSpeak no servidor Linux. Ambos geram WAV real."""
    phrase = re.sub(r'\s+', ' ', str(text or '')).strip()
    phrase = re.sub(r'[^A-Za-z0-9 ,.!?\'’:-]', ' ', phrase)
    phrase = re.sub(r'\s+', ' ', phrase).strip()
    if not phrase or len(phrase) > 300:
        raise RuntimeError('A frase de fala está vazia ou contém texto não compatível com a voz inglesa.')
    if os.name != 'nt':
        return _synthesize_portable(phrase)
    executable = os.environ.get('EC_STUDIO_POWERSHELL', 'powershell.exe')
    DATA.mkdir(mode=0o700, parents=True, exist_ok=True)
    path = None
    try:
        with tempfile.NamedTemporaryFile(prefix='fala-', suffix='.wav', dir=DATA, delete=False) as temp:
            path = Path(temp.name)
        path.unlink(missing_ok=True)
        script = (
            "$ErrorActionPreference='Stop'; Add-Type -AssemblyName System.Speech; "
            "$s=New-Object System.Speech.Synthesis.SpeechSynthesizer; "
            "$v=$s.GetInstalledVoices() | Where-Object { $_.Enabled -and $_.VoiceInfo.Culture.Name -like 'en-*' } | Select-Object -First 1; "
            "if(-not $v){throw 'Nenhuma voz inglesa SAPI instalada.'}; "
            "$s.SelectVoice($v.VoiceInfo.Name); $s.SetOutputToWaveFile($env:EC_STUDIO_TTS_FILE); "
            "$s.Speak($env:EC_STUDIO_TTS_TEXT); $s.Dispose()"
        )
        env = os.environ.copy()
        env['EC_STUDIO_TTS_TEXT'] = phrase
        env['EC_STUDIO_TTS_FILE'] = str(path)
        flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
        result = subprocess.run([executable, '-NoLogo', '-NoProfile', '-NonInteractive', '-Command', script],
                                cwd=ROOT, env=env, capture_output=True, text=True,
                                timeout=24, check=False, creationflags=flags)
        if result.returncode != 0 or not path.exists():
            detail = (result.stderr or result.stdout or '').strip()
            if 'voz inglesa' in detail.lower():
                raise RuntimeError('Instale uma voz de fala em inglês nas configurações de voz do Windows.')
            raise RuntimeError('Não foi possível gerar a voz sintética local.' +
                               ((' ' + detail[:180]) if detail else ''))
        with wave.open(str(path), 'rb') as audio:
            duration = audio.getnframes() / max(1, audio.getframerate())
        data = path.read_bytes()
        if len(data) < 48 or not 0.2 <= duration <= 30:
            raise RuntimeError('A voz sintética gerou um áudio inválido.')
        return data, duration
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError('A síntese de voz excedeu 24 segundos.') from exc
    finally:
        if path:
            path.unlink(missing_ok=True)


def _synthesize_portable(phrase: str) -> tuple[bytes, float]:
    executable = shutil.which('espeak-ng') or shutil.which('espeak')
    if not executable:
        raise RuntimeError('Instale espeak-ng no servidor Linux para gerar a voz inglesa. A imagem de servidor já inclui essa dependência.')
    DATA.mkdir(mode=0o700, parents=True, exist_ok=True)
    path = None
    try:
        with tempfile.NamedTemporaryFile(prefix='fala-', suffix='.wav', dir=DATA, delete=False) as temp:
            path = Path(temp.name)
        result = subprocess.run([executable, '-v', 'en-us', '-s', '155', '-w', str(path), '--stdin'],
                                input=phrase, capture_output=True, text=True, timeout=24, check=False)
        if result.returncode != 0:
            raise RuntimeError('Não foi possível gerar a voz inglesa no servidor.')
        with wave.open(str(path), 'rb') as audio:
            duration = audio.getnframes() / max(1, audio.getframerate())
            if audio.getcomptype() != 'NONE':
                raise RuntimeError('O servidor não gerou um WAV PCM válido.')
        data = path.read_bytes()
        if len(data) < 48 or not 0.2 <= duration <= 30:
            raise RuntimeError('A voz sintética gerou um áudio inválido.')
        return data, duration
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError('A síntese de voz excedeu 24 segundos.') from exc
    except (wave.Error, EOFError) as exc:
        raise RuntimeError('O servidor não gerou um arquivo de áudio válido.') from exc
    finally:
        if path:
            path.unlink(missing_ok=True)
