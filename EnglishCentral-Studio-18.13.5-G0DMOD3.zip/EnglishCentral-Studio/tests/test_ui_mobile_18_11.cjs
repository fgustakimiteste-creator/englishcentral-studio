const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const {JSDOM,VirtualConsole}=require(process.env.EC_JSDOM||'jsdom');
const html=fs.readFileSync(path.join(__dirname,'../web/index.html'),'utf8');
const sw=fs.readFileSync(path.join(__dirname,'../web/sw.js'),'utf8');
const pwa=fs.readFileSync(path.join(__dirname,'../web/pwa.js'),'utf8');
const wait=()=>new Promise(r=>setTimeout(r,30));
let passed=0;
async function test(name,fn){await fn();passed++;console.log('PASS',name)}
async function boot({url='https://estudos.example.com/#token=fixture-only',remote=true,preload={}}={}){
 const calls=[],errors=[],timers=[];
 const vc=new VirtualConsole();vc.on('jsdomError',e=>{if(!e.message.includes('navigation'))errors.push(e.message)});
 const state={aberto:false,executando:true,eventos:[],auto:{tipo:'aguardando',mensagem:'Executando no servidor'},modo:{assistir:true},aplicativo:{remoto:remote}};
 const dom=new JSDOM(html,{url,runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:vc,beforeParse(w){
  for(const [key,value] of Object.entries(preload))w.localStorage.setItem(key,value);
  w.scrollTo=()=>{};w.setInterval=(fn,delay)=>{timers.push({fn,delay});return timers.length};
  w.HTMLDialogElement.prototype.showModal=function(){this.open=true};w.HTMLDialogElement.prototype.close=function(){this.open=false};
  w.URL.createObjectURL=()=> 'blob:fixture';w.URL.revokeObjectURL=()=>{};
  w.fetch=async(url,options={})=>{calls.push({url,method:options.method||'GET',headers:options.headers,data:options.body?JSON.parse(options.body):null});return{ok:true,json:async()=>url.endsWith('/status')?structuredClone(state):{ok:true},blob:async()=>new w.Blob(['fixture'])}};
 }});await wait();assert.deepEqual(errors,[]);
 return{dom,w:dom.window,d:dom.window.document,calls,state,timers,errors};
}
function serviceWorker(){
 const events={},added=[],deleted=[],messages=[];
 const cache={addAll:async urls=>added.push(...urls),match:async path=>({offline:true,path})};
 const sandbox={URL,Set,AbortController,setTimeout,clearTimeout,
  self:{location:{origin:'https://estudos.example.com'},clients:{claim:async()=>{}},skipWaiting:()=>messages.push('skip'),addEventListener:(name,fn)=>events[name]=fn},
  caches:{open:async()=>cache,keys:async()=>['ec-studio-public-old','another-app'],delete:async name=>deleted.push(name)},
  fetch:async()=>{throw Error('offline')}
 };
 vm.runInNewContext(sw,sandbox);
 async function event(name,data={}){let work;events[name]({...data,waitUntil:p=>work=p,respondWith:p=>work=p});return work?await work:undefined}
 function request(path,extra={}){return{url:new URL(path,'https://estudos.example.com').href,method:'GET',mode:'cors',headers:new Headers(),...extra}}
 return{events,added,deleted,messages,event,request,sandbox};
}
(async()=>{
 await test('Manifesto oferece janela própria e ícones locais',async()=>{const m=JSON.parse(fs.readFileSync(path.join(__dirname,'../web/manifest.webmanifest')));assert.equal(m.display,'standalone');assert.equal(m.start_url,'/');assert(m.icons.some(i=>i.purpose==='maskable'));assert(html.includes('viewport-fit=cover'))});
 await test('Acesso persistente só é salvo após escolha da pessoa',async()=>{const t=await boot();assert.equal(t.w.localStorage.getItem('ec_token'),null);assert.equal(t.w.sessionStorage.getItem('ec_token'),'fixture-only');t.d.getElementById('rememberAccess').click();assert.equal(t.w.localStorage.getItem('ec_token'),'fixture-only');t.d.getElementById('rememberAccess').click();assert.equal(t.w.localStorage.getItem('ec_token'),null);assert.equal(t.w.sessionStorage.getItem('ec_token'),'fixture-only');t.dom.window.close()});
 await test('Reabrir aplicativo recupera acesso autorizado sem enviar senha',async()=>{const t=await boot({url:'https://estudos.example.com/',preload:{ec_token:'remembered-fixture','ec_remember:/':'true'}});assert(t.calls.some(c=>c.url==='/api/status'&&c.headers['X-EC-Token']==='remembered-fixture'));assert(t.d.getElementById('rememberAccess').checked);t.dom.window.close()});
 await test('Painel de outra pessoa usa caminho e armazenamento próprios',async()=>{const t=await boot({url:'https://estudos.example.com/p/pessoa7/#token=child-fixture',preload:{ec_token:'parent-fixture','ec_remember:/':'true'}});assert(t.calls.some(c=>c.url==='/p/pessoa7/api/status'&&c.headers['X-EC-Token']==='child-fixture'));assert(!t.calls.some(c=>c.url==='/api/status'));assert.equal(t.w.sessionStorage.getItem('ec_token:/p/pessoa7/'),'child-fixture');assert.equal(t.w.localStorage.getItem('ec_token'),'parent-fixture');t.dom.window.close()});
 await test('Esquecer aparelho apaga o token e não manda parar o servidor',async()=>{const t=await boot();t.d.getElementById('rememberAccess').click();t.d.getElementById('forgetDevice').click();assert.equal(t.w.localStorage.getItem('ec_token'),null);assert.equal(t.w.sessionStorage.getItem('ec_token'),null);assert(!t.calls.some(c=>c.method==='POST'&&c.url.includes('auto/')));t.dom.window.close()});
 await test('Voltar à tela sincroniza sem reiniciar nem pausar atividades',async()=>{const t=await boot();t.w.document.dispatchEvent(new t.w.Event('visibilitychange'));t.w.dispatchEvent(new t.w.Event('pageshow'));await wait();assert(t.calls.filter(c=>c.url==='/api/status').length>=2);assert(!t.calls.some(c=>c.url==='/api/auto/start'||c.url==='/api/auto/stop'));assert.equal(t.d.getElementById('toggleLabel').textContent,'Pausar assistente');t.dom.window.close()});
 await test('Modo remoto explica execução e não oferece Chrome do telefone',async()=>{const t=await boot();assert(t.d.getElementById('connectChrome').hidden);assert(t.d.getElementById('emptyConnectChrome').hidden);assert.equal(t.d.getElementById('appRuntime').textContent,'Executando no servidor');assert.match(t.d.getElementById('appRuntimeDetail').textContent,/Pode fechar/);t.dom.window.close()});
 await test('Modo Windows continua oferecendo conexão com Chrome existente',async()=>{const t=await boot({remote:false});assert(!t.d.getElementById('connectChrome').hidden);assert.match(t.d.getElementById('appRuntimeDetail').textContent,/computador ligado/);t.dom.window.close()});
 await test('Tecla Enter do controle remoto usa ação autenticada existente',async()=>{const t=await boot();t.d.querySelector('[data-remote-key="Enter"]').click();await wait();const req=t.calls.find(c=>c.url==='/api/key');assert.deepEqual(req.data,{key:'Enter'});assert.equal(req.headers['X-EC-Token'],'fixture-only');t.dom.window.close()});
 await test('Worker instala somente arquivos públicos e aguarda atualização',async()=>{const t=serviceWorker();await t.event('install');assert(t.added.includes('/offline.html'));assert(!t.added.some(p=>p==='/'||p.includes('api/')));assert.deepEqual(t.messages,[]);await t.event('activate');assert.deepEqual(t.deleted,['ec-studio-public-old'])});
 await test('Worker deixa API, capturas, tokens e POST fora do cache',async()=>{const t=serviceWorker();for(const r of [t.request('/api/status'),t.request('/p/pessoa7/api/screenshot'),t.request('/icons/icon-192.png',{headers:new Headers({'X-EC-Token':'fixture'})}),t.request('/api/auto/start',{method:'POST'}),t.request('/icons/icon-192.png?private=1')])assert.equal(await t.event('fetch',{request:r}),undefined)});
 await test('Navegação sem rede recebe tela de reconexão sem progresso fictício',async()=>{const t=serviceWorker();const result=await t.event('fetch',{request:t.request('/p/pessoa7/',{mode:'navigate'})});assert.equal(result.path,'/offline.html');assert.equal(result.offline,true)});
 await test('Instalação usa solicitação do navegador e não inicia automação',async()=>{const t=await boot();Object.defineProperty(t.w,'isSecureContext',{value:true});t.w.eval(pwa);let prompted=0;const event=new t.w.Event('beforeinstallprompt',{cancelable:true});event.prompt=async()=>prompted++;event.userChoice=Promise.resolve({outcome:'accepted'});t.w.dispatchEvent(event);assert.equal(t.d.getElementById('installApp').textContent,'Instalar aplicativo');t.d.getElementById('installApp').click();await wait();assert.equal(prompted,1);assert(!t.calls.some(c=>c.url==='/api/auto/start'));t.dom.window.close()});
 console.log(`${passed} cenários de aplicativo aprovados (DOM/worker com rede simulada).`);
})().catch(error=>{console.error(error);process.exitCode=1});
