"""Navegação por DOM representativo do curso Angular, sem login nem rede."""
import asyncio

from playwright.async_api import async_playwright

from conftest import chromium_launch_options
from course_flow import CourseCursor, advance_course, lesson_key


COURSE_HTML = r"""<!doctype html><html><head><style>
 ec-course-app,ec-course-unit,ec-course-unit-activity,ec-player-app {display:block}
 .unit,.unit-header,.course-unit-activity-thumbnail-title-wrapper {padding:10px;border:1px solid #aaa}
 .unit-activities {padding:10px} .outside-title{display:none}
 .d-none{display:none}
</style></head><body><ec-course-app data-course-id="8597">
 <div class="course-unit-activity-back-button-wrapper outside-title">Voltar</div>
 <div class="course-unit-activity-back-button-wrapper in-title" style="display:none">Voltar</div>
 <ec-course-unit><div class="units">
 <div class="unit" id="1"><div class="unit-header"><span class="unit-name">UNIDADE 1</span></div></div>
 <div class="unit" id="2"><div class="unit-header"><span class="unit-name">UNIDADE 2</span></div></div>
 </div></ec-course-unit></ec-course-app><script>
 window.actions=[];
 const units=[...document.querySelectorAll('.unit')];
 function video(id,title){return `<ec-course-unit-activity><div class="course-unit-activity-thumbnail-title-wrapper"><div class="course-unit-activity-thumbnail" style="background-image:url(https://cdna.englishcentral.com/dialogs/${id}/thumb_${id}.jpg)"></div><div class="course-unit-activity-title">${title}</div></div><div class="course-unit-activity-progress bg-average"></div></ec-course-unit-activity>`}
 function quiz(){return '<ec-course-unit-activity><div class="course-unit-activity-thumbnail-title-wrapper"><div class="course-unit-activity-thumbnail quiz-thumbnail"></div><div class="course-unit-activity-title">Quiz 1</div></div></ec-course-unit-activity>'}
 function openUnit(unit){
   actions.push('unit:'+unit.id);
   for(const u of units){u.classList.remove('active');u.querySelector('.unit-activities')?.remove()}
   unit.classList.add('active');
   const list=document.createElement('div');list.className='unit-activities';
   list.innerHTML=unit.id==='1'?video('101','Aula com mesmo título')+quiz()+video('102','Aula com mesmo título'):quiz()+video('201','Última aula');
   unit.append(list);
   for(const c of list.querySelectorAll('ec-course-unit-activity')) c.querySelector('.course-unit-activity-thumbnail-title-wrapper').onclick=()=>{
     const match=c.querySelector('.course-unit-activity-thumbnail').getAttribute('style')?.match(/dialogs\/(\d+)/);
      if(!match){actions.push('quiz:'+unit.id+':q'+[...c.parentElement.children].indexOf(c));return}
     actions.push('lesson:'+match[1]);
     const p=document.createElement('ec-player-app');
     p.innerHTML=`<ec-video><video id="ns-dialog-${match[1]}_html5_api" src="https://cdna.englishcentral.com/dialogs/${match[1]}/videoh264_${match[1]}.mp4" style="width:200px;height:80px"></video></ec-video>`;
     document.querySelector('ec-course-unit').append(p);
     document.querySelector('.in-title').style.display='block';
   };
 }
 for(const u of units) u.querySelector('.unit-header').onclick=()=>openUnit(u);
 document.querySelector('.in-title').onclick=()=>{actions.push('back');document.querySelector('ec-player-app')?.remove();document.querySelector('.in-title').style.display='none'};
 </script></body></html>"""


async def prepare(pw):
    browser = await pw.chromium.launch(**chromium_launch_options())
    page = await browser.new_page(viewport={"width": 1280, "height": 800})
    await page.route("https://cdna.englishcentral.com/**", lambda route: route.abort())
    await page.set_content(COURSE_HTML)
    return browser, page


def test_identidade_de_dialogo_e_reset():
    assert lesson_key("27496") == "27496"
    assert lesson_key("dialog:27496") == "27496"
    assert lesson_key("dialog:27496:other") == ""
    assert lesson_key("https://cdna.englishcentral.com/dialogs/27496/videoh264_27496_foo.mp4") == "27496"
    assert lesson_key("ns-dialog-27496_html5_api") == "27496"
    assert lesson_key("https://pt.englishcentral.com/course/8597") == ""
    cursor = CourseCursor(current="27496", visited_units={"1"})
    cursor.mark_done("ns-dialog-27496_html5_api")
    assert cursor.seen == {"27496"}
    cursor.pending, cursor.pending_attempts = "back:27496", 1
    cursor.mark_done("27496")
    assert cursor.pending == "back:27496" and cursor.pending_attempts == 1
    cursor.reset()
    assert not cursor.seen and not cursor.visited_units and not cursor.current


def test_varre_videos_e_quizzes_sem_repetir_conteudo_concluido():
    async def run():
        async with async_playwright() as pw:
            browser, page = await prepare(pw)
            try:
                cursor = CourseCursor()
                advance = lambda: advance_course(page, cursor, include_quizzes=True)
                result = await advance()
                assert result["acao"] == "abrir_unidade"
                result = await advance()
                assert result["acao"] == "abrir_aula" and cursor.current == "101"
                # Progresso agregado bg-average não marca a aula nem fecha o player.
                result = await advance()
                assert result["tipo"] == "aguardando" and not cursor.seen
                cursor.mark_done("101")
                assert (await advance())["acao"] == "voltar_lista"
                result = await advance()
                assert result["acao"] == "abrir_aula" and cursor.current == "102"
                cursor.mark_done("102")
                assert (await advance())["acao"] == "voltar_lista"
                quiz1 = await advance()
                assert quiz1["acao"] == "abrir_quiz" and quiz1["quiz_id"] == "1:q1"
                cursor.mark_quiz_done(quiz1["quiz_id"])
                assert (await advance())["acao"] == "abrir_unidade"
                assert (await advance())["acao"] == "abrir_aula"
                assert cursor.current == "201"
                cursor.mark_done("201")
                assert (await advance())["acao"] == "voltar_lista"
                quiz2 = await advance()
                assert quiz2["acao"] == "abrir_quiz" and quiz2["quiz_id"] == "2:q0"
                cursor.mark_quiz_done(quiz2["quiz_id"])
                done = await advance()
                assert done["tipo"] == "escopo_concluido" and done["aulas_verificadas"] == 3
                assert await page.evaluate("actions") == ["unit:1", "lesson:101", "back", "lesson:102", "back", "quiz:1:q1", "unit:2", "lesson:201", "back", "quiz:2:q0"]
            finally:
                await browser.close()
    asyncio.run(run())


def test_modo_quiz_abre_quizzes_sem_exigir_palavras_ou_videos():
    async def run():
        async with async_playwright() as pw:
            browser, page = await prepare(pw)
            try:
                cursor = CourseCursor()
                advance = lambda: advance_course(page, cursor, include_quizzes=True, include_videos=False)
                assert (await advance())['acao'] == 'abrir_unidade'
                first = await advance()
                assert first['acao'] == 'abrir_quiz' and first['quiz_id'] == '1:q1'
                cursor.mark_quiz_done(first['quiz_id'])
                assert (await advance())['acao'] == 'abrir_unidade'
                second = await advance()
                assert second['acao'] == 'abrir_quiz' and second['quiz_id'] == '2:q0'
                cursor.mark_quiz_done(second['quiz_id'])
                assert (await advance())['tipo'] == 'escopo_concluido'
                assert await page.evaluate('actions') == ['unit:1', 'quiz:1:q1', 'unit:2', 'quiz:2:q0']
            finally:
                await browser.close()
    asyncio.run(run())


def test_nao_fecha_player_desconhecido_nem_clica_voltar_fora_curso():
    async def run():
        async with async_playwright() as pw:
            browser, page = await prepare(pw)
            try:
                cursor = CourseCursor()
                await advance_course(page, cursor)
                await advance_course(page, cursor)
                cursor.mark_done("999")
                assert (await advance_course(page, cursor))["tipo"] == "aguardando"
                assert "back" not in await page.evaluate("actions")
                await page.set_content('<button onclick="window.bad=true">Voltar</button><ec-player-app><video style="height:50px;width:100px"></video></ec-player-app>')
                assert (await advance_course(page, cursor))["tipo"] == "fora_curso"
                assert await page.evaluate("!!window.bad") is False
            finally:
                await browser.close()
    asyncio.run(run())


def test_limita_retentativas_de_abrir_aula_e_indica_unidade_bloqueada():
    async def run():
        async with async_playwright() as pw:
            browser, page = await prepare(pw)
            try:
                cursor = CourseCursor()
                await advance_course(page, cursor)
                # Simula servidor que não abre o player ao clicar na aula.
                await page.locator('.unit.active ec-course-unit-activity .course-unit-activity-thumbnail-title-wrapper').first.evaluate("e=>e.onclick=()=>window.actions.push('not-opened')")
                await advance_course(page, cursor)
                assert (await advance_course(page, cursor))["tipo"] == "aguardando"
                cursor.pending_since -= 13
                assert (await advance_course(page, cursor))["acao"] == "abrir_aula"
                cursor.pending_since -= 13
                assert (await advance_course(page, cursor))["tipo"] == "ajuda"
                assert (await page.evaluate("actions")).count("not-opened") == 2
                cursor.mark_done("101")
                cursor.mark_done("102")
                await page.locator('.unit[id="2"]').evaluate("e=>e.classList.add('locked')")
                result = await advance_course(page, cursor)
                assert result["tipo"] == "ajuda" and result["unidades_bloqueadas"] == 1
            finally:
                await browser.close()
    asyncio.run(run())


def test_limita_retentativas_de_unidade_quando_a_anterior_continua_ativa():
    async def run():
        async with async_playwright() as pw:
            browser, page = await prepare(pw)
            try:
                cursor = CourseCursor()
                await advance_course(page, cursor)
                cursor.mark_done("101")
                cursor.mark_done("102")
                await page.locator('.unit[id="2"] .unit-header').evaluate("e=>e.onclick=()=>window.actions.push('unit-not-opened')")
                assert (await advance_course(page, cursor))["acao"] == "abrir_unidade"
                assert (await advance_course(page, cursor))["tipo"] == "aguardando"
                cursor.pending_since -= 13
                assert (await advance_course(page, cursor))["acao"] == "abrir_unidade"
                cursor.pending_since -= 13
                assert (await advance_course(page, cursor))["tipo"] == "ajuda"
                assert (await page.evaluate("actions")).count("unit-not-opened") == 2
            finally:
                await browser.close()
    asyncio.run(run())

def test_unidade_com_quiz_bloqueado_nao_fica_concluida():
    async def run():
        async with async_playwright() as pw:
            browser, page = await prepare(pw)
            try:
                cursor = CourseCursor(seen={'101','102','201'})
                await page.evaluate("openUnit(document.getElementById('1'))")
                await page.locator('ec-course-unit-activity').nth(1).evaluate("e=>e.classList.add('locked')")
                await advance_course(page, cursor, include_quizzes=True)
                assert '1' not in cursor.verified_units
            finally:
                await browser.close()
    asyncio.run(run())


def test_quiz_incomplete_nao_conta_como_complete():
    from course_flow import inspect_course
    async def run():
        async with async_playwright() as pw:
            browser, page = await prepare(pw)
            try:
                await page.evaluate("openUnit(document.getElementById('1'))")
                card = page.locator('ec-course-unit-activity').nth(1)
                await card.evaluate("e=>e.classList.add('incomplete')")
                assert not (await inspect_course(page))['units'][0]['cards'][1]['completed']
                await card.evaluate("e=>{e.classList.remove('incomplete');e.classList.add('completed')}")
                assert (await inspect_course(page))['units'][0]['cards'][1]['completed']
            finally:
                await browser.close()
    asyncio.run(run())


def test_resumo_nao_confunde_visitada_com_concluida():
    from course_flow import course_progress
    info={'course_id':'1','units':[{'id':'u1','cards':[]},{'id':'u2','cards':[]}]}
    cursor=CourseCursor(visited_units={'u1','u2'}, verified_units={'u2'})
    result=course_progress(info,cursor)
    assert [u['estado'] for u in result['unidades']] == ['nao_verificada','concluida']
