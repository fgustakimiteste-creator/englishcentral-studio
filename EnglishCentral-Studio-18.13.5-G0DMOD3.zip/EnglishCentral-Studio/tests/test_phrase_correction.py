from exercicio import read_correction

def test_correction_keeps_complete_expression():
    assert read_correction('Acabou o tempo! Resposta certa: get down')=='get down'
    assert read_correction('Resposta certa: back it up Continuar REPORT 2/3')=='back it up'
    assert read_correction('Correct answer: empire | Another hint')=='empire'
    assert read_correction('Digite a resposta correta') is None
