"""Repete somente leitura de telas transitórias; nunca login, CAPTCHA ou envio incerto."""
from dataclasses import dataclass

@dataclass
class Recuperacao:
    assinatura: tuple | None = None
    tentativas: int = 0

    def aplicar(self, resultado, pagina):
        tipo = resultado.get('tipo')
        if tipo not in {'lacuna_sem_texto', 'lacuna_sem_campo'}:
            self.assinatura, self.tentativas = None, 0
            return resultado
        assinatura = (pagina, tipo, resultado.get('mensagem'))
        if assinatura != self.assinatura:
            self.assinatura, self.tentativas = assinatura, 0
        self.tentativas += 1
        if self.tentativas > 2:
            return {**resultado, 'recuperacao': 'Limite de duas novas leituras atingido.'}
        return {**resultado, 'tipo': 'aguardando', 'mensagem':
                f'A página ainda não expôs a atividade. Nova leitura {self.tentativas}/2.',
                'recuperacao': resultado.get('mensagem', '')}
