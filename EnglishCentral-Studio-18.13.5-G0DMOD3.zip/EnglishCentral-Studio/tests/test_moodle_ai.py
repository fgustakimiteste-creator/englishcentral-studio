import asyncio
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest
from fastapi import HTTPException

import servidor


def test_moodle_draft_requires_seductec(monkeypatch):
    async def run():
        monkeypatch.setattr(servidor, 'lock', asyncio.Lock())
        monkeypatch.setattr(servidor, 'current_page', lambda: SimpleNamespace(url='https://example.com/'))
        monkeypatch.setattr(servidor, 'inspect_moodle_page', AsyncMock())
        with pytest.raises(HTTPException) as error:
            await servidor.draft_seductec_answer(servidor.MoodleDraftRequest(pergunta='Explique o tema central.'))
        assert error.value.status_code == 409
    asyncio.run(run())


def test_moodle_draft_uses_local_engine_and_does_not_submit(monkeypatch):
    async def run():
        async def inspect(_page):
            return {'ativo': True, 'curso': 'História', 'texto': 'Material visível da página.'}

        def draft(question, material, formato):
            assert question == 'Explique o tema central.'
            assert 'Material complementar.' in material
            assert 'Material visível da página.' in material
            assert formato == 'curta'
            return {'resposta': 'Rascunho local.', 'explicacao': '', 'fundamentacao': '',
                    'pontos_a_conferir': '', 'confianca': 'media'}

        monkeypatch.setattr(servidor, 'lock', asyncio.Lock())
        monkeypatch.setattr(servidor, 'current_page', lambda: SimpleNamespace(url='https://seductec.seduc.pi.gov.br/mod/assign/view.php?id=4'))
        monkeypatch.setattr(servidor, 'inspect_moodle_page', inspect)
        monkeypatch.setattr(servidor, 'draft_moodle_answer', draft)
        monkeypatch.setattr(servidor, 'ia_status', lambda: {'modelo': 'qwen2.5:3b'})
        result = await servidor.draft_seductec_answer(servidor.MoodleDraftRequest(
            pergunta='Explique o tema central.', material='Material complementar.', formato='curta'))
        assert result['resposta'] == 'Rascunho local.'
        assert result['preenchida'] is False
        assert result['enviada'] is False
        assert result['modelo'] == 'qwen2.5:3b'
    asyncio.run(run())


def test_moodle_feedback_endpoint_persists_aggregate_preferences(monkeypatch):
    async def run():
        def fake_feedback(question, rating):
            assert question == 'Explique a importância da água.'
            assert rating == 'mais_detalhes'
            return {'tipo_pergunta': 'explicacao', 'amostras': 1, 'aprendido': True}

        monkeypatch.setattr(servidor, 'lock', asyncio.Lock())
        monkeypatch.setattr(servidor, 'current_page', lambda: SimpleNamespace(url='https://seductec.seduc.pi.gov.br/mod/assign/view.php?id=4'))
        monkeypatch.setattr(servidor, 'record_moodle_feedback', fake_feedback)
        result = await servidor.moodle_answer_feedback(servidor.MoodleFeedbackRequest(
            pergunta='Explique a importância da água.', avaliacao='mais_detalhes'))
        assert result['aprendido'] is True
        assert 'não foram armazenados' in result['aviso']
    asyncio.run(run())
