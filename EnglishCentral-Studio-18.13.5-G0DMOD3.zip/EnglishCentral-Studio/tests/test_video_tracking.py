"""Reprodução HTML5 real e confirmação da etapa, sem depender da cor da barra.

As páginas são locais e representativas; nenhum teste acessa a conta do usuário.
O vídeo curto é um WebM VP8 local de 160 × 90, com 18 quadros a 12 fps.
Os testes não alteram propriedades nativas como currentTime, paused ou ended
para fingir reprodução.
"""
import asyncio
import base64
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

import pytest
from playwright.async_api import async_playwright

from conftest import chromium_launch_options
from ec_engine import ECState, _watch_only, process_ec_page
from ec_player import inspect_ec_player
from modos import ModoEstudo


PLAYER = '''<!doctype html><title>Aula local de reprodução</title><style>
ec-activity-app,ec-player-app,ec-video,ec-activity-list{display:block}
video{width:240px;height:135px}.progress{height:8px;background:#aaa}
.fill{height:8px;width:35%;background:rgb(0,150,0)}
</style><ec-activity-app><ec-player-app>
<div id="activity-app-container" class="watch-mode">
<div class="dialog-title">Aula local de reprodução</div>
<ec-video><video id="ns-dialog-123" preload="metadata" muted></video></ec-video>
<button data-testid="player-play-pause">Reproduzir vídeo</button>
<div class="progress"><div class="fill" role="progressbar" aria-valuenow="35" aria-valuemax="100"></div></div>
</div></ec-player-app><ec-activity-list>
<button data-testid="player-activity-button" class="activity-list-watch active">Assista ao vídeo</button>
<button data-testid="player-activity-button" class="activity-list-learn completed">Aprenda as palavras</button>
<button data-testid="player-activity-button" class="activity-list-speak">Fale as linhas</button>
</ec-activity-list></ec-activity-app>
<script>
window.siteTrackingStarted=false;window.sitePlayClicks=0;
document.querySelector('[data-testid="player-play-pause"]').onclick=async()=>{
  window.siteTrackingStarted=true;window.sitePlayClicks++;
  await document.querySelector('video').play();
};
</script>'''


async def _make_real_clip(page):
    """Carrega mídia determinística; não depende do compositor de canvas headless.

    Fixture gerada localmente com OpenCV/VP8: fundos alternados e uma barra móvel.
    Não é necessário OpenCV para executar os testes, nem acesso à rede.
    """
    clip=Path(__file__).with_name('fixtures')/'watch-test.webm'
    source='data:video/webm;base64,'+base64.b64encode(clip.read_bytes()).decode('ascii')
    metadata=await page.evaluate('''async source => {
      const video=document.querySelector('video');
      const metadata=new Promise((resolve,reject)=>{
        video.onloadedmetadata=resolve;video.onerror=()=>reject(Error('WebM local inválido: '
          +JSON.stringify({error:video.error?.code,message:video.error?.message})));
      });
      video.src=source;video.load();await metadata;
      return {width:video.videoWidth,height:video.videoHeight,duration:video.duration};
    }''',source)
    assert metadata['width']==160 and metadata['height']==90
    assert 1.4<=metadata['duration']<=1.6


def _with_page(scenario):
    async def run():
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(**chromium_launch_options())
            try:
                page=await browser.new_page(viewport={'width':900,'height':700})
                await page.set_content(PLAYER)
                await scenario(page)
            finally:
                await browser.close()
    asyncio.run(run())


@pytest.mark.parametrize(('attributes','expected'), [
    ({'class':'activity-list-watch active completed'},True),
    ({'data-completed':'true'},True),
    ({'aria-label':'Assistir ao vídeo concluído'},True),
    ({'data-status':'completed'},True),
    ({'class':'activity-list-watch active incomplete'},False),
    ({'class':'activity-list-watch active completed incomplete','data-completed':'true'},False),
    ({'aria-label':'Assistir ao vídeo não concluído','data-completed':'true'},False),
    ({'aria-label':'Assistir ao vídeo incompleto'},False),
])
def test_sinal_de_conclusao_pertence_a_assistir_e_respeita_negativas(attributes,expected):
    async def scenario(page):
        await page.locator('.activity-list-watch').evaluate('''(element,attributes)=>{
          for(const [name,value] of Object.entries(attributes))element.setAttribute(name,value);
        }''',attributes)
        snapshot=await inspect_ec_player(page)
        assert snapshot['supported']
        assert snapshot['watch_complete'] is expected
    _with_page(scenario)


def test_barra_verde_parcial_e_conclusao_de_aprender_nao_confirmam_assistir():
    async def scenario(page):
        assert await page.locator('.fill').evaluate("e=>getComputedStyle(e).backgroundColor")=='rgb(0, 150, 0)'
        snapshot=await inspect_ec_player(page)
        assert snapshot['learn_complete'] is True
        assert snapshot['watch_complete'] is False
    _with_page(scenario)


def test_video_oculto_nao_substitui_video_visivel_da_aula():
    async def scenario(page):
        await page.locator('ec-video').evaluate('''element=>{
          const hidden=document.createElement('video');hidden.id='ns-dialog-999';
          hidden.style.display='none';element.prepend(hidden);
        }''')
        snapshot=await inspect_ec_player(page)
        assert snapshot['lesson_id']=='dialog:123'
    _with_page(scenario)


def test_linha_com_check_e_cor_amarela_conta_como_evidencia_sem_concluir_etapa():
    async def scenario(page):
        await page.locator('#activity-app-container').evaluate('''container=>{
          const timeline=document.createElement('div');
          timeline.innerHTML='<div class="seek-bar" dialog-line-id="11" style="height:18px;width:150px">'
            +'<div class="bg-strong" style="height:12px;width:100%;background:rgb(219,190,91)">'
            +'<i class="fa fa-check"></i></div></div>'
            +'<div class="seek-bar" dialog-line-id="12" style="height:18px;width:150px">'
            +'<div style="height:12px;background:#aaa"></div></div>';
          container.append(timeline);
        }''')
        snapshot=await inspect_ec_player(page)
        assert snapshot['watch_tracking']['lines_total']==2
        assert snapshot['watch_tracking']['lines_done']==1
        assert snapshot['watch_tracking']['pending_line_ids']==['12']
        assert snapshot['watch_complete'] is False
    _with_page(scenario)


def test_reproducao_real_usa_botao_do_site_e_final_sem_confirmacao_fica_pendente():
    async def scenario(page):
        await _make_real_clip(page)
        before=await inspect_ec_player(page)
        assert before['video']['paused'] is True
        state=ECState(lesson=before['lesson_id'])
        mode=ModoEstudo(assistir=True,aprender=False,falar=False)
        result=await process_ec_page(page,state,submit=True,modo=mode,snapshot=before)
        assert result['tipo']=='video',result
        assert await page.evaluate('window.siteTrackingStarted') is True
        assert await page.evaluate('window.sitePlayClicks')==1
        await page.wait_for_function('document.querySelector("video").currentTime>0.15',timeout=8000)
        moving=await inspect_ec_player(page)
        assert moving['video']['position']>0
        assert moving['watch_complete'] is False
        await page.wait_for_function('document.querySelector("video").ended',timeout=8000)
        ended=await inspect_ec_player(page)
        assert ended['video']['ended'] is True
        with patch('ec_engine.advance_course',AsyncMock()) as advance:
            result=await process_ec_page(page,state,submit=True,modo=mode,snapshot=ended)
        assert result['tipo']=='aguardando',result
        assert not result.get('progresso_etapas',{}).get('assistir')
        assert not state.cursor.seen
        advance.assert_not_awaited()
    _with_page(scenario)


def test_confirmacao_sem_barra_verde_permite_avancar_apos_reproducao_real():
    async def scenario(page):
        await _make_real_clip(page)
        await page.locator('.fill').evaluate("e=>e.style.backgroundColor='rgb(100,100,100)'")
        before=await inspect_ec_player(page)
        state=ECState(lesson=before['lesson_id'])
        mode=ModoEstudo(assistir=True,aprender=False,falar=False)
        await process_ec_page(page,state,submit=True,modo=mode,snapshot=before)
        await page.wait_for_function('document.querySelector("video").ended',timeout=8000)
        await page.locator('.activity-list-watch').evaluate("e=>e.setAttribute('data-completed','true')")
        confirmed=await inspect_ec_player(page)
        assert confirmed['watch_complete'] is True
        with patch('ec_engine.advance_course',AsyncMock(return_value={'tipo':'fora_curso'})) as advance:
            result=await process_ec_page(page,state,submit=True,modo=mode,snapshot=confirmed)
        assert result['tipo']=='escopo_concluido',result
        assert result['progresso_etapas']['assistir'] is True
        assert '123' in state.cursor.seen
        advance.assert_awaited_once()
    _with_page(scenario)


def test_confirmacao_tardia_do_site_impede_clique_baseado_em_leitura_antiga():
    async def scenario(page):
        await _make_real_clip(page)
        stale=await inspect_ec_player(page)
        assert stale['video']['paused'] and not stale['watch_complete']
        # O site registra a etapa entre a leitura inicial e a decisão de clicar.
        await page.locator('.activity-list-watch').evaluate("e=>e.setAttribute('data-completed','true')")
        result=await _watch_only(page,stale,ECState(lesson=stale['lesson_id']))
        assert result['tipo']=='aguardando',result
        assert result['progresso_etapas']['assistir'] is True
        assert await page.evaluate('window.sitePlayClicks')==0
        assert await page.locator('video').evaluate('video=>video.paused') is True
    _with_page(scenario)


def test_inicio_do_site_entre_leitura_e_acao_nao_recebe_segundo_clique():
    async def scenario(page):
        await _make_real_clip(page)
        stale=await inspect_ec_player(page)
        assert stale['video']['paused']
        # Uma ação real do site inicia a reprodução depois da leitura antiga.
        await page.locator('[data-testid="player-play-pause"]').click()
        assert await page.locator('video').evaluate('video=>!video.paused') is True
        result=await _watch_only(page,stale,ECState(lesson=stale['lesson_id']))
        assert result['tipo']=='video',result
        assert not result['progresso_etapas']['assistir']
        assert await page.evaluate('window.sitePlayClicks')==1
        await page.wait_for_function('document.querySelector("video").currentTime>0.15',timeout=8000)
        assert not (await inspect_ec_player(page))['watch_complete']
    _with_page(scenario)


def test_repeticao_real_e_limitada_a_uma_tentativa_pelo_botao_oficial():
    async def scenario(page):
        await _make_real_clip(page)
        initial=await inspect_ec_player(page)
        state=ECState(lesson=initial['lesson_id'])
        mode=ModoEstudo(assistir=True,aprender=False,falar=False)
        await process_ec_page(page,state,submit=True,modo=mode,snapshot=initial)
        await page.wait_for_function('document.querySelector("video").ended',timeout=8000)
        ended=await inspect_ec_player(page)
        # Substitui só o relógio do motor; o navegador continua reproduzindo mídia real.
        with patch('ec_engine.time',SimpleNamespace(monotonic=lambda:100.0)):
            pending=await _watch_only(page,ended,state)
        assert pending['tipo']=='aguardando'
        with patch('ec_engine.time',SimpleNamespace(monotonic=lambda:113.0)):
            replay=await _watch_only(page,ended,state)
        assert replay['tipo']=='video',replay
        assert state.video_replays==1
        assert await page.evaluate('window.sitePlayClicks')==2
        await page.wait_for_function('document.querySelector("video").currentTime>0.15',timeout=8000)
        await page.wait_for_function('document.querySelector("video").ended',timeout=8000)
        ended_again=await inspect_ec_player(page)
        with patch('ec_engine.time',SimpleNamespace(monotonic=lambda:115.0)):
            assert (await _watch_only(page,ended_again,state))['tipo']=='aguardando'
        with patch('ec_engine.time',SimpleNamespace(monotonic=lambda:161.0)):
            exhausted=await _watch_only(page,ended_again,state)
        assert exhausted['tipo']=='video_atencao',exhausted
        assert not exhausted.get('progresso_etapas',{}).get('assistir')
        assert await page.evaluate('window.sitePlayClicks')==2
        assert not state.cursor.seen
    _with_page(scenario)


def test_repeticao_seleciona_primeiro_trecho_pendente_pela_interface():
    async def scenario(page):
        await _make_real_clip(page)
        await page.locator('#activity-app-container').evaluate('''container=>{
          window.segmentClicks=[];
          for(const [id,done] of [['11',true],['12',false]]){
            const segment=document.createElement('button');segment.className='seek-bar';
            segment.setAttribute('dialog-line-id',id);segment.textContent='Trecho '+id;
            if(done)segment.innerHTML+='<span class="bg-strong"><i class="fa fa-check"></i></span>';
            segment.onclick=async()=>{
              window.segmentClicks.push(id);
              const video=document.querySelector('video');
              video.currentTime=id==='12'?0.5:0;
              await video.play();
            };
            container.append(segment);
          }
        }''')
        initial=await inspect_ec_player(page)
        state=ECState(lesson=initial['lesson_id'])
        await process_ec_page(page,state,submit=True,
                              modo=ModoEstudo(assistir=True,aprender=False,falar=False),snapshot=initial)
        await page.wait_for_function('document.querySelector("video").ended',timeout=8000)
        ended=await inspect_ec_player(page)
        assert ended['watch_tracking']['pending_line_ids']==['12']
        state.video_ended_since=100.0
        with patch('ec_engine.time',SimpleNamespace(monotonic=lambda:113.0)):
            replay=await _watch_only(page,ended,state)
        assert replay['tipo']=='video',replay
        assert await page.evaluate('window.segmentClicks')==['12']
        # O handler de seleção já iniciou a mídia: apertar Play outra vez poderia pausá-la.
        assert await page.evaluate('window.sitePlayClicks')==1
        await page.wait_for_function('document.querySelector("video").currentTime>0.6',timeout=8000)
        assert not (await inspect_ec_player(page))['watch_complete']
        assert state.video_replays==1
    _with_page(scenario)


@pytest.mark.parametrize('video', [
    None,
    {'paused':False,'ended':False,'position':0,'duration':20},
])
def test_midia_ausente_ou_inicio_travado_nao_aguarda_indefinidamente(video):
    async def run():
        state=ECState(lesson='dialog:123',video_position_at=1)
        snapshot={'supported':True,'lesson_id':'dialog:123','mode':'watch','frame':0,
                  'player_index':0,'watch_complete':False,'video':video}
        with patch('ec_engine.time.monotonic',return_value=1):
            await _watch_only(object(),snapshot,state)
        with patch('ec_engine.time.monotonic',return_value=200):
            result=await _watch_only(object(),snapshot,state)
        assert result['tipo']=='video_atencao',result
        assert not result.get('progresso_etapas',{}).get('assistir')
    asyncio.run(run())


def test_erro_de_decodificacao_nao_e_reportado_como_video_reproduzindo():
    async def run():
        state=ECState(lesson='dialog:123',video_position_at=1)
        snapshot={'supported':True,'lesson_id':'dialog:123','mode':'watch','frame':0,
                  'player_index':0,'watch_complete':False,
                  'video':{'paused':True,'ended':False,'position':0,'duration':None,
                           'error':{'code':3,'message':'Local test decode failed'}}}
        result=await _watch_only(object(),snapshot,state)
        assert result['tipo']=='video_atencao',result
        assert not result.get('progresso_etapas',{}).get('assistir')
    asyncio.run(run())
